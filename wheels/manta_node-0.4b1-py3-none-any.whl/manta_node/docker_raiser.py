from datetime import datetime
from typing import Optional

from aiodocker import Docker
from aiodocker.docker import DockerContainer

from docker import DockerClient

from .common.errors import MantaDockerError
from .common.traces import Tracer


class DockerRaiser:
    async_client: Docker
    tracer: Tracer
    docker_client: DockerClient

    async def run_or_raise(self, config: dict) -> DockerContainer:
        """
        Start, pull or run a container

        Parameters
        ----------
        config : dict
            Configuration

        Returns
        -------
        DockerContainer
            Container

        Raises
        ------
        MantaDockerError
            Cannot run container
        """
        container = None
        try:
            container = await self.async_client.containers.run(config)
        except Exception as exc:
            self.tracer.error("Task cannot be started")
            raise MantaDockerError(
                "Task cannot be started", metadata=self.tracer.metadata
            ) from exc
        return container

    async def list_containers_or_raise(self, all_containers: bool = True) -> list:
        """
        List all containers in the docker engine

        Parameters
        ----------
        all_containers : bool, optional
            Show all containers; only running containers are shown by default

        Returns
        -------
        list
            List of containers

        Raises
        ------
        MantaDockerError
            Cannot list containers
        """
        containers = []
        try:
            containers = await self.async_client.containers.list(all=all_containers)
        except Exception as exc:
            self.tracer.error("Unable to list containers")
            raise MantaDockerError(
                "Unable to list containers", metadata=self.tracer.metadata
            ) from exc
        return containers

    def list_images_or_raise(self) -> list:
        """
        List all images in the docker engine

        Returns
        -------
        list
            List of images

        Raises
        ------
        MantaDockerError
            Cannot list images
        """
        images = []
        try:
            images = [
                tag for image in self.docker_client.images.list() for tag in image.tags
            ]
        except Exception as exc:
            self.tracer.error("Unable to list images")
            raise MantaDockerError(
                "Unable to list images", metadata=self.tracer.metadata
            ) from exc
        return images

    async def restart_or_raise(self, container: DockerContainer):
        """
        Restart container

        Parameters
        ----------
        container : DockerContainer
            Container

        Raises
        ------
        MantaDockerError
            Cannot restart container
        """
        try:
            await container.restart()
        except Exception as exc:
            self.tracer.error("Container cannot be restarted")
            raise MantaDockerError(
                "Container cannot be restart", metadata=self.tracer.metadata
            ) from exc

    async def stop_or_raise(self, container: DockerContainer):
        """
        Stop container

        Parameters
        ----------
        container : DockerContainer
            Container

        Raises
        ------
        MantaDockerError
            Cannot stop container
        """
        try:
            await container.stop()
        except Exception as exc:
            self.tracer.error("Container cannot be stopped")
            raise MantaDockerError(
                "Container cannot be stopped", metadata=self.tracer.metadata
            ) from exc

    async def remove_or_raise(self, container: DockerContainer):
        """
        Remove container

        Parameters
        ----------
        container : DockerContainer
            Container

        Raises
        ------
        MantaDockerError
            Cannot remove container
        """
        try:
            await container.delete()
        except Exception as exc:
            self.tracer.error("Container cannot be removed")
            raise MantaDockerError(
                "Container cannot be removed", metadata=self.tracer.metadata
            ) from exc

    async def get_status_or_raise(self, container: DockerContainer):
        """
        Reload container

        Parameters
        ----------
        container : DockerContainer
            Container

        Raises
        ------
        MantaDockerError
            Cannot reload container
        """
        status = "unknown"
        try:
            status = await container.show()
            status = status["State"]["Status"]
        except Exception as exc:
            self.tracer.error("Cannot get status of container")
            raise MantaDockerError(
                "Cannot get status of container", metadata=self.tracer.metadata
            ) from exc
        return status

    def get_container_logs_or_raise(
        self, container: DockerContainer, since: Optional[datetime] = None
    ) -> bytes:
        """
        Get container logs

        Parameters
        ----------
        container : DockerContainer
            Container
        since: Optional[datetime]
            Start time

        Returns
        -------
        bytes
            Logs

        Raises
        ------
        MantaDockerError
            Cannot get logs
        """
        logs = b""
        try:
            logs = self.docker_client.containers.get(container.id).logs(since=since)
        except Exception as exc:
            self.tracer.error("Cannot get logs of container")
            raise MantaDockerError(
                "Cannot get logs of container", metadata=self.tracer.metadata
            ) from exc
        return logs
