from __future__ import annotations

import ssl
from functools import lru_cache
from logging import getLogger
from pathlib import Path
from typing import (
    AsyncIterable,
    AsyncIterator,
    Iterable,
    Optional,
    Type,
    TypeVar,
    Union,
)

from .common.base_client import GrpcClientBase
from .common.build import (
    ChunkResultValues,
    DatasetOverviews,
    Empty,
    GlobalTag,
    GlobalUpdate,
    GlobalValue,
    Logs,
    NodeOverview,
    NodeStatus,
    NodeStub,
    Ok,
    Registration,
    Result,
    ResultQuery,
    SetSystemSummaryRequest,
    TaskScheduling,
    TaskUpdate,
)
from .common.conversions import ID
from .common.errors import MantaError
from .common.retry import RetryPolicy, StreamingRetryPolicy
from .common.traces import Tracer

__all__ = ["NodeClient"]

T = TypeVar("T")


class NodeClient(GrpcClientBase):
    """
    Node client facilitates management of requests to Manager with retry
    and connection management capabilities.
    """

    #: Default retry policy for regular methods
    DEFAULT_RETRY_POLICY = RetryPolicy(
        max_retries=3,
        initial_delay=0.2,
        max_delay=10.0,
        backoff_factor=2.0,
        jitter_factor=0.2,
    )

    #: Default retry policy for streaming methods
    DEFAULT_STREAMING_RETRY_POLICY = StreamingRetryPolicy(
        max_retries=3,
        initial_delay=0.2,
        max_delay=10.0,
        backoff_factor=2.0,
        jitter_factor=0.2,
        retry_if_no_items_processed=True,
    )

    def _get_stub_class(self) -> Type[NodeStub]:
        """
        Get the stub class for this client.
        """
        return NodeStub

    def __init__(
        self,
        node_id: ID,
        manager_host: str,
        manager_port: int,
        secured_token: str,
        ssl_cert_folder: Optional[Path] = None,
        retry_policy: Optional[RetryPolicy] = None,
        streaming_retry_policy: Optional[StreamingRetryPolicy] = None,
    ) -> None:
        """
        Initialize Node client

        Parameters
        ----------
        node_id : ID
            Node identifier
        manager_host : str
            Manager hostname
        manager_port : int
            Manager port
        secured_token : str
            Secured token for the Manager first connection
        ssl_cert_folder : Optional[Path]
            SSL certificate folder
        retry_policy : Optional[RetryPolicy]
            Custom retry policy for operations
        streaming_retry_policy : Optional[StreamingRetryPolicy]
            Custom retry policy for streaming operations
        """
        self.ssl_cert_folder = ssl_cert_folder
        self.tracer = Tracer(getLogger(__name__), node_id.oid)

        super().__init__(
            host=manager_host,
            port=manager_port,
            metadata={"authorization": secured_token},
            secure=ssl_cert_folder is not None or manager_port == 443,
            tracer=self.tracer,
            retry_policy=retry_policy,
            streaming_retry_policy=streaming_retry_policy,
        )

    # @property
    # @lru_cache(maxsize=1)
    # def ssl_context(self) -> Optional[ssl.SSLContext]:
    #     """
    #     Create a new SSL context with the given certificate authority
    #     and load the certificate and key from the given files.

    #     Returns
    #     -------
    #     Optional[ssl.SSLContext]
    #         Return an SSL context to be used for secure communication
    #         with the Manager.
    #     """
    #     if self.ssl_cert_folder is None:
    #         return None
    #     ssl_context = ssl.create_default_context(
    #         ssl.Purpose.SERVER_AUTH,
    #         cafile=self.ssl_cert_folder / "ca.crt",
    #     )
    #     ssl_context.load_cert_chain(
    #         certfile=self.ssl_cert_folder / "node.crt",
    #         keyfile=self.ssl_cert_folder / "node.key",
    #     )
    #     return ssl_context

    async def is_available(self, request: Empty) -> Ok:
        """
        Check if the Manager is available

        Parameters
        ----------
        request : Empty
            Empty request

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("is_available", request)

    async def register_node(self, request: NodeOverview) -> Registration:
        """
        Register the node with the Manager via gRPC
        and get back MQTT information

        Parameters
        ----------
        request : NodeOverview
            Node ID and its data names

        Returns
        -------
        Registration
            Node ID and MQTT information
        """
        return await self.call_service_method("register_node", request)

    async def get_task_result(
        self, request: ResultQuery
    ) -> AsyncIterator[ChunkResultValues]:
        """
        Get the swarm results

        Parameters
        ----------
        request : ResultQuery
            Result query

        Returns
        -------
        AsyncIterator[ChunkResultValues]
            Result values
        """
        async for chunk in self.stream_service_method("get_task_result", request):
            yield chunk

    async def add_task_result(self, request: AsyncIterable[Result]) -> Ok:
        """
        Set a swarm result

        Parameters
        ----------
        request : AsyncIterable[Result]
            Task ID, global tag and value

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("add_task_result", request)

    async def get_global(self, request: GlobalTag) -> AsyncIterator[GlobalValue]:
        """
        Get global values

        Parameters
        ----------
        request : GlobalTag
            Swarm ID and global tag

        Returns
        -------
        AsyncIterator[GlobalValue]
            Global values
        """
        async for value in self.stream_service_method("get_global", request):
            yield value

    async def set_global(
        self,
        request: Union[AsyncIterable[GlobalUpdate], Iterable[GlobalUpdate]],
    ) -> Ok:
        """
        Set global values

        Parameters
        ----------
        request : Union[AsyncIterable[GlobalUpdate], Iterable[GlobalUpdate]]
            Task ID, global tag and value

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("set_global", request)

    async def set_node_status(self, request: NodeStatus) -> Ok:
        """
        Set node status

        Parameters
        ----------
        request : NodeStatus
            Node ID, its status

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("set_node_status", request)

    async def set_system_summary(self, request: SetSystemSummaryRequest) -> Ok:
        """
        Set system summary

        Parameters
        ----------
        request : SetSystemSummaryRequest
            Node ID and its system information

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("set_system_summary", request)

    async def set_overviews(self, request: DatasetOverviews) -> Ok:
        """
        Set dataset overviews

        Parameters
        ----------
        request : DatasetOverviews
            Node ID and its dataset overviews

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("set_overviews", request)

    async def stop_swarm(self, request: TaskUpdate) -> Ok:
        """
        Stop the swarm

        Parameters
        ----------
        request : TaskUpdate
            Swarm ID

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("stop_swarm", request)

    async def add_task_logs(self, request: AsyncIterable[Logs]) -> Ok:
        """
        Add task logs to the database

        Parameters
        ----------
        request : AsyncIterable[Logs]
            Task logs

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("add_task_logs", request)

    async def schedule_task(self, request: TaskScheduling) -> Ok:
        """
        Schedule next task

        Parameters
        ----------
        request : TaskScheduling
            Task scheduling containing node IDs

        Returns
        -------
        Ok
            Response
        """
        return await self.call_service_method("schedule_task", request)

    async def send_error(self, manta_error: MantaError):
        """
        Send the error to the Manager

        Parameters
        ----------
        error : MantaError
            Error object
        """
        try:
            self.tracer.debug("Sending MantaError to the Manager")
            await self.call_service_method("send_error", manta_error.to_err())
        except Exception as exc:
            self.tracer.exception(f"Cannot send error to the Manager: {repr(exc)}")
