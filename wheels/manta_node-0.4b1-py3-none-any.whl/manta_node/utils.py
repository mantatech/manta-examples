from pathlib import Path
from typing import List

from .common.build import Overview

__all__ = ["collect_dataset_overviews"]

DTYPES = {
    ".txt": "text",
    ".csv": "csv",
    ".npx": "numpy",
    ".npy": "numpy",
    ".npz": "numpy",
    ".np": "numpy",
}


def collect_dataset_overviews(data_folder: Path) -> List[Overview]:
    """
    Collect dataset overviews including :

    - name of a dataset
    - its description
    - its dtype (numpy, pytorch ...)

    Parameters
    ----------
    data_folder: Path
        Data folder

    Returns
    -------
    List[Overview]
        List of dataset overviews
    """
    overviews = []
    # Check if the file exists in the data_folder
    if not data_folder.exists():
        # Create the data folder
        data_folder.mkdir(exist_ok=True)
        return overviews

    # Get the list of files in the data_folder
    overviews = [
        Overview(
            name=file.name,
            description="No description available",
            dtype=DTYPES.get(file.suffix, "binary") if file.is_file() else "folder",
        )
        for file in data_folder.iterdir()
    ]
    return overviews
