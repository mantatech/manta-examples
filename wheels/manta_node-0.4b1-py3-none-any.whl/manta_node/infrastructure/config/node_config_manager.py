"""Node Configuration Manager for manta-node.

This module provides a comprehensive configuration management system for manta-node,
using TOML files for persistent storage and dataclasses for type-safe configuration.
"""

import os
import threading

try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # Python < 3.11 fallback

from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

import toml  # For writing TOML files
from manta_node.common.errors import MantaConfigurationError

__all__ = ["NodeConfigManager", "NodeConfiguration"]


# Configuration Section Dataclasses


@dataclass
class IdentityConfig:
    """Node identity configuration."""

    secured_token: str  # Required field - must be provided
    alias: Optional[str] = None
    random_id: bool = False


@dataclass
class NetworkConfig:
    """Network configuration for node connections."""

    manager_host: str = "localhost"
    manager_port: int = 50051
    light_service_host: str = "0.0.0.0"
    light_service_port: Optional[int] = None  # Auto-assigned if not specified


@dataclass
class MQTTConfig:
    """MQTT broker configuration."""

    ping_interval: int = 1
    reconnect_attempts: int = 5
    reconnect_delay: float = 5.0
    # Runtime populated from manager registration
    broker_host: Optional[str] = None
    broker_port: Optional[int] = None
    topics: List[str] = field(default_factory=list)


@dataclass
class ContainerConfig:
    """Container/Docker configuration."""

    gpu_enabled: Optional[bool] = None  # Auto-detect if None
    default_memory_limit: str = "4G"
    default_cpu_limit: str = "2.0"
    docker_network: str = "host"
    runtime: str = "docker"  # docker or podman
    pull_timeout: int = 300
    log_config: Dict[str, Any] = field(
        default_factory=lambda: {
            "type": "json-file",
            "config": {"max-size": "10m", "max-file": "3"},
        }
    )


@dataclass
class DatasetConfig:
    """Dataset management configuration."""

    base_path: str = "/data/datasets"
    mount_readonly: bool = True
    mappings: Dict[str, str] = field(default_factory=dict)  # name -> path
    cache_metadata: bool = True


@dataclass
class TaskConfig:
    """Task execution configuration."""

    max_concurrent: int = 2
    task_timeout: int = 3600  # seconds
    retry_attempts: int = 3
    temp_folder: Optional[str] = None
    cleanup_on_failure: bool = True
    stream_logs: bool = True


@dataclass
class ResourceConfig:
    """Resource management configuration."""

    reserve_cpu_percent: int = 10
    reserve_memory_mb: int = 512
    max_disk_usage_percent: int = 90
    monitor_interval: int = 30  # seconds


@dataclass
class LoggingConfig:
    """Logging configuration."""

    level: str = "INFO"
    filename: str = "manta_node.log"
    log_to_file: bool = True
    log_to_console: bool = False
    debug_mode: bool = True
    max_file_size: str = "100M"
    backup_count: int = 5


@dataclass
class SecurityConfig:
    """Security configuration."""

    use_tls: bool = False
    cert_folder: str = "~/.manta/certs"
    verify_ssl: bool = True
    token_refresh_interval: int = 3600  # seconds


@dataclass
class MetadataConfig:
    """Configuration metadata."""

    name: str = "default"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    version: str = "1.0.0"
    description: str = ""


@dataclass
class NodeConfiguration:
    """Complete node configuration."""

    identity: IdentityConfig  # Required field - must have secured_token
    metadata: MetadataConfig = field(default_factory=MetadataConfig)
    network: NetworkConfig = field(default_factory=NetworkConfig)
    mqtt: MQTTConfig = field(default_factory=MQTTConfig)
    containers: ContainerConfig = field(default_factory=ContainerConfig)
    datasets: DatasetConfig = field(default_factory=DatasetConfig)
    tasks: TaskConfig = field(default_factory=TaskConfig)
    resources: ResourceConfig = field(default_factory=ResourceConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)

    def __post_init__(self):
        """Post-initialization to set automatic values."""
        # Only set log filename if it's still the default value "manta_node.log"
        # This means it wasn't explicitly set in the configuration
        if self.logging.filename == "manta_node.log":
            # Use alias if available, otherwise use metadata name if not default, else "node"
            if self.identity.alias:
                node_name = self.identity.alias
            elif self.metadata.name and self.metadata.name != "default":
                node_name = self.metadata.name
            else:
                node_name = "node"

            # Clean the name to be filesystem-safe
            safe_name = "".join(
                c if c.isalnum() or c in "-_" else "_" for c in node_name
            )
            # Set to centralized logs directory with nodes subfolder
            self.logging.filename = str(
                Path.home() / ".manta" / "logs" / "nodes" / f"{safe_name}.log"
            )

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "NodeConfiguration":
        """Create configuration from dictionary."""
        # For identity, we need to ensure secured_token is present
        identity_data = data.get("identity", {})
        if "secured_token" not in identity_data:
            raise ValueError("secured_token is required in identity configuration")

        # Create identity config (required)
        identity = IdentityConfig(**identity_data)

        # Create configuration with required identity
        config = cls(identity=identity)

        # Update each section if present
        if "metadata" in data:
            config.metadata = MetadataConfig(**data["metadata"])
        if "network" in data:
            config.network = NetworkConfig(**data["network"])
        if "mqtt" in data:
            config.mqtt = MQTTConfig(**data["mqtt"])
        if "containers" in data:
            config.containers = ContainerConfig(**data["containers"])
        if "datasets" in data:
            # Handle nested mappings
            datasets_data = data["datasets"].copy()
            if "mappings" not in datasets_data:
                datasets_data["mappings"] = {}
            config.datasets = DatasetConfig(**datasets_data)
        if "tasks" in data:
            config.tasks = TaskConfig(**data["tasks"])
        if "resources" in data:
            config.resources = ResourceConfig(**data["resources"])
        if "logging" in data:
            config.logging = LoggingConfig(**data["logging"])
        if "security" in data:
            config.security = SecurityConfig(**data["security"])

        return config


class NodeConfigManager:
    """Configuration manager for manta-node.

    Manages loading, saving, and runtime updates of node configuration.
    Configuration is stored in TOML format in ~/.manta/nodes/ directory.
    """

    # Runtime update categories
    SAFE_RUNTIME_UPDATES = [
        "logging",  # Can change log levels
        "datasets.mappings",  # Can add/remove datasets
        "tasks.max_concurrent",  # Can adjust concurrency
        "resources",  # Can adjust resource limits
    ]

    REQUIRES_RESTART = [
        "identity",  # Node ID is immutable
        "network",  # Port changes need restart
        "mqtt.broker_host",  # MQTT connection needs restart
        "mqtt.broker_port",
        "security",  # Certificate changes need reconnect
        "containers.runtime",  # Runtime change needs restart
    ]

    def __init__(self, config_path: Optional[Union[str, Path]] = None):
        """Initialize configuration manager.

        Args:
            config_path: Path to configuration file or None for default
        """
        self._lock = threading.RLock()
        self._observers: List[Callable] = []
        self._config = NodeConfiguration(IdentityConfig(secured_token="<REQUIRED>"))
        self._instances: List[Any] = []  # Track running instances

        # Determine config path
        if config_path:
            self._config_path = Path(config_path)
        else:
            self._config_path = self._get_default_config_path()

        # Ensure config directory exists
        self._ensure_config_dir()

        # Load configuration if file exists, otherwise create default template
        if self._config_path.exists():
            self.load()
        else:
            # Create a default template configuration
            self._create_default_config()

    @property
    def config(self) -> NodeConfiguration:
        """Get current configuration."""
        with self._lock:
            return self._config

    @property
    def current_config(self) -> NodeConfiguration:
        """Get current configuration (alias for config property)."""
        return self.config

    @current_config.setter
    def current_config(self, config_dict: Union[Dict[str, Any], NodeConfiguration]):
        """Set current configuration from dictionary or NodeConfiguration.

        Args:
            config_dict: Configuration as dict or NodeConfiguration instance
        """
        with self._lock:
            if isinstance(config_dict, NodeConfiguration):
                self._config = config_dict
            elif isinstance(config_dict, dict):
                # Handle legacy format with 'manager' key
                if "manager" in config_dict:
                    manager_config = config_dict["manager"]
                    if "host" in manager_config:
                        self._config.network.manager_host = manager_config["host"]
                    if "port" in manager_config:
                        self._config.network.manager_port = manager_config["port"]
                    if "token" in manager_config:
                        self._config.identity.secured_token = manager_config["token"]
                else:
                    # Handle the standard configuration format
                    self._config = NodeConfiguration.from_dict(config_dict)

    @property
    def config_path(self) -> Path:
        """Get configuration file path."""
        return self._config_path

    def _get_default_config_path(self) -> Path:
        """Get default configuration path."""
        config_dir = Path.home() / ".manta" / "nodes"
        return config_dir / "default.toml"

    def _ensure_config_dir(self):
        """Ensure configuration directory exists."""
        config_dir = self._config_path.parent
        config_dir.mkdir(parents=True, exist_ok=True)

    def _create_default_config(self):
        """Create a default configuration template file."""
        # Create a template configuration with placeholder token
        template_config = NodeConfiguration(
            identity=IdentityConfig(secured_token="<YOUR_JWT_TOKEN_HERE>")
        )

        # Set some helpful defaults
        template_config.metadata.name = "default"
        template_config.metadata.description = (
            "Default node configuration template - Please set your secured_token"
        )

        # Save the template to disk
        self._config = template_config
        self.save()

        # Print helpful message to inform user
        print(f"📝 Created default configuration template at: {self._config_path}")
        print("")
        print("⚠️  IMPORTANT: Please set your secured_token before starting the node!")
        print("")
        print("Next steps:")
        print("  1. Get your JWT token from the manta manager")
        print(f"  2. Edit the config file: {self._config_path}")
        print("  3. Replace '<YOUR_JWT_TOKEN_HERE>' with your actual token")
        print("  4. Or run interactive setup: manta_node config init")
        print("")

    def _expand_env_vars(self, value: Any) -> Any:
        """Expand environment variables in configuration values.

        Supports ${VAR_NAME} and ${VAR_NAME:default} syntax.
        """
        if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
            var_expr = value[2:-1]
            if ":" in var_expr:
                var_name, default = var_expr.split(":", 1)
            else:
                var_name = var_expr
                default = None

            result = os.environ.get(var_name, default)
            if result is None:
                raise MantaConfigurationError(
                    f"Environment variable {var_name} not found and no default provided"
                )
            return result
        elif isinstance(value, dict):
            return {k: self._expand_env_vars(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self._expand_env_vars(item) for item in value]
        return value

    def _expand_paths(self, value: Any) -> Any:
        """Expand tilde (~) and environment variables in path strings.

        This method recursively processes configuration values and expands:
        - Tilde (~) to home directory
        - Environment variables in ${VAR} format

        Args:
            value: Configuration value to process (can be string, dict, list, etc.)

        Returns:
            Processed value with expanded paths
        """
        if isinstance(value, str):
            # First expand environment variables if present
            if value.startswith("${") and value.endswith("}"):
                value = self._expand_env_vars(value)
            # Then expand tilde to home directory
            if value.startswith("~"):
                return str(Path(value).expanduser())
            return value
        elif isinstance(value, dict):
            return {k: self._expand_paths(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self._expand_paths(item) for item in value]
        return value

    def load(self, config_path: Optional[Union[str, Path]] = None) -> NodeConfiguration:
        """Load configuration from TOML file.

        Args:
            config_path: Optional path to load from (uses default if None)

        Returns:
            Loaded configuration

        Raises:
            MantaConfigurationError: If configuration is invalid
        """
        path = Path(config_path) if config_path else self._config_path

        if not path.exists():
            raise MantaConfigurationError(f"Configuration file not found: {path}")

        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)

            # Expand environment variables
            data = self._expand_env_vars(data)

            # Expand paths (tilde to home directory)
            data = self._expand_paths(data)

            # Create configuration from data
            with self._lock:
                self._config = NodeConfiguration.from_dict(data)
                if config_path:
                    self._config_path = path

            # Notify observers
            self._notify_observers({"action": "load", "path": str(path)})

            return self._config

        except Exception as e:
            raise MantaConfigurationError(f"Failed to load configuration: {e}")

    def save(self, config_path: Optional[Union[str, Path]] = None) -> bool:
        """Save configuration to TOML file.

        Args:
            config_path: Optional path to save to (uses default if None)

        Returns:
            True if successful

        Raises:
            MantaConfigurationError: If save fails
        """
        path = Path(config_path) if config_path else self._config_path

        # Ensure directory exists
        path.parent.mkdir(parents=True, exist_ok=True)

        try:
            with self._lock:
                data = self._config.to_dict()

            # Write TOML file
            with open(path, "w") as f:
                toml.dump(data, f)

            # Update config path if different
            if config_path:
                self._config_path = path

            # Notify observers
            self._notify_observers({"action": "save", "path": str(path)})

            return True

        except Exception as e:
            raise MantaConfigurationError(f"Failed to save configuration: {e}")

    def update(
        self, updates: Dict[str, Any], allow_restart_required: bool = False
    ) -> bool:
        """Update configuration with validation.

        Args:
            updates: Dictionary of updates (can be nested)
            allow_restart_required: Allow updates that require restart

        Returns:
            True if update successful

        Raises:
            MantaConfigurationError: If update is invalid or requires restart
        """
        # Check if updates require restart
        if not allow_restart_required:
            for key in updates:
                if any(
                    key.startswith(restricted) for restricted in self.REQUIRES_RESTART
                ):
                    raise MantaConfigurationError(
                        f"Update to '{key}' requires node restart. "
                        "Set allow_restart_required=True to proceed."
                    )

        try:
            with self._lock:
                # Apply updates to configuration
                for key, value in updates.items():
                    self._apply_update(key, value)

            # Save updated configuration
            self.save()

            # Notify observers
            self._notify_observers({"action": "update", "updates": updates})

            return True

        except Exception as e:
            raise MantaConfigurationError(f"Failed to update configuration: {e}")

    def _apply_update(self, key: str, value: Any):
        """Apply a single update to configuration.

        Args:
            key: Dot-separated path to configuration field
            value: New value to set
        """
        parts = key.split(".")
        target = self._config

        # Navigate to the target field
        for part in parts[:-1]:
            target = getattr(target, part)

        # Set the value
        setattr(target, parts[-1], value)

    def validate(self) -> List[str]:
        """Validate configuration.

        Returns:
            List of validation issues (empty if valid)
        """
        issues = []

        # Check required fields
        if (
            not self._config.identity.secured_token
            or self._config.identity.secured_token.startswith("<")
        ):
            issues.append(
                "identity.secured_token is required (cannot be empty or placeholder)"
            )
            issues.append("  → Set your JWT token in the configuration file")
            issues.append("  → Or run: manta_node config init")

        # Validate network ports
        if not (443 <= self._config.network.manager_port <= 65535):
            issues.append(
                f"network.manager_port ({self._config.network.manager_port}) must be between 443 and 65535"
            )
        if self._config.network.light_service_port is not None:
            if not (1024 <= self._config.network.light_service_port <= 65535):
                issues.append(
                    f"network.light_service_port ({self._config.network.light_service_port}) must be between 1024 and 65535"
                )

        # Validate dataset paths
        for name, path in self._config.datasets.mappings.items():
            dataset_path = Path(path).expanduser()
            if not dataset_path.exists():
                issues.append(f"Dataset path does not exist: {name} -> {path}")

        # Validate resource limits
        if self._config.resources.reserve_cpu_percent > 50:
            issues.append("resources.reserve_cpu_percent should not exceed 50%")

        return issues

    def register_observer(self, callback: Callable[[Dict[str, Any]], None]):
        """Register observer for configuration changes.

        Args:
            callback: Function to call on configuration changes
        """
        self._observers.append(callback)

    def _notify_observers(self, change: Dict[str, Any]):
        """Notify all observers of configuration change.

        Args:
            change: Dictionary describing the change
        """
        for observer in self._observers:
            try:
                observer(change)
            except Exception:
                pass  # Ignore observer errors

    def list_available_configs(self) -> List[str]:
        """List available configuration files.

        Returns:
            List of configuration names
        """
        config_dir = Path.home() / ".manta" / "nodes"
        if not config_dir.exists():
            return []

        configs = []
        for path in config_dir.glob("*.toml"):
            configs.append(path.stem)

        return sorted(configs)

    def get_node_config(self, config_name: str) -> Optional[NodeConfiguration]:
        """Load and return a specific node configuration by name.

        Args:
            config_name: Name of the configuration to load

        Returns:
            NodeConfiguration if found and valid, None otherwise
        """
        # Construct config path
        config_dir = Path.home() / ".manta" / "nodes"
        config_path = config_dir / f"{config_name}.toml"

        # Check if config exists
        if not config_path.exists():
            return None

        # Load the configuration
        try:
            temp_manager = NodeConfigManager(config_path)
            return temp_manager.config
        except Exception:
            return None

    def export_template(self, path: Optional[Union[str, Path]] = None) -> str:
        """Export a configuration template.

        Args:
            path: Optional path to save template

        Returns:
            Template content as string
        """
        template = NodeConfiguration(IdentityConfig("token"))
        template.metadata.name = "template"
        template.metadata.description = "Template configuration for manta-node"

        content = toml.dumps(template.to_dict())

        if path:
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w") as f:
                f.write(content)

        return content

    def set_manager_config(self, host: str, port: int, token: str) -> bool:
        """Set manager configuration (host, port, token).

        Args:
            host: Manager hostname
            port: Manager port
            token: JWT token

        Returns:
            True if configuration was set successfully
        """
        try:
            with self._lock:
                self._config.network.manager_host = host
                self._config.network.manager_port = port
                self._config.identity.secured_token = token

            # Notify observers
            self._notify_observers(
                {
                    "action": "update",
                    "updates": {
                        "network.manager_host": host,
                        "network.manager_port": port,
                        "identity.secured_token": token,
                    },
                }
            )

            return True

        except Exception as e:
            raise MantaConfigurationError(f"Failed to set manager configuration: {e}")

    def get_manager_config(self) -> Dict[str, Any]:
        """Get manager configuration as dictionary.

        Returns:
            Dictionary with manager configuration
        """
        with self._lock:
            return {
                "host": self._config.network.manager_host,
                "port": self._config.network.manager_port,
                "token": self._config.identity.secured_token,
            }

    def reset_to_defaults(self) -> bool:
        """Reset configuration to default values.

        Returns:
            True if reset was successful
        """
        try:
            with self._lock:
                self._config = NodeConfiguration(IdentityConfig("token"))

            # Notify observers
            self._notify_observers({"action": "reset"})

            return True

        except Exception as e:
            raise MantaConfigurationError(f"Failed to reset configuration: {e}")

    def is_using_config_file(self) -> bool:
        """Check if a configuration file exists and is being used.

        Returns:
            True if configuration file exists and is loaded
        """
        return self._config_path.exists()

    def save_node_config(self, config) -> bool:
        """Save a node configuration (compatibility method).

        Args:
            config: NodeConfig (old format) or NodeConfiguration object

        Returns:
            bool: True if saved successfully, False otherwise
        """
        try:
            # Handle old NodeConfig format by converting to NodeConfiguration
            if hasattr(config, "to_node_configuration"):
                node_config = config.to_node_configuration()
            else:
                node_config = config

            # Set as current config and save
            with self._lock:
                self._config = node_config

            return self.save()
        except Exception:
            return False

    def create_node_config_from_template(self, config_name: str, template: str):
        """Create node configuration from template (compatibility method).

        Args:
            config_name: Name of the configuration
            template: Template type ('basic', 'gpu', 'cpu')

        Returns:
            NodeConfig (old format) for compatibility
        """
        # Define minimal local classes for backward compatibility
        from dataclasses import dataclass

        @dataclass
        class ConnectionConfig:
            host: str
            port: int
            use_tls: bool

        @dataclass
        class HardwareConfig:
            gpu_enabled: Optional[bool]
            max_concurrent_tasks: int
            cpu_limit: str
            memory_limit: str

        @dataclass
        class NodeConfig:
            name: str
            alias: str
            connection: ConnectionConfig
            hardware: HardwareConfig
            datasets: Optional[Any]
            auto_register: bool
            random_id: bool

        # Template configurations
        templates = {
            "basic": {
                "gpu_enabled": None,  # Auto-detect
                "max_concurrent_tasks": 2,
                "cpu_limit": "2.0",
                "memory_limit": "4G",
            },
            "gpu": {
                "gpu_enabled": True,
                "max_concurrent_tasks": 2,
                "cpu_limit": "4.0",
                "memory_limit": "8G",
            },
            "cpu": {
                "gpu_enabled": False,
                "max_concurrent_tasks": 4,
                "cpu_limit": "4.0",
                "memory_limit": "4G",
            },
        }

        template_config = templates.get(template, templates["basic"])

        # Create hardware config
        hardware = HardwareConfig(
            gpu_enabled=template_config["gpu_enabled"],
            max_concurrent_tasks=template_config["max_concurrent_tasks"],
            cpu_limit=template_config["cpu_limit"],
            memory_limit=template_config["memory_limit"],
        )

        # Create connection config with defaults
        connection = ConnectionConfig(host="localhost", port=50051, use_tls=False)

        # Create NodeConfig with template settings
        return NodeConfig(
            name=config_name,
            alias=config_name,  # Default alias same as name
            connection=connection,
            hardware=hardware,
            datasets=None,
            auto_register=True,
            random_id=False,
        )

    def list_running_instances(self) -> List[Any]:
        """List all running node instances.

        Returns:
            List of running node instances
        """
        return self._instances.copy()

    def save_instance(self, instance: Any) -> None:
        """Save a running node instance.

        Args:
            instance: The node instance to save
        """
        self._instances.append(instance)

    def remove_instance(self, instance_id: str) -> bool:
        """Remove a running node instance.

        Args:
            instance_id: The ID of the instance to remove

        Returns:
            True if instance was removed, False otherwise
        """
        for i, inst in enumerate(self._instances):
            if hasattr(inst, "instance_id") and inst.instance_id == instance_id:
                del self._instances[i]
                return True
        return False

    def list_node_configs(self) -> List[Any]:
        """List all available node configurations.

        Returns:
            List of node configurations with their metadata
        """
        configs = []
        config_dir = Path.home() / ".manta" / "nodes"

        if not config_dir.exists():
            return configs

        # Iterate through all .toml files
        for config_file in config_dir.glob("*.toml"):
            try:
                # Try to load and parse each config
                temp_manager = NodeConfigManager(config_file)
                if temp_manager.config:
                    # Create a simple config object with name and metadata
                    config_info = type(
                        "NodeConfigInfo",
                        (),
                        {
                            "name": config_file.stem,
                            "path": str(config_file),
                            "metadata": temp_manager.config.metadata,
                            "identity": temp_manager.config.identity,
                            "network": temp_manager.config.network,
                        },
                    )()
                    configs.append(config_info)
            except Exception:
                # Skip invalid configs
                continue

        return configs
