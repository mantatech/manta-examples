"""Manta Node entry point.

This module provides both CLI and direct node execution capabilities.
It intelligently handles both standalone and combined installations with manta-sdk.
"""

import os
import sys
from pathlib import Path

from .cli.main import main as node_cli_main
from .cli.main import show_help


def main():
    """Main entry point with intelligent module detection and CLI/direct mode handling."""

    if sys.platform.lower() == "win32" or os.name.lower() == "nt":
        from asyncio import WindowsSelectorEventLoopPolicy, set_event_loop_policy

        set_event_loop_policy(WindowsSelectorEventLoopPolicy())

    # Check if we're being called to run a node directly (legacy compatibility)
    # This happens when called as: python -m manta_node <config_file>
    # versus CLI mode: manta_node <command>
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        # Check if first argument looks like a config file or node command
        first_arg = sys.argv[1]
        # List of known CLI commands for node
        cli_commands = [
            "init",
            "start",
            "stop",
            "status",
            "list",
            "config",
            "cluster",
            "logs",
            "help",
        ]

        if first_arg not in cli_commands and (
            first_arg.endswith(".toml")
            or first_arg.endswith(".yaml")
            or first_arg.endswith(".json")
            or Path(first_arg).exists()
            or (Path.home() / ".manta" / "nodes" / f"{first_arg}.toml").exists()
        ):

            show_help()
            return 1

    # Use the local CLI implementation
    return node_cli_main()


if __name__ == "__main__":
    sys.exit(main())
