"""Node status command implementation."""

import argparse
import json
import os
from datetime import datetime
from pathlib import Path
from typing import List

import psutil
from rich.console import Console
from rich.table import Table

console = Console()


def find_running_instances():
    """Find running node instances by looking for instance JSON files."""

    instances_dir = Path.home() / ".manta" / "nodes" / "instances"
    instances = []

    if not instances_dir.exists():
        return instances

    for instance_file in instances_dir.glob("*.json"):
        try:
            with open(instance_file, "r") as f:
                instance_data = json.load(f)

            pid = instance_data.get("pid")
            instance_id = instance_data.get("instance_id", instance_file.stem)

            # Check if process is still running
            try:
                # Send signal 0 to check if process exists

                os.kill(pid, 0)

                # Get process info if psutil is available
                try:

                    process = psutil.Process(pid)
                    cpu_percent = process.cpu_percent()
                    memory_mb = process.memory_info().rss // (1024 * 1024)
                    create_time = datetime.fromtimestamp(process.create_time())
                    status = "running"
                except ImportError:
                    cpu_percent = None
                    memory_mb = None
                    create_time = None
                    status = "running"
                except psutil.NoSuchProcess:
                    # Process disappeared
                    instance_file.unlink(missing_ok=True)
                    continue

                # Add additional info from JSON
                alias = instance_data.get("alias", instance_id)
                config_name = instance_data.get("config_name", "unknown")
                start_time_str = instance_data.get("start_time")
                if start_time_str and not create_time:
                    try:
                        create_time = datetime.fromisoformat(start_time_str)
                    except Exception:
                        pass

                instances.append(
                    {
                        "instance_id": instance_id,
                        "alias": alias,
                        "config_name": config_name,
                        "pid": pid,
                        "status": status,
                        "cpu_percent": cpu_percent,
                        "memory_mb": memory_mb,
                        "start_time": create_time,
                        "instance_file": instance_file,
                    }
                )

            except OSError:
                # Process no longer exists, remove stale instance file
                instance_file.unlink(missing_ok=True)

        except (ValueError, FileNotFoundError):
            # Invalid instance file, remove it
            instance_file.unlink(missing_ok=True)

    return instances


def show_status_table(instances: List[dict]) -> None:
    """Display instances in a formatted table."""
    if not instances:
        console.print("[yellow]No running node instances found.[/yellow]")
        console.print("")
        console.print("Start a node with:")
        console.print("  manta_node start [config_name]")
        return

    table = Table(title="Running Node Instances")
    table.add_column("Alias", style="cyan")
    table.add_column("Config", style="magenta")
    table.add_column("PID", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("CPU %", style="blue")
    table.add_column("Memory (MB)", style="blue")
    table.add_column("Started", style="dim")

    for instance in instances:
        cpu_str = (
            f"{instance['cpu_percent']:.1f}%"
            if instance["cpu_percent"] is not None
            else "N/A"
        )
        memory_str = (
            str(instance["memory_mb"]) if instance["memory_mb"] is not None else "N/A"
        )
        start_str = (
            instance["start_time"].strftime("%Y-%m-%d %H:%M:%S")
            if instance["start_time"]
            else "N/A"
        )

        table.add_row(
            instance["alias"],
            instance["config_name"],
            str(instance["pid"]),
            instance["status"],
            cpu_str,
            memory_str,
            start_str,
        )

    console.print(table)


def show_status_plain(instances: List[dict]) -> None:
    """Display instances in plain text format."""
    if not instances:
        console.print("No running node instances found.")
        console.print("")
        console.print("Start a node with:")
        console.print("  manta_node start [config_name]")
        return

    console.print(f"Found {len(instances)} running instance(s):")
    console.print("")

    for instance in instances:
        console.print(f"Instance: [cyan]{instance['instance_id']}[/cyan]")
        console.print(f"  PID: {instance['pid']}")
        console.print(f"  Status: {instance['status']}")

        if instance["cpu_percent"] is not None:
            console.print(f"  CPU: {instance['cpu_percent']:.1f}%")
        if instance["memory_mb"] is not None:
            console.print(f"  Memory: {instance['memory_mb']} MB")
        if instance["start_time"]:
            console.print(
                f"  Started: {instance['start_time'].strftime('%Y-%m-%d %H:%M:%S')}"
            )

        console.print("")


def status_command(args: List[str]) -> int:
    """Handle node status command.

    Args:
        args: Command line arguments

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    parser = argparse.ArgumentParser(
        prog="manta_node status", description="Show status of running node instances"
    )
    parser.add_argument(
        "--plain", action="store_true", help="Use plain text output instead of table"
    )
    parser.add_argument(
        "--all", action="store_true", help="Show all instances (same as default)"
    )

    try:
        parsed_args = parser.parse_args(args)
    except SystemExit:
        return 1

    instances = find_running_instances()

    if parsed_args.plain:
        show_status_plain(instances)
    else:
        show_status_table(instances)

    return 0


if __name__ == "__main__":
    import sys

    sys.exit(status_command(sys.argv[1:]))
