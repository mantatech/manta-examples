"""Node stop command implementation."""

import argparse
import os
import signal
import time
from pathlib import Path
from typing import List

from rich.console import Console

console = Console()


def print_error(message: str):
    """Print error message in red."""
    console.print(f"[red]Error: {message}[/red]")


def print_success(message: str):
    """Print success message in green."""
    console.print(f"[green]{message}[/green]")


def print_warning(message: str):
    """Print warning message in yellow."""
    console.print(f"[yellow]{message}[/yellow]")


def find_running_instances():
    """Find running node instances by looking for instance JSON files."""
    import json

    instances_dir = Path.home() / ".manta" / "nodes" / "instances"
    instances = []

    if not instances_dir.exists():
        return instances

    for instance_file in instances_dir.glob("*.json"):
        try:
            with open(instance_file, "r") as f:
                instance_data = json.load(f)

            pid = instance_data.get("pid")
            instance_id = instance_data.get("instance_id", instance_file.stem)
            alias = instance_data.get("alias", instance_id)

            # Check if process is still running
            try:
                # Send signal 0 to check if process exists
                import os

                os.kill(pid, 0)
                instances.append(
                    {
                        "instance_id": instance_id,
                        "alias": alias,
                        "pid": pid,
                        "instance_file": instance_file,
                    }
                )
            except OSError:
                # Process no longer exists, remove stale instance file
                instance_file.unlink(missing_ok=True)

        except (ValueError, FileNotFoundError):
            # Invalid instance file, remove it
            instance_file.unlink(missing_ok=True)

    return instances


def stop_instance_by_pid(
    instance: dict, force: bool = False, timeout: int = 10
) -> bool:
    """Stop a node instance using its PID.

    Args:
        instance: Instance information dictionary
        force: If True, use SIGKILL instead of SIGTERM
        timeout: Seconds to wait for graceful shutdown before force killing

    Returns:
        True if successfully stopped, False otherwise
    """
    pid = instance["pid"]
    instance_id = instance["instance_id"]
    alias = instance.get("alias", instance_id)

    try:
        if force:
            # Force kill with SIGKILL
            os.kill(pid, signal.SIGKILL)
            console.print(f"Force killed node '{alias}' (PID: {pid})")
        else:
            # Graceful shutdown with SIGTERM
            os.kill(pid, signal.SIGTERM)
            console.print(f"Sent termination signal to node '{alias}' (PID: {pid})")

            # Wait for process to terminate gracefully
            console.print(
                f"[dim]Waiting up to {timeout} seconds for graceful shutdown...[/dim]"
            )
            start_time = time.time()
            while time.time() - start_time < timeout:
                try:
                    # Check if process is still running
                    os.kill(pid, 0)
                    time.sleep(0.5)
                except OSError:
                    # Process has terminated
                    console.print(f"[green]Node '{alias}' stopped gracefully[/green]")
                    break
            else:
                # Timeout reached, process still running
                print_warning(
                    f"Node '{alias}' did not stop gracefully, sending SIGKILL..."
                )
                os.kill(pid, signal.SIGKILL)
                console.print(f"Force killed node '{alias}' after timeout")

        # Remove instance file
        instance["instance_file"].unlink(missing_ok=True)
        return True

    except OSError as e:
        if e.errno == 3:  # No such process
            # Process already dead, just remove instance file
            instance["instance_file"].unlink(missing_ok=True)
            print_warning(f"Node '{alias}' was already stopped")
            return True
        else:
            print_error(f"Failed to stop node '{alias}': {e}")
            return False


def stop_all_instances(force: bool = False, timeout: int = 10) -> int:
    """Stop all running node instances."""
    instances = find_running_instances()

    if not instances:
        console.print("No running node instances found.")
        return 0

    console.print(f"Found {len(instances)} running instance(s):")
    for instance in instances:
        console.print(f"  - {instance['alias']} (PID: {instance['pid']})")

    console.print("")
    if force:
        console.print("Force stopping all instances...")
    else:
        console.print("Stopping all instances...")

    success_count = 0
    for instance in instances:
        if stop_instance_by_pid(instance, force, timeout):
            success_count += 1

    if success_count == len(instances):
        print_success(f"All {success_count} instances stopped successfully")
        return 0
    else:
        print_error(
            f"Only {success_count}/{len(instances)} instances stopped successfully"
        )
        return 1


def stop_specific_instance(
    instance_name: str, force: bool = False, timeout: int = 10
) -> int:
    """Stop a specific node instance by name or ID."""
    instances = find_running_instances()

    if not instances:
        print_error("No running node instances found")
        return 1

    # Find matching instance (by alias or instance_id)
    target_instance = None
    for instance in instances:
        if (
            instance["alias"] == instance_name
            or instance["instance_id"] == instance_name
            or instance["instance_id"].startswith(instance_name)
        ):
            target_instance = instance
            break

    if not target_instance:
        print_error(f"Node instance '{instance_name}' not found")
        console.print("Running instances:")
        for instance in instances:
            console.print(f"  - {instance['alias']} (PID: {instance['pid']})")
        return 1

    if stop_instance_by_pid(target_instance, force, timeout):
        print_success(f"Node '{target_instance['alias']}' stopped successfully")
        return 0
    else:
        return 1


def stop_command(args: List[str]) -> int:
    """Handle node stop command.

    Args:
        args: Command line arguments

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    parser = argparse.ArgumentParser(
        prog="manta_node stop", description="Stop running node instances"
    )
    parser.add_argument(
        "instance",
        nargs="?",
        help="Instance ID or name to stop (if not provided, stops all instances)",
    )
    parser.add_argument("--all", action="store_true", help="Stop all running instances")
    parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Force stop using SIGKILL instead of SIGTERM",
    )
    parser.add_argument(
        "--timeout",
        "-t",
        type=int,
        default=10,
        help="Timeout in seconds to wait for graceful shutdown (default: 10)",
    )

    try:
        parsed_args = parser.parse_args(args)
    except SystemExit:
        return 1

    if parsed_args.all or not parsed_args.instance:
        return stop_all_instances(parsed_args.force, parsed_args.timeout)
    else:
        return stop_specific_instance(
            parsed_args.instance, parsed_args.force, parsed_args.timeout
        )


if __name__ == "__main__":
    import sys

    sys.exit(stop_command(sys.argv[1:]))
