"""Manta Node CLI main entry point."""

import sys
from typing import List, Optional

from rich.console import Console

from .commands.cluster import cluster_command
from .commands.config import config_command
from .commands.logs import logs_command
from .commands.start import start_command
from .commands.status import status_command
from .commands.stop import stop_command

console = Console()


def show_help():
    """Show CLI help information."""
    help_text = """
[bold cyan]Manta Node CLI[/bold cyan]

[bold]Usage:[/bold]
  manta_node <command> [options]

[bold]Commands:[/bold]
  [cyan]start[/cyan]      Start a node instance
  [cyan]stop[/cyan]       Stop running node instances
  [cyan]status[/cyan]     Show status of running nodes
  [cyan]logs[/cyan]       View node logs
  [cyan]config[/cyan]     Manage node configurations
  [cyan]cluster[/cyan]    Manage node clusters
  [cyan]help[/cyan]       Show this help message

[bold]Examples:[/bold]
  manta_node start --config default
  manta_node status --all
  manta_node logs --follow node-123
  manta_node config init

For more help on a specific command:
  manta_node <command> --help
"""
    console.print(help_text)


def main(args: Optional[List[str]] = None) -> int:
    """Main CLI entry point for manta-node.

    Args:
        args: Optional command line arguments (uses sys.argv if None)

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    if args is None:
        args = sys.argv[1:]  # Skip the script name

    # Remove 'node' if it's the first argument (when called as 'manta_node <command>')
    if args and args[0] == "node":
        args = args[1:]

    # Show help if no arguments or help requested
    if not args or args[0] in ["-h", "--help", "help"]:
        show_help()
        return 0

    command = args[0]
    command_args = args[1:]

    try:
        # Import and execute the appropriate command
        if command == "start":
            return start_command(command_args)
        elif command == "stop":
            return stop_command(command_args)
        elif command == "status":
            return status_command(command_args)
        elif command == "logs":
            return logs_command(command_args)
        elif command == "config":
            return config_command(command_args)
        elif command == "cluster":
            return cluster_command(command_args)
        else:
            console.print(f"[red]Error: Unknown command '{command}'[/red]")
            console.print("\nUse 'manta_node help' to see available commands.")
            return 1

    except ImportError as e:
        console.print(f"[red]Error: Command '{command}' not available[/red]")
        console.print(f"[dim]{e}[/dim]")
        return 1
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user[/yellow]")
        return 1
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        return 1


if __name__ == "__main__":
    sys.exit(main())
