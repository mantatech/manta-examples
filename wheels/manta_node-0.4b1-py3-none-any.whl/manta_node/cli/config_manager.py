"""
Compatibility layer for old configuration classes.

This module provides compatibility classes that match the old configuration API
but delegate to the new NodeConfiguration system.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any

from ..node_config_manager import NodeConfiguration


@dataclass
class ConnectionConfig:
    """Compatibility class for old ConnectionConfig."""

    host: str = "localhost"
    port: int = 50051
    use_tls: bool = False
    cert_folder: Optional[str] = None


@dataclass
class HardwareConfig:
    """Compatibility class for old HardwareConfig."""

    gpu_enabled: Optional[bool] = None
    max_concurrent_tasks: int = 2
    cpu_limit: str = "2.0"
    memory_limit: str = "4G"

    def get(self, key: str, default=None):
        """Make this object behave like a dictionary for compatibility."""
        return getattr(self, key, default)

    def copy(self):
        """Return a copy of this hardware config."""
        return HardwareConfig(
            gpu_enabled=self.gpu_enabled,
            max_concurrent_tasks=self.max_concurrent_tasks,
            cpu_limit=self.cpu_limit,
            memory_limit=self.memory_limit,
        )


@dataclass
class NodeConfig:
    """Compatibility class for old NodeConfig API."""

    name: str
    alias: str
    connection: ConnectionConfig
    hardware: Optional[HardwareConfig] = None
    datasets: Optional[Dict[str, str]] = None
    auto_register: bool = True
    random_id: bool = False
    created_at: Optional[Any] = None
    updated_at: Optional[Any] = None

    def __post_init__(self):
        """Ensure datasets is a proper dict if provided."""
        if self.datasets is None:
            self.datasets = {}
        # Set default timestamps if not provided
        from datetime import datetime

        if self.created_at is None:
            self.created_at = datetime.now()
        if self.updated_at is None:
            self.updated_at = datetime.now()

    def to_node_configuration(self) -> NodeConfiguration:
        """Convert to new NodeConfiguration format."""
        config = NodeConfiguration()

        # Metadata
        config.metadata.name = self.name

        # Identity
        config.identity.alias = self.alias
        config.identity.random_id = self.random_id

        # Network
        config.network.manager_host = self.connection.host
        config.network.manager_port = self.connection.port

        # Security
        config.security.use_tls = self.connection.use_tls
        if self.connection.cert_folder:
            config.security.cert_folder = self.connection.cert_folder

        # Containers/Hardware
        if self.hardware:
            config.containers.gpu_enabled = self.hardware.gpu_enabled
            config.containers.default_cpu_limit = self.hardware.cpu_limit
            config.containers.default_memory_limit = self.hardware.memory_limit
            config.tasks.max_concurrent = self.hardware.max_concurrent_tasks

        # Datasets
        if self.datasets:
            config.datasets.mappings = self.datasets

        return config

    @classmethod
    def from_node_configuration(cls, config: NodeConfiguration) -> "NodeConfig":
        """Create from new NodeConfiguration format."""
        connection = ConnectionConfig(
            host=config.network.manager_host,
            port=config.network.manager_port,
            use_tls=config.security.use_tls,
            cert_folder=config.security.cert_folder,
        )

        hardware = HardwareConfig(
            gpu_enabled=config.containers.gpu_enabled,
            max_concurrent_tasks=config.tasks.max_concurrent,
            cpu_limit=config.containers.default_cpu_limit,
            memory_limit=config.containers.default_memory_limit,
        )

        return cls(
            name=config.metadata.name,
            alias=config.identity.alias or config.metadata.name,
            connection=connection,
            hardware=hardware,
            datasets=(
                config.datasets.mappings.copy() if config.datasets.mappings else None
            ),
            auto_register=True,  # Default assumption
            random_id=config.identity.random_id,
        )
