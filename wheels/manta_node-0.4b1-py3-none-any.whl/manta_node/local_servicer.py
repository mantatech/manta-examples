from logging import getLogger
from typing import AsyncIterator

from .common.build import (
    Binary,
    DataRequest,
    DirRequest,
    ExistsResponse,
    ListDirResponse,
    LocalBase,
    ProtoPath,
    ReadText,
)
from .common.conversions import ID
from .common.decorators import catch_batch_errors, catch_streaming_errors
from .common.traces import Tracer
from .dataset_manager import DatasetManager
from .node_client import NodeClient

__all__ = ["LocalServicer"]


class LocalServicer(LocalBase):
    """
    Local Servicer that provides access to the local data

    Parameters
    ----------
    node_id : ID
        Node ID
    node_client : NodeClient
        Node client instance
    dataset_manager : DatasetManager
        Dataset manager for handling data operations
    """

    DTYPES = {
        ".txt": "text",
        ".csv": "csv",
        ".npx": "numpy",
        ".npy": "numpy",
        ".npz": "numpy",
        ".np": "numpy",
    }

    def __init__(
        self,
        node_id: ID,
        node_client: NodeClient,
        dataset_manager: DatasetManager,
    ):
        self.tracer = Tracer(getLogger(__name__), node_id.oid)
        self.node_client = node_client
        self.dataset_manager = dataset_manager
        super().__init__()

    def _set_task_and_swarm_ids(self, data_request: DataRequest):
        self.tracer.set_metadata(
            task_id=ID(data_request.task_id),
            swarm_id=ID(data_request.swarm_id),
        )

    @catch_streaming_errors
    async def get_binary_data(self, data_request: DataRequest) -> AsyncIterator[Binary]:
        """
        Get the binary data

        Parameters
        ----------
        data_request : DataRequest
            Data Request containing the name of the file

        Returns
        -------
        AsyncIterator[Binary]
            Binary data

        Raises
        ------
        MantaLocalError
            If the file is not found
        """
        self._set_task_and_swarm_ids(data_request)
        for chunk in self.dataset_manager.get_dataset_as_bytes(data_request.name):
            yield Binary(content=chunk)

    @catch_batch_errors
    async def list_dir(self, request: DirRequest):
        """
        List the directories in the data folder

        Parameters
        ----------
        request : DirRequest
            Data Request

        Returns
        -------
        ListString
            List of directories
        """
        self._set_task_and_swarm_ids(request.data_request)
        files = self.dataset_manager.list_files(request.data_request.name, request.path)
        paths = [ProtoPath(value=str(f["name"]), is_file=f["is_file"]) for f in files]
        self.tracer.info(f"Found {len(paths)} entries in directory")
        return ListDirResponse(paths=paths)

    @catch_streaming_errors
    async def read_file_lines(self, request: ReadText) -> AsyncIterator[Binary]:
        """
        Read the lines of a file

        Parameters
        ----------
        request : ReadText
            Data Request containing the name of the file

        Returns
        -------
        ListString
            List of lines
        """
        self._set_task_and_swarm_ids(request.data_request)
        for line in self.dataset_manager.read_file_lines(
            request.data_request.name,
            request.path.value,
            encoding=request.encoding,
            errors=request.errors,
            newline=request.newline,
        ):
            yield Binary(content=line)

    @catch_batch_errors
    async def exists(self, request: DirRequest) -> ExistsResponse:
        """
        Check if a file exists

        Parameters
        ----------
        request : DirRequest
            Data Request with path

        Returns
        -------
        ExistsResponse
            Response with boolean indicating if the file exists
        """
        self._set_task_and_swarm_ids(request.data_request)
        exists = self.dataset_manager.check_exists(
            request.data_request.name, request.path
        )
        return ExistsResponse(value=exists)
