import asyncio
import io
from datetime import datetime
from logging import getLogger
from pathlib import Path
from typing import AsyncIterable, Awaitable, Callable, List, Optional, cast

import aiomqtt

from .collector import Collector
from .common.base_mqtt import MqttBase
from .common.build import Logs, SetSystemSummaryRequest, TaskStatus, TaskUpdate
from .common.const import CHUNK_SIZE
from .common.conversions import ID
from .common.errors import MantaError, MantaGRPCError, MantaMQTTError, MantaNodeError
from .common.traces import Tracer
from .dataset_manager import DatasetManager
from .metrics_collector import MetricsCollectorBase
from .node_client import NodeClient
from .task_manager import TaskManager

TIMEOUT = 1  # s


class CommandHandler(TaskManager, Collector, MqttBase):
    """
    CommandHandler class to handle commands from the Manager

    Parameters
    ----------
    node_id: ID
        Node ID
    mqtt_client: MQTTClient
        MQTT client
    node_client: NodeClient
        Node client
    mqtt_broker_host : str
        MQTT broker host
    mqtt_broker_port : int
        MQTT broker port
    topics : List[str]
        List of topics
    light_service_port: int
        Light service port
    dataset_manager: DatasetManager
        Dataset manager
    metrics_collector: MetricsCollectorBase
        Metrics collector
    stop_callback: Callable[[], Awaitable[None]]
        Stop callback
    ssl_cert_folder : Optional[Path]
        SSL Certification folder
    """

    def __init__(
        self,
        node_id: ID,
        node_client: NodeClient,
        mqtt_broker_host: str,
        mqtt_broker_port: int,
        light_service_port: int,
        topics: List[str],
        dataset_manager: DatasetManager,
        metrics_collector: MetricsCollectorBase,
        stop_callback: Callable[[], Awaitable[None]],
        ssl_cert_folder: Optional[Path] = None,
        ping_interval: int = TIMEOUT,
        max_concurrent_tasks: int = 2,
        task_timeout: int = 3600,
    ) -> None:
        self.tracer = Tracer(getLogger(__name__), node_id.oid)
        self.node_client = node_client
        self.dataset_manager = dataset_manager
        self.metrics_collector = metrics_collector
        self.stop_callback = stop_callback
        self.node_id = node_id
        self.ping_interval = ping_interval
        self.max_concurrent_tasks = max_concurrent_tasks
        self.task_timeout = task_timeout

        MqttBase.__init__(
            self,
            mqtt_broker_host=mqtt_broker_host,
            mqtt_broker_port=mqtt_broker_port,
            topics=topics,
            client_id=self.node_id,
            ssl_cert_folder=ssl_cert_folder,
        )

        self.tracer.debug("Trying to connect to docker daemon...")
        TaskManager.__init__(self, light_service_port)
        self.tracer.info("Connected to docker daemon !")

    async def clean(self):  # TODO : use __del__
        """Delete the temporary folder and stop all containers"""
        self.tracer.debug("Cleaning up the temporary folder")
        self.temp_folder.cleanup()

        self.tracer.info("Stopping all tasks")
        for task_progression in self.tasks:
            try:
                task_id = task_progression.task_id
                swarm_id = task_progression.swarm_id

                task_progression.unlink()
                await self.stop_container(swarm_id, task_id)
                await self.remove_container(swarm_id, task_id)
            except Exception:
                self.tracer.exception(
                    f"Error when stopping task {task_progression.task_id}"
                )

        self.tracer.info("Closing Docker client")
        try:
            await self.async_client.close()
        except Exception:
            self.tracer.exception("Error when closing Docker client")

    async def loop_tasks(self):
        """
        Processes messages or check tasks to ping
        """
        while True:
            # Wait until we either (1) receive a message or (2) publish a message
            try:
                subscribe_task = asyncio.create_task(self.client.messages.__anext__())
                publish_task = asyncio.create_task(self.queue.get())
                ping_task = asyncio.create_task(self._ping())
                done, _ = await asyncio.wait(
                    (subscribe_task, publish_task, ping_task),
                    return_when=asyncio.FIRST_COMPLETED,
                )
            # If the asyncio.wait is cancelled, we must also cancel the queue task
            except asyncio.CancelledError:
                subscribe_task.cancel()
                publish_task.cancel()
                ping_task.cancel()
                raise

            # When we receive a message, process it
            if subscribe_task in done and publish_task in done:
                await self._subscribe_from_task(subscribe_task)
                await self._publish_from_task(publish_task)
                ping_task.cancel()
            elif subscribe_task in done:
                await self._subscribe_from_task(subscribe_task)
                publish_task.cancel()
                ping_task.cancel()
            # Publish the message to its topic with specific QoS
            elif publish_task in done:
                # self.tracer.debug("Publish message to MQTT broker.")
                await self._publish_from_task(publish_task)
                subscribe_task.cancel()
                ping_task.cancel()
            # If we disconnect from the broker, stop the loop with an exception
            elif ping_task in done:
                ping_task.cancel()
                publish_task.cancel()
                subscribe_task.cancel()
            else:
                self.tracer.warning("Disconnected during message iteration")
                publish_task.cancel()
                subscribe_task.cancel()
                ping_task.cancel()
                raise aiomqtt.MqttError("Disconnected during message iteration")

    async def _ping(self):
        """
        Ping the Manager
        """
        await asyncio.sleep(self.ping_interval)
        updated = await self.check_tasks()
        if len(updated) > 0:
            for task_progression in updated:
                if task_progression.task_status == TaskStatus.STOPPED:
                    try:
                        date, processed_logs = await self.get_task_logs(
                            task_progression
                        )
                        self.tracer.info(
                            f"Sending logs to the Manager for task {task_progression.task_id}"
                        )
                        await self.send_task_logs(date, processed_logs)
                    except MantaGRPCError as e:
                        self.tracer.exception(
                            f"gRPCError when updating finished tasks: {e}"
                        )
                        task_progression.task_status = TaskStatus.FAILED
                    except MantaError as manta_error:
                        self.tracer.exception("Error updating finished tasks.")
                        manta_error.metadata = self.tracer.metadata
                        task_progression.task_status = TaskStatus.FAILED
                        await self.node_client.send_error(manta_error)
                    except Exception as exc:
                        message = f"Error updating finished tasks: {repr(exc)}"
                        self.tracer.exception(message)
                        task_progression.task_status = TaskStatus.FAILED
                        await self.node_client.send_error(
                            MantaNodeError(message, metadata=self.tracer.metadata)
                        )
                else:
                    try:
                        await self.publish_task_update(task_progression.task_update)
                    except Exception as exc:
                        message = f"Error updating active tasks: {repr(exc)}"
                        self.tracer.exception("Error updating active tasks.")
                        await self.node_client.send_error(
                            MantaNodeError(message, metadata=self.tracer.metadata)
                        )
        else:
            await self.ping()

    async def ping(self):
        """
        Ping the Manager
        """
        try:
            metrics = await self.metrics_collector.collect_all_metrics()
            await self.publish_message(
                "manager/set_system_summary",
                SetSystemSummaryRequest(
                    node_id=self.node_id.oid,
                    metrics_snapshot=metrics,
                ),
            )
        except MantaGRPCError as e:
            self.tracer.exception(f"Error when pinging the Manager: {e}")
        except MantaError as e:
            self.tracer.exception(f"Error when pinging the Manager: {e}")
            await self.node_client.send_error(e)

    async def process_message(self, message: aiomqtt.Message):
        """
        Handle messages from MQTT

        Parameters
        ----------
        message : aiomqtt.Message
            Message
        """
        try:
            self.tracer.clean_metadata()
            key = str(message.topic).split("/")[-1]
            payload = cast(bytes, message.payload)

            if key == "deploy_task":
                await self.deploy_task(payload)
            elif key == "stop_task":
                task_update = await self.stop_task(payload)
                if task_update is not None:
                    await self.publish_task_update(task_update)
            elif key == "stop_swarm":
                await self.stop_swarm(payload)
            elif key == "collect_information":
                await self.collect_information(payload)
            elif key == "stop_node":
                await self.stop_node(payload)
            else:
                self.tracer.error(f"Not allowed method: {key}")
                raise MantaMQTTError(
                    f"Not allowed method: {key}", metadata=self.tracer.metadata
                )
        except MantaGRPCError as e:
            self.tracer.exception(f"Error sending message to the Manager: {e}")
        except MantaError as manta_error:
            self.tracer.exception(f"Error when handling message: {manta_error}")
            await self.node_client.send_error(manta_error)

    async def publish_task_update(self, task_update: TaskUpdate):
        """
        Publish a task update to the Manager through MQTT
        Message broker

        Parameters
        ----------
        task_update : TaskUpdate
            Task Update
        """
        await self.publish_message("manager/update_task_status", task_update)

    async def send_task_logs(self, date: datetime, processed_logs: bytes):
        """
        Send task logs to the Manager

        Parameters
        ----------
        date : datetime
            Date when logs where created
        processed_logs : bytes
            Logs prepared from tracer
        """

        async def chunk_logs(content: bytes) -> AsyncIterable[Logs]:
            data_stream = io.BytesIO(content)
            while chunk := data_stream.read(CHUNK_SIZE):
                yield Logs(content=chunk, timestamp=date)

        await self.node_client.add_task_logs(chunk_logs(processed_logs))

    async def stop_node(self, _payload: bytes):
        """
        Stop the node and prepare for graceful shutdown

        Parameters
        ----------
        payload : bytes
            Node ID to stop
        """
        await self.stop_callback()
