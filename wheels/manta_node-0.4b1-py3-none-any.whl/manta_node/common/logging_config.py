import logging
import logging.config
from typing import Optional

from rich.console import Console

__all__ = [
    "configure_logging",
    "filter_manta",
    "filter_maker",
    "MANTA_LOGGING_CONFIG",
    "configure_core_logging",
]

FORMAT = (
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)"
)


def filter_manta(level):
    def filter(record: logging.LogRecord):
        return "manta_" in record.name  # or "asyncio" in record.name

    return filter


def filter_maker(level):
    level = getattr(logging, level)

    def filter(record: logging.LogRecord):
        return record.levelno <= level

    return filter


CORE_LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {"format": FORMAT},
    },
    "filters": {
        "warnings_and_below": {
            "()": "manta_common.logging_config.filter_maker",
            "level": "WARNING",
        },
        "manta_filter": {
            "()": "manta_common.logging_config.filter_manta",
            "level": "INFO",
        },
    },
    "handlers": {
        "rich": {
            "class": "rich.logging.RichHandler",
            "formatter": "standard",
            "markup": True,
            "filters": ["manta_filter"],
            "console": Console(
                # log_path = False,
                _environ={"COLUMNS": "284"},
            ),
        },
    },
    "root": {
        "level": "CRITICAL",
        "handlers": ["rich"],
    },
}


MANTA_LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {"format": FORMAT},
    },
    "filters": {
        "warnings_and_below": {
            "()": "manta_common.logging_config.filter_maker",
            "level": "WARNING",
        },
        "manta_filter": {
            "()": "manta_common.logging_config.filter_manta",
            "level": "INFO",
        },
    },
    "handlers": {
        "rich": {
            "class": "rich.logging.RichHandler",
            "formatter": "standard",
            "markup": True,
            "filters": ["manta_filter"],
            "console": Console(
                # log_path = False,
                _environ={"COLUMNS": "284"},
            ),
        },
        "file": {
            "class": "logging.FileHandler",
            "formatter": "standard",
            "filename": "manta.log",
            "filters": ["manta_filter"],
            "mode": "w",
        },
    },
    "root": {
        "level": "CRITICAL",
        "handlers": ["rich", "file"],
    },
}

LEVELS = {
    0: "CRITICAL",
    1: "ERROR",
    2: "INFO",
    3: "DEBUG",
}


def configure_logging(
    log_filename: str = "manta.log",
    level: int = 0,
    debug: bool = False,
    config: Optional[dict] = None,
):
    """
    Configure logging

    Parameters
    ----------
    log_filename : str, optional
        Path of the log file, by default "manta_manager.log"
    level : int
        Verbose level
    debug : bool
        :code:`True` - all logs are printed and saved into a file
    config : Optional[dict]
        Logging config
    """
    if config:
        logging.config.dictConfig(config)
    else:
        config = MANTA_LOGGING_CONFIG
        config["root"]["level"] = LEVELS[level]
        config["handlers"]["file"]["filename"] = log_filename
        if not debug:
            config["handlers"] = {"default": {"class": "logging.NullHandler"}}
            config["root"]["handlers"] = ["default"]
        logging.config.dictConfig(config)


def configure_core_logging(level: int = 0, config: Optional[dict] = None):
    if config:
        logging.config.dictConfig(config)
    else:
        config = CORE_LOGGING_CONFIG
        config["root"]["level"] = LEVELS[level]
        logging.config.dictConfig(config)
