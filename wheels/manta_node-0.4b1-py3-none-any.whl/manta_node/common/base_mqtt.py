import asyncio
import ssl
from abc import ABC, abstractmethod
from logging import getLogger
from pathlib import Path
from typing import List, Optional

import aiomqtt
from betterproto import Message

from .conversions import ID
from .traces import Tracer

RECONNECTION_INTERVAL = 5  # s


class MqttBase(ABC):
    """
    Abstract class for MQTT communications

    Parameters
    ----------
    mqtt_broker_host : str
        MQTT broker host
    mqtt_broker_port : int
        MQTT broker port
    topics : List[str]
        MQTT topics for subscription
    client_id : Optional[ID]
        Client ID
    ssl_cert_folder : Optional[Path]
        SSL Certification folder

    Attributes
    ----------
    client_id : ID
        Client ID
    ssl_cert_folder : Optional[Path]
        SSL certification folder
    tracer : Tracer
        Tracer
    topics : List[str]
        List of topics for subscription
    client : aiomqtt.Client
        MQTT Client
    """

    def __init__(
        self,
        mqtt_broker_host: str,
        mqtt_broker_port: int,
        topics: List[str],
        client_id: Optional[ID] = None,
        ssl_cert_folder: Optional[Path] = None,
    ):
        self.client_id = client_id or ID()
        self.tracer = Tracer(
            getLogger(f"{self.__class__.__module__}.{self.__class__.__name__}"),
            self.client_id.oid,
        )

        # Set TLS parameters
        tls_params = None
        tls_insecure = None

        if ssl_cert_folder is not None:
            # Mutual TLS with client certificates (for certificate-based authentication)
            tls_params = aiomqtt.TLSParameters(
                ca_certs=str(ssl_cert_folder / "ca.crt"),
                certfile=str(ssl_cert_folder / "mqtt.crt"),
                keyfile=str(ssl_cert_folder / "mqtt.key"),
                tls_version=ssl.PROTOCOL_TLS_CLIENT,
            )
            tls_insecure = False
        elif mqtt_broker_port == 8883:
            # Server-side TLS only (for Let's Encrypt or other CA-signed certificates)
            # Use system CA certificates to verify server certificate
            tls_params = aiomqtt.TLSParameters(
                tls_version=ssl.PROTOCOL_TLS_CLIENT,
            )
            # tls_insecure is not set (defaults to None), which enables certificate verification

        self.client = aiomqtt.Client(
            hostname=mqtt_broker_host,
            port=mqtt_broker_port,
            logger=self.tracer.logger,
            identifier=self.client_id.xid,
            tls_params=tls_params,
            tls_insecure=tls_insecure,
        )
        self.topics = topics

        # Log TLS configuration for debugging
        if tls_params is not None:
            if ssl_cert_folder is not None:
                self.tracer.info(
                    f"MQTT client initialized with host {mqtt_broker_host} and port {mqtt_broker_port} (mutual TLS with client certificates)"
                )
            else:
                self.tracer.info(
                    f"MQTT client initialized with host {mqtt_broker_host} and port {mqtt_broker_port} (TLS with system CA certificates)"
                )
        else:
            self.tracer.info(
                f"MQTT client initialized with host {mqtt_broker_host} and port {mqtt_broker_port} (plain MQTT, no TLS)"
            )
        self.queue = asyncio.Queue()

    async def publish_message(self, topic: str, message: Message, qos: int = 0):
        """
        Publish a message to the MQTT broker

        Parameters
        ----------
        topic : str
            Topic to publish the message.
        message : Message
            :code:`betterproto.Message` to publish
        qos : int
            Quality of Service level
        """
        await self.queue.put((topic, message, qos))

    @abstractmethod
    async def process_message(self, message: aiomqtt.Message):
        """
        Abstract method for processing a message from MQTT

        Parameters
        ----------
        message : aiomqtt.Message
            Message received after subscription
        """
        ...

    async def _publish_from_task(self, task: asyncio.Task):
        """
        Publish a message from a task
        """
        topic, message, qos = task.result()
        await self.client.publish(topic, message.SerializeToString(), qos)

    async def _subscribe_from_task(self, task: asyncio.Task):
        """
        Subscribe from a task
        """
        self.tracer.debug("Message received from MQTT broker.")
        message = task.result()
        await self.process_message(message)

    async def loop_tasks(self):
        """
        Main loop to publish message and get messages from subcription.
        """
        while True:
            # Wait until we either (1) receive a message or (2) publish a message
            try:
                subscribe_task = asyncio.create_task(self.client.messages.__anext__())
                publish_task = asyncio.create_task(self.queue.get())
                done, _ = await asyncio.wait(
                    (subscribe_task, publish_task),
                    return_when=asyncio.FIRST_COMPLETED,
                )
            # If the asyncio.wait is cancelled, we must also cancel the queue task
            except asyncio.CancelledError:
                subscribe_task.cancel()
                publish_task.cancel()
                raise

            # When we receive a message, process it
            if subscribe_task in done and publish_task in done:
                await self._subscribe_from_task(subscribe_task)
                await self._publish_from_task(publish_task)
            elif subscribe_task in done:
                await self._subscribe_from_task(subscribe_task)
                publish_task.cancel()
            # Publish the message to its topic with specific QoS
            elif publish_task in done:
                # self.tracer.debug("Publish message to MQTT broker.")
                await self._publish_from_task(publish_task)
                subscribe_task.cancel()
            # If we disconnect from the broker, stop the loop with an exception
            else:
                self.tracer.warning("Disconnected during message iteration")
                publish_task.cancel()
                subscribe_task.cancel()
                raise aiomqtt.MqttError("Disconnected during message iteration")

    async def main(self):
        """Main loop for starting subscription and receiving messages."""
        self.tracer.debug("MQTT client going in main loop.")
        while True:
            try:
                async with self.client:
                    for topic in self.topics:
                        self.tracer.debug(f"MQTT client subscribing to {topic!r}")
                        await self.client.subscribe(topic)

                    await self.loop_tasks()
            except aiomqtt.MqttError:
                self.tracer.warning(
                    f"MQTT connection lost; Reconnecting in {RECONNECTION_INTERVAL} seconds ..."
                )
                await asyncio.sleep(RECONNECTION_INTERVAL)
