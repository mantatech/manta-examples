"""
Certificate Loader for Manta Platform

This module provides secure certificate loading and validation for all Manta components.
Certificates can be loaded from:
1. Bundled package data (for CA certificates)
2. File system paths (for deployment-specific certificates)
3. Environment variables (for cloud deployments)
"""

import os
import ssl
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional, Tuple, Union, cast

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.x509.oid import ExtensionOID, NameOID

from .errors import CertificateValidationError

__all__ = [
    "CertificateLoader",
    "create_ssl_context",
    "get_certificate_loader",
]


class CertificateLoader:
    """Load and validate certificates for Manta components."""

    def __init__(
        self,
        component_name: str,
        environment: Optional[str] = None,
        cert_folder: Optional[Union[str, Path]] = None,
    ):
        """Initialize certificate loader.

        Args:
            component_name: Name of the component (manta-sdk, manta-node, etc.)
            environment: Environment name (dev/staging/prod)
            cert_folder: Custom certificate folder path
        """
        self.component_name = component_name
        self.environment = environment or os.getenv("MANTA_ENV", "dev")
        self.cert_folder = Path(cert_folder) if cert_folder else None

        # Determine certificate paths
        self._resolve_certificate_paths()

    def _resolve_certificate_paths(self):
        """Resolve certificate paths based on configuration."""
        # Priority order:
        # 1. Explicit cert_folder parameter
        # 2. MANTA_CERT_DIR environment variable
        # 3. Package data directory
        # 4. Default system paths

        if self.cert_folder and self.cert_folder.exists():
            self.cert_dir = self.cert_folder
        elif cert_env := os.getenv("MANTA_CERT_DIR"):
            self.cert_dir = Path(cert_env)
        else:
            # Try to load from package data
            self.cert_dir = self._get_package_cert_dir()

    def _get_package_cert_dir(self) -> Path:
        """Get certificate directory from package data.

        Returns:
            Path to certificate directory
        """
        try:
            if self.component_name == "manta-sdk":
                import manta

                package_dir = Path(manta.__file__).parent
            elif self.component_name == "manta-node":
                import manta_node

                package_dir = Path(manta_node.__file__).parent
            else:
                # Fallback to system paths
                return Path("/etc/manta/certs")

            cert_dir = package_dir / "certs"
            if cert_dir.exists():
                return cert_dir
            else:
                # Development mode - use local certs directory
                return Path.cwd() / "certs"

        except ImportError:
            return Path("/etc/manta/certs")

    def load_ca_certificate(self) -> x509.Certificate:
        """Load CA certificate for trust validation.

        Returns:
            CA certificate object

        Raises:
            CertificateValidationError: If CA certificate cannot be loaded
        """
        ca_cert_path = self.cert_dir / f"manta-ca-{self.environment}.crt"

        if not ca_cert_path.exists():
            # Try trust bundle
            ca_cert_path = self.cert_dir / f"manta-trust-bundle-{self.environment}.pem"

        if not ca_cert_path.exists():
            raise CertificateValidationError(
                f"CA certificate not found at {ca_cert_path}. "
                f"Please ensure certificates are properly generated and bundled."
            )

        with open(ca_cert_path, "rb") as f:
            cert_data = f.read()

        try:
            cert = x509.load_pem_x509_certificate(cert_data, default_backend())
            self._validate_ca_certificate(cert)
            return cert
        except Exception as e:
            raise CertificateValidationError(f"Invalid CA certificate: {e}")

    def load_client_certificate(self) -> Tuple[x509.Certificate, Optional[bytes]]:
        """Load client certificate and private key.

        Returns:
            Tuple of (certificate, private_key_bytes)
            Note: private_key_bytes will be None if not available (common for bundled certs)

        Raises:
            CertificateValidationError: If certificate cannot be loaded
        """
        cert_path = self.cert_dir / f"{self.component_name}-{self.environment}.crt"
        key_path = self.cert_dir / f"{self.component_name}-{self.environment}.key"

        if not cert_path.exists():
            raise CertificateValidationError(
                f"Client certificate not found at {cert_path}"
            )

        with open(cert_path, "rb") as f:
            cert_data = f.read()

        try:
            cert = x509.load_pem_x509_certificate(cert_data, default_backend())
            self._validate_client_certificate(cert)
        except Exception as e:
            raise CertificateValidationError(f"Invalid client certificate: {e}")

        # Load private key if available (not bundled in wheels)
        private_key = None
        if key_path.exists():
            with open(key_path, "rb") as f:
                private_key = f.read()
        elif os.getenv(f"{self.component_name.upper().replace('-', '_')}_PRIVATE_KEY"):
            # Load from environment variable for cloud deployments
            private_key = os.getenv(
                f"{self.component_name.upper().replace('-', '_')}_PRIVATE_KEY"
            ).encode()

        return cert, private_key

    def _validate_ca_certificate(self, cert: x509.Certificate):
        """Validate CA certificate properties.

        Args:
            cert: Certificate to validate

        Raises:
            CertificateValidationError: If validation fails
        """
        # Check if it's actually a CA certificate
        try:
            basic_constraints_ext = cert.extensions.get_extension_for_oid(
                ExtensionOID.BASIC_CONSTRAINTS
            )
            basic_constraints = cast(x509.BasicConstraints, basic_constraints_ext.value)
            if not basic_constraints.ca:
                raise CertificateValidationError("Certificate is not a CA certificate")
        except x509.ExtensionNotFound:
            raise CertificateValidationError(
                "Certificate lacks BasicConstraints extension"
            )

        # Check validity period
        now = datetime.now(timezone.utc)
        if now < cert.not_valid_before_utc:
            raise CertificateValidationError("CA certificate is not yet valid")
        if now > cert.not_valid_after_utc:
            raise CertificateValidationError("CA certificate has expired")

        # Verify it's for the right environment
        cn = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)[0].value
        cn_str = (
            cn
            if isinstance(cn, str)
            else cn.decode("utf-8") if isinstance(cn, bytes) else str(cn)
        )
        if self.environment not in cn_str.lower():
            warnings.warn(
                f"CA certificate CN '{cn}' doesn't match environment '{self.environment}'",
                UserWarning,
            )

    def _validate_client_certificate(self, cert: x509.Certificate):
        """Validate client certificate properties.

        Args:
            cert: Certificate to validate

        Raises:
            CertificateValidationError: If validation fails
        """
        # Check validity period
        now = datetime.now(timezone.utc)
        if now < cert.not_valid_before_utc:
            raise CertificateValidationError("Client certificate is not yet valid")
        if now > cert.not_valid_after_utc:
            raise CertificateValidationError("Client certificate has expired")

        # Check key usage for client authentication
        try:
            key_usage_ext = cert.extensions.get_extension_for_oid(
                ExtensionOID.KEY_USAGE
            )
            key_usage = cast(x509.KeyUsage, key_usage_ext.value)
            if not key_usage.digital_signature:
                raise CertificateValidationError(
                    "Certificate lacks digital signature capability"
                )
        except x509.ExtensionNotFound:
            pass  # Key usage extension is optional

        # Check extended key usage
        try:
            ext_key_usage_ext = cert.extensions.get_extension_for_oid(
                ExtensionOID.EXTENDED_KEY_USAGE
            )
            ext_key_usage = cast(x509.ExtendedKeyUsage, ext_key_usage_ext.value)
            from cryptography.x509.oid import ExtendedKeyUsageOID

            if (
                ExtendedKeyUsageOID.CLIENT_AUTH not in ext_key_usage
                and ExtendedKeyUsageOID.SERVER_AUTH not in ext_key_usage
            ):
                raise CertificateValidationError(
                    "Certificate lacks client/server authentication capability"
                )
        except x509.ExtensionNotFound:
            pass  # Extended key usage is optional

    def get_certificate_paths(self) -> Dict[str, Path]:
        """Get paths to certificate files.

        Returns:
            Dictionary with paths to ca_cert, client_cert, and client_key
        """
        paths = {
            "ca_cert": self.cert_dir / f"manta-ca-{self.environment}.crt",
            "client_cert": self.cert_dir
            / f"{self.component_name}-{self.environment}.crt",
            "client_key": self.cert_dir
            / f"{self.component_name}-{self.environment}.key",
        }

        # Check trust bundle if CA cert doesn't exist
        if not paths["ca_cert"].exists():
            bundle_path = self.cert_dir / f"manta-trust-bundle-{self.environment}.pem"
            if bundle_path.exists():
                paths["ca_cert"] = bundle_path

        # Set to None if files don't exist
        for key, path in paths.items():
            if not path.exists():
                raise CertificateValidationError(
                    f"Certificate file {path} does not exist"
                )

        return paths


def create_ssl_context(
    component_name: str,
    environment: Optional[str] = None,
    cert_folder: Optional[Union[str, Path]] = None,
    verify_mode: ssl.VerifyMode = ssl.CERT_REQUIRED,
) -> ssl.SSLContext:
    """Create SSL context for secure connections.

    Args:
        component_name: Name of the component
        environment: Environment name
        cert_folder: Custom certificate folder
        verify_mode: SSL verification mode

    Returns:
        Configured SSL context
    """
    loader = CertificateLoader(component_name, environment, cert_folder)

    # Create SSL context
    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.check_hostname = True
    context.verify_mode = verify_mode
    # CRITICAL: Enable HTTP/2 via ALPN for gRPC over TLS
    context.set_alpn_protocols(['h2'])

    # Load CA certificate
    ca_cert = loader.load_ca_certificate()
    paths = loader.get_certificate_paths()
    if paths["ca_cert"]:
        context.load_verify_locations(cafile=str(paths["ca_cert"]))

    _, private_key = loader.load_client_certificate()
    paths = loader.get_certificate_paths()

    if paths["client_cert"] and paths["client_key"] and paths["client_key"].exists():
        context.load_cert_chain(
            certfile=str(paths["client_cert"]),
            keyfile=str(paths["client_key"]),
        )
    elif paths["client_cert"] and private_key:
        # Use in-memory private key
        import tempfile

        with tempfile.NamedTemporaryFile(mode="wb", delete=False) as key_file:
            key_file.write(private_key)
            key_path = key_file.name
        try:
            context.load_cert_chain(
                certfile=str(paths["client_cert"]),
                keyfile=key_path,
            )
        finally:
            os.unlink(key_path)

    return context


# Singleton instance for convenience
_loader_cache: Dict[str, CertificateLoader] = {}


def get_certificate_loader(
    component_name: str,
    environment: Optional[str] = None,
    cert_folder: Optional[Union[str, Path]] = None,
) -> CertificateLoader:
    """Get or create a certificate loader instance.

    Args:
        component_name: Name of the component
        environment: Environment name
        cert_folder: Custom certificate folder

    Returns:
        CertificateLoader instance
    """
    cache_key = f"{component_name}:{environment}:{cert_folder}"

    if cache_key not in _loader_cache:
        _loader_cache[cache_key] = CertificateLoader(
            component_name, environment, cert_folder
        )

    return _loader_cache[cache_key]
