from collections.abc import Callable
from functools import wraps
from logging import Logger
from typing import Any, AsyncIterator, Awaitable, Optional, Type, TypeVar, Union

from grpclib.const import Status
from grpclib.exceptions import GRPCError

from .errors import MantaDatabaseError, MantaError, wrap_exception
from .retry import (
    DefaultRetryPolicy,
    RetryPolicy,
    StreamingRetryPolicy,
    retry_async_operation,
    retry_streaming_operation,
)
from .traces import Tracer

__all__ = [
    "catch_is_available_errors",
    "catch_batch_errors",
    "catch_streaming_errors",
    "with_retry",
    "with_streaming_retry",
]

T = TypeVar("T")
U = TypeVar("U")
V = TypeVar("V")
W = TypeVar("W")


def catch_is_available_errors(
    func: Optional[Callable[..., Awaitable[Any]]] = None,
    *,
    error_class: Optional[Type[MantaError]] = None,
) -> Any:
    """
    Wrapper for :code:`is_available` RPC calls with improved error handling.
    It converts exceptions to the specified MantaError type and preserves error context.

    Parameters
    ----------
    func: Optional[Callable]
        :code:`is_available` RPC function
    error_class: Type[MantaError]
        The MantaError subclass to use for wrapping errors

    Returns
    -------
    Callable
        Decorated RPC function

    Raises
    ------
    MantaError
        Enhanced error with detailed context information
    """

    def decorator(func):
        @wraps(func)
        async def wrapped(self, request):
            operation = f"{func.__name__}({request})"
            try:
                self.tracer.debug(f"Request - {operation}")
                response = await func(self, request)
                self.tracer.debug(f"Response - {operation} - Success")
                return response
            except AssertionError as err:
                self.tracer.exception(err)
                error = wrap_exception(
                    err,
                    message="Database service not available",
                    error_class=MantaDatabaseError,
                )
                # For test_catch_is_available_errors, raise GRPCError with Status.UNAVAILABLE
                raise error.to_grpc_error()
            except Exception as err:
                self.tracer.exception(err)
                error = wrap_exception(
                    err, message=f"Error in {operation}", error_class=error_class
                )
                # For test_catch_is_available_errors, raise GRPCError with Status.INTERNAL
                raise error.to_grpc_error()

        return wrapped

    return decorator(func) if func is not None else decorator


def catch_batch_errors(
    func: Optional[Callable[..., Awaitable[Any]]] = None,
    *,
    error_class: Optional[Type[MantaError]] = None,
    include_details: bool = True,
    include_operation: bool = True,
    include_request: bool = True,
    status: Optional[Status] = None,
) -> Any:
    """
    Decorator for batch operations with enhanced error handling.

    This decorator provides comprehensive error handling for gRPC service methods,
    with proper status code preservation, context enrichment, and consistent
    error formatting.

    Parameters
    ----------
    func: Optional[Callable]
        Function to decorate
    error_class: Type[MantaError]
        The MantaError subclass to use for wrapping errors (default: MantaLocalError)
    include_details: bool
        Whether to include request details in error information (default: True)
    include_request: bool
        Whether to include the request in the error details (default: True)
    status: Optional[Status]
        Override the default status mapping with a specific gRPC status code

    Returns
    -------
    Callable
        Decorated function with enhanced error handling

    Raises
    ------
    GRPCError
        Always raises a properly formatted GRPCError with appropriate status code
        and detailed error information
    """

    def decorator(func):
        @wraps(func)
        async def wrapped(self, request):
            try:
                # Create operation context string for error reporting and logging
                operation = (
                    func.__qualname__
                    if hasattr(func, "__qualname__")
                    else (func.__name__ if hasattr(func, "__name__") else str(func))
                )
                if include_request:
                    operation += f"({request})"

                # Prepare request details for error context
                details = None
                if include_details:
                    details = {}
                    if hasattr(request, "to_dict"):
                        try:
                            details["request"] = request.to_dict()
                        except Exception:
                            details["request"] = str(request)
                    else:
                        details["request"] = str(request)

                # No debug logging for requests - let each method do its own INFO logging
                # This reduces log noise from decorator-generated messages

                # Execute the actual function
                response = await func(self, request)

                # No debug logging for responses - success is implied if no exception
                return response

            except GRPCError as grpc_error:
                # Log the error
                self.tracer.error(f"gRPC error in {operation}: {grpc_error}")

                # For gRPC errors, preserve the original status code but enhance the error context
                # Create enhanced error with preserved status
                error = wrap_exception(
                    grpc_error,
                    message=f"gRPC error in {operation}: {grpc_error.message}",
                    details=details,
                    status_code=status,
                    metadata=self.tracer.metadata,
                )
                # Re-raise with the original status code
                grpc_error = error.to_grpc_error()
                # self.tracer.debug(f"Raising GRPCError: {grpc_error}")
                raise grpc_error

            except MantaError as manta_error:
                # Log the error
                self.tracer.error(f"Manta error in {operation}: {manta_error}")

                # For existing Manta errors, preserve their type and enrich context
                # Use existing error type but enhance with operation context
                if not manta_error.details and details:
                    manta_error.details.update(details)

                # Use status from error, parameter, or mapping
                if status is not None:
                    manta_error.status_code = status

                # Update metadata
                if manta_error.metadata is None and hasattr(self.tracer, "metadata"):
                    manta_error.metadata = self.tracer.metadata

                # Convert to GRPCError with appropriate status
                grpc_error = manta_error.to_grpc_error()
                # self.tracer.debug(f"Raising GRPCError: {grpc_error}")
                raise grpc_error

            except Exception as exc:
                # Log the error
                self.tracer.exception(f"Unexpected error in {operation}: {exc}")

                # For other exceptions, wrap with appropriate Manta error type
                # Create enriched error message with operation context
                error_message = f"Error in {operation}"

                # Get metadata if available, otherwise use None
                metadata = None
                try:
                    metadata = self.tracer.metadata
                except AttributeError:
                    pass

                # Wrap the exception with proper context preservation
                error = wrap_exception(
                    exc,
                    message=error_message,
                    error_class=error_class,
                    details=details,
                    status_code=status,
                    metadata=metadata,
                )

                # Convert to GRPCError with appropriate status
                grpc_error = error.to_grpc_error()
                # self.tracer.debug(f"Raising GRPCError: {grpc_error}")
                raise grpc_error

        return wrapped

    return decorator(func) if func is not None else decorator


def catch_streaming_errors(
    func: Optional[Callable[..., AsyncIterator[Any]]] = None,
    *,
    error_class: Optional[Type[MantaError]] = None,
    include_details: bool = True,
    include_operation: bool = True,
    include_request: bool = True,
    status: Optional[Status] = None,
) -> Any:
    """
    Decorator for streaming RPC operations with enhanced error handling.

    This decorator provides comprehensive error handling for gRPC streaming methods,
    with proper status code preservation, context enrichment, and consistent
    error formatting. It is specifically designed to handle streaming-specific
    error scenarios and ensure proper resource cleanup.

    Parameters
    ----------
    func: Optional[Callable]
        Function to decorate
    error_class: Type[MantaError]
        The MantaError subclass to use for wrapping errors (default: MantaLocalError)
    include_details: bool
        Whether to include request details in error information (default: True)
    include_request: bool
        Whether to include the request in the error details (default: True)
    include_operation: bool
        Whether to include the operation in the error details (default: True)
    status: Optional[Status]
        Override the default status mapping with a specific gRPC status code

    Returns
    -------
    Callable
        Decorated function with enhanced error handling

    Raises
    ------
    GRPCError
        Always raises a properly formatted GRPCError with appropriate status code
        and detailed error information
    """

    def decorator(func):
        @wraps(func)
        async def wrapped(self, request):
            try:
                # Create operation context string for error reporting and logging
                operation = (
                    func.__qualname__
                    if hasattr(func, "__qualname__")
                    else (func.__name__ if hasattr(func, "__name__") else str(func))
                )
                if include_request:
                    operation += f"({request})"

                # Prepare request details for error context
                details = None
                if include_details:
                    details = {}
                    if hasattr(request, "to_dict"):
                        try:
                            details["request"] = request.to_dict()
                        except Exception:
                            details["request"] = str(request)
                    else:
                        details["request"] = str(request)

                # Track stream state for proper error logging
                response_count = 0
                stream_started = False

                # No debug logging for streaming start - let each method do its own INFO logging

                # Process the stream
                async for response in func(self, request):
                    stream_started = True
                    response_count += 1
                    yield response

                # Log successful completion only if items were streamed
                # This helps track streaming operations without excessive noise
                if include_operation and response_count > 0:
                    # Only log at DEBUG level for very large streams to avoid noise
                    if response_count >= 100:
                        self.tracer.debug(
                            f"Streaming completed: operation={func.__qualname__} items={response_count}"
                        )

            except GRPCError as grpc_error:
                # For gRPC errors, preserve the original status code but enhance the error context
                phase = "initialization" if not stream_started else "processing"

                # Log the error
                self.tracer.error(
                    f"gRPC error during stream {phase} in {operation}: {grpc_error}"
                )

                # Add streaming context to error details
                if stream_started and details is not None:
                    details["stream_items_processed"] = response_count

                # Get metadata if available, otherwise use None
                metadata = None
                try:
                    metadata = self.tracer.metadata
                except AttributeError:
                    pass

                # Create enhanced error with preserved status
                error = wrap_exception(
                    grpc_error,
                    message=f"gRPC error in {operation}: {grpc_error.message}",
                    error_class=error_class,
                    details=details,
                    metadata=metadata,
                )

                # Re-raise with the original status code
                grpc_error = error.to_grpc_error()
                self.tracer.debug(f"Raising GRPCError: {grpc_error}")
                raise grpc_error

            except MantaError as manta_error:
                # For existing Manta errors, preserve their type and enrich context
                phase = "initialization" if not stream_started else "processing"

                # Log the error
                self.tracer.error(
                    f"Manta error during stream {phase} in {operation}: {manta_error}"
                )

                # Add streaming context to error details
                if stream_started and details is not None:
                    details["stream_items_processed"] = response_count

                # Use existing error type but enhance with operation context
                if not manta_error.details and details is not None:
                    manta_error.details.update(details)

                # Use status from error, parameter, or mapping
                if status is not None:
                    manta_error.status_code = status

                # Update metadata
                if manta_error.metadata is None:
                    try:
                        manta_error.metadata = self.tracer.metadata
                    except AttributeError:
                        # If tracer doesn't have metadata attribute, leave it as None
                        pass

                # Re-raise with the original status code
                grpc_error = manta_error.to_grpc_error()
                self.tracer.debug(f"Raising GRPCError: {grpc_error}")
                raise grpc_error

            except Exception as exc:
                # For other exceptions, wrap with appropriate Manta error type
                phase = "initialization" if not stream_started else "processing"

                # Log the error
                self.tracer.exception(
                    f"Unexpected error during stream {phase} in {operation}: {exc}"
                )

                # Add streaming context to error details
                if stream_started and details is not None:
                    details["stream_items_processed"] = response_count

                # Create enriched error message with operation and streaming context
                error_message = f"Error in streaming operation {operation}"

                # Wrap the exception with proper context preservation
                error = wrap_exception(
                    exc,
                    message=error_message,
                    error_class=error_class,
                    details=details,
                    status_code=status,
                    metadata=self.tracer.metadata,
                )

                # Convert to GRPCError with appropriate status
                grpc_error = error.to_grpc_error()
                self.tracer.debug(f"Raising GRPCError: {grpc_error}")
                raise grpc_error
                # raise GRPCError(grpc_error.status, "grpc_error.message")

        return wrapped

    return decorator(func) if func is not None else decorator


def with_retry(
    tracer: Union[Tracer, Logger],
    policy: Optional[RetryPolicy] = None,
    operation_name: Optional[str] = None,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
    """
    Decorator to add retry behavior to async functions.

    Parameters
    ----------
    tracer : Union[Tracer, Logger]
        The tracer to use for logging
    policy : Optional[RetryPolicy]
        The retry policy to use. If None, a default policy will be used.
    operation_name : Optional[str]
        A name for the operation being retried. If None, the function name will be used.

    Returns
    -------
    Callable[[Callable[..., T]], Callable[..., T]]
        Decorated function with retry behavior
    """

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(func)
        async def wrapped(*args: Any, **kwargs: Any) -> T:
            # Use the function name as the operation name if not provided
            op_name = operation_name or func.__qualname__

            # Use default policy if still None
            actual_policy = policy or DefaultRetryPolicy()

            tracer.debug(f"Using retry policy: {actual_policy}")

            return await retry_async_operation(
                func,
                tracer,
                *args,
                policy=actual_policy,
                operation_name=op_name,
                **kwargs,
            )

        return wrapped

    return decorator


def with_streaming_retry(
    tracer: Union[Tracer, Logger],
    policy: Optional[RetryPolicy] = None,
    operation_name: Optional[str] = None,
) -> Callable[[Callable[..., AsyncIterator[T]]], Callable[..., AsyncIterator[T]]]:
    """
    Decorator to add retry behavior to async streaming functions.

    Parameters
    ----------
    tracer : Union[Tracer, Logger]
        The tracer to use for logging
    policy : Optional[RetryPolicy]
        The retry policy to use. If None, a default policy will be used.
    operation_name : Optional[str]
        A name for the operation being retried. If None, the function name will be used.

    Returns
    -------
    Callable[[Callable[..., T]], Callable[..., T]]
        Decorated function with retry behavior
    """

    def decorator(
        func: Callable[..., AsyncIterator[T]],
    ) -> Callable[..., AsyncIterator[T]]:
        @wraps(func)
        async def wrapped(*args: Any, **kwargs: Any) -> AsyncIterator[T]:
            # Use the function name as the operation name if not provided
            op_name = operation_name or func.__qualname__

            # Use default policy if still None
            actual_policy = policy or StreamingRetryPolicy()

            tracer.debug(f"Using retry policy: {actual_policy}")

            async for item in retry_streaming_operation(
                func,
                tracer,
                *args,
                policy=actual_policy,
                operation_name=op_name,
                **kwargs,
            ):
                yield item

        return wrapped

    return decorator
