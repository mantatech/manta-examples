"""
Retry mechanisms for handling transient failures in service communications.

This module provides retry policies and functions for retrying async operations
with configurable backoff, jitter, and failure handling strategies.
"""

import asyncio
import secrets
from dataclasses import dataclass, field
from logging import Logger
from socket import gaierror
from typing import (
    Any,
    AsyncIterator,
    Awaitable,
    Callable,
    Dict,
    Optional,
    Set,
    Type,
    TypeVar,
    Union,
)

from grpclib.const import Status
from grpclib.exceptions import GRPCError

from .errors import (
    MantaConnectionError,
    MantaError,
    MantaGRPCError,
    MantaMQTTError,
    MantaTimeoutError,
)
from .traces import Tracer

__all__ = [
    "RetryPolicy",
    "DefaultRetryPolicy",
    "StreamingRetryPolicy",
    "retry_async_operation",
    "retry_streaming_operation",
]

T = TypeVar("T")


@dataclass
class RetryContext:
    """
    Context information for a retry operation.

    Stores state between retry attempts, including the current attempt number,
    the last error encountered, and other metadata useful for logging and debugging.
    """

    operation_name: str
    attempt: int = 0
    last_error: Optional[Exception] = None
    retry_after: Optional[float] = None
    details: Dict[str, Any] = field(default_factory=dict)


class RetryPolicy:
    """
    Base class for retry policies.

    A retry policy determines when and how to retry failed operations,
    including the maximum number of retries, delays between attempts,
    and which errors should trigger retries.
    """

    DEFAULT_RETRYABLE_ERRORS = {
        ConnectionError,
        TimeoutError,
        asyncio.TimeoutError,
        asyncio.CancelledError,
        ConnectionRefusedError,
        ConnectionAbortedError,
        ConnectionResetError,
        gaierror,
        MantaConnectionError,
        MantaTimeoutError,
        MantaMQTTError,
    }

    DEFAULT_RETRYABLE_GRPC_STATUS_CODES = {
        Status.UNAVAILABLE,  # Service temporarily unavailable
        Status.RESOURCE_EXHAUSTED,  # Rate limiting, can retry later
        Status.ABORTED,  # Concurrent access conflict
        Status.DEADLINE_EXCEEDED,  # Timeout
    }

    def __init__(
        self,
        max_retries: int = 3,
        initial_delay: float = 0.1,
        max_delay: float = 60.0,
        backoff_factor: float = 2.0,
        jitter_factor: float = 0.2,
        retryable_errors: Optional[Set[Type[Exception]]] = None,
        retryable_grpc_statuses: Optional[Set[Status]] = None,
    ):
        """
        Initialize a retry policy with configurable parameters.

        Parameters
        ----------
        max_retries : int
            Maximum number of retry attempts
        initial_delay : float
            Initial delay in seconds between retries
        max_delay : float
            Maximum delay in seconds between retries
        backoff_factor : float
            Exponential backoff multiplier
        jitter_factor : float
            Random jitter factor to add to delay (0.0 - 1.0)
        retryable_errors : Optional[Set[Type[Exception]]]
            Additional retryable errors
        retryable_grpc_statuses : Optional[Set[Status]]
            Additional retryable gRPC status codes
        """
        self.max_retries = max_retries
        self.initial_delay = initial_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.jitter_factor = jitter_factor
        self.retryable_errors = retryable_errors or self.DEFAULT_RETRYABLE_ERRORS
        self.retryable_grpc_statuses = (
            retryable_grpc_statuses or self.DEFAULT_RETRYABLE_GRPC_STATUS_CODES
        )

    def should_retry(self, error: Exception, context: RetryContext) -> bool:
        """
        Determine if a retry should be attempted based on the error and context.

        Parameters
        ----------
        error : Exception
            The error that caused the operation to fail
        context : RetryContext
            Context information about the retry operation

        Returns
        -------
        bool
            True if a retry should be attempted, False otherwise
        """
        # Don't retry if we've reached the maximum number of attempts
        if context.attempt >= self.max_retries:
            return False

        # Determine if the error is retryable
        return self._is_retryable_error(error)

    def _is_retryable_error(self, error: Exception) -> bool:
        """
        Determine if an error is retryable.

        Parameters
        ----------
        error : Exception
            The error to check

        Returns
        -------
        bool
            True if the error is retryable, False otherwise
        """
        # Default implementation retries on connection and timeout errors
        # but not on other types of errors
        if isinstance(error, tuple(self.retryable_errors)):
            return True

        # Check for gRPC unavailable errors via MantaGRPCError
        if isinstance(error, MantaGRPCError) and error.status_code:
            return error.status_code in self.retryable_grpc_statuses

        if isinstance(error, GRPCError):
            return error.status in self.retryable_grpc_statuses

        # Don't retry on other MantaErrors by default
        if isinstance(error, MantaError):
            return False

        # Default to not retrying unknown errors
        return False

    def get_retry_delay(self, context: RetryContext) -> float:
        """
        Calculate the delay before the next retry attempt.

        This method implements exponential backoff with jitter to avoid
        the "thundering herd" problem.

        Parameters
        ----------
        context : RetryContext
            Context information about the retry operation

        Returns
        -------
        float
            Delay in seconds before the next retry attempt
        """
        # Calculate exponential backoff
        delay = self.initial_delay * (self.backoff_factor ** (context.attempt - 1))

        # Apply maximum delay constraint
        delay = min(delay, self.max_delay)

        # Add jitter to avoid synchronization
        if self.jitter_factor > 0:
            # Use secrets module for cryptographically secure randomness
            jitter = secrets.SystemRandom().uniform(0, self.jitter_factor * delay)
            delay = delay + jitter

        return delay

    def record_attempt(self, error: Exception, context: RetryContext) -> None:
        """
        Record an attempt in the retry context.

        Parameters
        ----------
        error : Exception
            The error that occurred during the attempt
        context : RetryContext
            Context to update
        """
        # Update context with attempt information
        context.attempt += 1
        context.last_error = error

        # Calculate and store the delay until next retry
        if context.attempt <= self.max_retries:
            context.retry_after = self.get_retry_delay(context)
        else:
            # No more retries if we've reached the limit
            context.retry_after = None

    def __str__(self) -> str:
        """Return string representation of the policy."""
        return (
            f"{self.__class__.__name__}("
            f"max_retries={self.max_retries}, "
            f"initial_delay={self.initial_delay}, "
            f"max_delay={self.max_delay}, "
            f"backoff_factor={self.backoff_factor}, "
            f"jitter_factor={self.jitter_factor})"
        )


class DefaultRetryPolicy(RetryPolicy):
    """
    Standard retry policy for regular async operations.

    This policy implements a standard exponential backoff strategy with jitter,
    and retries on connection-related errors.
    """

    def _is_retryable_error(self, error: Exception) -> bool:
        """
        Determine if an error is retryable for regular operations.

        Parameters
        ----------
        error : Exception
            The error to check

        Returns
        -------
        bool
            True if the error is retryable, False otherwise
        """
        # Use the base implementation for regular operations
        return super()._is_retryable_error(error)


class StreamingRetryPolicy(RetryPolicy):
    """
    Specialized retry policy for streaming operations.

    This policy extends the default policy with additional logic specific to
    streaming operations, such as considering whether any items were processed
    before the error occurred.
    """

    def __init__(
        self,
        max_retries: int = 2,
        initial_delay: float = 0.2,
        max_delay: float = 3.0,
        backoff_factor: float = 2.0,
        jitter_factor: float = 0.2,
        retry_if_no_items_processed: bool = True,
        retryable_errors: Optional[Set[Type[Exception]]] = None,
        retryable_grpc_statuses: Optional[Set[Status]] = None,
    ):
        """
        Initialize a streaming retry policy.

        Parameters
        ----------
        max_retries : int
            Maximum number of retry attempts
        initial_delay : float
            Initial delay in seconds between retries
        max_delay : float
            Maximum delay in seconds between retries
        backoff_factor : float
            Exponential backoff multiplier
        jitter_factor : float
            Random jitter factor to add to delay (0.0 - 1.0)
        retry_if_no_items_processed : bool
            Whether to retry if no items were processed before the error
        retryable_errors : Optional[Set[Type[Exception]]]
            Additional retryable errors
        retryable_grpc_statuses : Optional[Set[Status]]
            Additional retryable gRPC status codes
        """
        super().__init__(
            max_retries=max_retries,
            initial_delay=initial_delay,
            max_delay=max_delay,
            backoff_factor=backoff_factor,
            jitter_factor=jitter_factor,
            retryable_errors=retryable_errors,
            retryable_grpc_statuses=retryable_grpc_statuses,
        )
        self.retry_if_no_items_processed = retry_if_no_items_processed

    def should_retry(self, error: Exception, context: RetryContext) -> bool:
        """
        Determine if a streaming operation should be retried.

        This considers both the base retry conditions and streaming-specific
        conditions like whether any items were processed.

        Parameters
        ----------
        error : Exception
            The error that caused the operation to fail
        context : RetryContext
            Context information about the retry operation

        Returns
        -------
        bool
            True if a retry should be attempted, False otherwise
        """
        # First check base conditions
        if not super().should_retry(error, context):
            return False

        # If configured, only retry if no items were processed
        if not self.retry_if_no_items_processed:
            # Check if any items were processed before the error
            items_processed = context.details.get("items_processed", 0)
            if items_processed > 0:
                # Items were already processed, don't retry
                return False

        return True

    def _is_retryable_error(self, error: Exception) -> bool:
        """
        Determine if an error is retryable for streaming operations.

        Parameters
        ----------
        error : Exception
            The error to check

        Returns
        -------
        bool
            True if the error is retryable, False otherwise
        """
        # For streaming, we're a bit more conservative about what we retry
        if isinstance(error, tuple(self.retryable_errors)):
            return True

        # Check for gRPC unavailable errors via MantaGRPCError
        if isinstance(error, MantaGRPCError) and error.status_code:
            return error.status_code in self.retryable_grpc_statuses

        if isinstance(error, GRPCError):
            return error.status in self.retryable_grpc_statuses

        # Don't retry other errors for streaming
        return False


async def retry_async_operation(
    func: Callable[..., Awaitable[T]],
    tracer: Union[Tracer, Logger],
    *args: Any,
    policy: Optional[RetryPolicy] = None,
    operation_name: Optional[str] = None,
    **kwargs: Any,
) -> T:
    """
    Execute an async operation with retry logic.

    The function will be retried according to the policy if it fails.

    Parameters
    ----------
    func : Callable[..., T]
        The async function to execute with retry
    tracer : Union[Tracer, Logger]
        The tracer to use for logging
    *args : Any
        Positional arguments to pass to the function
    policy : Optional[RetryPolicy]
        The retry policy to use (or DefaultRetryPolicy if None)
    operation_name : Optional[str]
        Name of the operation for logging (or the function name if None)
    **kwargs : Any
        Keyword arguments to pass to the function

    Returns
    -------
    T
        The result of the function if successful

    Raises
    ------
    Exception
        The last exception raised by the function if all retries fail
    """
    # Create the retry policy if not provided
    if policy is None:
        policy = DefaultRetryPolicy()

    # Use the function name if no operation name is provided
    if operation_name is None:
        operation_name = (
            func.__qualname__
            if hasattr(func, "__qualname__")
            else (func.__name__ if hasattr(func, "__name__") else str(func))
        )

    # Create the retry context
    context = RetryContext(operation_name=operation_name)

    while True:
        try:
            # Execute the function
            tracer.debug(f"Executing {operation_name} (attempt {context.attempt + 1})")
            return await func(*args, **kwargs)
        except Exception as error:
            # Record this attempt
            policy.record_attempt(error, context)

            # Determine if we should retry
            if not policy.should_retry(error, context):
                tracer.debug(
                    f"Not retrying {operation_name} after {context.attempt} attempts: {error}"
                )
                raise

            # Wait before retrying
            tracer.debug(
                f"Retrying {operation_name} in {context.retry_after:.2f}s after attempt "
                f"{context.attempt} failed: {error}"
            )
            await asyncio.sleep(context.retry_after or 0)


async def retry_streaming_operation(
    func: Callable[..., AsyncIterator[T]],
    tracer: Union[Tracer, Logger],
    *args: Any,
    policy: Optional[RetryPolicy] = None,
    operation_name: Optional[str] = None,
    **kwargs: Any,
) -> AsyncIterator[T]:
    """
    Execute a streaming async operation with retry logic.

    This function expects the streaming operation to return a list of items on success.
    The function will be retried according to the policy if it fails.

    Parameters
    ----------
    func : Callable[..., AsyncIterator[T]]
        The async function to execute with retry, returning an async iterator of items
    tracer : Tracer
        The tracer to use for logging
    *args : Any
        Positional arguments to pass to the function
    policy : Optional[RetryPolicy]
        The retry policy to use (or StreamingRetryPolicy if None)
    operation_name : Optional[str]
        Name of the operation for logging (or the function name if None)
    **kwargs : Any
        Keyword arguments to pass to the function

    Returns
    -------
    AsyncIterator[T]
        The async iterator of items from the streaming operation if successful

    Raises
    ------
    Exception
        The last exception raised by the function if all retries fail
    """
    # Create the retry policy if not provided
    if policy is None:
        policy = StreamingRetryPolicy()

    # Use the function name if no operation name is provided
    if operation_name is None:
        operation_name = (
            func.__qualname__
            if hasattr(func, "__qualname__")
            else (func.__name__ if hasattr(func, "__name__") else str(func))
        )

    # Create the retry context
    context = RetryContext(operation_name=operation_name)
    context.details["items_processed"] = 0

    # For special handling of empty results
    should_retry_on_empty = isinstance(policy, StreamingRetryPolicy) and getattr(
        policy, "retry_if_no_items_processed", False
    )

    # For testing purposes, define the max attempts we'll try
    max_attempts = policy.max_retries + 1  # +1 for the initial attempt
    attempt = 0

    while True:
        attempt += 1
        try:
            # Execute the function
            tracer.debug(
                f"Executing streaming {operation_name} (attempt {context.attempt + 1})"
            )

            # Yield the items from the streaming operation
            async for item in func(*args, **kwargs):
                context.details["items_processed"] += 1
                yield item

            # Special handling for empty results when the policy supports it
            if (
                should_retry_on_empty
                and context.details["items_processed"] == 0
                and context.attempt < policy.max_retries
                and attempt < max_attempts
            ):
                # Create a dummy error for empty results
                empty_error = ValueError(
                    f"Empty result received on attempt {context.attempt + 1}"
                )

                # Record attempt
                policy.record_attempt(empty_error, context)

                # Log the retry
                tracer.debug(
                    f"Retrying {operation_name} due to empty result after attempt {context.attempt} "
                    f"(retry in {context.retry_after:.2f}s)"
                )

                # Wait before retrying
                await asyncio.sleep(context.retry_after or 0)
                continue

            # Break the while loop
            break

        except Exception as error:
            # Record this attempt
            policy.record_attempt(error, context)

            # Determine if we should retry
            if not policy.should_retry(error, context) or attempt >= max_attempts:
                tracer.debug(
                    f"Not retrying streaming {operation_name} after {context.attempt} attempts: {error}"
                )
                raise

            # Wait before retrying
            tracer.debug(
                f"Retrying streaming {operation_name} in {context.retry_after:.2f}s after "
                f"attempt {context.attempt} failed: {error} "
                f"(items processed: {context.details.get('items_processed', 0)})"
            )
            await asyncio.sleep(context.retry_after or 0)
