"""Manta SDK CLI entry point.

This module provides the command-line interface entry point for the Manta SDK.
When manta-sdk is installed, it serves as the primary CLI for all manta components.
It can be executed using 'python -m manta' or 'manta' (when installed).
"""

import sys

from .cli.main import main as unified_main


def main():
    """Main CLI entry point - primary handler when manta-sdk is installed."""
    # When manta-sdk is installed, it's the primary CLI provider
    # Use the unified CLI from manta-common which detects all installed components
    return unified_main()


if __name__ == "__main__":
    sys.exit(main())
