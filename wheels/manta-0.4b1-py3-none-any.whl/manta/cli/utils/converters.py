"""Utility functions for CLI data conversion and formatting."""

from datetime import datetime
from typing import Any, Dict, Optional, Union


def enum_to_string(value: Union[int, str], enum_map: Dict[int, str]) -> str:
    """Convert enum value to string representation.

    Args:
        value: Enum value (int) or string
        enum_map: Dictionary mapping enum int values to string names

    Returns:
        String representation of the enum value
    """
    if isinstance(value, int):
        return enum_map.get(value, "UNKNOWN")
    return str(value)


def timestamp_to_string(
    timestamp: Union[Dict[str, Any], str, int, float, None],
    format: str = "%Y-%m-%d %H:%M:%S",
) -> str:
    """Convert various timestamp formats to string.

    Args:
        timestamp: Timestamp in various formats (dict with seconds, string, int/float, or None)
        format: Output format string

    Returns:
        Formatted timestamp string or 'Unknown' if invalid
    """
    if not timestamp:
        return "Unknown"

    if isinstance(timestamp, dict):
        if "seconds" in timestamp:
            return datetime.fromtimestamp(timestamp["seconds"]).strftime(format)
    elif isinstance(timestamp, str):
        return timestamp
    elif isinstance(timestamp, (int, float)):
        return datetime.fromtimestamp(timestamp).strftime(format)

    return "Unknown"


def bytes_to_gb(bytes_value: Union[int, float, None]) -> float:
    """Convert bytes to gigabytes.

    Args:
        bytes_value: Value in bytes

    Returns:
        Value in GB rounded to 2 decimal places
    """
    if bytes_value is None:
        return 0.0
    return round(bytes_value / (1024**3), 2)


def extract_platform_type(platform_info: Optional[Dict[str, Any]]) -> str:
    """Extract platform type from platform_info structure.

    Args:
        platform_info: Platform information dictionary

    Returns:
        Platform/OS type string
    """
    if not platform_info:
        return "Unknown"

    # Try different possible field names
    for field in ["system", "platform", "os"]:
        if field in platform_info:
            return platform_info[field]

    return "Unknown"


def extract_node_resources(
    metrics_snapshot: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Extract resource information from metrics snapshot.

    Args:
        metrics_snapshot: Metrics snapshot dictionary

    Returns:
        Dictionary with cpu_count and memory_gb
    """
    resources = {"cpu_count": "Unknown", "memory_gb": "Unknown"}

    if not metrics_snapshot:
        return resources

    # Extract CPU info
    if "cpu" in metrics_snapshot and metrics_snapshot["cpu"]:
        cpu_info = metrics_snapshot["cpu"]
        if "count" in cpu_info:
            resources["cpu_count"] = cpu_info["count"]
        elif "cores" in cpu_info:
            resources["cpu_count"] = cpu_info["cores"]

    # Extract memory info
    if "memory" in metrics_snapshot and metrics_snapshot["memory"]:
        memory_info = metrics_snapshot["memory"]
        if "total_bytes" in memory_info:
            resources["memory_gb"] = bytes_to_gb(memory_info["total_bytes"])
        elif "total" in memory_info:
            resources["memory_gb"] = bytes_to_gb(memory_info["total"])

    return resources


# Enum mappings for various status fields
NODE_STATUS_MAP = {0: "UNKNOWN", 1: "CONNECTED", 2: "DISCONNECTED"}

SWARM_STATUS_MAP = {
    0: "PENDING",
    1: "ACTIVE",
    2: "PAUSED",
    3: "STOPPED",
    4: "COMPLETED",
    5: "FAILED",
}

CLUSTER_STATUS_MAP = {0: "CREATED", 1: "RUNNING", 2: "STOPPED", 3: "ERROR"}

TASK_STATUS_MAP = {
    0: "PENDING",
    1: "RUNNING",
    2: "COMPLETED",
    3: "FAILED",
    4: "CANCELLED",
}

LOG_SEVERITY_MAP = {0: "DEBUG", 1: "INFO", 2: "WARNING", 3: "ERROR", 4: "CRITICAL"}
