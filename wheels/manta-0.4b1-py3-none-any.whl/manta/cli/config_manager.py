"""Simplified SDK Configuration Manager for manta-sdk.

This module provides simple configuration management for SDK operations,
using individual config files in ~/.manta/sdk/ directory with an active config system.
Matches the pattern used by manta-node config management.
"""

import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # Python < 3.11 fallback

import toml  # For writing TOML files

__all__ = ["SDKConfigManager", "SDKConfiguration"]


@dataclass
class SDKConfiguration:
    """Simple SDK configuration matching AsyncUserAPI parameters."""

    # Core AsyncUserAPI parameters (token is required)
    token: str
    host: str = "localhost"
    port: int = 50052
    cert_folder: Optional[str] = None

    # Configuration metadata
    name: str = "default"
    description: str = "SDK configuration"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def __post_init__(self):
        """Validate configuration after initialization."""
        if not self.token or self.token.strip() == "":
            raise ValueError("token is required and cannot be empty")

        if not self.host or self.host.strip() == "":
            raise ValueError("host is required and cannot be empty")

        if self.port <= 0 or self.port > 65535:
            raise ValueError("port must be a valid port number (1-65535)")


class SDKConfigManager:
    """Simple configuration manager for SDK matching node config pattern."""

    DEFAULT_CONFIG_DIR = Path.home() / ".manta" / "sdk"
    ACTIVE_CONFIG_FILE = DEFAULT_CONFIG_DIR / "active"

    def __init__(self, config_dir: Optional[Path] = None):
        """Initialize SDK configuration manager.

        Args:
            config_dir: Optional custom configuration directory
        """
        self.config_dir = Path(config_dir) if config_dir else self.DEFAULT_CONFIG_DIR
        self.active_config_file = self.config_dir / "active"
        self._lock = threading.RLock()

        # Ensure config directory exists
        self.config_dir.mkdir(parents=True, exist_ok=True)

    def _ensure_config_dir(self):
        """Ensure the configuration directory exists."""
        self.config_dir.mkdir(parents=True, exist_ok=True)

    def list_configs(self) -> List[str]:
        """List all available configuration names.

        Returns:
            List of configuration names (without .toml extension)
        """
        self._ensure_config_dir()
        configs = []

        for config_file in self.config_dir.glob("*.toml"):
            configs.append(config_file.stem)

        return sorted(configs)

    def config_exists(self, config_name: str) -> bool:
        """Check if a configuration exists.

        Args:
            config_name: Name of the configuration

        Returns:
            True if configuration exists
        """
        config_path = self.config_dir / f"{config_name}.toml"
        return config_path.exists()

    def save_config(
        self, config: SDKConfiguration, config_name: Optional[str] = None
    ) -> bool:
        """Save a configuration to file.

        Args:
            config: Configuration to save
            config_name: Name for the configuration (uses config.name if None)

        Returns:
            True if saved successfully
        """
        if config_name is None:
            config_name = config.name

        config_path = self.config_dir / f"{config_name}.toml"

        with self._lock:
            try:
                self._ensure_config_dir()

                # Update timestamps
                config.name = config_name
                config.updated_at = datetime.now().isoformat()

                # Convert to dictionary and save
                config_dict = asdict(config)

                with open(config_path, "w") as f:
                    toml.dump(config_dict, f)

                return True

            except Exception as e:
                print(f"Error saving configuration: {e}")
                return False

    def load_config(self, config_name: str) -> Optional[SDKConfiguration]:
        """Load a configuration from file.

        Args:
            config_name: Name of the configuration to load

        Returns:
            Configuration object or None if not found/invalid
        """
        config_path = self.config_dir / f"{config_name}.toml"

        if not config_path.exists():
            return None

        try:
            with open(config_path, "rb") as f:
                data = tomllib.load(f)

            # Create configuration object
            return SDKConfiguration(**data)

        except Exception as e:
            print(f"Error loading configuration '{config_name}': {e}")
            return None

    def delete_config(self, config_name: str) -> bool:
        """Delete a configuration.

        Args:
            config_name: Name of the configuration to delete

        Returns:
            True if deleted successfully
        """
        if config_name == "default":
            print("Cannot delete the default configuration")
            return False

        config_path = self.config_dir / f"{config_name}.toml"

        with self._lock:
            try:
                if config_path.exists():
                    config_path.unlink()

                # If deleted config was active, switch to default
                active_config = self.get_active_config_name()
                if active_config == config_name:
                    self.set_active_config("default")

                return True

            except Exception as e:
                print(f"Error deleting configuration: {e}")
                return False

    def get_active_config_name(self) -> str:
        """Get the name of the active configuration.

        Returns:
            Name of active configuration (defaults to 'default')
        """
        if self.active_config_file.exists():
            try:
                return self.active_config_file.read_text().strip()
            except Exception:
                pass

        return "default"

    def set_active_config(self, config_name: str) -> bool:
        """Set the active configuration.

        Args:
            config_name: Name of the configuration to make active

        Returns:
            True if set successfully
        """
        # Check if config exists
        if not self.config_exists(config_name):
            print(f"Configuration '{config_name}' not found")
            return False

        with self._lock:
            try:
                self._ensure_config_dir()
                self.active_config_file.write_text(config_name)
                return True

            except Exception as e:
                print(f"Error setting active configuration: {e}")
                return False

    def get_active_config(self) -> Optional[SDKConfiguration]:
        """Get the active configuration.

        Returns:
            Active configuration or None if not found
        """
        active_name = self.get_active_config_name()
        return self.load_config(active_name)

    def create_default_config(self) -> bool:
        """Create a default configuration if it doesn't exist.

        Returns:
            True if created successfully
        """
        if self.config_exists("default"):
            return True

        # Create minimal default config (user must provide token)
        try:
            default_config = SDKConfiguration(
                name="default",
                token="<REQUIRED_JWT_TOKEN>",  # Placeholder that will trigger validation error
                host="localhost",
                port=50052,
                description="Default SDK configuration - please set your JWT token",
            )
        except ValueError:
            # Create with bypass for initial creation
            default_config = SDKConfiguration.__new__(SDKConfiguration)
            default_config.name = "default"
            default_config.token = "<REQUIRED_JWT_TOKEN>"
            default_config.host = "localhost"
            default_config.port = 50052
            default_config.cert_folder = None
            default_config.description = (
                "Default SDK configuration - please set your JWT token"
            )
            default_config.created_at = datetime.now().isoformat()
            default_config.updated_at = datetime.now().isoformat()

        success = self.save_config(default_config, "default")
        if success:
            self.set_active_config("default")

        return success

    def create_config(
        self,
        name: str,
        token: str,
        host: str = "localhost",
        port: int = 50052,
        cert_folder: Optional[str] = None,
        description: Optional[str] = None,
    ) -> bool:
        """Create a new configuration.

        Args:
            name: Configuration name
            token: JWT authentication token
            host: Server host
            port: Server port
            cert_folder: Path to certificate folder
            description: Configuration description

        Returns:
            True if configuration created successfully
        """
        if self.config_exists(name):
            print(f"Configuration '{name}' already exists")
            return False

        try:
            config = SDKConfiguration(
                name=name,
                token=token,
                host=host,
                port=port,
                cert_folder=cert_folder,
                description=description or f"SDK configuration '{name}'",
            )

            return self.save_config(config, name)

        except ValueError as e:
            print(f"Invalid configuration: {e}")
            return False

    def update_config(self, name: str, **kwargs) -> bool:
        """Update an existing configuration.

        Args:
            name: Configuration name
            **kwargs: Fields to update

        Returns:
            True if configuration updated successfully
        """
        config = self.load_config(name)
        if not config:
            print(f"Configuration '{name}' not found")
            return False

        # Update fields
        if "token" in kwargs:
            config.token = kwargs["token"]
        if "host" in kwargs:
            config.host = kwargs["host"]
        if "port" in kwargs:
            config.port = kwargs["port"]
        if "cert_folder" in kwargs:
            config.cert_folder = kwargs["cert_folder"]
        if "description" in kwargs:
            config.description = kwargs["description"]

        config.updated_at = datetime.now().isoformat()

        try:
            # Validate updated configuration
            config.__post_init__()
            return self.save_config(config, name)
        except ValueError as e:
            print(f"Invalid configuration update: {e}")
            return False

    # delete_config method already implemented above

    # set_active_config method already implemented above

    # list_configs method already implemented above

    def get_config(self, name: Optional[str] = None) -> Optional[SDKConfiguration]:
        """Get a specific configuration or the active one.

        Args:
            name: Configuration name (uses active if None)

        Returns:
            Configuration object or None if not found
        """
        if name is None:
            return self.get_active_config()
        return self.load_config(name)

    # get_active_config method already implemented above

    def get_connection_params(
        self, config_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get connection parameters for AsyncUserAPI initialization.

        Args:
            config_name: Configuration name (uses active if None)

        Returns:
            Dictionary with connection parameters for AsyncUserAPI
        """
        config = self.get_config(config_name)
        if not config:
            return {}

        # Return parameters matching AsyncUserAPI constructor
        params = {
            "token": config.token,
            "host": config.host,
            "port": config.port,
            "cert_folder": config.cert_folder,
        }

        return params

    def validate_config(self, config: SDKConfiguration) -> List[str]:
        """Validate a configuration and return any errors.

        Args:
            config: Configuration to validate

        Returns:
            List of validation error messages (empty if valid)
        """
        errors = []

        # Token validation
        if not config.token or config.token.strip() == "":
            errors.append("Token is required")
        elif config.token.startswith("<") and config.token.endswith(">"):
            errors.append(
                "Please replace the placeholder token with your actual JWT token"
            )
        elif len(config.token) < 10:
            errors.append("Token appears to be too short for a valid JWT token")

        # Host validation
        if not config.host or config.host.strip() == "":
            errors.append("Host is required")

        # Port validation
        if config.port <= 0 or config.port > 65535:
            errors.append("Port must be a valid port number (1-65535)")

        # Certificate folder validation (if provided)
        if config.cert_folder:
            cert_path = Path(config.cert_folder).expanduser()
            if not cert_path.exists():
                errors.append(
                    f"Certificate folder does not exist: {config.cert_folder}"
                )
            elif not cert_path.is_dir():
                errors.append(
                    f"Certificate folder is not a directory: {config.cert_folder}"
                )

        return errors
