"""Base command handler interface for modular SDK commands."""

import asyncio
import traceback
from abc import ABC, abstractmethod
from typing import Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from ..config_manager import SDKConfigManager


class BaseSDKHandler(ABC):
    """Base class for SDK command handlers."""

    def __init__(self, console: Console, config_manager: SDKConfigManager):
        self.console = console
        self.config_manager = config_manager
        self.debug = False  # Can be set to True for detailed error output

    def print(self, *args, **kwargs):
        """Print with console (always available in SDK context)."""
        self.console.print(*args, **kwargs)

    def print_error(self, message: str):
        """Print error message."""
        self.console.print(f"[red]Error:[/red] {message}")

    def print_success(self, message: str):
        """Print success message."""
        self.console.print(f"[green]Success:[/green] {message}")

    def print_warning(self, message: str):
        """Print warning message."""
        self.console.print(f"[yellow]Warning:[/yellow] {message}")

    def _run_with_progress(self, async_func, message: str):
        """Run an async function with progress indication and proper error handling."""
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
                transient=True,  # Remove progress bar after completion
            ) as progress:
                task = progress.add_task(message, total=None)

                # Create event loop and run the async function
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    result = loop.run_until_complete(async_func())
                    progress.update(task, completed=True)
                    return result
                except KeyboardInterrupt:
                    progress.stop()
                    self.print_warning("Operation cancelled by user")
                    raise
                except Exception as e:
                    progress.stop()
                    # Extract meaningful error message
                    error_msg = self._extract_error_message(e)
                    self.print_error(error_msg)

                    if self.debug:
                        self.console.print(f"[dim]{traceback.format_exc()}[/dim]")

                    raise
                finally:
                    loop.close()

        except KeyboardInterrupt:
            # Re-raise keyboard interrupt so the CLI can exit properly
            raise
        except Exception:
            # Error was already printed, just return None to indicate failure
            return None

    def _extract_error_message(self, error: Exception) -> str:
        """Extract a meaningful error message from various exception types."""
        error_str = str(error)

        # Handle gRPC errors specifically
        if "StatusCode" in error_str:
            # Extract the gRPC error details
            if "UNAVAILABLE" in error_str:
                return "Service unavailable - please check if the backend services are running"
            elif "UNAUTHENTICATED" in error_str:
                return "Authentication failed - please check your JWT token"
            elif "PERMISSION_DENIED" in error_str:
                return "Permission denied - you don't have access to this resource"
            elif "NOT_FOUND" in error_str:
                return "Resource not found"
            elif "ALREADY_EXISTS" in error_str:
                return "Resource already exists"
            elif "DEADLINE_EXCEEDED" in error_str:
                return "Request timed out - the operation took too long"
            elif "CANCELLED" in error_str:
                return "Request was cancelled"
            elif "INTERNAL" in error_str:
                # Try to extract the actual error message from internal errors
                if "details =" in error_str:
                    details_start = error_str.find("details =") + 10
                    details_end = error_str.find('"', details_start + 1)
                    if details_end > details_start:
                        return f"Backend error: {error_str[details_start:details_end]}"
                return "Internal server error"

        # Handle connection errors
        if "Failed to connect" in error_str or "Connection refused" in error_str:
            return "Cannot connect to backend service - please check if services are running"

        # Handle timeout errors
        if "timeout" in error_str.lower():
            return "Operation timed out - please try again"

        # Default: return the original error message
        return error_str

    def _run_async(self, coro):
        """Run async coroutine with proper error handling."""
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                return loop.run_until_complete(coro)
            finally:
                loop.close()
        except KeyboardInterrupt:
            self.print_warning("Operation cancelled by user")
            raise
        except Exception as e:
            error_msg = self._extract_error_message(e)
            self.print_error(error_msg)
            if self.debug:
                self.console.print(f"[dim]{traceback.format_exc()}[/dim]")
            return None

    def _get_user_api(self):
        """Get configured AsyncUserAPI instance."""
        try:
            # Dynamic import of manta-sdk
            from manta.apis import AsyncUserAPI

            # Get connection parameters from config manager
            try:
                # Use config override if specified, otherwise use active config
                config_name = getattr(self, "_config_override", None)
                connection_params = self.config_manager.get_connection_params(
                    config_name
                )
            except Exception as e:
                self.print_error(f"Failed to get connection configuration: {e}")
                return None

            if not connection_params:
                self.print_error(
                    "No configuration found. Run 'manta sdk config init' first."
                )
                return None

            # Create API instance with configuration
            # Note: AsyncUserAPI constructor order is (token, host, port, cert_folder)
            cert_folder = (
                connection_params.get("cert_folder")
                if connection_params.get("use_tls", False)
                else None
            )
            return AsyncUserAPI(
                token=connection_params.get("token"),
                host=connection_params.get("host", "localhost"),
                port=connection_params.get("port", 50052),
                cert_folder=cert_folder,
            )

        except ImportError:
            self.print_error(
                "manta-sdk not available. Install with: pip install manta-sdk[api]"
            )
            return None
        except Exception as e:
            self.print_error(f"Failed to create API client: {e}")
            return None

    def set_profile_override(self, config: Optional[str]):
        """Set config override for this handler."""
        self._config_override = config

    def enable_debug(self, enabled: bool = True):
        """Enable or disable debug output."""
        self.debug = enabled

    def _format_size(self, size_bytes: int) -> str:
        """Format byte size in human readable format."""
        if size_bytes == 0:
            return "0 B"

        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} PB"

    @abstractmethod
    def add_subparsers(self, parent_parser):
        """Add command-specific subparsers to the parent parser."""
        pass

    @abstractmethod
    def handle(self, args) -> int:
        """Handle command execution."""
        pass
