"""Documentation commands for Manta CLI."""

import webbrowser

from rich.console import Console
from rich.panel import Panel
from rich.table import Table


class DocCommands:
    """Handle documentation-related CLI commands."""

    # Documentation URLs
    DOCS = {
        "main": "https://github.com/Openmesh-Network/manta",
        "sdk": "https://github.com/Openmesh-Network/manta/blob/main/manta-sdk/README.md",
        "node": "https://github.com/Openmesh-Network/manta/blob/main/manta-node/README.md",
        "api": "https://github.com/Openmesh-Network/manta/blob/main/docs/api.md",
        "examples": "https://github.com/Openmesh-Network/manta/tree/main/examples",
        "quickstart": "https://github.com/Openmesh-Network/manta/blob/main/docs/quickstart.md",
        "architecture": "https://github.com/Openmesh-Network/manta/blob/main/docs/architecture.md",
        "configuration": "https://github.com/Openmesh-Network/manta/blob/main/docs/configuration.md",
        "deployment": "https://github.com/Openmesh-Network/manta/blob/main/docs/deployment.md",
    }

    def __init__(self, console: Console):
        self.console = console

    def print(self, *args, **kwargs):
        """Print with console."""
        self.console.print(*args, **kwargs)

    def print_error(self, message: str):
        """Print error message."""
        self.console.print(f"[red]Error:[/red] {message}")

    def print_success(self, message: str):
        """Print success message."""
        self.console.print(f"[green]Success:[/green] {message}")

    def print_warning(self, message: str):
        """Print warning message."""
        self.console.print(f"[yellow]Warning:[/yellow] {message}")

    def handle(self, args) -> int:
        """Handle documentation commands."""
        if hasattr(args, "doc_topic") and args.doc_topic:
            return self.show_topic(
                args.doc_topic,
                open_browser=args.open if hasattr(args, "open") else False,
            )
        else:
            return self.show_documentation_index()

    def show_documentation_index(self) -> int:
        """Show documentation index with all available topics."""
        self.print("📚 Manta Documentation")
        self.print("=" * 25)

        # Create table of documentation topics
        table = Table(title="Available Documentation")
        table.add_column("Topic", style="cyan")
        table.add_column("Description", style="white")
        table.add_column("Command", style="magenta")

        topics = [
            ("main", "Main documentation and README", "manta doc main"),
            ("sdk", "SDK documentation", "manta doc sdk"),
            ("admin", "Admin documentation", "manta doc admin"),
            ("node", "Node documentation", "manta doc node"),
            ("api", "API reference", "manta doc api"),
            ("examples", "Example code and tutorials", "manta doc examples"),
            ("quickstart", "Quick start guide", "manta doc quickstart"),
            ("architecture", "Architecture overview", "manta doc architecture"),
            ("configuration", "Configuration guide", "manta doc configuration"),
            ("deployment", "Deployment guide", "manta doc deployment"),
        ]

        for topic, description, command in topics:
            table.add_row(topic, description, command)

        self.console.print(table)

        # Show usage help
        panel_text = (
            "[cyan]View documentation:[/cyan]\n"
            "  manta doc <topic>        - Show documentation URL\n"
            "  manta doc <topic> --open - Open in browser\n\n"
            "[cyan]Examples:[/cyan]\n"
            "  manta doc quickstart\n"
            "  manta doc api --open\n\n"
            "[cyan]Online Resources:[/cyan]\n"
            f"  Main Docs: {self.DOCS['main']}\n"
            f"  Examples: {self.DOCS['examples']}"
        )

        panel = Panel.fit(panel_text, title="How to Use")
        self.console.print(panel)

        return 0

    def show_topic(self, topic: str, open_browser: bool = False) -> int:
        """Show documentation for a specific topic."""
        topic = topic.lower()

        if topic not in self.DOCS:
            self.print_error(f"Unknown documentation topic: {topic}")
            self.print("Available topics:")
            for t in self.DOCS.keys():
                self.print(f"  • {t}")
            return 1

        url = self.DOCS[topic]

        # Create panel with documentation info
        panel_text = f"[cyan]Topic:[/cyan] {topic}\n[cyan]URL:[/cyan] {url}"

        if topic == "main":
            panel_text += "\n\n[yellow]Main documentation includes:[/yellow]\n"
            panel_text += "  • Getting started guide\n"
            panel_text += "  • Platform overview\n"
            panel_text += "  • Installation instructions\n"
            panel_text += "  • Basic usage examples"
        elif topic == "sdk":
            panel_text += "\n\n[yellow]SDK documentation includes:[/yellow]\n"
            panel_text += "  • API client usage\n"
            panel_text += "  • Task deployment\n"
            panel_text += "  • Result retrieval\n"
            panel_text += "  • Configuration management"
        elif topic == "admin":
            panel_text += "\n\n[yellow]Admin documentation includes:[/yellow]\n"
            panel_text += "  • User management\n"
            panel_text += "  • Cluster administration\n"
            panel_text += "  • System monitoring\n"
            panel_text += "  • Security settings"
        elif topic == "node":
            panel_text += "\n\n[yellow]Node documentation includes:[/yellow]\n"
            panel_text += "  • Node installation\n"
            panel_text += "  • Configuration options\n"
            panel_text += "  • Resource management\n"
            panel_text += "  • Troubleshooting"
        elif topic == "api":
            panel_text += "\n\n[yellow]API documentation includes:[/yellow]\n"
            panel_text += "  • REST API endpoints\n"
            panel_text += "  • gRPC service definitions\n"
            panel_text += "  • Authentication methods\n"
            panel_text += "  • Request/response schemas"
        elif topic == "examples":
            panel_text += "\n\n[yellow]Examples include:[/yellow]\n"
            panel_text += "  • Federated learning examples\n"
            panel_text += "  • Data processing pipelines\n"
            panel_text += "  • Multi-node deployments\n"
            panel_text += "  • Integration patterns"
        elif topic == "quickstart":
            panel_text += "\n\n[yellow]Quick start guide includes:[/yellow]\n"
            panel_text += "  • 5-minute setup\n"
            panel_text += "  • First task deployment\n"
            panel_text += "  • Basic CLI commands\n"
            panel_text += "  • Common workflows"
        elif topic == "architecture":
            panel_text += "\n\n[yellow]Architecture documentation includes:[/yellow]\n"
            panel_text += "  • System design overview\n"
            panel_text += "  • Component relationships\n"
            panel_text += "  • Communication patterns\n"
            panel_text += "  • Security architecture"
        elif topic == "configuration":
            panel_text += "\n\n[yellow]Configuration guide includes:[/yellow]\n"
            panel_text += "  • Configuration file structure\n"
            panel_text += "  • Environment variables\n"
            panel_text += "  • Profile management\n"
            panel_text += "  • Advanced settings"
        elif topic == "deployment":
            panel_text += "\n\n[yellow]Deployment guide includes:[/yellow]\n"
            panel_text += "  • Production deployment\n"
            panel_text += "  • Docker configuration\n"
            panel_text += "  • Kubernetes setup\n"
            panel_text += "  • Scaling strategies"

        panel = Panel.fit(panel_text, title=f"Documentation: {topic.capitalize()}")
        self.console.print(panel)

        if open_browser:
            self.print(f"\n🌐 Opening {url} in browser...")
            try:
                webbrowser.open(url)
                self.print_success("Browser opened successfully!")
            except Exception as e:
                self.print_error(f"Failed to open browser: {e}")
                self.print(f"Please visit: {url}")
        else:
            self.print(f"\n💡 To open in browser, use: manta doc {topic} --open")

        return 0
