"""SDK node information and status commands."""

from rich.panel import Panel
from rich.table import Table

from .base_handler import BaseSDKHandler
from ..utils import (
    enum_to_string,
    timestamp_to_string,
    extract_platform_type,
    extract_node_resources,
    NODE_STATUS_MAP,
)


class SDKNodesHandler(BaseSDKHandler):
    """Handle node-related SDK commands."""

    def add_subparsers(self, parent_parser):
        """Add node command subparsers."""
        subparsers = parent_parser.add_subparsers(
            dest="node_command", help="Node commands"
        )

        # List nodes command
        list_parser = subparsers.add_parser("list", help="List all nodes")
        list_parser.add_argument("--cluster-id", help="Filter by cluster ID")

        # Get node command
        get_parser = subparsers.add_parser("get", help="Get detailed node information")
        get_parser.add_argument("node_id", help="Node ID to get information for")

        # Add profile override to all subcommands
        for parser in [list_parser, get_parser]:
            parser.add_argument("--profile", help="Use specific profile")

    def handle(self, args) -> int:
        """Handle node commands."""
        if not args.node_command:
            self.print_error("Node command required")
            return 1

        if args.node_command == "list":
            return self.list_nodes(getattr(args, "cluster_id", None))
        elif args.node_command == "get":
            return self.get_node(args.node_id)
        else:
            self.print_error(f"Unknown node command: {args.node_command}")
            return 1

    def list_nodes(self, cluster_id: str = None) -> int:
        """List all nodes, optionally filtered by cluster."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                if cluster_id:
                    return await api.stream_and_fetch_nodes(cluster_id)
                else:
                    # Get all nodes across all clusters
                    all_nodes = []
                    clusters = await api.stream_and_fetch_clusters()
                    for cluster in clusters:
                        cluster_nodes = await api.stream_and_fetch_nodes(
                            cluster["cluster_id"]
                        )
                        all_nodes.extend(cluster_nodes)
                    return all_nodes

            message = (
                f"Fetching nodes{f' for cluster {cluster_id}' if cluster_id else ''}..."
            )
            nodes = self._run_with_progress(run, message)

            if not nodes:
                self.print("No nodes found.")
                return 0

            # Create and display nodes table
            table = Table(
                title=f"Nodes{f' (Cluster: {cluster_id})' if cluster_id else ''}"
            )
            table.add_column("Node ID", style="cyan")
            table.add_column("Status", style="green")
            table.add_column("Type", style="blue")
            table.add_column("Cluster", style="magenta")
            table.add_column("Last Seen", style="yellow")

            for node in nodes:
                # Use converter functions for consistent parsing
                status = enum_to_string(node.get("node_status", 0), NODE_STATUS_MAP)

                node_type = extract_platform_type(node.get("platform_info"))

                last_seen = timestamp_to_string(
                    node.get("updated_at") or node.get("created_at")
                )

                table.add_row(
                    node.get("node_id", "Unknown"),
                    status,
                    node_type,
                    cluster_id if cluster_id else "Unknown",
                    last_seen,
                )

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to list nodes: {e}")
            return 1

    def get_node(self, node_id: str) -> int:
        """Get detailed node information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                # Since get_node needs cluster_id, we need to find which cluster the node belongs to
                clusters = await api.stream_and_fetch_clusters()
                for cluster in clusters:
                    nodes = await api.stream_and_fetch_nodes(cluster["cluster_id"])
                    for node in nodes:
                        if node.get("node_id") == node_id:
                            # Found the node, now get its detailed info
                            return await api.get_node(cluster["cluster_id"], node_id)
                raise ValueError(f"Node {node_id} not found in any cluster")

            node = self._run_with_progress(run, f"Fetching node {node_id}...")

            # Extract and format fields using converters
            status = enum_to_string(node.get("node_status", 0), NODE_STATUS_MAP)

            node_type = extract_platform_type(node.get("platform_info"))

            last_seen = timestamp_to_string(
                node.get("updated_at") or node.get("created_at")
            )

            # Extract resource information
            resources = extract_node_resources(node.get("metrics_snapshot"))

            # Display node details
            panel = Panel.fit(
                f"[cyan]Node ID:[/cyan] {node.get('node_id', 'Unknown')}\n"
                f"[cyan]Status:[/cyan] {status}\n"
                f"[cyan]Type:[/cyan] {node_type}\n"
                f"[cyan]Cluster:[/cyan] {node.get('cluster_id', 'Unknown')}\n"
                f"[cyan]Resources:[/cyan] CPU: {resources['cpu_count']}, "
                f"RAM: {resources['memory_gb']}GB\n"
                f"[cyan]Last Seen:[/cyan] {last_seen}",
                title=f"Node: {node_id}",
            )
            self.console.print(panel)

            return 0

        except Exception as e:
            self.print_error(f"Failed to get node details: {e}")
            return 1
