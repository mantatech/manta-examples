"""Installation helper commands for Manta CLI."""

import subprocess
import sys
from typing import List

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm
from rich.table import Table

from ..component_detector import ComponentDetector


class InstallCommands:
    """Handle installation-related CLI commands."""

    def __init__(self, detector: ComponentDetector, console: Console = None):
        self.detector = detector
        self.console = console

    def print(self, *args, **kwargs):
        """Print with console if available."""
        self.console.print(*args, **kwargs)

    def print_error(self, message: str):
        """Print error message."""
        self.console.print(f"[red]Error:[/red] {message}")

    def print_success(self, message: str):
        """Print success message."""
        self.console.print(f"[green]Success:[/green] {message}")

    def print_warning(self, message: str):
        """Print warning message."""
        self.console.print(f"[yellow]Warning:[/yellow] {message}")

    def handle(self, args) -> int:
        """Handle installation commands."""
        if hasattr(args, "install_command") and args.install_command:
            if args.install_command == "wizard":
                return self.run_installation_wizard()
            elif args.install_command == "check":
                return self.check_requirements()
            elif args.install_command == "component":
                # Handle component installation with name
                if hasattr(args, "name") and args.name:
                    return self.install_component(args.name)
                else:
                    self.print_error("Component name is required")
                    return 1
            elif args.install_command == "sdk":
                return self.install_component("sdk")
            elif args.install_command == "admin":
                return self.install_component("admin")
            elif args.install_command == "node":
                return self.install_component("node")
            elif args.install_command == "all":
                return self.install_all_components()
            else:
                self.print_error(f"Unknown install command: {args.install_command}")
                return 1
        else:
            # Show installation help
            return self.show_installation_help()

    def show_installation_help(self) -> int:
        """Show installation help and current status."""
        self.print("📦 Manta Installation Guide")
        self.print("=" * 30)

        # Refresh detection
        self.detector.refresh()

        # Show current status
        table = Table(title="Component Status")
        table.add_column("Component", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Install Command", style="magenta")

        for comp_name in self.detector.list_components():
            comp_info = self.detector.get_component_info(comp_name)
            if comp_info:
                status = "✅ Installed" if comp_info.installed else "❌ Not Installed"
                install_cmd = (
                    self.detector.get_installation_command(comp_name)
                    if not comp_info.installed
                    else "-"
                )
                table.add_row(comp_info.name, status, install_cmd)

        self.console.print(table)

        # Show available commands
        self.print("\n💡 Available Commands:")
        self.print("  • manta install wizard     - Interactive installation wizard")
        self.print("  • manta install check      - Check system requirements")
        self.print("  • manta install sdk        - Install Manta SDK")
        self.print("  • manta install admin      - Install Manta Admin")
        self.print("  • manta install node       - Install Manta Node")
        self.print("  • manta install all        - Install all components")

        return 0

    def run_installation_wizard(self) -> int:
        """Run interactive installation wizard."""
        self.print("🧙 Manta Installation Wizard")
        self.print("=" * 30)

        # Check requirements first
        self.print("\n1️⃣  Checking system requirements...")
        if not self._check_python_version():
            return 1

        if not self._check_pip():
            return 1

        self.print_success("System requirements met!")

        # Detect missing components
        self.detector.refresh()
        summary = self.detector.get_status_summary()

        if not summary["missing"]:
            self.print_success("\n✅ All components are already installed!")
            return 0

        # Ask what to install
        self.print(f"\n2️⃣  Found {len(summary['missing'])} missing component(s):")
        for comp in summary["missing"]:
            self.print(f"  • {comp}")

        if Confirm.ask("\nWould you like to install all missing components?"):
            return self._install_components(summary["missing"])
        else:
            # Let user select specific components
            to_install = []
            for comp in summary["missing"]:
                if Confirm.ask(f"Install {comp}?"):
                    to_install.append(comp)

            if to_install:
                return self._install_components(to_install)
            else:
                self.print("No components selected for installation.")
                return 0

    def check_requirements(self) -> int:
        """Check system requirements."""
        self.print("🔍 Checking System Requirements")
        self.print("=" * 35)

        all_good = True

        # Check Python version
        if not self._check_python_version():
            all_good = False

        # Check pip
        if not self._check_pip():
            all_good = False

        # Check git
        if not self._check_git():
            all_good = False

        # Check Docker (optional)
        self._check_docker()

        if all_good:
            self.print_success("\n✅ All requirements met!")
        else:
            self.print_error(
                "\n❌ Some requirements are not met. Please install missing dependencies."
            )
            return 1

        return 0

    def install_component(self, component: str) -> int:
        """Install a specific component."""
        comp_info = self.detector.get_component_info(component)

        if not comp_info:
            self.print_error(f"Unknown component: {component}")
            return 1

        if comp_info.installed:
            self.print_success(f"{comp_info.name} is already installed!")
            return 0

        return self._install_components([component])

    def install_all_components(self) -> int:
        """Install all missing components."""
        self.detector.refresh()
        summary = self.detector.get_status_summary()

        if not summary["missing"]:
            self.print_success("All components are already installed!")
            return 0

        return self._install_components(summary["missing"])

    def _install_components(self, components: List[str]) -> int:
        """Install multiple components."""
        self.print(f"\n📦 Installing {len(components)} component(s)...")

        failed = []

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
        ) as progress:
            for comp in components:
                task = progress.add_task(f"Installing {comp}...", total=None)

                install_cmd = self.detector.get_installation_command(comp)
                if not install_cmd:
                    progress.update(
                        task,
                        description=f"[red]Failed to get install command for {comp}",
                    )
                    failed.append(comp)
                    continue

                try:
                    # Run pip install
                    result = subprocess.run(
                        [sys.executable, "-m", "pip", "install"]
                        + install_cmd.split()[2:],
                        capture_output=True,
                        text=True,
                        check=False,
                    )

                    if result.returncode == 0:
                        progress.update(
                            task, description=f"[green]✅ {comp} installed successfully"
                        )
                    else:
                        progress.update(
                            task, description=f"[red]❌ Failed to install {comp}"
                        )
                        failed.append(comp)
                        if result.stderr:
                            self.print_error(f"Error: {result.stderr}")

                except Exception as e:
                    progress.update(
                        task, description=f"[red]❌ Error installing {comp}: {e}"
                    )
                    failed.append(comp)

        # Show summary
        if failed:
            self.print_error(
                f"\n❌ Failed to install {len(failed)} component(s): {', '.join(failed)}"
            )
            return 1
        else:
            self.print_success(
                f"\n✅ Successfully installed {len(components)} component(s)!"
            )
            self.print("\n💡 Next steps:")
            self.print("  • Configure the platform: manta config init --interactive")
            self.print("  • View documentation: manta doc")
            return 0

    def _check_python_version(self) -> bool:
        """Check Python version requirement."""
        python_version = f"{sys.version_info.major}.{sys.version_info.minor}"
        required_version = "3.9"

        if sys.version_info.major == 3 and sys.version_info.minor >= 9:
            self.print(f"✅ Python {python_version} (>= {required_version} required)")
            return True
        else:
            self.print_error(
                f"❌ Python {python_version} (>= {required_version} required)"
            )
            return False

    def _check_pip(self) -> bool:
        """Check if pip is available."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "--version"],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
            if result.returncode == 0:
                pip_version = result.stdout.split()[1] if result.stdout else "Unknown"
                self.print(f"✅ pip {pip_version}")
                return True
            else:
                self.print_error("❌ pip is not available")
                return False
        except Exception:
            self.print_error("❌ pip is not available")
            return False

    def _check_git(self) -> bool:
        """Check if git is available."""
        try:
            result = subprocess.run(
                ["git", "--version"],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
            if result.returncode == 0:
                git_version = result.stdout.strip()
                self.print(f"✅ {git_version}")
                return True
            else:
                self.print_warning("⚠️  Git is not available (optional)")
                return True  # Git is optional
        except Exception:
            self.print_warning("⚠️  Git is not available (optional)")
            return True  # Git is optional

    def _check_docker(self) -> bool:
        """Check if Docker is available."""
        try:
            result = subprocess.run(
                ["docker", "--version"],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
            if result.returncode == 0:
                docker_version = result.stdout.strip()
                self.print(f"✅ {docker_version} (optional)")
                return True
            else:
                self.print_warning("⚠️  Docker is not available (optional)")
                return True  # Docker is optional
        except Exception:
            self.print_warning("⚠️  Docker is not available (optional)")
            return True  # Docker is optional
