"""SDK module management commands."""

from pathlib import Path
from typing import Optional

from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table
from rich.tree import Tree

from .base_handler import BaseSDKHandler


class SDKModuleHandler(BaseSDKHandler):
    """Handle module-related SDK commands."""

    def add_subparsers(self, parent_parser):
        """Add module command subparsers."""
        self.parser = parent_parser  # Store parser reference
        subparsers = parent_parser.add_subparsers(
            dest="module_command", help="Module commands"
        )

        # List modules command
        list_parser = subparsers.add_parser("list", help="List all user modules")

        # List module IDs command
        list_ids_parser = subparsers.add_parser("list-ids", help="List module IDs only")

        # Show module command
        show_parser = subparsers.add_parser(
            "show", help="Show detailed module information"
        )
        show_parser.add_argument("module_id", help="Module ID to show")

        # Upload/Push module command (using 'push' for consistency)
        push_parser = subparsers.add_parser("push", help="Upload a module from file")
        push_parser.add_argument("module_file", help="Path to module file")
        push_parser.add_argument("--module-id", help="Optional module ID")

        # Update module command
        update_parser = subparsers.add_parser(
            "update", help="Update an existing module"
        )
        update_parser.add_argument("module_id", help="Module ID to update")
        update_parser.add_argument("module_file", help="Path to new module file")

        # Delete module command
        delete_parser = subparsers.add_parser("delete", help="Delete a module")
        delete_parser.add_argument("module_id", help="Module ID to delete")
        delete_parser.add_argument(
            "--force", action="store_true", help="Skip confirmation"
        )

        # Download/Get module command (using 'get' for consistency)
        get_parser = subparsers.add_parser("get", help="Download a module to file")
        get_parser.add_argument("module_id", help="Module ID to download")
        get_parser.add_argument("--output", help="Output file or directory path")

        # Add profile override to all subcommands
        for parser in [
            list_parser,
            list_ids_parser,
            show_parser,
            push_parser,
            update_parser,
            delete_parser,
            get_parser,
        ]:
            parser.add_argument("--profile", help="Use specific profile")

    def handle(self, args) -> int:
        """Handle module commands."""
        if not args.module_command:
            if hasattr(self, "parser"):
                self.parser.print_help()
            return 0  # Return 0 for help display

        if args.module_command == "list":
            return self.list_modules()
        elif args.module_command == "list-ids":
            return self.list_module_ids()
        elif args.module_command == "show":
            return self.show_module(args.module_id)
        elif args.module_command == "push":
            return self.upload_module(
                args.module_file, getattr(args, "module_id", None)
            )
        elif args.module_command == "update":
            return self.update_module(args.module_id, args.module_file)
        elif args.module_command == "delete":
            return self.delete_module(args.module_id, getattr(args, "force", False))
        elif args.module_command == "get":
            return self.download_module(args.module_id, getattr(args, "output", None))
        else:
            self.print_error(f"Unknown module command: {args.module_command}")
            return 1

    def list_modules(self) -> int:
        """List all modules for the user."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                modules = await api.stream_and_fetch_modules()
                return modules

            modules = self._run_with_progress(run, "Fetching modules...")

            if modules is None:
                return 1

            if not modules:
                self.print("No modules found.")
                return 0

            # Display modules
            table = Table(title="User Modules")
            table.add_column("Module ID", style="cyan")
            table.add_column("Name", style="blue")
            table.add_column("Type", style="green")
            table.add_column("Size", style="magenta")
            table.add_column("Created", style="yellow")

            for module in modules:
                # UserAPI returns Module objects (not dicts, not protos)
                module_id = (
                    module.module_id
                    if hasattr(module, "module_id") and module.module_id
                    else ""
                )
                name = (
                    module.name
                    if hasattr(module, "name") and module.name
                    else "Unknown"
                )
                image = (
                    module.image
                    if hasattr(module, "image") and module.image
                    else "Python"
                )

                # Get size from python_files if available
                data_size = 0
                if hasattr(module, "python_files") and module.python_files:
                    # Sum the size of all files
                    data_size = sum(
                        len(content) for content in module.python_files.values()
                    )

                table.add_row(
                    module_id,
                    name,
                    image,
                    self._format_size(data_size),
                    "N/A",  # Created timestamp not available
                )

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to list modules: {e}")
            return 1

    def list_module_ids(self) -> int:
        """List module IDs only."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.list_module_ids()

            module_ids = self._run_with_progress(run, "Fetching module IDs...")

            if module_ids is None:
                return 1

            if not module_ids:
                self.print("No modules found.")
                return 0

            self.print(f"Found {len(module_ids)} modules:")
            for module_id in module_ids:
                self.print(f"  {module_id}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to list module IDs: {e}")
            return 1

    def show_module(self, module_id: str) -> int:
        """Show detailed module information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.get_module(module_id)

            module = self._run_with_progress(run, "Fetching module details...")

            if module is None:
                return 1

            # Display module details
            # UserAPI returns Module objects
            name = module.name if hasattr(module, "name") and module.name else "Unknown"
            image = (
                module.image if hasattr(module, "image") and module.image else "Python"
            )

            # Get size from python_files if available
            data_size = 0
            if hasattr(module, "python_files") and module.python_files:
                data_size = sum(
                    len(content) for content in module.python_files.values()
                )

            panel = Panel.fit(
                f"[cyan]Module ID:[/cyan] {module_id}\n"
                f"[cyan]Name:[/cyan] {name}\n"
                f"[cyan]Type:[/cyan] {image}\n"
                f"[cyan]Size:[/cyan] {self._format_size(data_size)}\n"
                f"[cyan]Created:[/cyan] N/A",
                title=f"Module: {module_id}",
            )
            self.console.print(panel)

            return 0

        except Exception as e:
            self.print_error(f"Failed to get module details: {e}")
            return 1

    def upload_module(self, module_file: str, module_id: Optional[str] = None) -> int:
        """Upload a module from file."""
        api = self._get_user_api()
        if not api:
            return 1

        try:
            # Import Module class
            from manta.apis.module import Module

            # Validate file path
            module_path = Path(module_file)
            if not module_path.exists():
                self.print_error(f"Module file not found: {module_file}")
                return 1

            # Get image name from user if not provided
            default_image = "python:3.9-slim"
            image = Prompt.ask("Container image", default=default_image)

            # Create Module object
            module = Module(
                python_program=module_path,
                image=image,
                name=module_path.stem if module_path.is_file() else module_path.name,
            )

            async def run():
                return await api.send_module(module)

            result_id = self._run_with_progress(
                run, f"Uploading module from {module_file}..."
            )

            if result_id is None:
                return 1

            self.print_success(f"Module uploaded successfully with ID: {result_id}")
            return 0

        except FileNotFoundError:
            self.print_error(f"Module file not found: {module_file}")
            return 1
        except PermissionError:
            self.print_error(f"Permission denied reading file: {module_file}")
            return 1
        except Exception as e:
            self.print_error(f"Failed to upload module: {e}")
            return 1

    def update_module(self, module_id: str, module_file: str) -> int:
        """Update an existing module."""
        api = self._get_user_api()
        if not api:
            return 1

        try:
            # Import Module class
            from manta.apis.module import Module

            # Validate module_id parameter
            if not module_id:
                self.print_error("Module ID is required for update operation")
                return 1

            # Validate file path
            module_path = Path(module_file)
            if not module_path.exists():
                self.print_error(f"Module file not found: {module_file}")
                return 1

            # First verify the module exists by trying to get it
            async def check_module_exists():
                try:
                    return await api.get_module(module_id)
                except Exception:
                    return None

            existing_module = self._run_with_progress(
                check_module_exists, "Checking if module exists..."
            )

            if existing_module is None:
                # Error during fetch, not just missing module
                return 1

            if not existing_module:
                self.print_error(f"Module with ID '{module_id}' not found")
                return 1

            # Get image name - use existing image as default or prompt for new one
            existing_image = getattr(existing_module, "image", "python:3.9-slim")
            image = Prompt.ask("Container image", default=existing_image)

            # Create updated Module object
            module = Module(
                python_program=module_path,
                image=image,
                name=module_path.stem if module_path.is_file() else module_path.name,
            )

            async def run():
                return await api.update_module(module, module_id)

            result_id = self._run_with_progress(run, f"Updating module {module_id}...")

            if result_id is None:
                return 1

            self.print_success(f"Module updated successfully: {result_id}")
            return 0

        except FileNotFoundError:
            self.print_error(f"Module file not found: {module_file}")
            return 1
        except PermissionError:
            self.print_error(f"Permission denied reading file: {module_file}")
            return 1
        except Exception as e:
            self.print_error(f"Failed to update module: {e}")
            return 1

    def delete_module(self, module_id: str, force: bool = False) -> int:
        """Delete a module."""
        if not force:
            confirm = Confirm.ask(
                f"Are you sure you want to delete module '{module_id}'?"
            )
            if not confirm:
                self.print("Operation cancelled.")
                return 0

        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.remove_module(module_id)

            result = self._run_with_progress(run, "Deleting module...")

            if result is None:
                return 1

            self.print_success("Module deleted successfully")
            return 0

        except Exception as e:
            self.print_error(f"Failed to delete module: {e}")
            return 1

    def download_module(self, module_id: str, output_file: Optional[str] = None) -> int:
        """Download a module to file."""
        api = self._get_user_api()
        if not api:
            return 1

        try:
            # Validate module_id parameter
            if not module_id:
                self.print_error("Module ID is required for download operation")
                return 1

            # Fetch module from server
            async def run():
                return await api.get_module(module_id)

            module = self._run_with_progress(run, f"Downloading module {module_id}...")

            if module is None:
                return 1

            # Check if module has python_files (from Module.from_proto)
            if not hasattr(module, "python_files") or not module.python_files:
                self.print_error("Module contains no python files to download")
                return 1

            # Determine output path
            if output_file:
                output_path = Path(output_file)
            else:
                # Use module name or ID as default filename
                module_name = getattr(module, "name", None) or module_id
                if len(module.python_files) == 1:
                    # Single file - use the filename from the module
                    filename = list(module.python_files.keys())[0]
                    output_path = Path(filename)
                else:
                    # Multiple files - create a directory
                    output_path = Path(f"{module_name}_module")

            # Handle single file vs directory
            if len(module.python_files) == 1:
                # Single file download
                filename, content = next(iter(module.python_files.items()))

                # If output_file is a directory, put file inside it
                if output_path.is_dir():
                    output_path = output_path / filename

                # Check for conflicts
                if output_path.exists():
                    overwrite = Confirm.ask(
                        f"File '{output_path}' already exists. Overwrite?"
                    )
                    if not overwrite:
                        self.print("Download cancelled.")
                        return 0

                # Write single file
                try:
                    output_path.parent.mkdir(parents=True, exist_ok=True)
                    output_path.write_text(content, encoding="utf-8")
                    self.print_success(
                        f"Module downloaded to: {output_path.absolute()}"
                    )
                except Exception as e:
                    self.print_error(f"Failed to write file: {e}")
                    return 1

            else:
                # Multiple files - create directory structure
                if output_path.exists() and output_path.is_dir():
                    overwrite = Confirm.ask(
                        f"Directory '{output_path}' already exists. Continue?"
                    )
                    if not overwrite:
                        self.print("Download cancelled.")
                        return 0
                elif output_path.exists():
                    self.print_error(
                        f"Path '{output_path}' exists and is not a directory"
                    )
                    return 1

                # Create directory and write all files
                try:
                    output_path.mkdir(parents=True, exist_ok=True)

                    files_written = 0
                    for filename, content in module.python_files.items():
                        file_path = output_path / filename

                        # Create subdirectories if needed
                        file_path.parent.mkdir(parents=True, exist_ok=True)

                        # Write file
                        file_path.write_text(content, encoding="utf-8")
                        files_written += 1

                    self.print_success(
                        f"Module downloaded: {files_written} files written to {output_path.absolute()}"
                    )

                    # Show file structure
                    tree = Tree(f"📁 {output_path.name}")
                    for filename in sorted(module.python_files.keys()):
                        tree.add(f"📄 {filename}")
                    self.console.print(tree)

                except Exception as e:
                    self.print_error(f"Failed to write files: {e}")
                    return 1

            return 0

        except Exception as e:
            self.print_error(f"Failed to download module: {e}")
            return 1
