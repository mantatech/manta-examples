"""Status display commands for Manta CLI."""

import subprocess
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..component_detector import ComponentDetector


class StatusCommands:
    """Handle status-related CLI commands."""

    def __init__(self, detector: ComponentDetector, console: Console):
        self.detector = detector
        self.console = console

    def print(self, *args, **kwargs):
        """Print with console if available."""
        self.console.print(*args, **kwargs)

    def print_error(self, message: str):
        """Print error message."""
        self.console.print(f"[red]Error:[/red] {message}")

    def print_success(self, message: str):
        """Print success message."""
        self.console.print(f"[green]Success:[/green] {message}")

    def print_warning(self, message: str):
        """Print warning message."""
        self.console.print(f"[yellow]Warning:[/yellow] {message}")

    def handle(self, args) -> int:
        """Handle status commands."""
        if hasattr(args, "status_command") and args.status_command:
            if args.status_command == "installation":
                return self.show_installation_status()
            elif args.status_command == "system":
                return self.show_system_status()
            elif args.status_command == "services":
                return self.show_services_status()
            else:
                self.print_error(f"Unknown status command: {args.status_command}")
                return 1
        else:
            # Default: show general status
            return self.show_general_status()

    def show_general_status(self) -> int:
        """Show general Manta platform status."""
        self.print("🔍 Manta Platform Status")
        self.print("=" * 30)

        # Refresh component detection
        self.detector.refresh()

        # Show installation summary
        summary = self.detector.get_status_summary()

        # Components table
        table = Table(title="Installed Components")
        table.add_column("Component", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Version", style="blue")
        table.add_column("Capabilities", style="magenta")

        for _, comp_info in self.detector._components.items():
            status = "✅ Installed" if comp_info.installed else "❌ Missing"
            version = comp_info.version if comp_info.installed else "-"
            capabilities = (
                ", ".join(list(comp_info.capabilities)[:3])
                if comp_info.capabilities
                else "-"
            )
            if len(comp_info.capabilities) > 3:
                capabilities += "..."

            table.add_row(comp_info.name, status, version, capabilities)

        self.console.print(table)

        # Summary panel
        coverage = summary["installation_coverage"] * 100
        panel_text = (
            f"[cyan]Total Components:[/cyan] {summary['total_components']}\n"
            f"[green]Installed:[/green] {len(summary['installed'])}\n"
            f"[red]Missing:[/red] {len(summary['missing'])}\n"
            f"[blue]Coverage:[/blue] {coverage:.1f}%"
        )

        if summary["missing"]:
            panel_text += "\n\n[yellow]Missing Components:[/yellow]\n"
            for comp in summary["missing"]:
                panel_text += f"  • {comp}\n"
            panel_text = panel_text.rstrip("\n")

        panel = Panel.fit(panel_text, title="Installation Summary")
        self.console.print(panel)

        # Show next steps
        if summary["missing"]:
            self.print("\n💡 Next Steps:")
            self.print("  • Install missing components: manta install wizard")
            self.print("  • View installation help: manta install --help")
        else:
            self.print_success("\n✅ All components installed successfully!")
            self.print("💡 Next Steps:")
            self.print("  • Configure the platform: manta config init --interactive")
            self.print("  • View documentation: manta doc")

        return 0

    def show_installation_status(self) -> int:
        """Show detailed installation status."""
        self.print("📦 Installation Status")
        self.print("=" * 25)

        # Refresh component detection
        self.detector.refresh()

        # Detailed table
        table = Table(title="Component Installation Details")
        table.add_column("Component", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Version", style="blue")
        table.add_column("Install Command", style="magenta")

        for _, comp_info in self.detector._components.items():
            status = "✅ Installed" if comp_info.installed else "❌ Missing"
            version = comp_info.version if comp_info.installed else "-"

            install_cmd = (
                "-"
                if comp_info.installed
                else self.detector.get_installation_command(comp_info.name)
            )

            table.add_row(comp_info.name, status, version, install_cmd)

        self.console.print(table)

        return 0

    def show_system_status(self) -> int:
        """Show system-level status information."""
        self.print("🖥️  System Status")
        self.print("=" * 20)

        try:
            # Python version
            python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

            # Pip version
            pip_version = "Unknown"
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "--version"],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if result.returncode == 0:
                    pip_version = (
                        result.stdout.split()[1] if result.stdout else "Unknown"
                    )
            except Exception:
                pass

            system_info = (
                f"[cyan]Python Version:[/cyan] {python_version}\n"
                f"[cyan]Python Executable:[/cyan] {sys.executable}\n"
                f"[cyan]Pip Version:[/cyan] {pip_version}\n"
                f"[cyan]Platform:[/cyan] {sys.platform}"
            )

            panel = Panel.fit(system_info, title="System Information")
            self.console.print(panel)

            return 0

        except Exception as e:
            self.print_error(f"Failed to get system status: {e}")
            return 1

    def show_services_status(self) -> int:
        """Show services status (Docker containers, processes, etc.)."""
        self.print("🔧 Services Status")
        self.print("=" * 22)

        services_status = []

        # Check Docker
        docker_available = self._check_docker()
        services_status.append(
            ("Docker", "Available" if docker_available else "Not Available")
        )

        # Check Manta containers (if Docker is available)
        containers = []
        if docker_available:
            containers = self._check_manta_containers()

        # Services table
        table = Table(title="System Services")
        table.add_column("Service", style="cyan")
        table.add_column("Status", style="green")

        for service, status in services_status:
            table.add_row(service, status)

        self.console.print(table)

        # Containers table (if any)
        if containers:
            container_table = Table(title="Manta Containers")
            container_table.add_column("Container", style="cyan")
            container_table.add_column("Status", style="green")
            container_table.add_column("Image", style="blue")

            for container in containers:
                container_table.add_row(
                    container["name"], container["status"], container["image"]
                )

            self.console.print(container_table)

        # Show guidance
        if not docker_available:
            self.print_warning(
                "\n⚠️  Docker is not available. Some Manta features may be limited."
            )
            self.print("To install Docker: https://docs.docker.com/get-docker/")

        return 0

    def _check_docker(self) -> bool:
        """Check if Docker is available."""
        try:
            result = subprocess.run(
                ["docker", "--version"],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            return False

    def _check_manta_containers(self) -> list:
        """Check status of Manta Docker containers."""
        containers = []

        try:
            # List containers with manta in the name
            result = subprocess.run(
                [
                    "docker",
                    "ps",
                    "-a",
                    "--filter",
                    "name=manta",
                    "--format",
                    "table {{.Names}}\t{{.Status}}\t{{.Image}}",
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=10,
            )

            if result.returncode == 0 and result.stdout:
                lines = result.stdout.strip().split("\n")[1:]  # Skip header
                for line in lines:
                    if line.strip():
                        parts = line.split("\t")
                        if len(parts) >= 3:
                            containers.append(
                                {
                                    "name": parts[0],
                                    "status": parts[1],
                                    "image": parts[2],
                                }
                            )

        except Exception:
            pass

        return containers
