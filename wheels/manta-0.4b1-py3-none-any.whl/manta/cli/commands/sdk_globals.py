"""SDK globals retrieval and management commands."""

import json
import signal
import time

from rich.table import Table

from .base_handler import BaseSDKHandler


class SDKGlobalsHandler(BaseSDKHandler):
    """Handle globals-related SDK commands."""

    def add_subparsers(self, parent_parser):
        """Add globals command subparsers."""
        self.parser = parent_parser  # Store parser reference
        subparsers = parent_parser.add_subparsers(
            dest="globals_command", help="Globals commands"
        )

        # List tags command
        list_tags_parser = subparsers.add_parser(
            "list-tags", help="List available global tags for a swarm"
        )
        list_tags_parser.add_argument(
            "swarm_id", help="Swarm ID to list global tags for"
        )

        # Get globals command
        get_parser = subparsers.add_parser("get", help="Get globals for a swarm")
        get_parser.add_argument("swarm_id", help="Swarm ID to get globals for")
        get_parser.add_argument(
            "--tag", default="latest", help="Global tag (default: latest)"
        )

        # Export globals command
        export_parser = subparsers.add_parser("export", help="Export globals to file")
        export_parser.add_argument("swarm_id", help="Swarm ID to export globals for")
        export_parser.add_argument(
            "--tag", default="latest", help="Global tag (default: latest)"
        )
        export_parser.add_argument("--output", required=True, help="Output file path")

        # Stream globals command
        stream_parser = subparsers.add_parser(
            "stream", help="Stream globals in real-time"
        )
        stream_parser.add_argument("swarm_id", help="Swarm ID to stream globals for")
        stream_parser.add_argument(
            "--tag", default="latest", help="Global tag (default: latest)"
        )

        # Add profile override to all subcommands
        for parser in [list_tags_parser, get_parser, export_parser, stream_parser]:
            parser.add_argument("--profile", help="Use specific profile")

    def handle(self, args) -> int:
        """Handle globals commands."""
        if not args.globals_command:
            if hasattr(self, "parser"):
                self.parser.print_help()
            return 0  # Return 0 for help display

        if args.globals_command == "list-tags":
            return self.list_tags(args.swarm_id)
        elif args.globals_command == "get":
            return self.get_globals(args.swarm_id, getattr(args, "tag", "latest"))
        elif args.globals_command == "export":
            return self.export_globals(
                args.swarm_id, getattr(args, "tag", "latest"), args.output
            )
        elif args.globals_command == "stream":
            return self.stream_globals(args.swarm_id, getattr(args, "tag", "latest"))
        else:
            self.print_error(f"Unknown globals command: {args.globals_command}")
            return 1

    def list_tags(self, swarm_id: str) -> int:
        """List available global tags for a swarm."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.list_global_tags(swarm_id)

            tags_info = self._run_with_progress(
                run, f"Fetching global tags for swarm {swarm_id}..."
            )

            if tags_info is None:
                return 1

            if not tags_info or not tags_info.get("tags"):
                self.print("No global tags found for this swarm.")
                return 0

            # Display tags in a table
            table = Table(title=f"Global Tags for Swarm: {swarm_id}")
            table.add_column("Tag", style="cyan")
            table.add_column("Count", style="green")
            table.add_column("Total Size", style="yellow")
            table.add_column("Last Updated", style="blue")

            tags = tags_info.get("tags", {})
            for tag, tag_data in tags.items():
                count = tag_data.get("count", 0)
                size = tag_data.get("total_size", 0)
                last_updated = tag_data.get("last_updated", "Unknown")

                table.add_row(tag, str(count), self._format_size(size), last_updated)

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to list global tags: {e}")
            return 1

    def get_globals(self, swarm_id: str, tag: str = "latest") -> int:
        """Get globals for a swarm."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                # Use select_global to get globals data
                globals_data = []
                async for global_item in api.select_global(swarm_id, tag):
                    globals_data.append(global_item)
                return globals_data

            globals_data = self._run_with_progress(
                run, f"Fetching globals for swarm {swarm_id}..."
            )

            if globals_data is None:
                return 1

            if not globals_data:
                self.print("No globals found.")
                return 0

            # Display globals
            table = Table(title=f"Globals for Swarm: {swarm_id} (Tag: {tag})")
            table.add_column("Global ID", style="cyan")
            table.add_column("Type", style="blue")
            table.add_column("Size", style="green")
            table.add_column("Created", style="yellow")

            for global_item in globals_data:
                data = global_item.get("data", {})
                data_size = len(json.dumps(data)) if data else 0

                table.add_row(
                    global_item.get("global_id", "Unknown"),
                    global_item.get("global_type", "Unknown"),
                    self._format_size(data_size),
                    global_item.get("created_at", "Unknown"),
                )

            self.console.print(table)

            # Show first few globals as samples
            self.print("\nSample Globals:")
            for i, global_item in enumerate(globals_data[:3]):
                self.print(f"Global {i + 1}:")
                self.print(json.dumps(global_item.get("data", {}), indent=2))
                if i < 2 and i < len(globals_data) - 1:
                    self.print("-" * 40)

            return 0

        except Exception as e:
            self.print_error(f"Failed to get globals: {e}")
            return 1

    def export_globals(self, swarm_id: str, tag: str, output_file: str) -> int:
        """Export globals to a file."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                # Use select_global to get globals data
                globals_data = []
                async for global_item in api.select_global(swarm_id, tag):
                    globals_data.append(global_item)
                return globals_data

            globals_data = self._run_with_progress(
                run, "Fetching globals for export..."
            )

            if globals_data is None:
                return 1

            if not globals_data:
                self.print_error("No globals found")
                return 1

            # Write to file
            with open(output_file, "w") as f:
                json.dump(globals_data, f, indent=2)

            self.print_success(f"Globals exported to {output_file}")
            return 0

        except Exception as e:
            self.print_error(f"Export failed: {e}")
            return 1

    def stream_globals(self, swarm_id: str, tag: str = "latest") -> int:
        """Stream globals in real-time."""
        api = self._get_user_api()
        if not api:
            return 1

        self.print(f"Streaming globals for swarm: {swarm_id} (Tag: {tag})")
        self.print("Press Ctrl+C to stop streaming...")

        try:
            # Set up signal handler for graceful shutdown
            shutdown_flag = False

            def signal_handler(sig, frame):
                nonlocal shutdown_flag
                shutdown_flag = True

            signal.signal(signal.SIGINT, signal_handler)

            last_global_count = 0

            while not shutdown_flag:
                try:

                    async def get_globals():
                        globals_data = []
                        async for global_item in api.select_global(swarm_id, tag):
                            globals_data.append(global_item)
                        return globals_data

                    globals_data = self._run_async(get_globals())

                    # Show new globals since last check
                    if globals_data and len(globals_data) > last_global_count:
                        new_globals = globals_data[last_global_count:]

                        for global_item in new_globals:
                            timestamp = global_item.get("created_at", "unknown")
                            data = global_item.get("data", {})
                            self.print(f"[{timestamp}] {json.dumps(data, indent=2)}")

                        last_global_count = len(globals_data)

                    time.sleep(5)  # Wait 5 seconds before next poll

                except KeyboardInterrupt:
                    self.print("\nStreaming stopped.")
                    return 130  # KeyboardInterrupt exit code

        except Exception as e:
            self.print_error(f"Streaming failed: {e}")
            return 1

    def _format_size(self, size: int) -> str:
        """Format byte size to human readable string."""
        for unit in ["B", "KB", "MB", "GB"]:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"
