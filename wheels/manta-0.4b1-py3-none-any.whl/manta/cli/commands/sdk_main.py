"""Main SDK commands class that delegates to modular command handlers."""

from typing import Optional

from rich.console import Console

from ..config_manager import SDKConfigManager

# User commands removed - unified into config commands
from .sdk_module import SDKModuleHandler
from .sdk_swarm import SDKSwarmHandler
from .sdk_cluster import SDKClusterHandler
from .sdk_results import SDKResultsHandler
from .sdk_globals import SDKGlobalsHandler

# Removed SDKNodesHandler - node operations should use 'manta node' commands
from .sdk_logs import SDKLogsHandler
from .sdk_config import SDKConfigHandler


class SDKCommands:
    """Main SDK commands class that delegates to modular handlers."""

    def __init__(self, console: Optional[Console] = None):
        """Initialize with optional console (for backwards compatibility with CLI)."""
        self.console = console or Console()

        # Initialize config manager - will be properly instantiated when needed
        self.config_manager = None

        # Initialize handlers - will be created lazily
        self._handlers = {}

    def _ensure_managers(self):
        """Ensure config manager is initialized."""
        if self.config_manager is None:
            self.config_manager = SDKConfigManager()

    def _get_handler(self, handler_name: str):
        """Get or create a command handler."""
        if handler_name not in self._handlers:
            self._ensure_managers()

            handler_classes = {
                # 'user' removed - unified into config
                "module": SDKModuleHandler,
                "swarm": SDKSwarmHandler,
                "cluster": SDKClusterHandler,
                "results": SDKResultsHandler,
                "globals": SDKGlobalsHandler,
                "logs": SDKLogsHandler,
                "config": SDKConfigHandler,
            }

            if handler_name not in handler_classes:
                raise ValueError(f"Unknown handler: {handler_name}")

            handler_class = handler_classes[handler_name]
            self._handlers[handler_name] = handler_class(
                self.console, self.config_manager
            )

        return self._handlers[handler_name]

    def handle(self, args) -> int:
        """Handle SDK commands by delegating to appropriate handlers."""
        # Extract the primary command
        if hasattr(args, "sdk_command"):
            command = args.sdk_command
        else:
            # Fallback for direct usage
            command = getattr(args, "command", None)

        if not command:
            self.console.print("[red]Error:[/red] No command specified")
            return 1

        # Set config override if specified
        config_override = getattr(args, "config", None)

        # Map commands to handlers
        command_mapping = {
            # 'user' removed - unified into config
            "cluster": "cluster",
            "module": "module",
            "swarm": "swarm",
            "results": "results",
            "globals": "globals",
            "logs": "logs",
            "config": "config",
        }

        handler_name = command_mapping.get(command)
        if not handler_name:
            self.console.print(f"[red]Error:[/red] Unknown SDK command: {command}")
            return 1

        try:
            handler = self._get_handler(handler_name)

            # Set config override if specified
            if config_override:
                handler.set_profile_override(config_override)

            return handler.handle(args)

        except Exception as e:
            self.console.print(f"[red]Error:[/red] Failed to execute command: {e}")
            return 1

    def add_subparsers(self, parent_parser):
        """Add all SDK subcommands to the parent parser."""
        # Ensure managers are initialized for handler creation
        self._ensure_managers()

        # User commands removed - unified into config

        # Module commands
        module_parser = parent_parser.add_parser(
            "module", help="Module management operations"
        )
        module_handler = self._get_handler("module")
        module_handler.add_subparsers(module_parser)

        # Swarm commands
        swarm_parser = parent_parser.add_parser(
            "swarm", help="Swarm deployment and management"
        )
        swarm_handler = self._get_handler("swarm")
        swarm_handler.add_subparsers(swarm_parser)

        # Cluster commands
        cluster_parser = parent_parser.add_parser(
            "cluster", help="Cluster information and management"
        )
        cluster_handler = self._get_handler("cluster")
        cluster_handler.add_subparsers(cluster_parser)

        # Results commands
        results_parser = parent_parser.add_parser(
            "results", help="Results retrieval and management"
        )
        results_handler = self._get_handler("results")
        results_handler.add_subparsers(results_parser)

        # Globals commands
        globals_parser = parent_parser.add_parser(
            "globals", help="Globals retrieval and management"
        )
        globals_handler = self._get_handler("globals")
        globals_handler.add_subparsers(globals_parser)

        # Node commands removed - use 'manta node' instead

        # Logs commands
        logs_parser = parent_parser.add_parser(
            "logs", help="Log retrieval and streaming"
        )
        logs_handler = self._get_handler("logs")
        logs_handler.add_subparsers(logs_parser)

        # Config commands
        config_parser = parent_parser.add_parser(
            "config", help="Configuration management"
        )
        config_handler = self._get_handler("config")
        config_handler.add_subparsers(config_parser)
