"""SDK log retrieval and streaming commands."""

import signal
import time
from typing import Optional

from rich.table import Table

from .base_handler import BaseSDKHandler
from ..utils.converters import enum_to_string, LOG_SEVERITY_MAP


class SDKLogsHandler(BaseSDKHandler):
    """Handle log-related SDK commands."""

    def add_subparsers(self, parent_parser):
        """Add logs command subparsers."""
        self.parser = parent_parser  # Store parser reference
        subparsers = parent_parser.add_subparsers(
            dest="logs_command", help="Log commands"
        )

        # Get logs command
        get_parser = subparsers.add_parser("get", help="Get logs for a swarm or task")
        get_parser.add_argument("target_id", help="Swarm ID or Task ID to get logs for")
        get_parser.add_argument(
            "--type",
            choices=["swarm", "task"],
            default="swarm",
            help="Type of target (default: swarm)",
        )
        get_parser.add_argument("--lines", type=int, help="Number of lines to retrieve")

        # Stream logs command
        stream_parser = subparsers.add_parser("stream", help="Stream logs in real-time")
        stream_parser.add_argument(
            "target_id", help="Swarm ID or Task ID to stream logs for"
        )
        stream_parser.add_argument(
            "--type",
            choices=["swarm", "task"],
            default="swarm",
            help="Type of target (default: swarm)",
        )

        # Add profile override to all subcommands
        for parser in [get_parser, stream_parser]:
            parser.add_argument("--profile", help="Use specific profile")

    def handle(self, args) -> int:
        """Handle logs commands."""
        if not args.logs_command:
            if hasattr(self, "parser"):
                self.parser.print_help()
            return 0  # Return 0 for help display

        if args.logs_command == "get":
            return self.get_logs(
                args.target_id,
                getattr(args, "type", "swarm"),
                getattr(args, "lines", None),
            )
        elif args.logs_command == "stream":
            return self.stream_logs(args.target_id, getattr(args, "type", "swarm"))
        else:
            self.print_error(f"Unknown logs command: {args.logs_command}")
            return 1

    def get_logs(
        self, target_id: str, log_type: str = "swarm", lines: Optional[int] = None
    ) -> int:
        """Get logs for a swarm or task."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                if log_type == "swarm":
                    return await api.get_swarm_logs(target_id, lines=lines)
                else:
                    return await api.get_task_logs(target_id, lines=lines)

            logs = self._run_with_progress(
                run, f"Fetching logs for {log_type} {target_id}..."
            )

            if logs is None:
                return 1

            if not logs:
                self.print("No logs found.")
                return 0

            # Display logs
            table = Table(title=f"Logs for {log_type.title()}: {target_id}")
            table.add_column("Timestamp", style="cyan")
            table.add_column("Level", style="blue")
            table.add_column("Message", style="white")

            for log_entry in logs:
                # Convert log level if it's an enum
                level = log_entry.get("level", "INFO")
                if isinstance(level, int):
                    level = enum_to_string(level, LOG_SEVERITY_MAP)

                table.add_row(
                    log_entry.get("timestamp", "Unknown"),
                    level,
                    log_entry.get("message", ""),
                )

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to get logs: {e}")
            return 1

    def stream_logs(self, target_id: str, log_type: str = "swarm") -> int:
        """Stream logs in real-time."""
        api = self._get_user_api()
        if not api:
            return 1

        self.print(f"Streaming logs for {log_type}: {target_id}")
        self.print("Press Ctrl+C to stop streaming...")

        try:
            # Set up signal handler for graceful shutdown
            shutdown_flag = False

            def signal_handler(sig, frame):
                nonlocal shutdown_flag
                shutdown_flag = True

            signal.signal(signal.SIGINT, signal_handler)

            last_log_count = 0

            while not shutdown_flag:
                try:

                    async def get_logs():
                        if log_type == "swarm":
                            return await api.get_swarm_logs(target_id)
                        else:
                            return await api.get_task_logs(target_id)

                    logs = self._run_async(get_logs())

                    # Show new logs since last check
                    if logs and len(logs) > last_log_count:
                        new_logs = logs[last_log_count:]

                        for log_entry in new_logs:
                            timestamp = log_entry.get("timestamp", "unknown")
                            level = log_entry.get("level", "INFO")
                            message = log_entry.get("message", "")
                            self.print(f"[{timestamp}] {level}: {message}")

                        last_log_count = len(logs)

                    time.sleep(2)  # Poll every 2 seconds for logs

                except KeyboardInterrupt:
                    self.print("\nLog streaming stopped.")
                    return 130  # KeyboardInterrupt exit code

        except Exception as e:
            self.print_error(f"Log streaming failed: {e}")
            return 1
