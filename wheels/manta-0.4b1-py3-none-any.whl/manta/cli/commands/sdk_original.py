"""SDK commands that integrate with manta-sdk user API functionality."""

import asyncio
import json
import signal
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.columns import Columns
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm, IntPrompt, Prompt
from rich.table import Table
from rich.tree import Tree

from ..config_manager import ConfigManager, CredentialManager, ProfileManager


class SDKCommands:
    """Handle SDK-related CLI commands that use manta-sdk functionality."""

    def __init__(
        self,
        config_manager: ConfigManager,
        profile_manager: ProfileManager,
        credential_manager: CredentialManager,
        console: Optional[Console] = None,
    ):
        self.config_manager = config_manager
        self.profile_manager = profile_manager
        self.credential_manager = credential_manager
        self.console = console

    def print(self, *args, **kwargs):
        """Print with console if available."""
        self.console.print(*args, **kwargs)

    def print_error(self, message: str):
        """Print error message."""
        self.console.print(f"[red]Error:[/red] {message}")

    def print_success(self, message: str):
        """Print success message."""
        self.console.print(f"[green]Success:[/green] {message}")

    def _run_with_progress(self, async_func, message: str):
        """Run an async function with progress indication."""
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            ) as progress:
                task = progress.add_task(message, total=None)
                result = asyncio.run(async_func())
                progress.update(task, completed=True)
                return result
        except Exception:
            # Fallback to simple progress indication if Rich progress fails
            self.print(message)
            return asyncio.run(async_func())

    def handle(self, args) -> int:
        """Handle SDK commands."""
        command = args.command

        # Set profile override if specified
        if hasattr(args, "profile") and args.profile:
            self._profile_override = args.profile
        else:
            self._profile_override = None

        if command == "user":
            return self.handle_user_commands(args)
        elif command == "cluster":
            return self.handle_cluster_commands(args)
        elif command == "simulation":
            return self.handle_simulation_commands(args)
        elif command == "module":
            return self.handle_module_commands(args)
        elif command == "swarm":
            return self.handle_swarm_commands(args)
        elif command == "node":
            return self.handle_node_commands(args)
        elif command == "results":
            return self.handle_results_commands(args)
        elif command == "logs":
            return self.handle_logs_commands(args)
        else:
            self.print_error(f"Unknown SDK command: {command}")
            return 1

    def handle_user_commands(self, args) -> int:
        """Handle user API commands."""
        if not args.user_command:
            self.print_error("User command required")
            return 1

        if args.user_command == "status":
            return self.check_user_service_status()
        elif args.user_command == "get-user":
            return self.get_user_info()
        elif args.user_command == "list-clusters":
            return self.list_clusters()
        elif args.user_command == "list-swarms":
            return self.list_swarms(getattr(args, "cluster_id", None))
        else:
            self.print_error(f"Unknown user command: {args.user_command}")
            return 1

    def handle_cluster_commands(self, args) -> int:
        """Handle cluster commands."""
        if not args.cluster_command:
            self.print_error("Cluster command required")
            return 1

        if args.cluster_command == "list":
            return self.list_clusters()
        elif args.cluster_command == "show":
            return self.show_cluster(args.cluster_id)
        else:
            self.print_error(f"Unknown cluster command: {args.cluster_command}")
            return 1

    def handle_simulation_commands(self, args) -> int:
        """Handle simulation commands."""
        if not args.simulation_command:
            self.print_error("Simulation command required")
            return 1

        if args.simulation_command == "list":
            return self.list_simulations()
        elif args.simulation_command == "deploy":
            return self.deploy_simulation(args.swarm_file, args.cluster_id)
        else:
            self.print_error(f"Unknown simulation command: {args.simulation_command}")
            return 1

    def _get_user_api(self):
        """Get configured AsyncUserAPI instance."""
        try:
            # Dynamic import of manta-sdk
            from manta.apis.user_api import AsyncUserAPI

            # Get configuration
            config = self._load_config()
            if not config:
                self.print_error(
                    "No configuration found. Run 'manta config init' first."
                )
                return None

            # Get credentials
            credential_id = config.get("credential_id")
            if not credential_id:
                self.print_error(
                    "No credential configured. Run 'manta config credentials add' first."
                )
                return None

            token = self.credential_manager.get_credential(credential_id)
            if not token:
                self.print_error(f"Credential '{credential_id}' not found.")
                return None

            # Create API instance
            connection = config.get("connection", {})
            api = AsyncUserAPI(
                token=token,
                host=connection.get("host", "localhost"),
                port=connection.get("port", 50052),
                cert_folder=(
                    connection.get("cert_folder") if connection.get("use_tls") else None
                ),
            )

            return api

        except ImportError:
            self.print_error(
                "manta-sdk not installed. Install with: pip install manta-sdk[api]"
            )
            return None
        except Exception as e:
            self.print_error(f"Failed to create API instance: {e}")
            return None

    def _load_config(self):
        """Load active configuration with fallbacks."""
        # Use profile override if specified
        if hasattr(self, "_profile_override") and self._profile_override:
            profile = self.profile_manager.get_profile(self._profile_override)
            if profile:
                return profile.to_dict() if hasattr(profile, "to_dict") else profile
            else:
                self.print_warning(
                    f"Profile '{self._profile_override}' not found, using default"
                )

        # Get active profile
        active_profile = self.config_manager.get_active_profile()
        if active_profile:
            profile = self.profile_manager.get_profile(active_profile)
            if profile:
                return profile.to_dict() if hasattr(profile, "to_dict") else profile

        # No active profile, try default
        default_profile = self.profile_manager.get_profile("default")
        if default_profile:
            return (
                default_profile.to_dict()
                if hasattr(default_profile, "to_dict")
                else default_profile
            )

        return None

    def get_user_info(self) -> int:
        """Get current user information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                user_info = await api.get_user()
                return user_info

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            ) as progress:
                task = progress.add_task("Getting user information...", total=None)
                user_info = asyncio.run(run())
                progress.update(task, completed=True)

            # Display user info
            panel = Panel.fit(
                f"[cyan]User ID:[/cyan] {user_info.get('user_id', 'Unknown')}\n"
                f"[cyan]Username:[/cyan] {user_info.get('username', 'Unknown')}\n"
                f"[cyan]Email:[/cyan] {user_info.get('email', 'Unknown')}\n"
                f"[cyan]Roles:[/cyan] {', '.join(user_info.get('roles', []))}",
                title="User Information",
            )
            self.console.print(panel)
            return 0

        except Exception as e:
            self.print_error(f"Failed to get user information: {e}")
            return 1

    def list_clusters(self) -> int:
        """List available clusters."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                clusters = await api.stream_and_fetch_clusters()
                return clusters

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            ) as progress:
                task = progress.add_task("Fetching clusters...", total=None)
                clusters = asyncio.run(run())
                progress.update(task, completed=True)

            # Display clusters
            if not clusters:
                self.print("No clusters found.")
                return 0

            table = Table(title="Available Clusters")
            table.add_column("Cluster ID", style="cyan")
            table.add_column("Name", style="blue")
            table.add_column("Status", style="green")
            table.add_column("Nodes", style="magenta")

            for cluster in clusters:
                table.add_row(
                    cluster.get("cluster_id", "Unknown"),
                    cluster.get("name", "Unknown"),
                    cluster.get("status", "Unknown"),
                    str(cluster.get("node_count", 0)),
                )

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to list clusters: {e}")
            return 1

    def list_swarms(self, cluster_id: str) -> int:
        """List swarms for a cluster."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                swarms = await api.stream_and_fetch_swarms()
                return swarms

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            ) as progress:
                task = progress.add_task("Fetching swarms...", total=None)
                swarms = asyncio.run(run())
                progress.update(task, completed=True)

            # Filter by cluster if specified
            if cluster_id:
                swarms = [s for s in swarms if s.get("cluster_id") == cluster_id]

            # Display swarms
            if not swarms:
                msg = (
                    f"No swarms found for cluster '{cluster_id}'."
                    if cluster_id
                    else "No swarms found."
                )
                self.print(msg)
                return 0

            table = Table(
                title=f"Swarms{' for cluster ' + cluster_id if cluster_id else ''}"
            )
            table.add_column("Swarm ID", style="cyan")
            table.add_column("Name", style="blue")
            table.add_column("Status", style="green")
            table.add_column("Tasks", style="magenta")

            for swarm in swarms:
                table.add_row(
                    swarm.get("swarm_id", "Unknown"),
                    swarm.get("name", "Unknown"),
                    swarm.get("status", "Unknown"),
                    str(swarm.get("task_count", 0)),
                )

            self.console.print(table)
            return 0

        except Exception as e:
            self.print_error(f"Failed to list swarms: {e}")
            return 1

    def show_cluster(self, cluster_id: str) -> int:
        """Show detailed cluster information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                cluster = await api.get_cluster(cluster_id)
                return cluster

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            ) as progress:
                task = progress.add_task("Fetching cluster details...", total=None)
                cluster = asyncio.run(run())
                progress.update(task, completed=True)

            # Display cluster details
            panel = Panel.fit(
                f"[cyan]Cluster ID:[/cyan] {cluster.get('cluster_id', 'Unknown')}\n"
                f"[cyan]Name:[/cyan] {cluster.get('name', 'Unknown')}\n"
                f"[cyan]Description:[/cyan] {cluster.get('description', 'None')}\n"
                f"[cyan]Status:[/cyan] {cluster.get('status', 'Unknown')}\n"
                f"[cyan]Node Count:[/cyan] {cluster.get('node_count', 0)}\n"
                f"[cyan]Created:[/cyan] {cluster.get('created_at', 'Unknown')}",
                title=f"Cluster: {cluster_id}",
            )
            self.console.print(panel)

            return 0

        except Exception as e:
            self.print_error(f"Failed to get cluster details: {e}")
            return 1

            return 0

        except Exception as e:
            self.print_error(f"Failed to get cluster details: {e}")
            return 1

    def list_simulations(self) -> int:
        """List all simulations."""
        # This is essentially the same as list_swarms without cluster filtering
        return self.list_swarms(None)

    def deploy_simulation(self, swarm_file: str, cluster_id: str) -> int:
        """Deploy simulation from swarm file."""
        self.print_error("Simulation deployment not yet implemented in CLI")
        self.print("Use the SDK directly for now:")
        self.print("  from manta.apis import AsyncUserAPI")
        self.print(f"  # Load and deploy your swarm from {swarm_file}")
        return 1

    # ============================================
    # Service Status Operations
    # ============================================

    def check_user_service_status(self) -> int:
        """Check if User service is available."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.is_available()

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task(
                        "Checking service availability...", total=None
                    )
                    available = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Checking service availability...")
                available = asyncio.run(run())

            if available:
                self.print_success("User service is available")
                return 0
            else:
                self.print_error("User service is not available")
                return 1

        except Exception as e:
            self.print_error(f"Failed to check service status: {e}")
            return 1

    # ============================================
    # Module Management Operations
    # ============================================

    def handle_module_commands(self, args) -> int:
        """Handle module management commands."""
        if not args.module_command:
            self.print_error("Module command required")
            return 1

        if args.module_command == "list":
            return self.list_modules()
        elif args.module_command == "list-ids":
            return self.list_module_ids()
        elif args.module_command == "show":
            return self.show_module(args.module_id)
        elif args.module_command == "upload":
            return self.upload_module(
                args.module_file, getattr(args, "module_id", None)
            )
        elif args.module_command == "update":
            return self.update_module(args.module_id, args.module_file)
        elif args.module_command == "delete":
            return self.delete_module(args.module_id, getattr(args, "force", False))
        elif args.module_command == "download":
            return self.download_module(
                args.module_id, getattr(args, "output_file", None)
            )
        else:
            self.print_error(f"Unknown module command: {args.module_command}")
            return 1

    def list_modules(self) -> int:
        """List all modules for the user."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                modules = await api.stream_and_fetch_modules()
                return modules

            if self.console:
                try:
                    with Progress(
                        SpinnerColumn(),
                        TextColumn("[progress.description]{task.description}"),
                        console=self.console,
                    ) as progress:
                        task = progress.add_task("Fetching modules...", total=None)
                        modules = asyncio.run(run())
                        progress.update(task, completed=True)
                except Exception:
                    # Fallback to simple progress indication if Rich progress fails
                    self.print("Fetching modules...")
                    modules = asyncio.run(run())
            else:
                print("Fetching modules...")
                modules = asyncio.run(run())

            if not modules:
                self.print("No modules found.")
                return 0

            # Display modules
            if self.console:
                table = Table(title="User Modules")
                table.add_column("Module ID", style="cyan")
                table.add_column("Name", style="blue")
                table.add_column("Type", style="green")
                table.add_column("Size", style="magenta")
                table.add_column("Created", style="yellow")

                for module in modules:
                    # Module is a Module object with attributes
                    module.__dict__ if hasattr(module, "__dict__") else {}

                    # Handle data attribute carefully for mock objects
                    data_attr = getattr(module, "data", b"")
                    if hasattr(data_attr, "_mock_name"):  # It's a Mock object
                        data_size = 0
                    else:
                        data_size = len(data_attr) if data_attr else 0

                    table.add_row(
                        str(getattr(module, "module_id", "Unknown")),
                        str(getattr(module, "name", "Unknown")),
                        str(getattr(module, "module_type", "Unknown")),
                        self._format_size(data_size),
                        str(getattr(module, "created_at", "Unknown")),
                    )

                self.console.print(table)
            else:
                print("Modules:")
                print("-" * 80)
                for module in modules:
                    module_id = str(getattr(module, "module_id", "Unknown"))
                    module_name = str(getattr(module, "name", "Unknown"))
                    module_type = str(getattr(module, "module_type", "Unknown"))
                    print(f"{module_id:30} {module_name:20} {module_type}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to list modules: {e}")
            return 1

    def list_module_ids(self) -> int:
        """List module IDs only."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.list_module_ids()

            module_ids = self._run_with_progress(run, "Fetching module IDs...")

            if not module_ids:
                self.print("No modules found.")
                return 0

            self.print(f"Found {len(module_ids)} modules:")
            for module_id in module_ids:
                self.print(f"  {module_id}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to list module IDs: {e}")
            return 1

    def show_module(self, module_id: str) -> int:
        """Show detailed module information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.get_module(module_id)

            module = self._run_with_progress(run, "Fetching module details...")

            # Display module details
            if self.console:
                panel = Panel.fit(
                    f"[cyan]Module ID:[/cyan] {getattr(module, 'module_id', 'Unknown')}\n"
                    f"[cyan]Name:[/cyan] {getattr(module, 'name', 'Unknown')}\n"
                    f"[cyan]Type:[/cyan] {getattr(module, 'module_type', 'Unknown')}\n"
                    f"[cyan]Size:[/cyan] {self._format_size(len(getattr(module, 'data', b'')))}\n"
                    f"[cyan]Created:[/cyan] {getattr(module, 'created_at', 'Unknown')}",
                    title=f"Module: {module_id}",
                )
                self.console.print(panel)
            else:
                print(f"Module: {module_id}")
                print(f"  Name: {getattr(module, 'name', 'Unknown')}")
                print(f"  Type: {getattr(module, 'module_type', 'Unknown')}")
                print(f"  Size: {self._format_size(len(getattr(module, 'data', b'')))}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to get module details: {e}")
            return 1

    def upload_module(self, module_file: str, module_id: Optional[str] = None) -> int:
        """Upload a module from file."""
        api = self._get_user_api()
        if not api:
            return 1

        try:
            # Import Module class
            from manta.apis.module import Module

            # Validate file path
            module_path = Path(module_file)
            if not module_path.exists():
                self.print_error(f"Module file not found: {module_file}")
                return 1

            # Get image name from user if not provided
            if self.console:
                default_image = "python:3.9-slim"
                image = Prompt.ask("Container image", default=default_image)
            else:
                image = "python:3.9-slim"
                self.print(f"Using default image: {image}")

            # Create Module object
            module = Module(
                python_program=module_path,
                image=image,
                name=module_path.stem if module_path.is_file() else module_path.name,
            )

            async def run():
                return await api.send_module(module)

            result_id = self._run_with_progress(
                run, f"Uploading module from {module_file}..."
            )

            self.print_success(f"Module uploaded successfully with ID: {result_id}")
            return 0

        except FileNotFoundError:
            self.print_error(f"Module file not found: {module_file}")
            return 1
        except PermissionError:
            self.print_error(f"Permission denied reading file: {module_file}")
            return 1
        except Exception as e:
            self.print_error(f"Failed to upload module: {e}")
            return 1

    def update_module(self, module_id: str, module_file: str) -> int:
        """Update an existing module."""
        api = self._get_user_api()
        if not api:
            return 1

        try:
            # Import Module class
            from manta.apis.module import Module

            # Validate module_id parameter
            if not module_id:
                self.print_error("Module ID is required for update operation")
                return 1

            # Validate file path
            module_path = Path(module_file)
            if not module_path.exists():
                self.print_error(f"Module file not found: {module_file}")
                return 1

            # First verify the module exists by trying to get it
            async def check_module_exists():
                try:
                    return await api.get_module(module_id)
                except Exception:
                    return None

            existing_module = self._run_with_progress(
                check_module_exists, "Checking if module exists..."
            )

            if not existing_module:
                self.print_error(f"Module with ID '{module_id}' not found")
                return 1

            # Get image name - use existing image as default or prompt for new one
            existing_image = getattr(existing_module, "image", "python:3.9-slim")
            if self.console:
                image = Prompt.ask("Container image", default=existing_image)
            else:
                image = existing_image
                self.print(f"Using existing image: {image}")

            # Create updated Module object
            module = Module(
                python_program=module_path,
                image=image,
                name=module_path.stem if module_path.is_file() else module_path.name,
            )

            async def run():
                return await api.update_module(module, module_id)

            result_id = self._run_with_progress(run, f"Updating module {module_id}...")

            self.print_success(f"Module updated successfully: {result_id}")
            return 0

        except FileNotFoundError:
            self.print_error(f"Module file not found: {module_file}")
            return 1
        except PermissionError:
            self.print_error(f"Permission denied reading file: {module_file}")
            return 1
        except Exception as e:
            self.print_error(f"Failed to update module: {e}")
            return 1

    def delete_module(self, module_id: str, force: bool = False) -> int:
        """Delete a module."""
        if not force:
            if self.console:
                confirm = Confirm.ask(
                    f"Are you sure you want to delete module '{module_id}'?"
                )
                if not confirm:
                    self.print("Operation cancelled.")
                    return 0

        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.remove_module(module_id)

            result = self._run_with_progress(run, "Deleting module...")

            self.print_success(f"Module deleted: {result}")
            return 0

        except Exception as e:
            self.print_error(f"Failed to delete module: {e}")
            return 1

    def download_module(self, module_id: str, output_file: Optional[str] = None) -> int:
        """Download a module to file."""
        api = self._get_user_api()
        if not api:
            return 1

        try:
            # Validate module_id parameter
            if not module_id:
                self.print_error("Module ID is required for download operation")
                return 1

            # Fetch module from server
            async def run():
                return await api.get_module(module_id)

            module = self._run_with_progress(run, f"Downloading module {module_id}...")

            # Check if module has python_files (from Module.from_proto)
            if not hasattr(module, "python_files") or not module.python_files:
                self.print_error("Module contains no python files to download")
                return 1

            # Determine output path
            if output_file:
                output_path = Path(output_file)
            else:
                # Use module name or ID as default filename
                module_name = getattr(module, "name", None) or module_id
                if len(module.python_files) == 1:
                    # Single file - use the filename from the module
                    filename = list(module.python_files.keys())[0]
                    output_path = Path(filename)
                else:
                    # Multiple files - create a directory
                    output_path = Path(f"{module_name}_module")

            # Handle single file vs directory
            if len(module.python_files) == 1:
                # Single file download
                filename, content = next(iter(module.python_files.items()))

                # If output_file is a directory, put file inside it
                if output_path.is_dir():
                    output_path = output_path / filename

                # Check for conflicts
                if output_path.exists():
                    if self.console:
                        overwrite = Confirm.ask(
                            f"File '{output_path}' already exists. Overwrite?"
                        )
                        if not overwrite:
                            self.print("Download cancelled.")
                            return 0
                    else:
                        self.print_error(
                            f"File '{output_path}' already exists. Use --force or specify a different output path."
                        )
                        return 1

                # Write single file
                try:
                    output_path.parent.mkdir(parents=True, exist_ok=True)
                    output_path.write_text(content, encoding="utf-8")
                    self.print_success(
                        f"Module downloaded to: {output_path.absolute()}"
                    )
                except Exception as e:
                    self.print_error(f"Failed to write file: {e}")
                    return 1

            else:
                # Multiple files - create directory structure
                if output_path.exists() and output_path.is_dir():
                    if self.console:
                        overwrite = Confirm.ask(
                            f"Directory '{output_path}' already exists. Continue?"
                        )
                        if not overwrite:
                            self.print("Download cancelled.")
                            return 0
                elif output_path.exists():
                    self.print_error(
                        f"Path '{output_path}' exists and is not a directory"
                    )
                    return 1

                # Create directory and write all files
                try:
                    output_path.mkdir(parents=True, exist_ok=True)

                    files_written = 0
                    for filename, content in module.python_files.items():
                        file_path = output_path / filename

                        # Create subdirectories if needed
                        file_path.parent.mkdir(parents=True, exist_ok=True)

                        # Write file
                        file_path.write_text(content, encoding="utf-8")
                        files_written += 1

                    self.print_success(
                        f"Module downloaded: {files_written} files written to {output_path.absolute()}"
                    )

                    # Show file structure if console available
                    if self.console:
                        tree = Tree(f"📁 {output_path.name}")
                        for filename in sorted(module.python_files.keys()):
                            tree.add(f"📄 {filename}")
                        self.console.print(tree)

                except Exception as e:
                    self.print_error(f"Failed to write files: {e}")
                    return 1

            return 0

        except Exception as e:
            self.print_error(f"Failed to download module: {e}")
            return 1

    # ============================================
    # Swarm Management Operations
    # ============================================

    def handle_swarm_commands(self, args) -> int:
        """Handle swarm management commands."""
        if not args.swarm_command:
            self.print_error("Swarm command required")
            return 1

        if args.swarm_command == "list":
            return self.list_swarms(getattr(args, "cluster_id", None))
        elif args.swarm_command == "list-ids":
            return self.list_swarm_ids()
        elif args.swarm_command == "show":
            return self.show_swarm(args.swarm_id)
        elif args.swarm_command == "tasks":
            return self.show_swarm_tasks(args.swarm_id)
        elif args.swarm_command == "start":
            return self.start_swarm(args.swarm_id)
        elif args.swarm_command == "stop":
            return self.stop_swarm(args.swarm_id, getattr(args, "force", False))
        elif args.swarm_command == "delete":
            return self.delete_swarm(args.swarm_id, getattr(args, "force", False))
        elif args.swarm_command == "deploy":
            return self.deploy_swarm_interactive()
        elif args.swarm_command == "monitor":
            return self.monitor_swarm(args.swarm_id)
        else:
            self.print_error(f"Unknown swarm command: {args.swarm_command}")
            return 1

    def list_swarm_ids(self) -> int:
        """List swarm IDs only."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.list_swarm_ids()

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching swarm IDs...", total=None)
                    swarm_ids = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching swarm IDs...")
                swarm_ids = asyncio.run(run())

            if not swarm_ids:
                self.print("No swarms found.")
                return 0

            self.print(f"Found {len(swarm_ids)} swarms:")
            for swarm_id in swarm_ids:
                self.print(f"  {swarm_id}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to list swarm IDs: {e}")
            return 1

    def show_swarm(self, swarm_id: str) -> int:
        """Show detailed swarm information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.get_swarm(swarm_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching swarm details...", total=None)
                    swarm = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching swarm details...")
                swarm = asyncio.run(run())

            # Display swarm details
            if self.console:
                panel = Panel.fit(
                    f"[cyan]Swarm ID:[/cyan] {swarm.get('swarm_id', 'Unknown')}\n"
                    f"[cyan]Name:[/cyan] {swarm.get('name', 'Unknown')}\n"
                    f"[cyan]Status:[/cyan] {swarm.get('status', 'Unknown')}\n"
                    f"[cyan]Cluster ID:[/cyan] {swarm.get('cluster_id', 'Unknown')}\n"
                    f"[cyan]Task Count:[/cyan] {swarm.get('task_count', 0)}\n"
                    f"[cyan]Created:[/cyan] {swarm.get('created_at', 'Unknown')}",
                    title=f"Swarm: {swarm_id}",
                )
                self.console.print(panel)
            else:
                print(f"Swarm: {swarm_id}")
                print(f"  Name: {swarm.get('name', 'Unknown')}")
                print(f"  Status: {swarm.get('status', 'Unknown')}")
                print(f"  Cluster ID: {swarm.get('cluster_id', 'Unknown')}")
                print(f"  Task Count: {swarm.get('task_count', 0)}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to get swarm details: {e}")
            return 1

    def show_swarm_tasks(self, swarm_id: str) -> int:
        """Show tasks for a swarm."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.stream_and_fetch_tasks(swarm_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching swarm tasks...", total=None)
                    tasks = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching swarm tasks...")
                tasks = asyncio.run(run())

            if not tasks:
                self.print("No tasks found for this swarm.")
                return 0

            # Display tasks
            if self.console:
                table = Table(title=f"Tasks for Swarm: {swarm_id}")
                table.add_column("Task ID", style="cyan")
                table.add_column("Status", style="green")
                table.add_column("Node ID", style="blue")
                table.add_column("Module", style="magenta")
                table.add_column("Progress", style="yellow")

                for task in tasks:
                    table.add_row(
                        task.get("task_id", "Unknown"),
                        task.get("status", "Unknown"),
                        task.get("node_id", "N/A"),
                        task.get("module_id", "Unknown"),
                        f"{task.get('progress', 0)}%",
                    )

                self.console.print(table)
            else:
                print(f"Tasks for Swarm: {swarm_id}")
                print("-" * 80)
                for task in tasks:
                    print(
                        f"{task.get('task_id', 'Unknown'):30} {task.get('status', 'Unknown'):15} {task.get('node_id', 'N/A'):20}"
                    )

            return 0

        except Exception as e:
            self.print_error(f"Failed to get swarm tasks: {e}")
            return 1

    def start_swarm(self, swarm_id: str) -> int:
        """Start a swarm."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.start_swarm(swarm_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Starting swarm...", total=None)
                    result = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Starting swarm...")
                result = asyncio.run(run())

            self.print_success(f"Swarm started: {result}")
            return 0

        except Exception as e:
            self.print_error(f"Failed to start swarm: {e}")
            return 1

    def stop_swarm(self, swarm_id: str, force: bool = False) -> int:
        """Stop a swarm."""
        if not force:
            if self.console:
                confirm = Confirm.ask(
                    f"Are you sure you want to stop swarm '{swarm_id}'?"
                )
                if not confirm:
                    self.print("Operation cancelled.")
                    return 0

        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.stop_swarm(swarm_id, force)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Stopping swarm...", total=None)
                    result = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Stopping swarm...")
                result = asyncio.run(run())

            self.print_success(f"Swarm stopped: {result}")
            return 0

        except Exception as e:
            self.print_error(f"Failed to stop swarm: {e}")
            return 1

    def delete_swarm(self, swarm_id: str, force: bool = False) -> int:
        """Delete a swarm."""
        if not force:
            if self.console:
                confirm = Confirm.ask(
                    f"Are you sure you want to delete swarm '{swarm_id}'?"
                )
                if not confirm:
                    self.print("Operation cancelled.")
                    return 0

        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.remove_swarm(swarm_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Deleting swarm...", total=None)
                    result = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Deleting swarm...")
                result = asyncio.run(run())

            self.print_success(f"Swarm deleted: {result}")
            return 0

        except Exception as e:
            self.print_error(f"Failed to delete swarm: {e}")
            return 1

    def deploy_swarm_interactive(self) -> int:
        """Interactive swarm deployment wizard."""
        api = self._get_user_api()
        if not api:
            return 1

        try:
            # Welcome message
            if self.console:
                self.console.print(
                    Panel.fit(
                        "[bold cyan]Welcome to the Swarm Deployment Wizard![/bold cyan]\n\n"
                        "This wizard will guide you through deploying a swarm to your cluster.\n"
                        "You can deploy from a Python swarm definition file or create one interactively.",
                        title="Swarm Deployment Wizard",
                    )
                )
            else:
                self.print("=== Swarm Deployment Wizard ===")
                self.print("This wizard will guide you through deploying a swarm.")
                self.print(
                    "You can deploy from a Python file or create one interactively."
                )

            # Step 1: Choose deployment mode
            deployment_mode = self._choose_deployment_mode()
            if deployment_mode == "cancel":
                return 0

            # Step 2: Select cluster
            cluster_id = self._select_cluster_interactive(api)
            if not cluster_id:
                return 1

            # Step 3: Deploy based on mode
            if deployment_mode == "file":
                return self._deploy_from_file(api, cluster_id)
            else:
                return self._deploy_interactive(api, cluster_id)

        except KeyboardInterrupt:
            self.print("\nDeployment cancelled by user.")
            return 1
        except Exception as e:
            self.print_error(f"Deployment failed: {e}")
            return 1

    def monitor_swarm(self, swarm_id: str) -> int:
        """Monitor swarm execution in real-time."""
        self.print_error("Real-time swarm monitoring not yet implemented")
        self.print("Use 'manta swarm tasks' to see current status")
        return 1

    # ============================================
    # Node Management Operations
    # ============================================

    def handle_node_commands(self, args) -> int:
        """Handle node management commands."""
        if not args.node_command:
            self.print_error("Node command required")
            return 1

        if args.node_command == "list":
            return self.list_nodes(args.cluster_id, getattr(args, "available", False))
        elif args.node_command == "list-ids":
            return self.list_node_ids(
                args.cluster_id, getattr(args, "available", False)
            )
        elif args.node_command == "show":
            return self.show_node(args.cluster_id, args.node_id)
        elif args.node_command == "resources":
            return self.show_node_resources(args.cluster_id, args.node_id)
        elif args.node_command == "tasks":
            return self.show_node_tasks(args.cluster_id, args.node_id)
        elif args.node_command == "stop":
            return self.stop_node(args.cluster_id, args.node_id)
        elif args.node_command == "remove":
            return self.remove_node(
                args.cluster_id, args.node_id, getattr(args, "force", False)
            )
        elif args.node_command == "errors":
            return self.collect_node_errors(args.cluster_id)
        elif args.node_command == "monitor":
            return self.monitor_node(args.cluster_id, args.node_id)
        else:
            self.print_error(f"Unknown node command: {args.node_command}")
            return 1

    def list_nodes(self, cluster_id: str, available_only: bool = False) -> int:
        """List nodes in cluster."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.stream_and_fetch_nodes(cluster_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching nodes...", total=None)
                    nodes = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching nodes...")
                nodes = asyncio.run(run())

            if not nodes:
                self.print("No nodes found.")
                return 0

            # Filter available nodes if requested
            if available_only:
                nodes = [n for n in nodes if n.get("status") == "available"]

            # Display nodes
            if self.console:
                table = Table(title=f"Nodes in Cluster: {cluster_id}")
                table.add_column("Node ID", style="cyan")
                table.add_column("Status", style="green")
                table.add_column("CPU", style="blue")
                table.add_column("Memory", style="magenta")
                table.add_column("Tasks", style="yellow")

                for node in nodes:
                    resources = node.get("resources", {})
                    table.add_row(
                        node.get("node_id", "Unknown"),
                        node.get("status", "Unknown"),
                        f"{resources.get('cpu', 0)}%",
                        f"{resources.get('memory', 0)} MB",
                        str(node.get("running_tasks", 0)),
                    )

                self.console.print(table)
            else:
                print(f"Nodes in Cluster: {cluster_id}")
                print("-" * 80)
                for node in nodes:
                    print(
                        f"{node.get('node_id', 'Unknown'):30} {node.get('status', 'Unknown'):15} Tasks: {node.get('running_tasks', 0)}"
                    )

            return 0

        except Exception as e:
            self.print_error(f"Failed to list nodes: {e}")
            return 1

    def list_node_ids(self, cluster_id: str, available_only: bool = False) -> int:
        """List node IDs only."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.list_node_ids(cluster_id, available_only)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching node IDs...", total=None)
                    node_ids = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching node IDs...")
                node_ids = asyncio.run(run())

            if not node_ids:
                self.print("No nodes found.")
                return 0

            status_text = "available " if available_only else ""
            self.print(f"Found {len(node_ids)} {status_text}nodes:")
            for node_id in node_ids:
                self.print(f"  {node_id}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to list node IDs: {e}")
            return 1

    def show_node(self, cluster_id: str, node_id: str) -> int:
        """Show detailed node information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.get_node(cluster_id, node_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching node details...", total=None)
                    node = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching node details...")
                node = asyncio.run(run())

            # Display node details
            if self.console:
                resources = node.get("resources", {})
                panel = Panel.fit(
                    f"[cyan]Node ID:[/cyan] {node.get('node_id', 'Unknown')}\n"
                    f"[cyan]Status:[/cyan] {node.get('status', 'Unknown')}\n"
                    f"[cyan]Cluster ID:[/cyan] {cluster_id}\n"
                    f"[cyan]CPU Usage:[/cyan] {resources.get('cpu', 0)}%\n"
                    f"[cyan]Memory Usage:[/cyan] {resources.get('memory', 0)} MB\n"
                    f"[cyan]Running Tasks:[/cyan] {node.get('running_tasks', 0)}\n"
                    f"[cyan]Last Seen:[/cyan] {node.get('last_seen', 'Unknown')}",
                    title=f"Node: {node_id}",
                )
                self.console.print(panel)
            else:
                print(f"Node: {node_id}")
                print(f"  Status: {node.get('status', 'Unknown')}")
                print(f"  Cluster ID: {cluster_id}")
                print(f"  Running Tasks: {node.get('running_tasks', 0)}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to get node details: {e}")
            return 1

    def show_node_resources(self, cluster_id: str, node_id: str) -> int:
        """Show current node resources."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.get_node_resources(cluster_id, node_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching node resources...", total=None)
                    resources = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching node resources...")
                resources = asyncio.run(run())

            # Display resources
            if self.console:
                panel = Panel.fit(
                    f"[cyan]CPU Usage:[/cyan] {resources.get('cpu', 0)}%\n"
                    f"[cyan]Memory Usage:[/cyan] {resources.get('memory', 0)} MB\n"
                    f"[cyan]Disk Usage:[/cyan] {resources.get('disk', 0)} MB\n"
                    f"[cyan]GPU Usage:[/cyan] {resources.get('gpu', 'N/A')}%\n"
                    f"[cyan]Network I/O:[/cyan] {resources.get('network_io', 'N/A')} MB/s\n"
                    f"[cyan]Last Updated:[/cyan] {resources.get('timestamp', 'Unknown')}",
                    title=f"Resources for Node: {node_id}",
                )
                self.console.print(panel)
            else:
                print(f"Resources for Node: {node_id}")
                print(f"  CPU Usage: {resources.get('cpu', 0)}%")
                print(f"  Memory Usage: {resources.get('memory', 0)} MB")
                print(f"  Disk Usage: {resources.get('disk', 0)} MB")

            return 0

        except Exception as e:
            self.print_error(f"Failed to get node resources: {e}")
            return 1

    def show_node_tasks(self, cluster_id: str, node_id: str) -> int:
        """Show tasks assigned to a node."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.select_tasks(cluster_id, node_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching node tasks...", total=None)
                    tasks = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching node tasks...")
                tasks = asyncio.run(run())

            if not tasks:
                self.print(f"No tasks found for node '{node_id}'.")
                return 0

            # Display tasks
            if self.console:
                table = Table(title=f"Tasks for Node: {node_id}")
                table.add_column("Task ID", style="cyan")
                table.add_column("Swarm ID", style="blue")
                table.add_column("Status", style="green")
                table.add_column("Progress", style="yellow")

                for task in tasks:
                    table.add_row(
                        task.get("task_id", "Unknown"),
                        task.get("swarm_id", "Unknown"),
                        task.get("status", "Unknown"),
                        f"{task.get('progress', 0)}%",
                    )

                self.console.print(table)
            else:
                print(f"Tasks for Node: {node_id}")
                print("-" * 80)
                for task in tasks:
                    print(
                        f"{task.get('task_id', 'Unknown'):30} {task.get('swarm_id', 'Unknown'):30} {task.get('status', 'Unknown')}"
                    )

            return 0

        except Exception as e:
            self.print_error(f"Failed to get node tasks: {e}")
            return 1

    def stop_node(self, cluster_id: str, node_id: str) -> int:
        """Stop a node."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.stop_node(cluster_id, node_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Stopping node...", total=None)
                    result = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Stopping node...")
                result = asyncio.run(run())

            self.print_success(f"Node stopped: {result}")
            return 0

        except Exception as e:
            self.print_error(f"Failed to stop node: {e}")
            return 1

    def remove_node(self, cluster_id: str, node_id: str, force: bool = False) -> int:
        """Remove a node from cluster."""
        if not force:
            if self.console:
                confirm = Confirm.ask(
                    f"Are you sure you want to remove node '{node_id}' from cluster?"
                )
                if not confirm:
                    self.print("Operation cancelled.")
                    return 0

        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.remove_node(cluster_id, node_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Removing node...", total=None)
                    result = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Removing node...")
                result = asyncio.run(run())

            self.print_success(f"Node removed: {result}")
            return 0

        except Exception as e:
            self.print_error(f"Failed to remove node: {e}")
            return 1

    def collect_node_errors(self, cluster_id: str) -> int:
        """Collect errors from nodes in cluster."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.collect_errors(cluster_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Collecting errors...", total=None)
                    errors = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Collecting errors...")
                errors = asyncio.run(run())

            if not errors:
                self.print_success("No errors found.")
                return 0

            # Display errors
            if self.console:
                table = Table(title=f"Errors in Cluster: {cluster_id}")
                table.add_column("Time", style="cyan")
                table.add_column("Node ID", style="blue")
                table.add_column("Error", style="red")

                for error in errors:
                    table.add_row(
                        error.get("timestamp", "Unknown"),
                        error.get("node_id", "Unknown"),
                        error.get("error_message", "Unknown"),
                    )

                self.console.print(table)
            else:
                print(f"Errors in Cluster: {cluster_id}")
                print("-" * 80)
                for error in errors:
                    print(
                        f"{error.get('timestamp', 'Unknown'):20} {error.get('node_id', 'Unknown'):20} {error.get('error_message', 'Unknown')}"
                    )

            return 0

        except Exception as e:
            self.print_error(f"Failed to collect errors: {e}")
            return 1

    def monitor_node(self, cluster_id: str, node_id: str) -> int:
        """Monitor node resources in real-time."""
        self.print_error("Real-time node monitoring not yet implemented")
        self.print("Use 'manta node resources' to see current status")
        return 1

    # ============================================
    # Results Management Operations
    # ============================================

    def handle_results_commands(self, args) -> int:
        """Handle results management commands."""
        if not args.results_command:
            self.print_error("Results command required")
            return 1

        if args.results_command == "list":
            return self.list_results(args.swarm_id, args.tag)
        elif args.results_command == "list-tags":
            return self.list_result_tags(args.swarm_id)
        elif args.results_command == "list-global-tags":
            return self.list_global_tags(args.swarm_id)
        elif args.results_command == "stream":
            return self.stream_results(args.swarm_id, args.tag)
        elif args.results_command == "export":
            return self.export_results(
                args.swarm_id, args.tag, getattr(args, "output_file", None)
            )
        elif args.results_command == "delete":
            return self.delete_results(
                args.swarm_id, args.tag, getattr(args, "force", False)
            )
        elif args.results_command == "global":
            return self.select_global_data(args.swarm_id, args.tag)
        else:
            self.print_error(f"Unknown results command: {args.results_command}")
            return 1

    def list_results(self, swarm_id: str, tag: str) -> int:
        """List results for a swarm and tag."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.select_results(swarm_id, tag)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching results...", total=None)
                    results = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching results...")
                results = asyncio.run(run())

            if not results or swarm_id not in results:
                self.print("No results found.")
                return 0

            result_data = results[swarm_id]

            # Display results summary
            if self.console:
                panel = Panel.fit(
                    f"[cyan]Swarm ID:[/cyan] {swarm_id}\n"
                    f"[cyan]Tag:[/cyan] {tag}\n"
                    f"[cyan]Iterations:[/cyan] {len(result_data.data)}\n"
                    f"[cyan]Node Count:[/cyan] {len(set(node_id for iteration in result_data.data for node_id in iteration.keys()))}\n"
                    f"[cyan]Total Results:[/cyan] {sum(len(nodes) for nodes in result_data.data)}",
                    title=f"Results: {swarm_id}/{tag}",
                )
                self.console.print(panel)

                # Show sample of results
                if result_data.data:
                    table = Table(title="Sample Results (First Iteration)")
                    table.add_column("Node ID", style="cyan")
                    table.add_column("Value", style="green")

                    first_iteration = result_data.data[0]
                    for node_id, node_data in first_iteration.items():
                        value = str(node_data.get(tag, "N/A"))[
                            :50
                        ]  # Truncate long values
                        table.add_row(node_id, value)

                    self.console.print(table)
            else:
                print(f"Results: {swarm_id}/{tag}")
                print(f"  Iterations: {len(result_data.data)}")
                print(
                    f"  Total Results: {sum(len(nodes) for nodes in result_data.data)}"
                )

            return 0

        except Exception as e:
            self.print_error(f"Failed to list results: {e}")
            return 1

    def list_result_tags(self, swarm_id: str) -> int:
        """List available result tags for a swarm."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.list_result_tags(swarm_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching result tags...", total=None)
                    tags = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching result tags...")
                tags = asyncio.run(run())

            if not tags or not tags.get("tags"):
                self.print("No result tags found.")
                return 0

            # Display tags
            if self.console:
                table = Table(title=f"Result Tags for Swarm: {swarm_id}")
                table.add_column("Tag", style="cyan")
                table.add_column("Count", style="blue")
                table.add_column("Last Updated", style="green")

                for tag_name, tag_info in tags.get("tags", {}).items():
                    table.add_row(
                        tag_name,
                        str(tag_info.get("count", 0)),
                        tag_info.get("last_updated", "Unknown"),
                    )

                self.console.print(table)
            else:
                print(f"Result Tags for Swarm: {swarm_id}")
                print("-" * 60)
                for tag_name, tag_info in tags.get("tags", {}).items():
                    print(f"{tag_name:30} Count: {tag_info.get('count', 0)}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to list result tags: {e}")
            return 1

    def list_global_tags(self, swarm_id: str) -> int:
        """List available global tags for a swarm."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.list_global_tags(swarm_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching global tags...", total=None)
                    tags = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching global tags...")
                tags = asyncio.run(run())

            if not tags or not tags.get("tags"):
                self.print("No global tags found.")
                return 0

            # Display global tags
            if self.console:
                table = Table(title=f"Global Tags for Swarm: {swarm_id}")
                table.add_column("Tag", style="cyan")
                table.add_column("Type", style="blue")
                table.add_column("Size", style="green")

                for tag_name, tag_info in tags.get("tags", {}).items():
                    table.add_row(
                        tag_name,
                        tag_info.get("type", "Unknown"),
                        self._format_size(tag_info.get("size", 0)),
                    )

                self.console.print(table)
            else:
                print(f"Global Tags for Swarm: {swarm_id}")
                print("-" * 60)
                for tag_name, tag_info in tags.get("tags", {}).items():
                    print(f"{tag_name:30} Type: {tag_info.get('type', 'Unknown')}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to list global tags: {e}")
            return 1

    def stream_results(self, swarm_id: str, tag: str) -> int:
        """Stream results in real-time."""
        api = self._get_user_api()
        if not api:
            return 1

        async def run_stream():
            try:
                # Set up signal handling for graceful shutdown
                stop_streaming = False

                def signal_handler(_signum, _frame):
                    nonlocal stop_streaming
                    stop_streaming = True

                signal.signal(signal.SIGINT, signal_handler)
                signal.signal(signal.SIGTERM, signal_handler)

                # Create Rich components
                table = Table(title=f"Real-time Results: {swarm_id} (tag: {tag})")
                table.add_column("Timestamp", style="cyan")
                table.add_column("Node ID", style="blue")
                table.add_column("Task ID", style="magenta")
                table.add_column("Iteration", style="green")
                table.add_column("Data Size", style="yellow")

                # Status panel for connection info
                status_panel = Panel(
                    "[green]● Connected[/green] - Streaming results...\n"
                    + "Press Ctrl+C to stop streaming",
                    title="Streaming Status",
                    border_style="green",
                )

                # Counters for statistics
                result_count = 0
                start_time = time.time()
                last_result_time = None

                # Display initial table with status
                if self.console:
                    with Live(console=self.console, refresh_per_second=4) as live:
                        # Start streaming
                        try:
                            async for result in api.stream_results(swarm_id, tag):
                                if stop_streaming:
                                    break

                                # Process result data
                                timestamp = result.get(
                                    "timestamp", datetime.now().strftime("%H:%M:%S")
                                )
                                node_id = result.get("node_id", "Unknown")
                                task_id = result.get("task_id", "Unknown")
                                iteration = result.get("iteration", 0)
                                data = result.get("data", b"")
                                data_size = (
                                    len(data) if isinstance(data, (bytes, str)) else 0
                                )

                                # Add to table
                                table.add_row(
                                    str(timestamp),
                                    str(node_id),
                                    str(task_id),
                                    str(iteration),
                                    self._format_size(data_size),
                                )

                                # Update counters
                                result_count += 1
                                last_result_time = time.time()
                                elapsed = last_result_time - start_time

                                # Update status panel with stats
                                status_text = (
                                    f"[green]● Connected[/green] - Streaming results...\n"
                                    f"Results received: {result_count}\n"
                                    f"Elapsed time: {elapsed:.1f}s\n"
                                    f"Press Ctrl+C to stop streaming"
                                )
                                status_panel = Panel(
                                    status_text,
                                    title="Streaming Status",
                                    border_style="green",
                                )

                                # Update live display
                                display = Columns(
                                    [status_panel, table], equal=False, expand=True
                                )
                                live.update(display)

                        except KeyboardInterrupt:
                            stop_streaming = True
                        except Exception as e:
                            # Update status to show error
                            error_panel = Panel(
                                f"[red]✗ Connection Error[/red]: {str(e)}\n"
                                + "Attempting to reconnect...",
                                title="Streaming Status",
                                border_style="red",
                            )
                            display = Columns(
                                [error_panel, table], equal=False, expand=True
                            )
                            live.update(display)

                            # Wait a bit before trying to reconnect
                            await asyncio.sleep(2)

                        # Final status update
                        final_status = (
                            f"[yellow]● Disconnected[/yellow] - Streaming stopped.\n"
                            f"Total results received: {result_count}\n"
                            f"Total time: {time.time() - start_time:.1f}s"
                        )
                        final_panel = Panel(
                            final_status,
                            title="Streaming Complete",
                            border_style="yellow",
                        )
                        display = Columns(
                            [final_panel, table], equal=False, expand=True
                        )
                        live.update(display)

                        # Brief pause to show final status
                        await asyncio.sleep(1)
                else:
                    # Fallback for non-Rich console
                    print(f"Streaming results for swarm {swarm_id}, tag {tag}...")
                    print("Press Ctrl+C to stop streaming")

                    try:
                        async for result in api.stream_results(swarm_id, tag):
                            if stop_streaming:
                                break

                            timestamp = result.get(
                                "timestamp", datetime.now().strftime("%H:%M:%S")
                            )
                            node_id = result.get("node_id", "Unknown")
                            task_id = result.get("task_id", "Unknown")
                            iteration = result.get("iteration", 0)

                            print(
                                f"[{timestamp}] Node: {node_id}, Task: {task_id}, Iteration: {iteration}"
                            )
                            result_count += 1

                    except KeyboardInterrupt:
                        pass

                    print(
                        f"\nStreaming stopped. Total results received: {result_count}"
                    )

                return 0

            except Exception as e:
                if self.console:
                    self.print_error(f"Failed to stream results: {e}")
                else:
                    print(f"Error: Failed to stream results: {e}")
                return 1

        try:
            if self.console:
                self.print(
                    f"[cyan]Starting result streaming for swarm {swarm_id}, tag {tag}...[/cyan]"
                )
            else:
                print(f"Starting result streaming for swarm {swarm_id}, tag {tag}...")

            return asyncio.run(run_stream())

        except Exception as e:
            self.print_error(f"Failed to start result streaming: {e}")
            return 1

    def export_results(
        self, swarm_id: str, tag: str, output_file: Optional[str] = None
    ) -> int:
        """Export results to file."""
        self.print_error("Results export not yet implemented in CLI")
        self.print("Use the SDK directly for now:")
        self.print("  from manta.apis import AsyncUserAPI")
        self.print("  # Export results to file")
        return 1

    def delete_results(self, swarm_id: str, tag: str, force: bool = False) -> int:
        """Delete results for a swarm and tag."""
        if not force:
            if self.console:
                confirm = Confirm.ask(
                    f"Are you sure you want to delete results '{tag}' for swarm '{swarm_id}'?"
                )
                if not confirm:
                    self.print("Operation cancelled.")
                    return 0

        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.delete_results(swarm_id, tag)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Deleting results...", total=None)
                    result = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Deleting results...")
                result = asyncio.run(run())

            self.print_success(f"Results deleted: {result}")
            return 0

        except Exception as e:
            self.print_error(f"Failed to delete results: {e}")
            return 1

    def select_global_data(self, swarm_id: str, tag: str) -> int:
        """Select global data for a swarm and tag."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                global_data = []
                async for data in api.select_global(swarm_id, tag):
                    global_data.append(data)
                return global_data

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Fetching global data...", total=None)
                    global_data = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Fetching global data...")
                global_data = asyncio.run(run())

            if not global_data:
                self.print("No global data found.")
                return 0

            # Display global data
            self.print(f"Global data for {swarm_id}/{tag}:")
            if self.console:
                for i, data in enumerate(global_data[:5]):  # Show first 5 entries
                    panel = Panel.fit(
                        json.dumps(data, indent=2)[:500]
                        + ("..." if len(json.dumps(data, indent=2)) > 500 else ""),
                        title=f"Entry {i + 1}",
                    )
                    self.console.print(panel)

                if len(global_data) > 5:
                    self.print(f"... and {len(global_data) - 5} more entries")
            else:
                for i, data in enumerate(global_data[:3]):  # Show first 3 entries
                    print(f"Entry {i + 1}: {str(data)[:200]}")
                if len(global_data) > 3:
                    print(f"... and {len(global_data) - 3} more entries")

            return 0

        except Exception as e:
            self.print_error(f"Failed to select global data: {e}")
            return 1

    # ============================================
    # Logging Operations
    # ============================================

    def handle_logs_commands(self, args) -> int:
        """Handle logging commands."""
        if not args.logs_command:
            self.print_error("Logs command required")
            return 1

        if args.logs_command == "collect":
            return self.collect_logs(
                args.swarm_id,
                getattr(args, "node_ids", None),
                getattr(args, "task_ids", None),
                getattr(args, "severity", None),
            )
        elif args.logs_command == "stream":
            return self.stream_logs(args.swarm_id)
        elif args.logs_command == "export":
            return self.export_logs(args.swarm_id, getattr(args, "output_file", None))
        else:
            self.print_error(f"Unknown logs command: {args.logs_command}")
            return 1

    def collect_logs(
        self,
        swarm_id: str,
        node_ids: Optional[List[str]] = None,
        task_ids: Optional[List[str]] = None,
        severity: Optional[List[str]] = None,
    ) -> int:
        """Collect logs with filtering."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.collect_logs(
                    swarm_id=swarm_id,
                    node_ids=node_ids,
                    task_ids=task_ids,
                    severity=severity,
                )

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Collecting logs...", total=None)
                    logs = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                print("Collecting logs...")
                logs = asyncio.run(run())

            if not logs:
                self.print("No logs found.")
                return 0

            # Display logs
            if self.console:
                table = Table(title=f"Logs for Swarm: {swarm_id}")
                table.add_column("Time", style="cyan")
                table.add_column("Node", style="blue")
                table.add_column("Task", style="magenta")
                table.add_column("Severity", style="yellow")
                table.add_column("Message", style="white")

                for log_entry in logs[-50:]:  # Show last 50 entries
                    table.add_row(
                        log_entry.get("timestamp", "Unknown"),
                        (
                            log_entry.get("node_id", "Unknown")[:8]
                            if log_entry.get("node_id")
                            else "N/A"
                        ),
                        (
                            log_entry.get("task_id", "Unknown")[:8]
                            if log_entry.get("task_id")
                            else "N/A"
                        ),
                        log_entry.get("severity", "INFO"),
                        log_entry.get("message", "")[:100],  # Truncate long messages
                    )

                self.console.print(table)

                if len(logs) > 50:
                    self.print(
                        f"Showing last 50 of {len(logs)} log entries. Use export for full logs."
                    )
            else:
                print(f"Logs for Swarm: {swarm_id}")
                print("-" * 120)
                for log_entry in logs[-20:]:  # Show last 20 entries
                    timestamp = log_entry.get("timestamp", "Unknown")
                    node_id = (
                        log_entry.get("node_id", "Unknown")[:8]
                        if log_entry.get("node_id")
                        else "N/A"
                    )
                    severity = log_entry.get("severity", "INFO")
                    message = log_entry.get("message", "")[:80]
                    print(f"{timestamp:20} {node_id:10} {severity:8} {message}")

                if len(logs) > 20:
                    print(f"... showing last 20 of {len(logs)} log entries")

            return 0

        except Exception as e:
            self.print_error(f"Failed to collect logs: {e}")
            return 1

    def stream_logs(self, swarm_id: str) -> int:
        """Stream logs in real-time."""
        api = self._get_user_api()
        if not api:
            return 1

        async def run_stream():
            try:
                # Set up signal handling for graceful shutdown
                stop_streaming = False

                def signal_handler(_signum, _frame):
                    nonlocal stop_streaming
                    stop_streaming = True

                signal.signal(signal.SIGINT, signal_handler)
                signal.signal(signal.SIGTERM, signal_handler)

                # Create Rich components for log display
                log_entries = []
                max_log_entries = 1000  # Keep last 1000 log entries

                # Status panel for connection info
                status_panel = Panel(
                    "[green]● Connected[/green] - Streaming logs...\n"
                    + "Press Ctrl+C to stop streaming",
                    title="Log Streaming Status",
                    border_style="green",
                )

                # Counters for statistics
                log_count = 0
                start_time = time.time()
                log_levels = {"ERROR": 0, "WARN": 0, "INFO": 0, "DEBUG": 0, "OTHER": 0}

                def get_log_color(level):
                    """Get color for log level."""
                    colors = {
                        "ERROR": "red",
                        "WARN": "yellow",
                        "WARNING": "yellow",
                        "INFO": "blue",
                        "DEBUG": "dim",
                        "TRACE": "dim",
                    }
                    return colors.get(level.upper(), "white")

                def format_log_entry(log):
                    """Format a log entry for display."""
                    timestamp = log.get(
                        "timestamp", datetime.now().strftime("%H:%M:%S.%f")[:-3]
                    )
                    level = log.get("level", "INFO")
                    message = log.get("message", str(log.get("data", "")))
                    node_id = log.get("node_id", "Unknown")
                    task_id = log.get("task_id", "Unknown")

                    # Truncate long messages for display
                    if len(message) > 100:
                        message = message[:97] + "..."

                    color = get_log_color(level)
                    formatted = f"[dim]{timestamp}[/dim] [{color}]{level:5s}[/{color}] [cyan]{node_id}[/cyan] [magenta]{task_id}[/magenta] {message}"
                    return formatted

                # Display streaming logs
                if self.console:
                    with Live(console=self.console, refresh_per_second=10) as live:
                        try:
                            async for log in api.stream_logs(swarm_id):
                                if stop_streaming:
                                    break

                                # Process log entry
                                level = log.get("level", "INFO").upper()
                                if level in log_levels:
                                    log_levels[level] += 1
                                else:
                                    log_levels["OTHER"] += 1

                                # Add to log entries list
                                formatted_entry = format_log_entry(log)
                                log_entries.append(formatted_entry)

                                # Keep only recent entries
                                if len(log_entries) > max_log_entries:
                                    log_entries.pop(0)

                                # Update counters
                                log_count += 1
                                elapsed = time.time() - start_time

                                # Create log panel with recent entries
                                recent_logs = log_entries[-20:]  # Show last 20 entries
                                log_display = "\n".join(recent_logs)
                                if len(log_entries) > 20:
                                    log_display = (
                                        f"[dim]... {len(log_entries) - 20} older entries ...[/dim]\n"
                                        + log_display
                                    )

                                log_panel = Panel(
                                    log_display,
                                    title=f"Recent Log Entries ({len(log_entries)} total)",
                                    border_style="blue",
                                    height=15,
                                )

                                # Update status panel with stats
                                status_text = (
                                    f"[green]● Connected[/green] - Streaming logs...\n"
                                    f"Total logs: {log_count}\n"
                                    f"Elapsed: {elapsed:.1f}s\n"
                                    f"ERROR: {log_levels['ERROR']} | WARN: {log_levels['WARN']} | INFO: {log_levels['INFO']} | DEBUG: {log_levels['DEBUG']}\n"
                                    f"Press Ctrl+C to stop"
                                )
                                status_panel = Panel(
                                    status_text,
                                    title="Log Streaming Status",
                                    border_style="green",
                                )

                                # Create combined display
                                layout = Layout()
                                layout.split_column(
                                    Layout(status_panel, size=8), Layout(log_panel)
                                )
                                live.update(layout)

                        except KeyboardInterrupt:
                            stop_streaming = True
                        except Exception as e:
                            # Show error in status
                            error_panel = Panel(
                                f"[red]✗ Connection Error[/red]: {str(e)}\n"
                                + "Attempting to reconnect...",
                                title="Log Streaming Status",
                                border_style="red",
                            )

                            # Keep recent logs visible during error
                            recent_logs = (
                                log_entries[-20:]
                                if log_entries
                                else ["[dim]No logs received yet...[/dim]"]
                            )
                            log_display = "\n".join(recent_logs)
                            log_panel = Panel(
                                log_display,
                                title=f"Recent Log Entries ({len(log_entries)} total)",
                                border_style="red",
                                height=15,
                            )

                            layout = Layout()
                            layout.split_column(
                                Layout(error_panel, size=8), Layout(log_panel)
                            )
                            live.update(layout)

                            # Wait before retrying
                            await asyncio.sleep(2)

                        # Final status update
                        final_status = (
                            f"[yellow]● Disconnected[/yellow] - Log streaming stopped.\n"
                            f"Total logs received: {log_count}\n"
                            f"Total time: {time.time() - start_time:.1f}s\n"
                            f"Final counts - ERROR: {log_levels['ERROR']} | WARN: {log_levels['WARN']} | INFO: {log_levels['INFO']} | DEBUG: {log_levels['DEBUG']}"
                        )
                        final_panel = Panel(
                            final_status,
                            title="Log Streaming Complete",
                            border_style="yellow",
                        )

                        # Show final logs
                        if log_entries:
                            final_logs = log_entries[
                                -30:
                            ]  # Show more entries in final view
                            log_display = "\n".join(final_logs)
                            if len(log_entries) > 30:
                                log_display = (
                                    f"[dim]... {len(log_entries) - 30} older entries ...[/dim]\n"
                                    + log_display
                                )
                        else:
                            log_display = "[dim]No logs were received during the streaming session.[/dim]"

                        final_log_panel = Panel(
                            log_display,
                            title=f"Final Log Summary ({len(log_entries)} total entries)",
                            border_style="yellow",
                        )

                        final_layout = Layout()
                        final_layout.split_column(
                            Layout(final_panel, size=8), Layout(final_log_panel)
                        )
                        live.update(final_layout)

                        # Brief pause to show final status
                        await asyncio.sleep(2)
                else:
                    # Fallback for non-Rich console
                    print(f"Streaming logs for swarm {swarm_id}...")
                    print("Press Ctrl+C to stop streaming")

                    try:
                        async for log in api.stream_logs(swarm_id):
                            if stop_streaming:
                                break

                            timestamp = log.get(
                                "timestamp", datetime.now().strftime("%H:%M:%S")
                            )
                            level = log.get("level", "INFO")
                            message = log.get("message", str(log.get("data", "")))
                            node_id = log.get("node_id", "Unknown")

                            print(f"[{timestamp}] {level:5s} [{node_id}] {message}")
                            log_count += 1

                    except KeyboardInterrupt:
                        pass

                    print(f"\nLog streaming stopped. Total logs received: {log_count}")

                return 0

            except Exception as e:
                if self.console:
                    self.print_error(f"Failed to stream logs: {e}")
                else:
                    print(f"Error: Failed to stream logs: {e}")
                return 1

        try:
            if self.console:
                self.print(
                    f"[cyan]Starting log streaming for swarm {swarm_id}...[/cyan]"
                )
            else:
                print(f"Starting log streaming for swarm {swarm_id}...")

            return asyncio.run(run_stream())

        except Exception as e:
            self.print_error(f"Failed to start log streaming: {e}")
            return 1

    def export_logs(self, swarm_id: str, output_file: Optional[str] = None) -> int:
        """Export logs to file."""
        self.print_error("Log export not yet implemented in CLI")
        self.print("Use the SDK directly for now:")
        return 1

    # ============================================
    # Swarm Deployment Wizard Helper Functions
    # ============================================

    def _choose_deployment_mode(self) -> str:
        """Choose between interactive creation or file-based deployment."""
        if self.console:
            self.console.print(
                "\n[bold yellow]Step 1: Choose Deployment Mode[/bold yellow]"
            )

            choices = [
                "1. Python - Deploy from Python swarm definition file",
                "2. Interactive - Create swarm configuration step-by-step",
                "3. Cancel",
            ]

            for choice in choices:
                self.console.print(f"  {choice}")

            while True:
                mode = Prompt.ask("\nChoose deployment mode", choices=["1", "2", "3"])
                if mode == "1":
                    return "file"
                elif mode == "2":
                    return "interactive"
                elif mode == "3":
                    return "cancel"
        else:
            self.print("\nChoose deployment mode:")
            self.print("1. Python - Deploy from Python swarm definition")
            self.print("2. Interactive - Create swarm configuration")
            self.print("3. Cancel")

            while True:
                mode = input("Enter choice (1-3): ").strip()
                if mode == "1":
                    return "file"
                elif mode == "2":
                    return "interactive"
                elif mode == "3":
                    return "cancel"
                else:
                    self.print("Invalid choice. Please enter 1, 2, or 3.")

    def _select_cluster_interactive(self, api) -> Optional[str]:
        """Interactively select a cluster for deployment."""
        if self.console:
            self.console.print(
                "\n[bold yellow]Step 2: Select Target Cluster[/bold yellow]"
            )
        else:
            self.print("\nStep 2: Select Target Cluster")

        try:
            # Fetch clusters
            async def run():
                return await api.stream_and_fetch_clusters()

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task(
                        "Fetching available clusters...", total=None
                    )
                    clusters = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                self.print("Fetching available clusters...")
                clusters = asyncio.run(run())

            if not clusters:
                self.print_error(
                    "No clusters available. Please create a cluster first."
                )
                return None

            # Display clusters and let user choose
            if self.console:
                table = Table(title="Available Clusters")
                table.add_column("#", style="cyan", width=3)
                table.add_column("Cluster ID", style="blue")
                table.add_column("Name", style="green")
                table.add_column("Status", style="yellow")
                table.add_column("Nodes", style="magenta")

                for i, cluster in enumerate(clusters, 1):
                    table.add_row(
                        str(i),
                        cluster.get("cluster_id", "Unknown"),
                        cluster.get("name", "Unknown"),
                        cluster.get("status", "Unknown"),
                        str(cluster.get("node_count", 0)),
                    )

                self.console.print(table)

                while True:
                    try:
                        choice = IntPrompt.ask("Select cluster number", default=1)
                        if 1 <= choice <= len(clusters):
                            selected_cluster = clusters[choice - 1]
                            cluster_id = selected_cluster.get("cluster_id")
                            self.console.print(
                                f"Selected cluster: [cyan]{cluster_id}[/cyan]"
                            )
                            return cluster_id
                        else:
                            self.console.print(
                                f"[red]Please enter a number between 1 and {len(clusters)}[/red]"
                            )
                    except KeyboardInterrupt:
                        return None
            else:
                self.print("Available clusters:")
                for i, cluster in enumerate(clusters, 1):
                    self.print(
                        f"{i}. {cluster.get('cluster_id', 'Unknown')} - {cluster.get('name', 'Unknown')} ({cluster.get('node_count', 0)} nodes)"
                    )

                while True:
                    try:
                        choice = input(
                            f"Select cluster number (1-{len(clusters)}): "
                        ).strip()
                        choice = int(choice)
                        if 1 <= choice <= len(clusters):
                            selected_cluster = clusters[choice - 1]
                            cluster_id = selected_cluster.get("cluster_id")
                            self.print(f"Selected cluster: {cluster_id}")
                            return cluster_id
                        else:
                            self.print(
                                f"Please enter a number between 1 and {len(clusters)}"
                            )
                    except (ValueError, KeyboardInterrupt):
                        return None

        except Exception as e:
            self.print_error(f"Failed to fetch clusters: {e}")
            return None

    def _deploy_from_file(self, api, cluster_id: str) -> int:
        """Deploy swarm from Python definition file."""
        if self.console:
            self.console.print(
                "\n[bold yellow]Step 3: Deploy from Python Swarm Definition[/bold yellow]"
            )

            file_path = Prompt.ask("Enter path to Python swarm file (e.g., swarm.py)")
        else:
            self.print("\nStep 3: Deploy from Python Swarm Definition")
            file_path = input("Enter path to Python swarm file: ").strip()

        if not file_path:
            self.print_error("No file path provided.")
            return 1

        config_path = Path(file_path)
        if not config_path.exists():
            self.print_error(f"Swarm file not found: {file_path}")
            return 1

        if not config_path.suffix == ".py":
            self.print_error(
                "Please provide a Python file (.py) containing the swarm definition."
            )
            return 1

        try:
            # Load the Python swarm definition
            swarm = self._load_python_swarm(config_path)
            if not swarm:
                return 1

            # Preview swarm configuration
            if not self._preview_python_swarm(swarm):
                return 0  # User cancelled

            # Deploy the swarm
            return self._execute_deployment(api, cluster_id, swarm)

        except ImportError as e:
            self.print_error(f"Failed to import swarm module: {e}")
            return 1
        except AttributeError as e:
            self.print_error(f"Invalid swarm definition: {e}")
            return 1
        except Exception as e:
            self.print_error(f"Failed to load swarm: {e}")
            return 1

    def _deploy_interactive(self, api, cluster_id: str) -> int:
        """Deploy swarm with interactive configuration."""
        if self.console:
            self.console.print(
                "\n[bold yellow]Step 3: Interactive Swarm Configuration[/bold yellow]"
            )
        else:
            self.print("\nStep 3: Interactive Swarm Configuration")

        # Get available modules
        modules = self._fetch_available_modules(api)
        if modules is None:
            return 1

        # Build swarm configuration interactively
        swarm_config = self._build_swarm_config_interactive(modules)
        if not swarm_config:
            return 1

        # Create swarm object
        swarm = self._create_swarm_from_config(swarm_config)
        if not swarm:
            return 1

        # Preview configuration
        if not self._preview_swarm_config(swarm, swarm_config):
            return 0  # User cancelled

        # Deploy the swarm
        return self._execute_deployment(api, cluster_id, swarm)

    def _fetch_available_modules(self, api) -> Optional[List[Any]]:
        """Fetch available modules for swarm configuration."""
        try:

            async def run():
                return await api.stream_and_fetch_modules()

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task(
                        "Fetching available modules...", total=None
                    )
                    modules = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                self.print("Fetching available modules...")
                modules = asyncio.run(run())

            return modules

        except Exception as e:
            self.print_error(f"Failed to fetch modules: {e}")
            return None

    def _build_swarm_config_interactive(
        self, modules: List[Any]
    ) -> Optional[Dict[str, Any]]:
        """Build swarm configuration through interactive prompts."""
        config = {
            "name": "InteractiveSwarm",
            "modules": [],
            "globals": {},
            "networks": [],
            "tasks": [],
        }

        # Step 3a: Basic configuration
        if self.console:
            self.console.print("\n[bold blue]Basic Configuration[/bold blue]")
            config["name"] = Prompt.ask("Swarm name", default="InteractiveSwarm")
        else:
            self.print("\nBasic Configuration:")
            name = input("Swarm name (default: InteractiveSwarm): ").strip()
            config["name"] = name if name else "InteractiveSwarm"

        # Step 3b: Select modules
        if not self._select_modules_interactive(config, modules):
            return None

        # Step 3c: Configure global parameters
        if not self._configure_globals_interactive(config):
            return None

        # Step 3d: Configure networks (optional)
        self._configure_networks_interactive(config)

        # Step 3e: Configure task execution order
        if not self._configure_tasks_interactive(config):
            return None

        return config

    def _validate_swarm_config(self, config: Dict[str, Any]) -> bool:
        """Validate the structure of a swarm configuration."""
        required_fields = ["name", "modules"]

        for field in required_fields:
            if field not in config:
                self.print_error(f"Missing required field '{field}' in configuration")
                return False

        # Validate modules structure
        modules = config.get("modules", [])
        if not isinstance(modules, list) or len(modules) == 0:
            self.print_error("Configuration must contain at least one module")
            return False

        for i, module in enumerate(modules):
            if not isinstance(module, dict):
                self.print_error(
                    f"Module {i + 1}: must be an object with 'id' and 'alias' fields"
                )
                return False
            if "id" not in module or "alias" not in module:
                self.print_error(
                    f"Module {i + 1}: must have both 'id' and 'alias' fields"
                )
                return False

        # Validate optional fields if present
        if "globals" in config and not isinstance(config["globals"], dict):
            self.print_error("'globals' field must be an object")
            return False

        if "networks" in config:
            networks = config["networks"]
            if not isinstance(networks, list):
                self.print_error("'networks' field must be an array")
                return False

            for i, network in enumerate(networks):
                if not isinstance(network, dict) or "name" not in network:
                    self.print_error(f"Network {i + 1}: must have a 'name' field")
                    return False

        if "tasks" in config:
            tasks = config["tasks"]
            if not isinstance(tasks, list):
                self.print_error("'tasks' field must be an array")
                return False

            for i, task in enumerate(tasks):
                if not isinstance(task, dict) or "type" not in task:
                    self.print_error(f"Task {i + 1}: must have a 'type' field")
                    return False

        return True

    def _select_modules_interactive(
        self, config: Dict[str, Any], modules: List[Any]
    ) -> bool:
        """Interactively select and configure modules."""
        if self.console:
            self.console.print("\n[bold blue]Module Selection[/bold blue]")
        else:
            self.print("\nModule Selection:")

        if not modules:
            self.print_error(
                "No modules available. Please upload modules first using 'manta module upload'."
            )
            return False

        # Display available modules
        if self.console:
            table = Table(title="Available Modules")
            table.add_column("#", style="cyan", width=3)
            table.add_column("Module ID", style="blue")
            table.add_column("Name", style="green")
            table.add_column("Type", style="yellow")

            for i, module in enumerate(modules, 1):
                table.add_row(
                    str(i),
                    str(getattr(module, "module_id", "Unknown")),
                    str(getattr(module, "name", "Unknown")),
                    str(getattr(module, "module_type", "Unknown")),
                )

            self.console.print(table)
        else:
            self.print("Available modules:")
            for i, module in enumerate(modules, 1):
                self.print(
                    f"{i}. {getattr(module, 'module_id', 'Unknown')} - {getattr(module, 'name', 'Unknown')}"
                )

        # Select modules
        selected_modules = []
        while True:
            if self.console:
                if selected_modules:
                    self.console.print(
                        f"\nCurrently selected: {len(selected_modules)} modules"
                    )
                choice = Prompt.ask(
                    "Select module number (or 'done' to finish, 'cancel' to abort)"
                )
            else:
                if selected_modules:
                    self.print(f"\nCurrently selected: {len(selected_modules)} modules")
                choice = input("Select module number (or 'done'/'cancel'): ").strip()

            if choice.lower() == "done":
                if selected_modules:
                    break
                else:
                    self.print_error("You must select at least one module.")
                    continue
            elif choice.lower() == "cancel":
                return False

            try:
                choice_num = int(choice)
                if 1 <= choice_num <= len(modules):
                    module = modules[choice_num - 1]
                    module_id = str(getattr(module, "module_id", "Unknown"))

                    # Check if already selected
                    if any(m["id"] == module_id for m in selected_modules):
                        self.print("Module already selected.")
                        continue

                    # Add module with alias
                    if self.console:
                        alias = Prompt.ask(
                            f"Alias for module {getattr(module, 'name', 'Unknown')}",
                            default=getattr(
                                module, "name", f"module_{len(selected_modules) + 1}"
                            ),
                        )
                    else:
                        alias = input(
                            f"Alias for module (default: {getattr(module, 'name', f'module_{len(selected_modules) + 1}')}): "
                        ).strip()
                        if not alias:
                            alias = getattr(
                                module, "name", f"module_{len(selected_modules) + 1}"
                            )

                    selected_modules.append(
                        {
                            "id": module_id,
                            "alias": alias,
                            "name": getattr(module, "name", "Unknown"),
                        }
                    )

                    self.print_success(f"Added module: {alias}")
                else:
                    self.print_error(
                        f"Please enter a number between 1 and {len(modules)}"
                    )
            except ValueError:
                self.print_error("Please enter a valid number, 'done', or 'cancel'")

        config["modules"] = selected_modules
        return True

    def _configure_globals_interactive(self, config: Dict[str, Any]) -> bool:
        """Interactively configure global parameters."""
        if self.console:
            self.console.print("\n[bold blue]Global Parameters (Optional)[/bold blue]")
            self.console.print(
                "Global parameters are shared across all tasks in the swarm."
            )

            add_globals = Confirm.ask(
                "Would you like to add global parameters?", default=False
            )
        else:
            self.print("\nGlobal Parameters (Optional):")
            self.print("Global parameters are shared across all tasks in the swarm.")
            add_globals_input = input("Add global parameters? (y/N): ").strip().lower()
            add_globals = add_globals_input in ["y", "yes"]

        if not add_globals:
            return True

        globals_config = {}
        while True:
            if self.console:
                if globals_config:
                    self.console.print(
                        f"\nCurrent globals: {list(globals_config.keys())}"
                    )

                param_name = Prompt.ask("Parameter name (or 'done' to finish)").strip()
            else:
                if globals_config:
                    self.print(f"\nCurrent globals: {list(globals_config.keys())}")
                param_name = input("Parameter name (or 'done'): ").strip()

            if param_name.lower() == "done":
                break

            if not param_name:
                self.print_error("Parameter name cannot be empty.")
                continue

            # Get parameter value
            if self.console:
                param_value = Prompt.ask(f"Value for '{param_name}' (JSON format)")
            else:
                param_value = input(f"Value for '{param_name}' (JSON format): ")

            try:
                # Try to parse as JSON
                parsed_value = json.loads(param_value)
                globals_config[param_name] = parsed_value
                self.print_success(f"Added global parameter: {param_name}")
            except json.JSONDecodeError:
                # Store as string if not valid JSON
                globals_config[param_name] = param_value
                self.print_success(f"Added global parameter: {param_name} (as string)")

        config["globals"] = globals_config
        return True

    def _configure_networks_interactive(self, config: Dict[str, Any]):
        """Interactively configure networks (optional)."""
        if self.console:
            self.console.print(
                "\n[bold blue]Network Configuration (Optional)[/bold blue]"
            )
            self.console.print("Networks enable communication between tasks.")

            add_networks = Confirm.ask(
                "Would you like to add custom networks?", default=False
            )
        else:
            self.print("\nNetwork Configuration (Optional):")
            self.print("Networks enable communication between tasks.")
            add_networks_input = input("Add custom networks? (y/N): ").strip().lower()
            add_networks = add_networks_input in ["y", "yes"]

        if not add_networks:
            return

        networks = []
        drivers = ["overlay", "bridge", "host"]

        while True:
            if self.console:
                if networks:
                    self.console.print(
                        f"\nCurrent networks: {[n['name'] for n in networks]}"
                    )

                network_name = Prompt.ask("Network name (or 'done' to finish)").strip()
            else:
                if networks:
                    self.print(f"\nCurrent networks: {[n['name'] for n in networks]}")
                network_name = input("Network name (or 'done'): ").strip()

            if network_name.lower() == "done":
                break

            if not network_name:
                self.print_error("Network name cannot be empty.")
                continue

            # Select driver
            if self.console:
                self.console.print("Available drivers:")
                for i, driver in enumerate(drivers, 1):
                    self.console.print(f"  {i}. {driver}")

                driver_choice = IntPrompt.ask(
                    "Select driver", default=1, choices=["1", "2", "3"]
                )
                selected_driver = drivers[driver_choice - 1]
            else:
                self.print("Available drivers:")
                for i, driver in enumerate(drivers, 1):
                    self.print(f"  {i}. {driver}")

                while True:
                    try:
                        driver_choice = input(
                            "Select driver (1-3, default=1): "
                        ).strip()
                        if not driver_choice:
                            driver_choice = "1"
                        driver_choice = int(driver_choice)
                        if 1 <= driver_choice <= 3:
                            selected_driver = drivers[driver_choice - 1]
                            break
                        else:
                            self.print("Please enter 1, 2, or 3")
                    except ValueError:
                        self.print("Please enter a valid number")

            networks.append({"name": network_name, "driver": selected_driver})

            self.print_success(f"Added network: {network_name} ({selected_driver})")

        config["networks"] = networks

    def _configure_tasks_interactive(self, config: Dict[str, Any]) -> bool:
        """Configure task execution flow."""
        if self.console:
            self.console.print("\n[bold blue]Task Execution Configuration[/bold blue]")
            self.console.print("Define how your modules are executed and connected.")
        else:
            self.print("\nTask Execution Configuration:")
            self.print("Define how your modules are executed and connected.")

        modules = config.get("modules", [])
        if len(modules) == 1:
            # Simple single module execution
            config["tasks"] = [{"type": "single", "module": modules[0]["alias"]}]
            if self.console:
                self.console.print(f"Single module execution: {modules[0]['alias']}")
            else:
                self.print(f"Single module execution: {modules[0]['alias']}")
            return True

        # Multiple modules - ask for execution pattern
        if self.console:
            self.console.print("Execution patterns:")
            self.console.print("  1. Sequential - Execute modules one after another")
            self.console.print("  2. Parallel - Execute modules simultaneously")
            self.console.print("  3. Custom - Define custom execution flow")

            pattern = Prompt.ask(
                "Select execution pattern", choices=["1", "2", "3"], default="1"
            )
        else:
            self.print("Execution patterns:")
            self.print("  1. Sequential - Execute modules one after another")
            self.print("  2. Parallel - Execute modules simultaneously")
            self.print("  3. Custom - Define custom execution flow")

            pattern = input("Select pattern (1-3, default=1): ").strip()
            if not pattern:
                pattern = "1"

        if pattern == "1":
            # Sequential execution
            config["tasks"] = [
                {"type": "sequential", "modules": [m["alias"] for m in modules]}
            ]
            self.print_success("Configured sequential execution")
        elif pattern == "2":
            # Parallel execution
            config["tasks"] = [
                {"type": "parallel", "modules": [m["alias"] for m in modules]}
            ]
            self.print_success("Configured parallel execution")
        else:
            # Custom execution - simplified for now
            self.print("Custom execution flow not yet implemented. Using sequential.")
            config["tasks"] = [
                {"type": "sequential", "modules": [m["alias"] for m in modules]}
            ]

        return True

    def _load_python_swarm(self, swarm_path: Path) -> Optional[Any]:
        """Load a swarm from a Python file."""
        import importlib.util
        import inspect

        try:
            # Add the parent directory to sys.path for imports
            parent_dir = str(swarm_path.parent.resolve())
            if parent_dir not in sys.path:
                sys.path.insert(0, parent_dir)

            # Create a proper module name based on the file structure
            # This helps with relative imports
            module_name = swarm_path.stem
            if swarm_path.parent.name != ".":
                # Use the parent directory name as package name
                package_name = swarm_path.parent.name
                full_module_name = f"{package_name}.{module_name}"
            else:
                full_module_name = module_name

            # Load the Python module
            spec = importlib.util.spec_from_file_location(full_module_name, swarm_path)
            if spec is None or spec.loader is None:
                self.print_error(f"Failed to load Python module from {swarm_path}")
                return None

            swarm_module = importlib.util.module_from_spec(spec)
            sys.modules[full_module_name] = swarm_module

            # For relative imports to work, we need to set up the package structure
            if "." in full_module_name:
                parent_package = full_module_name.rsplit(".", 1)[0]
                if parent_package not in sys.modules:
                    # Create a dummy parent package
                    parent_spec = importlib.util.spec_from_file_location(
                        parent_package, "__init__.py"
                    )
                    parent_module = (
                        importlib.util.module_from_spec(parent_spec)
                        if parent_spec
                        else type(sys)("module")
                    )
                    parent_module.__path__ = [str(swarm_path.parent)]
                    sys.modules[parent_package] = parent_module
                    swarm_module.__package__ = parent_package

            spec.loader.exec_module(swarm_module)

            # Find the Swarm class in the module
            from manta.apis.swarm import Swarm

            swarm_instance = None
            for name, obj in inspect.getmembers(swarm_module):
                if inspect.isclass(obj) and issubclass(obj, Swarm) and obj != Swarm:
                    # Found a Swarm subclass, instantiate it
                    try:
                        swarm_instance = obj()
                        self.print(f"Loaded swarm class: {name}")
                        break
                    except TypeError:
                        # Try with default arguments if constructor requires them
                        try:
                            swarm_instance = obj(image="manta_light:pytorch")
                            self.print(
                                f"Loaded swarm class: {name} (with default image)"
                            )
                            break
                        except Exception:
                            continue

            if not swarm_instance:
                # No Swarm subclass found, try to find a swarm instance directly
                for name, obj in inspect.getmembers(swarm_module):
                    if isinstance(obj, Swarm):
                        swarm_instance = obj
                        self.print(f"Found swarm instance: {name}")
                        break

            if not swarm_instance:
                self.print_error("No Swarm class or instance found in the file.")
                self.print_error(
                    "Make sure your file defines a class that inherits from Swarm."
                )
                return None

            return swarm_instance

        except Exception as e:
            self.print_error(f"Failed to load swarm from {swarm_path}: {e}")
            import traceback

            if self.console:
                self.console.print(f"[red]{traceback.format_exc()}[/red]")
            else:
                print(traceback.format_exc())
            return None
        finally:
            # Clean up sys.path
            if "parent_dir" in locals() and parent_dir in sys.path:
                sys.path.remove(parent_dir)
            # Remove the temporary modules
            if "full_module_name" in locals() and full_module_name in sys.modules:
                del sys.modules[full_module_name]
            if "parent_package" in locals() and parent_package in sys.modules:
                del sys.modules[parent_package]

    def _preview_python_swarm(self, swarm: Any) -> bool:
        """Preview Python swarm definition and ask for confirmation."""
        if self.console:
            self.console.print("\n[bold yellow]Step 4: Swarm Preview[/bold yellow]")

            # Create preview content
            preview_content = []

            # Get swarm name
            swarm_name = getattr(swarm, "name", swarm.__class__.__name__)
            preview_content.append(f"[cyan]Swarm:[/cyan] {swarm_name}")

            # List tasks
            task_count = 0
            task_names = []
            for attr_name in dir(swarm):
                attr = getattr(swarm, attr_name)
                if hasattr(attr, "__class__") and "Task" in attr.__class__.__name__:
                    task_count += 1
                    task_names.append(attr_name)

            if task_count > 0:
                preview_content.append(f"[cyan]Tasks:[/cyan] {task_count}")
                for task_name in task_names:
                    task = getattr(swarm, task_name)
                    module = getattr(task, "module", None)
                    if module:
                        module_info = getattr(module, "image", "unknown")
                        preview_content.append(
                            f"  - {task_name} (image: {module_info})"
                        )
                    else:
                        preview_content.append(f"  - {task_name}")

            # Check for execute method
            if hasattr(swarm, "execute"):
                preview_content.append("[cyan]Execute Method:[/cyan] Defined")
            else:
                preview_content.append(
                    "[yellow]Warning:[/yellow] No execute() method defined"
                )

            # Check for globals
            if hasattr(swarm, "_globals"):
                globals_count = len(swarm._globals) if swarm._globals else 0
                if globals_count > 0:
                    preview_content.append(
                        f"[cyan]Global Parameters:[/cyan] {globals_count}"
                    )
                    for key in list(swarm._globals.keys())[:5]:  # Show first 5
                        preview_content.append(f"  - {key}")
                    if globals_count > 5:
                        preview_content.append(f"  ... and {globals_count - 5} more")

            panel = Panel.fit("\n".join(preview_content), title="Python Swarm Preview")
            self.console.print(panel)

            return Confirm.ask("\nDeploy this swarm?", default=True)
        else:
            self.print("\nStep 4: Swarm Preview")
            self.print("=" * 40)

            swarm_name = getattr(swarm, "name", swarm.__class__.__name__)
            self.print(f"Swarm: {swarm_name}")

            # List tasks
            task_count = 0
            for attr_name in dir(swarm):
                attr = getattr(swarm, attr_name)
                if hasattr(attr, "__class__") and "Task" in attr.__class__.__name__:
                    task_count += 1
                    self.print(f"  - Task: {attr_name}")

            if task_count > 0:
                self.print(f"Total Tasks: {task_count}")

            # Check for execute method
            if hasattr(swarm, "execute"):
                self.print("Execute Method: Defined")
            else:
                self.print("Warning: No execute() method defined")

            self.print("=" * 40)

            confirm = input("\nDeploy this swarm? (y/n): ").strip().lower()
            return confirm in ["y", "yes"]

    def _create_swarm_from_config(self, config: Dict[str, Any]) -> Optional[Any]:
        """Create a Swarm object from configuration."""
        # Note: This is a simplified implementation for the CLI wizard
        # Full configuration-based deployment with module ID references
        # requires additional development to properly resolve module IDs to Module objects

        self.print_warning("Configuration-based swarm deployment is currently limited.")
        self.print_warning(
            "For production deployments, use the manta-sdk API directly."
        )

        try:
            # Import required classes
            from manta.apis.graph import Task
            from manta.apis.module import Module
            from manta.apis.swarm import Driver, Swarm

            # Create a simple swarm class for basic functionality
            class ConfigurableSwarm(Swarm):
                def __init__(self, swarm_config):
                    super().__init__()
                    self.name = swarm_config.get("name", "ConfigurableSwarm")
                    self.config = swarm_config

                    # Set up globals
                    for key, value in swarm_config.get("globals", {}).items():
                        self.set_global(key, value)

                    # Set up networks
                    for network in swarm_config.get("networks", []):
                        driver_name = network.get("driver", "overlay").upper()
                        driver = getattr(Driver, driver_name, Driver.OVERLAY)
                        self.add_network(network["name"], driver)

                def execute(self):
                    # Simplified execution - this is a placeholder implementation
                    # In a real scenario, you would need to:
                    # 1. Fetch actual Module objects from the server using module IDs
                    # 2. Build the proper task graph based on the configuration
                    # 3. Handle different execution patterns (sequential, parallel, custom)

                    modules_config = self.config.get("modules", [])
                    if not modules_config:
                        raise NotImplementedError("No modules configured in swarm")

                    # For now, create a placeholder module to demonstrate structure
                    # This would need to be replaced with proper module resolution
                    placeholder_module = Module("placeholder.py", "python:3.9-slim")
                    placeholder_module.name = "ConfigurationPlaceholder"

                    return Task(placeholder_module)

            return ConfigurableSwarm(config)

        except ImportError as e:
            self.print_error(f"Failed to import required modules: {e}")
            self.print_error("Make sure manta-sdk[api] is installed")
            return None
        except Exception as e:
            self.print_error(f"Failed to create swarm from configuration: {e}")
            return None

    def _preview_swarm_config(self, swarm: Any, config: Dict[str, Any]) -> bool:
        """Preview swarm configuration and ask for confirmation."""
        if self.console:
            self.console.print(
                "\n[bold yellow]Step 4: Configuration Preview[/bold yellow]"
            )

            # Create preview panel
            preview_content = []
            preview_content.append(
                f"[cyan]Swarm Name:[/cyan] {config.get('name', 'Unknown')}"
            )
            preview_content.append(
                f"[cyan]Modules:[/cyan] {len(config.get('modules', []))}"
            )

            modules = config.get("modules", [])
            for module in modules:
                preview_content.append(
                    f"  - {module.get('alias', 'Unknown')} ({module.get('id', 'Unknown')})"
                )

            globals_config = config.get("globals", {})
            if globals_config:
                preview_content.append(
                    f"[cyan]Global Parameters:[/cyan] {len(globals_config)}"
                )
                for key in globals_config.keys():
                    preview_content.append(f"  - {key}")

            networks = config.get("networks", [])
            if networks:
                preview_content.append(f"[cyan]Networks:[/cyan] {len(networks)}")
                for network in networks:
                    preview_content.append(
                        f"  - {network.get('name', 'Unknown')} ({network.get('driver', 'overlay')})"
                    )

            tasks = config.get("tasks", [])
            if tasks:
                preview_content.append(
                    f"[cyan]Execution:[/cyan] {tasks[0].get('type', 'Unknown')}"
                )

            panel = Panel.fit(
                "\n".join(preview_content), title="Swarm Configuration Preview"
            )
            self.console.print(panel)

            return Confirm.ask("\nDeploy this swarm configuration?", default=True)
        else:
            self.print("\nStep 4: Configuration Preview")
            self.print("=" * 40)
            self.print(f"Swarm Name: {config.get('name', 'Unknown')}")
            self.print(f"Modules: {len(config.get('modules', []))}")

            modules = config.get("modules", [])
            for module in modules:
                self.print(
                    f"  - {module.get('alias', 'Unknown')} ({module.get('id', 'Unknown')})"
                )

            globals_config = config.get("globals", {})
            if globals_config:
                self.print(f"Global Parameters: {len(globals_config)}")
                for key in globals_config.keys():
                    self.print(f"  - {key}")

            networks = config.get("networks", [])
            if networks:
                self.print(f"Networks: {len(networks)}")
                for network in networks:
                    self.print(
                        f"  - {network.get('name', 'Unknown')} ({network.get('driver', 'overlay')})"
                    )

            self.print("=" * 40)

            confirm = input("Deploy this swarm configuration? (Y/n): ").strip().lower()
            return confirm in ["", "y", "yes"]

    def _execute_deployment(self, api, cluster_id: str, swarm: Any) -> int:
        """Execute the swarm deployment."""
        try:
            if self.console:
                self.console.print(
                    "\n[bold yellow]Step 5: Deploying Swarm[/bold yellow]"
                )
            else:
                self.print("\nStep 5: Deploying Swarm")

            # Deploy swarm
            async def run():
                return await api.send_swarm(cluster_id, swarm)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Sending swarm to cluster...", total=None)
                    result = asyncio.run(run())
                    progress.update(task, completed=True)
            else:
                self.print("Sending swarm to cluster...")
                result = asyncio.run(run())

            swarm_id = result.get("swarm_id")
            if not swarm_id:
                self.print_error("Failed to get swarm ID from deployment result")
                return 1

            # Start the swarm
            async def start_run():
                return await api.start_swarm(swarm_id)

            if self.console:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=self.console,
                ) as progress:
                    task = progress.add_task("Starting swarm execution...", total=None)
                    asyncio.run(start_run())
                    progress.update(task, completed=True)
            else:
                self.print("Starting swarm execution...")
                asyncio.run(start_run())

            # Display success message
            if self.console:
                success_panel = Panel.fit(
                    f"[green]Swarm deployed successfully![/green]\n\n"
                    f"[cyan]Swarm ID:[/cyan] {swarm_id}\n"
                    f"[cyan]Cluster ID:[/cyan] {cluster_id}\n"
                    f"[cyan]Status:[/cyan] {result.get('status', 'Unknown')}\n\n"
                    f"Use the following commands to monitor your swarm:\n"
                    f"  [yellow]manta swarm show {swarm_id}[/yellow]\n"
                    f"  [yellow]manta swarm tasks {swarm_id}[/yellow]\n"
                    f"  [yellow]manta results list {swarm_id} <tag>[/yellow]",
                    title="Deployment Complete",
                )
                self.console.print(success_panel)
            else:
                self.print("\n" + "=" * 50)
                self.print("DEPLOYMENT SUCCESSFUL!")
                self.print("=" * 50)
                self.print(f"Swarm ID: {swarm_id}")
                self.print(f"Cluster ID: {cluster_id}")
                self.print(f"Status: {result.get('status', 'Unknown')}")
                self.print("\nMonitoring commands:")
                self.print(f"  manta swarm show {swarm_id}")
                self.print(f"  manta swarm tasks {swarm_id}")
                self.print(f"  manta results list {swarm_id} <tag>")
                self.print("=" * 50)

            return 0

        except Exception as e:
            self.print_error(f"Deployment failed: {e}")
            return 1

    def _run_async(self, coroutine):
        """Run an async coroutine and return the result."""
        try:
            return asyncio.run(coroutine)
        except Exception as e:
            self.print_error(f"Async operation failed: {e}")
            return None

    def _format_user_info_table(self, user_info: Dict) -> Table:
        """Format user info as Rich table."""
        table = Table(
            title="User Information", show_header=True, header_style="bold blue"
        )
        table.add_column("Field", style="cyan", no_wrap=True)
        table.add_column("Value", style="white")

        # Add user info rows
        for key, value in user_info.items():
            if key == "id":
                table.add_row("User ID", str(value))
            elif key == "username":
                table.add_row("Username", str(value))
            elif key == "created_at":
                table.add_row("Created At", str(value))
            elif key == "email":
                table.add_row("Email", str(value))
            elif key == "clusters":
                table.add_row("Active Clusters", str(value))
            elif key == "swarms":
                table.add_row("Total Swarms", str(value))
            else:
                # Convert underscores to spaces and capitalize
                field_name = key.replace("_", " ").title()
                table.add_row(field_name, str(value))

        return table

    def _format_cluster_table(self, clusters: List[Dict]) -> Table:
        """Format clusters as Rich table."""
        table = Table(title="Clusters", show_header=True, header_style="bold blue")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Name", style="white")
        table.add_column("Status", style="green")
        table.add_column("Nodes", justify="right", style="yellow")
        table.add_column("Created At", style="dim")

        for cluster in clusters:
            status_color = "green" if cluster.get("status") == "active" else "red"
            table.add_row(
                cluster.get("id", ""),
                cluster.get("name", ""),
                f"[{status_color}]{cluster.get('status', 'unknown')}[/{status_color}]",
                str(cluster.get("nodes", 0)),
                cluster.get("created_at", ""),
            )

        return table

    def _format_swarm_table(self, swarms: List[Dict]) -> Table:
        """Format swarms as Rich table."""
        table = Table(title="Swarms", show_header=True, header_style="bold blue")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Cluster ID", style="white")
        table.add_column("Status", style="green")
        table.add_column("Progress", justify="right", style="yellow")
        table.add_column("Created At", style="dim")

        for swarm in swarms:
            status_color = {
                "running": "green",
                "completed": "blue",
                "failed": "red",
                "pending": "yellow",
            }.get(swarm.get("status"), "white")

            progress = swarm.get("progress", 0)
            if isinstance(progress, (int, float)):
                progress_text = f"{progress * 100:.1f}%"
            else:
                progress_text = str(progress)

            table.add_row(
                swarm.get("id", ""),
                swarm.get("cluster_id", ""),
                f"[{status_color}]{swarm.get('status', 'unknown')}[/{status_color}]",
                progress_text,
                swarm.get("created_at", ""),
            )

        return table

    def _format_module_table(self, modules: List[Dict]) -> Table:
        """Format modules as Rich table."""
        table = Table(title="Modules", show_header=True, header_style="bold blue")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Name", style="white")
        table.add_column("Version", style="green")
        table.add_column("Size", justify="right", style="yellow")

        for module in modules:
            size = module.get("size", 0)
            if isinstance(size, int):
                size_text = self._format_size(size)
            else:
                size_text = str(size)

            table.add_row(
                module.get("id", ""),
                module.get("name", ""),
                module.get("version", ""),
                size_text,
            )

        return table

    def _interactive_swarm_deploy(self, api) -> int:
        """Interactive swarm deployment."""
        try:
            # Prompt for cluster ID
            cluster_id = Prompt.ask("Enter cluster ID")

            # Prompt for swarm config
            config_path = Prompt.ask("Enter path to swarm configuration file")

            # Check if file exists
            config_file = Path(config_path)
            if not config_file.exists():
                self.print_error(f"Configuration file not found: {config_path}")
                return 1

            # Load config
            try:
                config_content = config_file.read_text()
                swarm_config = json.loads(config_content)
            except Exception as e:
                self.print_error(f"Failed to load configuration: {e}")
                return 1

            # Confirm deployment
            confirm = Confirm.ask(f"Deploy swarm to cluster {cluster_id}?")
            if not confirm:
                self.print("Deployment cancelled.")
                return 0

            # Deploy swarm
            async def deploy():
                return await api.deploy_swarm(cluster_id, swarm_config)

            result = self._run_async(deploy())
            if result:
                self.print_success(
                    f"Swarm deployed successfully: {result.get('id', 'unknown')}"
                )
                return 0
            else:
                return 1

        except Exception as e:
            self.print_error(f"Interactive deployment failed: {e}")
            return 1

    def _stream_results(self, api, swarm_id: str, tag: str) -> int:
        """Stream results from a swarm."""
        try:
            self.print(f"Streaming results for swarm {swarm_id}, tag: {tag}")
            self.print("Press Ctrl+C to stop streaming...")

            while True:
                try:

                    async def get_results():
                        return await api.get_results(swarm_id, tag)

                    results = self._run_async(get_results())
                    if results:
                        for result in results:
                            timestamp = result.get("created_at", "unknown")
                            data = result.get("data", {})
                            self.print(f"[{timestamp}] {json.dumps(data, indent=2)}")

                    time.sleep(5)  # Wait 5 seconds before next poll

                except KeyboardInterrupt:
                    self.print("\nStreaming stopped.")
                    return 130  # KeyboardInterrupt exit code

        except Exception as e:
            self.print_error(f"Streaming failed: {e}")
            return 1

    def _export_results(self, api, swarm_id: str, tag: str, output_file: str) -> int:
        """Export results to a file."""
        try:

            async def get_results():
                return await api.get_results(swarm_id, tag)

            results = self._run_async(get_results())
            if not results:
                self.print_error("No results found")
                return 1

            # Write to file
            with open(output_file, "w") as f:
                json.dump(results, f, indent=2)

            self.print_success(f"Results exported to {output_file}")
            return 0

        except Exception as e:
            self.print_error(f"Export failed: {e}")
            return 1

    # ============================================
    # Utility Functions
    # ============================================

    def _format_size(self, size_bytes: int) -> str:
        """Format byte size in human readable format."""
        if size_bytes == 0:
            return "0 B"

        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} PB"

    def print_warning(self, message: str):
        """Print warning message."""
        if self.console:
            self.console.print(f"[yellow]Warning:[/yellow] {message}")
        else:
            print(f"Warning: {message}")
