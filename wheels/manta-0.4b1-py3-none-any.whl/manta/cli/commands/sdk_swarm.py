"""SDK swarm management and simulation commands."""

import signal
import time
from typing import Optional

from rich.panel import Panel
from rich.prompt import Confirm
from rich.table import Table

from .base_handler import BaseSDKHandler
from ..utils.converters import (
    enum_to_string,
    timestamp_to_string,
    SWARM_STATUS_MAP,
    TASK_STATUS_MAP,
)


class SDKSwarmHandler(BaseSDKHandler):
    """Handle swarm-related SDK commands including simulations."""

    def add_subparsers(self, parent_parser):
        """Add swarm command subparsers."""
        self.parser = parent_parser  # Store parser reference
        subparsers = parent_parser.add_subparsers(
            dest="swarm_command", help="Swarm commands"
        )

        # List swarms command
        list_parser = subparsers.add_parser("list", help="List user swarms")
        list_parser.add_argument("--cluster-id", help="Filter by cluster ID")

        # List swarm IDs command
        list_ids_parser = subparsers.add_parser("list-ids", help="List swarm IDs only")

        # Show swarm command
        show_parser = subparsers.add_parser(
            "show", help="Show detailed swarm information"
        )
        show_parser.add_argument("swarm_id", help="Swarm ID to show")

        # Show swarm tasks command
        tasks_parser = subparsers.add_parser("tasks", help="Show swarm tasks")
        tasks_parser.add_argument("swarm_id", help="Swarm ID to show tasks for")

        # Start swarm command
        start_parser = subparsers.add_parser("start", help="Start a swarm")
        start_parser.add_argument("swarm_id", help="Swarm ID to start")

        # Stop swarm command
        stop_parser = subparsers.add_parser("stop", help="Stop a swarm")
        stop_parser.add_argument("swarm_id", help="Swarm ID to stop")
        stop_parser.add_argument(
            "--force", action="store_true", help="Force stop without confirmation"
        )

        # Delete/Remove swarm command
        delete_parser = subparsers.add_parser("remove", help="Delete a swarm")
        delete_parser.add_argument("swarm_id", help="Swarm ID to delete")
        delete_parser.add_argument(
            "--force", action="store_true", help="Skip confirmation"
        )

        # Monitor swarm command
        monitor_parser = subparsers.add_parser(
            "monitor", help="Monitor swarm execution"
        )
        monitor_parser.add_argument("swarm_id", help="Swarm ID to monitor")

        # Add profile override to all subcommands
        for parser in [
            list_parser,
            list_ids_parser,
            show_parser,
            tasks_parser,
            start_parser,
            stop_parser,
            delete_parser,
            monitor_parser,
        ]:
            parser.add_argument("--profile", help="Use specific profile")

    def handle(self, args) -> int:
        """Handle swarm commands."""
        # Handle both swarm_command and simulation_command (for backwards compatibility)
        command = getattr(args, "swarm_command", None) or getattr(
            args, "simulation_command", None
        )

        if not command:
            if hasattr(self, "parser"):
                self.parser.print_help()
            return 0  # Return 0 for help display

        if command == "list":
            return self.list_swarms(getattr(args, "cluster_id", None))
        elif command == "list-ids":
            return self.list_swarm_ids()
        elif command == "show":
            return self.show_swarm(args.swarm_id)
        elif command == "tasks":
            return self.show_swarm_tasks(args.swarm_id)
        elif command == "start":
            return self.start_swarm(args.swarm_id)
        elif command == "stop":
            return self.stop_swarm(args.swarm_id, getattr(args, "force", False))
        elif command in ["delete", "remove"]:
            return self.delete_swarm(args.swarm_id, getattr(args, "force", False))
        elif command == "monitor":
            return self.monitor_swarm(args.swarm_id)
        else:
            self.print_error(f"Unknown swarm command: {command}")
            return 1

    def list_swarm_ids(self) -> int:
        """List swarm IDs only."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.list_swarm_ids()

            swarm_ids = self._run_with_progress(run, "Fetching swarm IDs...")

            if swarm_ids is None:
                return 1

            if not swarm_ids:
                self.print("No swarms found.")
                return 0

            self.print(f"Found {len(swarm_ids)} swarms:")
            for swarm_id in swarm_ids:
                self.print(f"  {swarm_id}")

            return 0

        except Exception as e:
            self.print_error(f"Failed to list swarm IDs: {e}")
            return 1

    def list_swarms(self, cluster_id: Optional[str] = None) -> int:
        """List user swarms, optionally filtered by cluster."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                # stream_and_fetch_swarms doesn't have cluster_id parameter
                # Get all swarms and filter by cluster if needed
                swarms = await api.stream_and_fetch_swarms()
                if cluster_id:
                    # Filter swarms by cluster_id
                    swarms = [s for s in swarms if s.get("cluster_id") == cluster_id]
                return swarms

            message = f"Fetching swarms{f' for cluster {cluster_id}' if cluster_id else ''}..."
            swarms = self._run_with_progress(run, message)

            if swarms is None:
                return 1

            # Display swarms
            if not swarms:
                self.print("No swarms found.")
                return 0

            table = Table(
                title=f"User Swarms{f' (Cluster: {cluster_id})' if cluster_id else ''}"
            )
            table.add_column("Swarm ID", style="cyan")
            table.add_column("Name", style="blue")
            table.add_column("Status", style="green")
            table.add_column("Cluster", style="magenta")
            table.add_column("Created", style="yellow")

            for swarm in swarms:
                # Convert status enum to string
                status = swarm.get("status")
                status_str = (
                    enum_to_string(status, SWARM_STATUS_MAP)
                    if status is not None
                    else "Unknown"
                )

                # Convert timestamp
                created_at = timestamp_to_string(
                    swarm.get("created_at") or swarm.get("creation_date")
                )

                table.add_row(
                    swarm.get("swarm_id", "Unknown"),
                    swarm.get("name", "Unknown"),
                    status_str,
                    swarm.get("cluster_id", "Unknown"),
                    created_at,
                )

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to list swarms: {e}")
            return 1

    def show_swarm(self, swarm_id: str) -> int:
        """Show detailed swarm information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.get_swarm(swarm_id)

            swarm = self._run_with_progress(run, "Fetching swarm details...")

            if swarm is None:
                return 1

            # Display swarm details
            status = swarm.get("status")
            status_str = (
                enum_to_string(status, SWARM_STATUS_MAP)
                if status is not None
                else "Unknown"
            )
            created_at = timestamp_to_string(
                swarm.get("creation_date") or swarm.get("created_at")
            )

            panel = Panel.fit(
                f"[cyan]Swarm ID:[/cyan] {swarm.get('swarm_id', 'Unknown')}\n"
                f"[cyan]Name:[/cyan] {swarm.get('name', 'Unknown')}\n"
                f"[cyan]Status:[/cyan] {status_str}\n"
                f"[cyan]Cluster ID:[/cyan] {swarm.get('cluster_id', 'Unknown')}\n"
                f"[cyan]Task Count:[/cyan] {swarm.get('task_count', 0)}\n"
                f"[cyan]Node Count:[/cyan] {swarm.get('node_count', 0)}\n"
                f"[cyan]Iteration:[/cyan] {swarm.get('iteration', 0)}\n"
                f"[cyan]Created:[/cyan] {created_at}",
                title=f"Swarm: {swarm_id}",
            )
            self.console.print(panel)

            return 0

        except Exception as e:
            self.print_error(f"Failed to get swarm details: {e}")
            return 1

    def show_swarm_tasks(self, swarm_id: str) -> int:
        """Show tasks for a swarm."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                # Use stream_swarm_tasks and collect all tasks
                tasks = []
                async for task in api.stream_swarm_tasks(swarm_id):
                    tasks.append(task)
                return tasks

            tasks = self._run_with_progress(
                run, f"Fetching tasks for swarm {swarm_id}..."
            )

            if tasks is None:
                return 1

            if not tasks:
                self.print("No tasks found for this swarm.")
                return 0

            table = Table(title=f"Tasks for Swarm: {swarm_id}")
            table.add_column("Task ID", style="cyan")
            table.add_column("Status", style="green")
            table.add_column("Node", style="blue")
            table.add_column("Started", style="yellow")

            for task in tasks:
                # Convert status enum to string
                status = task.get("status")
                status_str = (
                    enum_to_string(status, TASK_STATUS_MAP)
                    if status is not None
                    else "Unknown"
                )

                # Convert timestamp
                started_at = timestamp_to_string(
                    task.get("started_at") or task.get("start_time")
                )

                table.add_row(
                    task.get("task_id", "Unknown"),
                    status_str,
                    task.get("node_id", "Unknown"),
                    started_at,
                )

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to get swarm tasks: {e}")
            return 1

    def start_swarm(self, swarm_id: str) -> int:
        """Start a swarm."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.start_swarm(swarm_id)

            result = self._run_with_progress(run, f"Starting swarm {swarm_id}...")

            if result is None:
                return 1

            self.print_success("Swarm started successfully")
            return 0

        except Exception as e:
            self.print_error(f"Failed to start swarm: {e}")
            return 1

    def stop_swarm(self, swarm_id: str, force: bool = False) -> int:
        """Stop a swarm."""
        if not force:
            confirm = Confirm.ask(f"Are you sure you want to stop swarm '{swarm_id}'?")
            if not confirm:
                self.print("Operation cancelled.")
                return 0

        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.stop_swarm(swarm_id)

            result = self._run_with_progress(run, "Stopping swarm...")

            if result is None:
                return 1

            self.print_success("Swarm stopped successfully")
            return 0

        except Exception as e:
            self.print_error(f"Failed to stop swarm: {e}")
            return 1

    def delete_swarm(self, swarm_id: str, force: bool = False) -> int:
        """Delete a swarm."""
        if not force:
            confirm = Confirm.ask(
                f"Are you sure you want to delete swarm '{swarm_id}'?"
            )
            if not confirm:
                self.print("Operation cancelled.")
                return 0

        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.remove_swarm(swarm_id)

            result = self._run_with_progress(run, "Deleting swarm...")

            if result is None:
                return 1

            self.print_success("Swarm deleted successfully")
            return 0

        except Exception as e:
            self.print_error(f"Failed to delete swarm: {e}")
            return 1

    def monitor_swarm(self, swarm_id: str) -> int:
        """Monitor swarm execution in real-time."""
        api = self._get_user_api()
        if not api:
            return 1

        self.print(f"Monitoring swarm: {swarm_id}")
        self.print("Press Ctrl+C to stop monitoring...")

        try:
            # Set up signal handler for graceful shutdown
            shutdown_flag = False

            def signal_handler(sig, frame):
                nonlocal shutdown_flag
                shutdown_flag = True

            signal.signal(signal.SIGINT, signal_handler)

            while not shutdown_flag:
                try:

                    async def get_status():
                        return await api.get_swarm(swarm_id)

                    swarm_status = self._run_async(get_status())

                    # Display current status
                    status = swarm_status.get("status")
                    status_str = (
                        enum_to_string(status, SWARM_STATUS_MAP)
                        if status is not None
                        else "Unknown"
                    )
                    status_text = f"Status: {status_str}"
                    self.console.print(f"[{time.strftime('%H:%M:%S')}] {status_text}")

                    # Check if swarm is finished
                    status = swarm_status.get("status", "").lower()
                    if status in ["completed", "failed", "cancelled"]:
                        self.print(f"Swarm execution {status}.")
                        return 0

                    time.sleep(5)  # Poll every 5 seconds

                except KeyboardInterrupt:
                    self.print("\nMonitoring stopped.")
                    return 130  # KeyboardInterrupt exit code

        except Exception as e:
            self.print_error(f"Monitoring failed: {e}")
            return 1
