"""Main unified Manta CLI entry point.

This module provides the main CLI interface that works across all Manta components
with dynamic component detection and installation assistance.
"""

import argparse
import logging
import sys

from rich.console import Console

from .commands.doc import DocCommands
from .commands.install import InstallCommands
from .commands.status import StatusCommands
from .component_detector import ComponentDetector

logger = logging.getLogger(__name__)


class MantaCLI:
    """Main unified CLI application."""

    def __init__(self):
        self.console = Console()
        self.detector = ComponentDetector()

        # Base commands always available
        self.install_cmd = InstallCommands(self.detector, self.console)
        self.status_cmd = StatusCommands(self.detector, self.console)
        self.doc_cmd = DocCommands(self.console)

        # Component commands (loaded dynamically)
        self.sdk_cmd = None
        self.admin_main = None
        self.node_main = None

        # Try to load component commands
        self._load_component_commands()

    def _load_component_commands(self):
        """Load component commands - SDK is always available, others detected."""
        # SDK commands are always available since we're part of manta-sdk
        try:
            from manta.cli.commands.sdk import SDKCommands

            self.sdk_cmd = SDKCommands(self.console)
        except ImportError:
            # This should never happen since we're in manta-sdk
            self.sdk_cmd = None

        # Try to get admin main function for direct delegation
        try:
            from manta_admin.cli.main import main as admin_main

            self.admin_main = admin_main
        except ImportError:
            self.admin_main = None

        # Try to get node main function for direct delegation
        try:
            from manta_node.cli.main import main as node_main

            self.node_main = node_main
        except ImportError:
            self.node_main = None

    def print(self, *args, **kwargs):
        """Rich print function."""
        self.console.print(*args, **kwargs)

    def print_error(self, message: str):
        """Print error message."""
        self.console.print(f"[red]Error:[/red] {message}")

    def print_success(self, message: str):
        """Print success message."""
        self.console.print(f"[green]Success:[/green] {message}")

    def print_warning(self, message: str):
        """Print warning message."""
        self.console.print(f"[yellow]Warning:[/yellow] {message}")

    def handle_missing_component(self, component: str, command: str):
        """Handle missing component error with installation guidance."""
        comp_info = self.detector.get_component_info(component)

        if comp_info:
            self.print_error(
                f"Command '{command}' requires {comp_info.name} but it's not installed."
            )
            self.print(f"\nTo install {comp_info.name}:")

            # Suggest installation command
            install_cmd = self.detector.get_installation_command(component)
            self.print(f"  {install_cmd}")

            self.print("\nAlternatively, use the installation wizard:")
            self.print("  manta install wizard")
        else:
            self.print_error(f"Unknown component: {component}")


def create_parser(cli: MantaCLI) -> argparse.ArgumentParser:
    """Create main argument parser with dynamic subcommands."""
    parser = argparse.ArgumentParser(
        prog="manta",
        description="Unified Manta CLI - Manage SDK, Node, and Admin operations",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  manta status                  # Show component status
  manta install wizard          # Interactive installation
  manta doc                     # View documentation

Component Commands (when installed):
  manta sdk <command>           # SDK operations (user, cluster, swarm, results)
  manta node <command>          # Node operations (start, stop, config, logs)
""",
    )

    parser.add_argument("--version", action="version", version="%(prog)s 0.4b1")

    parser.add_argument("--debug", action="store_true", help="Enable debug output")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Status command (always available)
    status_parser = subparsers.add_parser("status", help="Show Manta platform status")
    status_parser.add_argument(
        "status_command",
        nargs="?",
        choices=["installation", "system", "services"],
        help="Specific status to show",
    )

    # Install command (always available)
    install_parser = subparsers.add_parser("install", help="Install Manta components")
    install_parser.add_argument(
        "install_command",
        nargs="?",
        choices=["wizard", "check", "sdk", "admin", "node", "all"],
        help="Installation command",
    )

    # Documentation command (always available)
    doc_parser = subparsers.add_parser("doc", help="View Manta documentation")
    doc_parser.add_argument(
        "doc_topic",
        nargs="?",
        choices=[
            "main",
            "sdk",
            "admin",
            "node",
            "api",
            "examples",
            "quickstart",
            "architecture",
            "configuration",
            "deployment",
        ],
        help="Documentation topic to view",
    )
    doc_parser.add_argument(
        "--open", action="store_true", help="Open documentation in browser"
    )

    # SDK commands (always available since we're part of manta-sdk)
    if cli.sdk_cmd:
        sdk_parser = subparsers.add_parser(
            "sdk", help="SDK operations (user, swarm, module, cluster, results, config)"
        )
        sdk_subparsers = sdk_parser.add_subparsers(
            dest="sdk_command", help="SDK commands"
        )

        # Add SDK subcommands (including config)
        cli.sdk_cmd.add_subparsers(sdk_subparsers)

    # Node commands (if installed) - simplified delegation
    if cli.node_main:
        node_parser = subparsers.add_parser(
            "node", help="Node operations (start, stop, status, cluster)"
        )
        node_parser.add_argument(
            "node_args",
            nargs=argparse.REMAINDER,
            help="Node command arguments (will be passed to manta-node CLI)",
        )

    return parser


def main():
    """Main entry point for the Manta CLI."""
    # Create CLI instance
    cli = MantaCLI()

    # Create parser
    parser = create_parser(cli)

    # Parse arguments
    args = parser.parse_args()

    # Configure logging
    if args.debug:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.WARNING)

    # Handle commands
    try:
        if not args.command:
            parser.print_help()
            return 0

        # Base commands (always available)
        if args.command == "status":
            return cli.status_cmd.handle(args)
        elif args.command == "install":
            return cli.install_cmd.handle(args)
        elif args.command == "doc":
            return cli.doc_cmd.handle(args)

        # Component commands (check if installed)
        elif args.command == "sdk":
            if cli.sdk_cmd:
                return cli.sdk_cmd.handle(args)
            else:
                cli.handle_missing_component("sdk", "manta sdk")
                return 1

        elif args.command == "node":
            if cli.node_main:
                # Direct delegation to manta-node CLI
                node_args = getattr(args, "node_args", [])
                try:
                    return cli.node_main(node_args)
                except Exception as e:
                    cli.print_error(f"Error executing node command: {e}")
                    return 1
            else:
                cli.handle_missing_component("node", "manta node")
                return 1

        else:
            cli.print_error(f"Unknown command: {args.command}")
            parser.print_help()
            return 1

    except KeyboardInterrupt:
        cli.print("\n\nInterrupted by user")
        return 130
    except Exception as e:
        cli.print_error(f"An error occurred: {e}")
        if args.debug:
            import traceback

            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
