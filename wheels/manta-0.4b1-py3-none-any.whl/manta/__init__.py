import importlib.metadata

__version__ = importlib.metadata.version(str(__package__))

from typing import Optional

# Import submodules for explicit access
from . import apis as api  # Expose as manta.api

# Backwards compatibility - expose main API classes at top level
from .apis import *
from .apis.results import *
from .common.conversions import bytes_to_dict, dict_to_bytes

# from . import light  # Expose as manta.light


def configure_from_config(config_name: Optional[str] = None) -> AsyncUserAPI:
    """Configure AsyncUserAPI from SDK configuration.

    Args:
        config_name: Configuration name (uses active if None)

    Returns:
        Configured AsyncUserAPI instance

    Raises:
        ValueError: If configuration is not found or invalid

    Examples:
        # Use active configuration
        api = manta.configure_from_config()

        # Use specific configuration
        api = manta.configure_from_config("production")
    """
    from .cli.config_manager import SDKConfigManager

    config_manager = SDKConfigManager()

    if config_name is None:
        config = config_manager.get_active_config()
        config_name = config_manager.get_active_config_name()
    else:
        config = config_manager.load_config(config_name)

    if not config:
        raise ValueError(
            f"Configuration '{config_name}' not found. "
            "Run 'manta sdk config init --interactive' to create a configuration."
        )

    # Validate configuration
    errors = config_manager.validate_config(config)
    if errors:
        error_msg = f"Configuration '{config_name}' has validation errors:\n"
        for error in errors:
            error_msg += f"  • {error}\n"
        error_msg += "Run 'manta sdk config doctor' for more details."
        raise ValueError(error_msg)

    # Create AsyncUserAPI with validated configuration
    return AsyncUserAPI(
        token=config.token,
        host=config.host,
        port=config.port,
        cert_folder=config.cert_folder,
    )


__all__ = [
    # Submodules for explicit import
    "api",  # Access via: from manta.api import AsyncUserAPI
    # Configuration utilities
    "configure_from_config",  # Main configuration function
    # Backwards compatibility - legacy top-level imports
    "AsyncUserAPI",
    "Module",
    "Swarm",
    "Task",
    "UserAPI",
    "bytes_to_dict",
    "dict_to_bytes",
]
