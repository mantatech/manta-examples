"""
Error handling utilities for Manta Manager.

This module provides utility functions and classes for consistent error handling,
formatting, logging, and propagation across service boundaries.
"""

import asyncio
from datetime import datetime, timezone
from enum import Enum, auto
from socket import gaierror
from typing import Any, Callable, Dict, Optional, Type, TypeVar, Union

from grpclib.const import Status
from grpclib.exceptions import GRPCError

from .build.common.system import Error
from .traces import Metadata

# Type variables for function signatures
T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])

__all__ = [
    "MantaError",
    "MantaLocalError",
    "MantaWorldError",
    "MantaWorldFindError",
    "MantaWorldSaveError",
    "MantaGRPCError",
    "MantaConfigurationError",
    "MantaManagerError",
    "MantaValidationError",
    "MantaConnectionError",
    "MantaTimeoutError",
    "MantaResourceError",
    "MantaGlobalError",
    "MantaResultError",
    "MantaDockerError",
    "MantaK8sError",
    "MantaNodeError",
    "MantaDatabaseError",
    "MantaOrchestrationError",
    "MantaMQTTError",
    "MantaPermissionDeniedError",
    "MantaSecurityError",
    "wrap_exception",
]


class ErrorID(Enum):
    """Error ID enumeration"""

    UNKNOWN_ERROR = auto()
    LOCAL_ERROR = auto()
    WORLD_ERROR = auto()
    WORLD_FIND_ERROR = auto()
    WORLD_SAVE_ERROR = auto()
    GRPC_ERROR = auto()
    CONFIGURATION_ERROR = auto()
    MANAGER_ERROR = auto()
    VALIDATION_ERROR = auto()
    CONNECTION_ERROR = auto()
    TIMEOUT_ERROR = auto()
    RESOURCE_ERROR = auto()
    AUTHENTICATION_ERROR = auto()
    AUTHORIZATION_ERROR = auto()
    DATA_ERROR = auto()
    GLOBAL_ERROR = auto()
    RESULT_ERROR = auto()
    DOCKER_ERROR = auto()
    NODE_ERROR = auto()
    DATABASE_ERROR = auto()
    ORCHESTRATION_ERROR = auto()
    MQTT_ERROR = auto()
    NETWORK_MANAGER_ERROR = auto()
    PERMISSION_DENIED_ERROR = auto()
    CERTIFICATE_VALIDATION_ERROR = auto()


#
# Error Classes
#


class MantaError(Exception):
    """Base class for all Manta-related errors."""

    error_id: ErrorID = ErrorID.UNKNOWN_ERROR
    _default_status_code: Status = Status.INTERNAL

    def __init__(
        self,
        message: str,
        status_code: Optional[Status] = None,
        details: Optional[Dict[str, Any]] = None,
        cause: Optional[Exception] = None,
        metadata: Optional[Metadata] = None,
    ):
        """Initialize a MantaError.

        Args:
            message: The error message
            status_code: Optional gRPC status code
            details: Optional dictionary of error details
            cause: Optional original exception that caused this error
        """
        # Format error message with error ID if defined
        if hasattr(self, "error_id") and self.error_id is not None:
            full_message = f"{self.error_id.name}: {message}"
        else:
            full_message = message

        super().__init__(full_message)
        self.original_message = message
        self.status_code: Status = status_code or self._default_status_code
        self.details = details or {}
        self.metadata = metadata

        # Set cause using Python's exception chaining
        if cause is not None:
            self.__cause__ = cause

    def to_grpc_error(
        self,
        status: Optional[Status] = None,
    ) -> GRPCError:
        """Convert to a GRPCError."""
        status = status or self.status_code
        return GRPCError(status, str(self))

    def to_err(self) -> Error:
        """
        Convert the :code:`MantaError` to an `protobuf.system.Error`

        Returns
        -------
        Error
            Protobuf error
        """
        if self.metadata is None:
            raise ValueError("Metadata is required to convert to protobuf.system.Error")
        return Error(
            swarm_id=self.metadata.swarm_id,
            node_id=self.metadata.node_id,
            task_id=self.metadata.task_id,
            iteration=self.metadata.iteration,
            circular=self.metadata.circular,
            timestamp=datetime.now(timezone.utc),
            error_id=self.error_id.value,
            content=self.original_message,
        )


class CertificateValidationError(MantaError):
    """Raised when certificate validation fails."""

    error_id = ErrorID.CERTIFICATE_VALIDATION_ERROR
    _default_status_code = Status.INTERNAL


class MantaLocalError(MantaError):
    """Error related to local configuration or validation."""

    error_id = ErrorID.LOCAL_ERROR
    _default_status_code = Status.FAILED_PRECONDITION


class MantaWorldError(MantaError):
    """Error related to world state."""

    error_id = ErrorID.WORLD_ERROR
    _default_status_code = Status.NOT_FOUND


class MantaWorldFindError(MantaWorldError):
    """Error raised when a finding operation failed."""

    error_id = ErrorID.WORLD_FIND_ERROR
    _default_status_code = Status.NOT_FOUND


class MantaWorldSaveError(MantaWorldError):
    """Error raised when a saving operation failed."""

    error_id = ErrorID.WORLD_SAVE_ERROR
    _default_status_code = Status.INTERNAL


class MantaGRPCError(MantaError):
    """Error related to gRPC operations."""

    error_id = ErrorID.GRPC_ERROR
    _default_status_code = Status.INTERNAL


class MantaConfigurationError(MantaError):
    """Error raised when configuration is invalid."""

    error_id = ErrorID.CONFIGURATION_ERROR
    _default_status_code = Status.FAILED_PRECONDITION


class MantaManagerError(MantaError):
    """Error related to manager operations."""

    error_id = ErrorID.MANAGER_ERROR
    _default_status_code = Status.INTERNAL


class MantaValidationError(MantaError):
    """Error raised when input validation fails."""

    error_id = ErrorID.VALIDATION_ERROR
    _default_status_code = Status.INVALID_ARGUMENT


class MantaConnectionError(MantaError):
    """Error raised when a connection fails."""

    error_id = ErrorID.CONNECTION_ERROR
    _default_status_code = Status.UNAVAILABLE


class MantaTimeoutError(MantaError):
    """Error raised when an operation times out."""

    error_id = ErrorID.TIMEOUT_ERROR
    _default_status_code = Status.DEADLINE_EXCEEDED

    def __init__(
        self,
        message: str = "",
        timeout_seconds: Optional[float] = None,
        status_code: Optional[Status] = None,
        details: Optional[Dict[str, Any]] = None,
        cause: Optional[Exception] = None,
        metadata: Optional[Metadata] = None,
    ):
        error_msg = message
        if timeout_seconds:
            error_msg = (
                f"Operation timed out after {timeout_seconds} seconds: {message}"
            )
        super().__init__(
            error_msg,
            status_code=status_code,
            details=details,
            cause=cause,
            metadata=metadata,
        )


class MantaResourceError(MantaError):
    """Error raised when a resource is unavailable or exhausted."""

    error_id = ErrorID.RESOURCE_ERROR
    _default_status_code = Status.FAILED_PRECONDITION

    def __init__(
        self,
        message: str = "",
        resource_name: Optional[str] = None,
        status_code: Optional[Status] = None,
        details: Optional[Dict[str, Any]] = None,
        cause: Optional[Exception] = None,
        metadata: Optional[Metadata] = None,
    ):
        error_msg = message
        if resource_name:
            error_msg = f"Resource '{resource_name}' error: {message}"
        super().__init__(
            error_msg,
            status_code=status_code,
            details=details,
            cause=cause,
            metadata=metadata,
        )


class MantaGlobalError(MantaError):
    """Error related to global operations."""

    error_id = ErrorID.GLOBAL_ERROR
    _default_status_code = Status.FAILED_PRECONDITION


class MantaResultError(MantaError):
    """Error related to result processing."""

    error_id = ErrorID.RESULT_ERROR
    _default_status_code = Status.INTERNAL


class MantaDockerError(MantaError):
    """Error related to Docker operations."""

    error_id = ErrorID.DOCKER_ERROR
    _default_status_code = Status.UNAVAILABLE


class MantaK8sError(MantaError):
    """Error related to Kubernetes operations."""

    error_id = ErrorID.ORCHESTRATION_ERROR
    _default_status_code = Status.UNAVAILABLE


class MantaNodeError(MantaError):
    """Error related to node operations."""

    error_id = ErrorID.NODE_ERROR
    _default_status_code = Status.UNAVAILABLE


class MantaSecurityError(MantaNodeError):
    """Raised when there are security-related errors (path traversal, etc.)."""

    pass


class MantaDatabaseError(MantaError):
    """Error related to database operations."""

    error_id = ErrorID.DATABASE_ERROR
    _default_status_code = Status.UNAVAILABLE


class MantaOrchestrationError(MantaError):
    """Error related to orchestration operations."""

    error_id = ErrorID.ORCHESTRATION_ERROR
    _default_status_code = Status.ABORTED


class MantaMQTTError(MantaError):
    """Error related to MQTT operations."""

    error_id = ErrorID.MQTT_ERROR
    _default_status_code = Status.UNAVAILABLE


class NetworkManagerError(MantaError):
    """Error related to network manager operations."""

    error_id = ErrorID.NETWORK_MANAGER_ERROR
    _default_status_code = Status.UNAVAILABLE


class MantaPermissionDeniedError(MantaError):
    """Error related to permission denied."""

    error_id = ErrorID.PERMISSION_DENIED_ERROR
    _default_status_code = Status.PERMISSION_DENIED


#
# Error Mapping and Conversion
#


def error_to_dict(error: Exception) -> Dict[str, Any]:
    """
    Convert an exception to a dictionary for serialization.

    This is useful for returning structured error information in APIs
    or storing errors in a database.

    Args:
        error: The exception to convert

    Returns:
        A dictionary representation of the error
    """
    result: Dict[str, Any] = {
        "error_type": type(error).__name__,
        "message": str(error),
    }

    if isinstance(error, MantaError):
        result["error_id"] = error.error_id.name
        result["details"] = error.details

        # Include status code name if available
        if error.status_code:
            result["status"] = error.status_code.name

    elif isinstance(error, GRPCError):
        result["status"] = error.status.name

    # Add cause if available
    cause = getattr(error, "__cause__", None)
    if cause:
        result["cause"] = error_to_dict(cause)

    return result


def wrap_exception(
    exception: Exception,
    message: Optional[str] = None,
    error_class: Optional[Type[MantaError]] = None,
    details: Optional[Dict[str, Any]] = None,
    status_code: Optional[Status] = None,
    metadata: Optional[Metadata] = None,
) -> MantaError:
    """
    Wrap an exception in an appropriate error type.

    This preserves the original exception as the cause and maintains
    the exception context for better debugging and error reporting.

    Args:
        exception: The exception to wrap
        message: Optional message to override the default message
        error_class: Optional specific error class to use
        details: Optional dictionary of details to include in the error
        status_code: Optional gRPC status code
        metadata: Optional gRPC metadata

    Returns:
        A MantaError instance wrapping the original exception
    """
    # Prepare message and details
    composed_message = message or "Error occurred"
    # Ensure str(exception) is included, as it often contains valuable info.
    # If the original message already contains it, this might be slightly redundant
    # but ensures it's there.
    if str(exception) not in composed_message:
        composed_message += f": {str(exception)}"

    # Use provided details, or generate from exception, or ensure it's a dict
    current_details: Dict[str, Any] = (
        details if details is not None else error_to_dict(exception)
    )

    # 1. Handle GRPCError (special case)
    if isinstance(exception, GRPCError):
        # If a custom message was provided for the wrapper, append GRPCError's details to it.
        # Otherwise, the composed_message already includes str(exception) which contains GRPCError's message.
        final_grpc_message = composed_message
        if (
            exception.details and exception.details not in final_grpc_message
        ):  # Avoid duplicating details if already in custom message
            final_grpc_message = (
                f"{composed_message} (gRPC details: {exception.details})"
            )

        return MantaGRPCError(
            message=final_grpc_message,
            status_code=exception.status,  # GRPCError has .status
            details=current_details,  # Use current_details which might include original exception.details or new ones
            cause=exception,
            metadata=metadata,  # Use new metadata if provided
        )

    # 2. Handle if error_class is explicitly provided by the caller (and not a GRPCError)
    if error_class is not None:
        return error_class(
            message=composed_message,
            status_code=status_code,
            details=current_details,
            cause=exception,
            metadata=metadata,
        )

    # 3. Handle if the exception is already a MantaError instance
    if isinstance(exception, MantaError):
        # Use the original MantaError subclass (e.g., MantaNodeError)
        # Update message, and other fields if new values are provided.
        return type(
            exception
        )(
            message=composed_message,
            status_code=(
                status_code if status_code is not None else exception.status_code
            ),
            details=current_details,  # Use newly composed/provided details
            cause=exception,  # The original MantaError becomes the cause of this potentially "re-wrapped" MantaError
            metadata=metadata if metadata is not None else exception.metadata,
        )

    # 4. Map common Python exceptions to MantaError subclasses
    # Ensure imports for gaierror, asyncio.TimeoutError are present at the top of the file.
    _exception_map: Dict[
        Union[Type[Exception], tuple[Type[Exception], ...]], Type[MantaError]
    ] = {
        (ValueError, TypeError, AttributeError): MantaValidationError,
        (KeyError, IndexError, FileNotFoundError): MantaResourceError,
        (
            ConnectionError,
            ConnectionRefusedError,
            gaierror,  # from socket
            ConnectionAbortedError,
            ConnectionResetError,
            OSError,  # Catches a broad range of OS-related issues including some network ones
        ): MantaConnectionError,
        (
            TimeoutError,  # Python's built-in TimeoutError
            asyncio.TimeoutError,  # asyncio's TimeoutError
        ): MantaTimeoutError,
        # Add other specific mappings here if needed
    }

    try:
        from pymongo.errors import PyMongoError

        _exception_map[(PyMongoError,)] = MantaDatabaseError
    except ImportError:
        pass

    for error_types, manta_error_class_to_use in _exception_map.items():
        if isinstance(exception, error_types):
            return manta_error_class_to_use(
                message=composed_message,
                status_code=status_code,
                details=current_details,
                cause=exception,
                metadata=metadata,
            )

    # 5. Default case for unrecognized exceptions
    return MantaError(
        message=composed_message,
        status_code=status_code,
        details=current_details,
        cause=exception,
        metadata=metadata,
    )
