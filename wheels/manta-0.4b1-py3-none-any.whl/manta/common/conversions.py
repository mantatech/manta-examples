import uuid
from dataclasses import asdict
from datetime import datetime
from functools import cache
from typing import Iterator, List, Optional, Sequence, Tuple, Union

import blake3

from .build.common.system import Error, PairId
from .build.common.tasks import Scheduling, Task

MAX_HEX_INT = 2**128
HEX_SIZE = 128 // 8
MASK_HEAD = 2**128 - 2**64
MASK_TAIL = 2**64 - 1

# IDs conversions

TupleID = Tuple[int, int]

__all__ = [
    "TupleID",
    "x2u64",
    "u64u128",
    "u64x",
    "b2x",
    "oid",
    "xid",
    "lid",
    "tid",
    "ID",
    "ListIDs",
    "datetime_to_int",
    "int_to_datetime",
    "task2dict",
    "dict2task",
    "dict_to_bytes",
    "bytes_to_dict",
]


@cache
def x2u64(hex_value: Union[str, int]) -> TupleID:
    """
    Convert an hex value into two 64-bits integers (head and tail)

    Parameters
    ----------
    hex_value : Union[str, int]
        Hex value (string or integer)

    Returns
    -------
    TupleID
        Two 64-bits integers

    Examples
    --------
    >>> hex_value = 94877792630087975162035649532394405618
    >>> x2u64(hex_value)
    (5143335444508528211, 11537001611497766642)
    """
    if isinstance(hex_value, str):
        try:
            hex_value = int(hex_value, 16)
        except ValueError:
            hex_value = int(b2x(hex_value.encode("utf-8")), 16)
    if hex_value >= MAX_HEX_INT:
        raise ValueError(
            f"ID must be a 128-bits hexadecimal integer. Found {hex_value!r}"
        )
    head = (hex_value & MASK_HEAD) >> 64
    tail = hex_value & MASK_TAIL
    return (head, tail)


@cache
def u64u128(pair_i64: TupleID) -> int:
    """
    Convert two 64-bits integers (head, tail) into a 128-bits integer

    Parameters
    ----------
    id_tuple : TupleID
        A tuple of head and tail integers

    Returns
    -------
    int
        Integer from the two integer parts

    Examples
    --------
    >>> pair_i64 = (5143335444508528211, 11537001611497766642)
    >>> u64u128(pair_i64)
    94877792630087975162035649532394405618
    """
    head, tail = pair_i64
    return head << 64 | tail


@cache
def u64x(pair_i64: TupleID) -> str:
    """
    Convert two 64-bits integers (head, tail) into an hexadecimal integer
    casted into a string

    Parameters
    ----------
    pair_i64 : TupleID
        A tuple of head and tail integers

    Returns
    -------
    str
        hexadecimal string from the two integer parts
    """
    hex_value = hex(u64u128(pair_i64))[2:]
    return hex_value if len(hex_value) == 32 else f"0{hex_value}"


@cache
def b2x(bytes_value: bytes) -> str:
    """
    Convert a byte value into two unique 64-bits integer

    Parameters
    ----------
    bytes_value : bytes
        Byte value

    Returns
    -------
    str
        Unique 128-bits hexadecimal integer
    """
    return blake3.blake3(bytes_value).hexdigest(HEX_SIZE)


def oid(value: Union[PairId, TupleID, int, str]) -> PairId:
    """
    Optimized ID; Transform hex value into optimized ID

    Parameters
    ----------
    value : Union[PairId, TupleID, int, str]
        Value

    Returns
    -------
    PairId
        Optimized ID
    """
    if isinstance(value, PairId):
        return value
    elif isinstance(value, (tuple, list)) and len(value) == 2:
        return PairId(head=value[0], tail=value[1])
    head, tail = x2u64(value)
    return PairId(head=head, tail=tail)


def xid(value: Union[PairId, TupleID, int, str]) -> str:
    """
    heXadecimal ID; Convert a pair id to a 128-bits
    hexadecimal integer casted into an hexadecimal string

    Parameters
    ----------
    value : Union[PairId, TupleID, int, str]
        Value

    Returns
    -------
    str
        Hexadecimal integer string
    """
    if isinstance(value, str):
        return value
    elif isinstance(value, int):
        value = x2u64(value)
    elif isinstance(value, PairId):
        value = (value.head, value.tail)
    return u64x(value)


def lid(value: Union[PairId, TupleID, int, str]) -> int:
    """
    Long integer ID; Convert an pair id to a 128-bits
    hexadecimal integer

    Parameters
    ----------
    value : Union[PairId, TupleID, int, str]
        Value

    Returns
    -------
    int
        128-bits hexadecimal bits
    """
    if isinstance(value, int):
        return value
    elif isinstance(value, str):
        value = x2u64(value)
    elif isinstance(value, PairId):
        value = (value.head, value.tail)
    return u64u128(value)


def tid(value: Union[PairId, TupleID, int, str]) -> TupleID:
    """
    Tuple ID; Transform value into tuple of 64-bits integers

    Parameters
    ----------
    value : Union[PairId, TupleID, int, str]
        Value

    Returns
    -------
    TupleID
        Tuple ID
    """
    if isinstance(value, PairId):
        return (value.head, value.tail)
    elif isinstance(value, (tuple, list)) and len(value) == 2:
        return value
    return x2u64(value)


class ID:
    """
    Convenient class to convert an ID to :

    * :code:`PairId`
    * :code:`Tuple[int, int]`
    * :code:`int`
    * :code:`str`

    Parameters
    ----------
    value : Union[PairId, TupleID, int, str, ID]
        Value of the ID (can also be another ID object for idempotent wrapping)
    """

    def __init__(self, value: Optional[Union[PairId, TupleID, int, str, "ID"]] = None):
        # Handle ID wrapping ID case (idempotent)
        if isinstance(value, ID):
            self.value = value.value
        else:
            self.value = value or uuid.uuid4().hex
        self._tid = None
        self._xid = None
        self._oid = None

    @property
    def tid(self) -> TupleID:
        if self._tid is None:
            self._tid = tid(self.value)
        return self._tid

    @property
    def xid(self) -> str:
        if self._xid is None:
            self._xid = xid(self.value)
        return self._xid

    @property
    def oid(self) -> PairId:
        if self._oid is None:
            self._oid = oid(self.value)
        return self._oid

    def __eq__(self, other):
        if not isinstance(other, ID):
            # Check if it's a tuple of size 2 (like TupleID) without using the generic alias
            if isinstance(other, tuple) and len(other) == 2:
                # Optionally check element types if needed: and all(isinstance(i, int) for i in other)
                return self.tid == other
            elif isinstance(other, PairId):
                return self.oid == other
            elif isinstance(other, str):
                return self.xid == other
            return NotImplemented
        # two IDs are equal if their tuple IDs match
        return self.tid == other.tid

    def __hash__(self):
        # hash on that tuple so it’s consistent with __eq__
        return hash(self.tid)

    def __repr__(self):
        return self.xid


class ListIDs:
    """
    Convenient class to convert a list of IDs to :

    * list of :code:`PairId`
    * list of :code:`Tuple[int, int]`
    * list of :code:`int`
    * list of :code:`str`

    Parameters
    ----------
    values : Union[Sequence[Union[PairId, TupleID, int, str, ID]], ListIDs]
        Values of the IDs (can also be another ListIDs object for idempotent wrapping)
    """

    def __init__(
        self, values: Union[Sequence[Union[PairId, TupleID, int, str, ID]], "ListIDs"]
    ):
        # Handle ListIDs wrapping ListIDs case (idempotent)
        if isinstance(values, ListIDs):
            self.values: List[ID] = values.values.copy()  # Copy to avoid mutation
        else:
            self.values: List[ID] = [
                value if isinstance(value, ID) else ID(value) for value in values
            ]
        self._tid = None
        self._xid = None
        self._oid = None

    @property
    def tid(self) -> List[TupleID]:
        if self._tid is None:
            self._tid = [value.tid for value in self.values]
        return self._tid

    @property
    def xid(self) -> List[str]:
        if self._xid is None:
            self._xid = [value.xid for value in self.values]
        return self._xid

    @property
    def oid(self) -> List[PairId]:
        if self._oid is None:
            self._oid = [value.oid for value in self.values]
        return self._oid

    def __len__(self) -> int:
        return len(self.values)

    def __bool__(self) -> bool:
        return bool(self.values)

    def __iter__(self) -> Iterator[ID]:
        return iter(self.values)

    def append(self, other: ID) -> None:
        self.values.append(other)

    def extend(self, other: List[ID]) -> None:
        self.values.extend(other)


# Datetime conversions


def datetime_to_int(date: datetime) -> int:
    """
    Transform a datetime to an integer

    Parameters
    ----------
    date : datetime
        Date

    Returns
    -------
    int
        Integer related to the datetime
    """
    return round(date.timestamp() * 1e6)


def int_to_datetime(timestamp: int) -> datetime:
    """
    Convert an timestamp to a datetime

    Parameters
    ----------
    timestamp : int
        Integer timestamp to convert

    Returns
    -------
    datetime
        Date from the timestamp
    """
    return datetime.fromtimestamp(timestamp * 1e-6)


# Task conversion


def task2dict(task: Task) -> dict:
    task_id = task.task_id
    next_tasks = ListIDs(task.next_tasks)
    previous_tasks = ListIDs(task.previous_tasks)
    task_dict = {}
    task_dict["task_id"] = ID(task_id).xid
    task_dict["next_tasks"] = next_tasks.xid
    task_dict["previous_tasks"] = previous_tasks.xid
    task_dict["conditions"] = task.conditions
    task_dict["order"] = task.order
    task_dict["network"] = task.network
    task_dict["alias"] = task.alias

    task_dict["scheduling"] = asdict(task.scheduling)
    task_dict["module_id"] = task.module_id
    return task_dict


def dict2task(task: dict) -> Task:
    task_id = oid(task["task_id"])
    next_tasks = ListIDs(task["next_tasks"]).oid
    previous_tasks = ListIDs(task["previous_tasks"]).oid
    return Task(
        task_id=task_id,
        scheduling=Scheduling(**task["scheduling"]),
        module_id=task["module_id"],
        previous_tasks=previous_tasks,
        next_tasks=next_tasks,
        conditions=task["conditions"],
        order=task["order"],
        network=task["network"],
        alias=task["alias"],
    )


def error2dict(error: Error) -> dict:
    """
    Convert an Error protobuf message to a dictionary suitable for MongoDB storage.

    Converts PairId objects to hex strings to avoid MongoDB integer overflow
    (MongoDB only supports signed 64-bit integers, but PairId uses uint64).

    Parameters
    ----------
    error : Error
        Error protobuf message

    Returns
    -------
    dict
        Dictionary with PairId fields converted to hex strings
    """
    return {
        "swarm_id": ID(error.swarm_id).xid,
        "node_id": ID(error.node_id).xid,
        "task_id": ID(error.task_id).xid,
        "iteration": error.iteration,
        "circular": error.circular,
        "timestamp": error.timestamp,
        "error_id": error.error_id,
        "content": error.content,
    }


def dict2error(error: dict) -> Error:
    """
    Convert a dictionary (from MongoDB) back to an Error protobuf message.

    Converts hex string IDs back to PairId objects.

    Parameters
    ----------
    error : dict
        Dictionary with hex string IDs

    Returns
    -------
    Error
        Error protobuf message with PairId objects
    """
    return Error(
        swarm_id=ID(error["swarm_id"]).oid,
        node_id=ID(error["node_id"]).oid,
        task_id=ID(error["task_id"]).oid,
        iteration=error["iteration"],
        circular=error["circular"],
        timestamp=error["timestamp"],
        error_id=error["error_id"],
        content=error["content"],
    )


# Dictionary conversions


def dict_to_bytes(d: dict) -> bytes:
    """
    Convert a dictionary to bytes

    Parameters
    ----------
    d : dict
        The dictionary to convert

    Returns
    -------
    bytes
        The bytes representation of the dictionary

    Examples
    --------

    >>> from manta.utils import dict_to_bytes
    >>> dictionary = {"key1": ["a", "b"], "key2", 0.2}
    >>> dict_to_bytes(dictionary)
    """
    import msgpack

    result = msgpack.packb(d, use_bin_type=True)
    return bytes(result) if result is not None else b""


def bytes_to_dict(b: bytes) -> dict:
    """
    Convert bytes to a dictionary

    Parameters
    ----------
    b : bytes
        The bytes to convert

    Returns
    -------
    dict
        The dictionary representation of the bytes

    Examples
    --------

    >>> from manta.utils import dict_to_bytes
    >>> dictionary = {"key1": ["a", "b"], "key2", 0.2}
    >>> dict_bytes = dict_to_bytes(dictionary)
    >>> bytes_to_dict(dict_bytes)
    """
    import msgpack

    return msgpack.unpackb(b, raw=False)
