import asyncio
import logging
from typing import Any, Optional


def call_async(func):
    """
    Decorator to call an asynchronous function
    """

    def wrapper(self, *args, **kwargs) -> Any:
        return self.event_loop.run_coroutine(
            getattr(self.async_api, func.__name__)(*args, **kwargs)
        )

    return wrapper


class EventLoopManager:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = EventLoopManager()
        return cls._instance

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def get_loop(self) -> asyncio.AbstractEventLoop:
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
            self.logger.debug(f"Created new event loop: {id(self._loop)}")
        return self._loop

    def run_coroutine(self, coroutine):
        loop = self.get_loop()
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(coroutine)

    def close(self):
        if self._loop and not self._loop.is_closed():
            self.logger.debug(f"Closing event loop: {id(self._loop)}")
            self._loop.close()
            self._loop = None
