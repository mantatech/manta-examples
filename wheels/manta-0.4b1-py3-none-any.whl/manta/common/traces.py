from __future__ import annotations

import logging
import re
import sqlite3
import struct
import sys
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from logging import Logger
from pathlib import Path
from typing import List, Optional, Tuple, Union
from zlib import compress

from .build.common.system import PairId
from .conversions import ID, datetime_to_int, xid

__all__ = ["Tracer", "Metadata", "SQLite"]

DATETIME_FORMAT = "%d/%m/%Y %H:%M:%S.%f"
MESSAGE_FORMAT = "{date} - {name} - {level} - {message} ({filename}:{lineno})"

LEVELS = {
    logging.NOTSET: "NOTSET",
    logging.INFO: "INFO",
    logging.DEBUG: "DEBUG",
    logging.WARNING: "WARNING",
    logging.ERROR: "ERROR",
    logging.CRITICAL: "CRITICAL",
}

METADATA_SIZE = (64 * 6 + 16 * 2) // 8


def default_pair_id():
    return PairId(0, 0)


@dataclass
class Metadata:
    """
    Meta data dataclass used in header of a trace

    Parameters
    ----------
    swarm_id : PairId
        Swarm ID
    node_id : PairId
        Node ID
    task_id : PairId
        Task ID
    iteration : PairId
        Iteration
    circular : PairId
        Circular
    date : Optional[datetime]
        Date (excluded for :code:`to_bytes` method)
    """

    swarm_id: PairId = field(default_factory=default_pair_id)
    node_id: PairId = field(default_factory=default_pair_id)
    task_id: PairId = field(default_factory=default_pair_id)
    iteration: int = 0
    circular: int = 0
    date: Optional[datetime] = None

    def to_bytes(self) -> bytes:
        """
        Convert the meta data values to a unique byte value

        Returns
        -------
        bytes
            Meta data in bytes
        """
        return struct.pack(
            "QQQQQQHH",
            self.swarm_id.head,
            self.swarm_id.tail,
            self.node_id.head,
            self.node_id.tail,
            self.task_id.head,
            self.task_id.tail,
            self.iteration,
            self.circular,
        )

    @staticmethod
    def from_bytes(data_bytes: bytes, date: Optional[datetime] = None) -> Metadata:
        (
            swarm_id_head,
            swarm_id_tail,
            node_id_head,
            node_id_tail,
            task_id_head,
            task_id_tail,
            iteration,
            circular,
        ) = struct.unpack("QQQQQQHH", data_bytes)
        return Metadata(
            PairId(swarm_id_head, swarm_id_tail),
            PairId(node_id_head, node_id_tail),
            PairId(task_id_head, task_id_tail),
            iteration,
            circular,
            date or datetime.now(),
        )

    def set_now(self):
        """Set date to now"""
        self.date = datetime.now()

    def __copy__(self):
        return Metadata(
            swarm_id=self.swarm_id,
            node_id=self.node_id,
            task_id=self.task_id,
            iteration=self.iteration,
            circular=self.circular,
            date=self.date,
        )


class SQLite:
    """
    Small database in which traces are stored
    """

    TRACE_PATH = Path.home() / ".manta" / "traces.db"
    TABLE_NAME = "traces"

    def __init__(
        self, trace_path: Optional[Path] = None, table_name: Optional[str] = None
    ):
        self.trace_path = trace_path or self.TRACE_PATH
        self.table_name = table_name or self.TABLE_NAME

        # Validate table name to prevent SQL injection
        # Allow only alphanumeric characters and underscores (safe for SQL identifiers)
        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", self.table_name):
            raise ValueError(
                f"Invalid table name '{self.table_name}'. "
                "Table names must start with a letter or underscore "
                "and contain only alphanumeric characters and underscores."
            )

        self.trace_path.parent.mkdir(exist_ok=True)
        self.con = sqlite3.connect(self.trace_path)
        self.cur = self.con.cursor()
        if self.table_not_exists():
            self.create_table()

    def table_not_exists(self) -> bool:
        """
        Check if main table does not exist

        Returns
        -------
        bool
            :code:`True` if main table does not exist
        """
        names = self.cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (self.table_name,),
        )
        return names.fetchone() is None

    def create_table(self):
        """
        Creates the main table
        """
        self.cur.execute(
            f"CREATE TABLE {self.table_name}(datetime primary key, content)"
        )

    def insert(self, row: Tuple[int, bytes]):
        """
        Inserts a row (datetime, content) in the database where :

        * datetime is the reference key of the row
        * content is a bytes value of traces

        Parameters
        ----------
        row : Tuple[datetime, bytes]
            Row
        """
        try:
            self.cur.execute(f"INSERT INTO {self.table_name} VALUES(?, ?)", row)
            self.con.commit()
        except (sqlite3.IntegrityError, sqlite3.OperationalError) as e:
            print(f"Error inserting row: {row}")
            print(e)

    def find_between(self, start: int, end: int) -> List[Tuple[int, bytes]]:
        """
        Returns the row

        Parameters
        ----------
        start : int
            Start date timestamp
        end : int
            End date timestamp

        Returns
        -------
        List[Tuple[int, bytes]]
            List of rows
        """
        return self.cur.execute(
            f"SELECT datetime, content FROM {self.table_name} WHERE datetime BETWEEN ? AND ?",
            (start, end),
        ).fetchall()

    def __del__(self):
        """
        Close the connection when object :code:`SQLite` is dropped
        """
        self.con.close()


class Tracer(SQLite):
    """
    Tracer helps to store logs formatted and compressed automatically.
    The database used is a SQLite storage with key-value approach.
    Keys are datetime timestamps and values are a combination of
    header values from meta data and the compressed message value.

    Parameters
    ----------
    logger : Logger
        Logger from the environment
    """

    def __init__(self, logger: Logger, node_id: Optional[PairId] = None):
        super().__init__(table_name=f"node_{xid(node_id)}" if node_id else None)
        self.logger = logger
        self.metadata = Metadata(node_id=node_id or PairId(1, 1), swarm_id=PairId(0, 0))

    def set_node_id(self, node_id: ID):
        """
        Sets node ID to metadata

        Parameters
        ----------
        node_id : ID
            Node ID
        """
        self.metadata.node_id = node_id.oid

    def set_swarm_id(self, swarm_id: ID):
        """
        Sets swarm ID to metadata

        Parameters
        ----------
        swarm_id : ID
            Swarm ID
        """
        self.metadata.swarm_id = swarm_id.oid

    def set_task_id(self, task_id: ID):
        """
        Sets task ID to metadata

        Parameters
        ----------
        task_id : ID
            Task ID
        """
        self.metadata.task_id = task_id.oid

    def set_iteration(self, iteration: int):
        """
        Sets iteration to metadata

        Parameters
        ----------
        iteration : int
            Iteration
        """
        self.metadata.iteration = iteration

    def set_circular(self, circular: int):
        """
        Sets circular to metadata

        Parameters
        ----------
        circular : int
            Circular
        """
        self.metadata.circular = circular

    def set_metadata(
        self,
        node_id: Optional[ID] = None,
        swarm_id: Optional[ID] = None,
        task_id: Optional[ID] = None,
        iteration: Optional[int] = None,
        circular: Optional[int] = None,
    ):
        """
        Sets metadata given arguments

        Parameters
        ----------
        node_id : ID
            Node ID
        swarm_id : ID
            Swarm ID
        task_id : ID
            Task ID
        iteration : int
            Iteration
        circular : int
            Circular
        """
        self.metadata.node_id = node_id.oid if node_id else self.metadata.node_id
        self.metadata.swarm_id = swarm_id.oid if swarm_id else self.metadata.swarm_id
        self.metadata.task_id = task_id.oid if task_id else self.metadata.task_id
        self.metadata.iteration = iteration or self.metadata.iteration
        self.metadata.circular = circular or self.metadata.circular
        self.metadata.set_now()

    def clean_metadata(self):
        """
        Sets swarm ID, task ID, iteration and circular
        to default values and update time to now
        """
        self.metadata.swarm_id = PairId(0, 0)
        self.metadata.task_id = PairId(0, 0)
        self.metadata.iteration = 0
        self.metadata.circular = 0
        self.metadata.set_now()

    def store_raw_logs(self, raw_logs: bytes) -> Tuple[datetime, bytes]:
        """
        Compressed raw logs into serialized content, store them
        in the SQLite database and returns the datetime and
        then final content

        Parameters
        ----------
        raw_logs : bytes
            Raw logs

        Returns
        -------
        Tuple[datetime, bytes]
            (datetime, metadata + compressed logs)
        """
        date = datetime.now(timezone.utc)
        compressed_logs = compress(raw_logs, level=9)
        header = self.metadata.to_bytes()
        content = header + compressed_logs
        self.insert(row=(datetime_to_int(date), content))
        return (date, content)

    def prepare_message(
        self,
        level: int,
        message: str,
        date: datetime,
        exc_info: Optional[Union[BaseException, bool]] = None,
    ) -> bytes:
        """
        Gather environment information and format the message with
        environment information and compress the final message

        Parameters
        ----------
        level : int
            Level of the log message
        message : str
            Log message
        date : datetime
            Date of the log message
        exc_info : Optional[Union[BaseException, bool]]
            :code:`True` if it is called in :code:`except` block to
            get traceback

        Returns
        -------
        bytes
            Compressed message
        """
        try:
            fn, lno, func, _ = self.logger.findCaller(stack_info=False, stacklevel=1)
        except ValueError:  # pragma: no cover
            fn, lno, func = "unknown file", 0, "unknown function"
        if exc_info:
            if isinstance(exc_info, BaseException):
                exc_info = (type(exc_info), exc_info, exc_info.__traceback__)
                message = "".join(traceback.format_tb(exc_info[2]))
            elif not isinstance(exc_info, tuple):
                exc_info = sys.exc_info()
                message = "".join(traceback.format_tb(exc_info[2]))
        message = MESSAGE_FORMAT.format(
            date=date.strftime(DATETIME_FORMAT),
            name=func,
            level=LEVELS[level],
            message=message,
            filename=Path(fn).name,
            lineno=lno,
        )
        return compress(message.encode("UTF-8"), level=9)

    def store_trace(
        self,
        level: int,
        message: str,
        exc_info: Optional[Union[BaseException, bool]] = None,
    ):
        """
        Store a trace into SQLite database

        Parameters
        ----------
        level : int
            Level of the log message
        message : str
            Message content
        exc_info : Optional[Union[BaseException, bool]]
            :code:`True` if it is called in :code:`except` block to
            get traceback
        """
        date = datetime.now()
        bytes_message = self.prepare_message(level, message, date, exc_info)
        header = self.metadata.to_bytes()
        content = header + bytes_message
        self.insert(row=(datetime_to_int(date), content))

    def info(self, message: str):
        """
        Store a message with info level

        Parameters
        ----------
        message : str
            Message content
        """
        if self.logger.isEnabledFor(logging.INFO):
            self.store_trace(logging.INFO, message)
            self.logger._log(logging.INFO, message, [])

    def debug(self, message: str):
        """
        Store a message with debug level

        Parameters
        ----------
        message : str
            Message content
        """
        if self.logger.isEnabledFor(logging.DEBUG):
            self.store_trace(logging.DEBUG, message)
            self.logger._log(logging.DEBUG, message, [])

    def warning(self, message: str):
        """
        Store a message with warning level

        Parameters
        ----------
        message : str
            Message content
        """
        if self.logger.isEnabledFor(logging.WARNING):
            self.store_trace(logging.WARNING, message)
            self.logger._log(logging.WARNING, message, [])

    def error(
        self,
        message: str,
        exc_info: Optional[Union[BaseException, bool]] = None,
    ):
        """
        Store a message with error level

        Parameters
        ----------
        message : str
            Message content
        exc_info : Optional[Union[BaseException, bool]]
            :code:`True` if it is called in :code:`except` block to
            get traceback
        """
        if self.logger.isEnabledFor(logging.ERROR):
            self.store_trace(logging.ERROR, message, exc_info=exc_info)
            self.logger._log(logging.ERROR, message, [], exc_info=exc_info)

    def exception(self, message: str = ""):
        """
        Store a message with traceback of the error
        and error level

        Parameters
        ----------
        message : str
            Message content
        """
        self.error(message, exc_info=True)

    def critical(self, message: str):
        """
        Store a message with critical level

        Parameters
        ----------
        message : str
            Message content
        """
        if self.logger.isEnabledFor(logging.CRITICAL):
            self.store_trace(logging.CRITICAL, message)
            self.logger._log(logging.CRITICAL, message, [])

    @staticmethod
    def sanitize_dict(data: dict, sensitive_keys: Optional[set] = None) -> dict:
        """
        Remove sensitive fields from a dictionary for safe logging

        Parameters
        ----------
        data : dict
            Dictionary to sanitize
        sensitive_keys : Optional[set]
            Additional sensitive keys to remove (default includes common secrets)

        Returns
        -------
        dict
            Sanitized copy of the dictionary
        """
        default_sensitive = {
            "password",
            "jwt_secret",
            "token",
            "api_key",
            "secret",
            "auth_key",
            "authorization",
            "credential",
            "private_key",
        }
        sensitive_keys = sensitive_keys or set()
        all_sensitive = default_sensitive | sensitive_keys

        sanitized = {}
        for key, value in data.items():
            if key in all_sensitive:
                sanitized[key] = "[REDACTED]"
            elif isinstance(value, dict):
                sanitized[key] = Tracer.sanitize_dict(value, sensitive_keys)
            elif isinstance(value, list) and value and isinstance(value[0], dict):
                sanitized[key] = [
                    Tracer.sanitize_dict(item, sensitive_keys) for item in value
                ]
            else:
                sanitized[key] = value
        return sanitized

    @staticmethod
    def format_duration(duration_ms: float) -> str:
        """
        Format duration in milliseconds for consistent logging

        Parameters
        ----------
        duration_ms : float
            Duration in milliseconds

        Returns
        -------
        str
            Formatted duration string
        """
        if duration_ms < 1:
            return f"{duration_ms:.3f}ms"
        elif duration_ms < 1000:
            return f"{duration_ms:.2f}ms"
        else:
            return f"{duration_ms / 1000:.2f}s"

    def debug_dict(self, message: str, data: dict, keys: Optional[list] = None):
        """
        Log dictionary with only specified keys (or all non-sensitive keys)

        Parameters
        ----------
        message : str
            Message prefix
        data : dict
            Dictionary to log
        keys : Optional[list]
            Specific keys to include (if None, sanitize and include all)
        """
        if not self.logger.isEnabledFor(logging.DEBUG):
            return

        if keys:
            filtered = {k: data.get(k) for k in keys if k in data}
        else:
            filtered = self.sanitize_dict(data)

        formatted_data = " ".join([f"{k}={v}" for k, v in filtered.items()])
        self.debug(f"{message}: {formatted_data}")
