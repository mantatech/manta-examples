# Minimal __init__.py for manta.light runtime in containers
# This file replaces the main __init__.py during Docker build to avoid heavy imports
import importlib.metadata

__version__ = importlib.metadata.version(__package__)

# Only import the light module for container runtime
# No heavy API imports needed for task execution
from . import light

# Import essential conversions that manta.light exports
try:
    from .common.conversions import bytes_to_dict, dict_to_bytes

    __all__ = [
        "light",
        "bytes_to_dict",
        "dict_to_bytes",
    ]
except ImportError:
    # If conversions are not available, just export light
    __all__ = ["light"]
