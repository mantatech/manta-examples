from __future__ import annotations

from logging import getLogger
from typing import (
    AsyncIterable,
    AsyncIterator,
    Iterable,
    Optional,
    Type,
    TypeVar,
    Union,
)

from ..common.base_client import GrpcClientBase
from ..common.build import (
    ChunkResultValues,
    EnvId,
    GetGlobalRequest,
    GlobalValue,
    LightResult,
    LightResultQuery,
    Ok,
    SetGlobalRequest,
    TaskScheduling,
    WorldStub,
)
from ..common.retry import RetryPolicy, StreamingRetryPolicy

__all__ = ["WorldClient"]

T = TypeVar("T")


class WorldClient(GrpcClientBase):
    """
    World client facilitates access to the world (Session) data with retry
    and connection management capabilities.
    """

    __slots__ = ()

    #: Default retry policy for regular methods
    DEFAULT_RETRY_POLICY = RetryPolicy(
        max_retries=3,
        initial_delay=0.2,
        max_delay=10.0,
        backoff_factor=2.0,
        jitter_factor=0.2,
    )

    #: Default retry policy for streaming methods
    DEFAULT_STREAMING_RETRY_POLICY = StreamingRetryPolicy(
        max_retries=3,
        initial_delay=0.2,
        max_delay=10.0,
        backoff_factor=2.0,
        jitter_factor=0.2,
        retry_if_no_items_processed=True,
    )

    def _get_stub_class(self) -> Type[WorldStub]:
        """
        Get the stub class for this client.
        """
        return WorldStub

    def __init__(
        self,
        host: str = "localhost",
        port: int = 50051,
        retry_policy: Optional[RetryPolicy] = None,
        streaming_retry_policy: Optional[StreamingRetryPolicy] = None,
    ) -> None:
        """
        Initialize World client

        Parameters
        ----------
        host : str
            Manager hostname
        port : int
            Manager port
        retry_policy : Optional[RetryPolicy]
            Custom retry policy for operations
        streaming_retry_policy : Optional[StreamingRetryPolicy]
            Custom retry policy for streaming operations
        """
        super().__init__(
            host=host,
            port=port,
            retry_policy=retry_policy,
            streaming_retry_policy=streaming_retry_policy,
            tracer=getLogger(__name__),
        )

    async def get_task_result(
        self, request: LightResultQuery
    ) -> AsyncIterator[ChunkResultValues]:
        """
        Get task results from the manager.

        Parameters
        ----------
        request : LightResultQuery
            Query containing task_id, swarm_id, tag, size, and method

        Returns
        -------
        AsyncIterator[ChunkResultValues]
            Stream of result chunks
        """
        async for chunk in self.stream_service_method("get_task_result", request):
            yield chunk

    async def add_task_result(self, request: AsyncIterable[LightResult]) -> Ok:
        """
        Add task result to the manager.

        Parameters
        ----------
        request : AsyncIterable[LightResult]
            Stream of light results containing task_id, swarm_id, tag, and data

        Returns
        -------
        Ok
            Response indicating success
        """
        return await self.call_service_method("add_task_result", request)

    async def get_global(self, request: GetGlobalRequest) -> AsyncIterator[GlobalValue]:
        """
        Get global values from the manager.

        Parameters
        ----------
        request : GetGlobalRequest
            Global tag to query

        Returns
        -------
        AsyncIterator[GlobalValue]
            Stream of global values
        """
        async for value in self.stream_service_method("get_global", request):
            yield value

    async def set_global(
        self,
        request: Union[AsyncIterable[SetGlobalRequest], Iterable[SetGlobalRequest]],
    ) -> Ok:
        """
        Set global values in the manager.

        Parameters
        ----------
        request : Union[AsyncIterable[SetGlobalRequest], Iterable[SetGlobalRequest]]
            Stream of global updates

        Returns
        -------
        Ok
            Response indicating success
        """
        return await self.call_service_method("set_global", request)

    async def stop_swarm(self, request: EnvId) -> Ok:
        """
        Stop a swarm.

        Parameters
        ----------
        request : EnvID
            Swarm ID to stop

        Returns
        -------
        Ok
            Response indicating success
        """
        return await self.call_service_method("stop_swarm", request)

    async def schedule_task(self, request: TaskScheduling) -> Ok:
        """
        Schedule a task.

        Parameters
        ----------
        request : TaskScheduling
            Task scheduling information

        Returns
        -------
        Ok
            Response indicating success
        """
        return await self.call_service_method("schedule_task", request)
