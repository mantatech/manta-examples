"""
User Management Client implementation.

This module provides the UserManagementClient class for interacting with the UserManagement service.
"""

from __future__ import annotations

from logging import Logger
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional, Type, TypeVar

from ..common.base_client import GrpcClientBase
from ..common.build import Empty  # Common types; Permissions
from ..common.build import (
    CollectionIds,
    Response,
    User,
    UserAuthorization,
    UserPermission,
    UserQuotas,
)
from ..common.build.core.user_services import (  # Request/Response messages; Service stub
    AddUserRequest,
    DeleteUserRequest,
    GetUserRequest,
    RegisterUserRequest,
    RegisterUserResponse,
    RequestPasswordResetRequest,
    RequestPasswordResetResponse,
    ResendVerificationRequest,
    ResendVerificationResponse,
    ResetPasswordRequest,
    ResetPasswordResponse,
    SignInRequest,
    UserManagementStub,
    ValidateUserRequest,
    ValidateUserResponse,
)
from ..common.retry import RetryPolicy

T = TypeVar("T")


class UserManagementClient(GrpcClientBase):
    """
    Client for interacting with the UserManagement Service.

    This client provides a high-level interface for making gRPC calls to the UserManagement service,
    handling user registration, authentication, and account management operations.
    """

    __slots__ = ("_secure", "cafile", "certfile", "keyfile")

    def __init__(
        self,
        host: str,
        port: int,
        jwt_token: Optional[str] = None,
        secure: bool = False,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
        channel_options: Optional[Dict[str, Any]] = None,
        logger: Optional[Logger] = None,
        retry_policy: Optional[RetryPolicy] = None,
        streaming_retry_policy: Optional[RetryPolicy] = None,
    ):
        """
        Initialize the UserManagementClient.

        Parameters
        ----------
        host : str
            The host of the UserManagement service
        port : int
            The port of the UserManagement service
        jwt_token : Optional[str]
            JWT token for authentication (not required for SignIn/RegisterUser)
        secure : bool
            Whether to use a secure connection
        cafile : Optional[str]
            Path to the CA certificate file for verifying the server
        certfile : Optional[str]
            Path to the client certificate file
        keyfile : Optional[str]
            Path to the client private key file
        channel_options : Optional[Dict[str, Any]]
            The channel options
        logger : Optional[Logger]
            The logger
        retry_policy : Optional[RetryPolicy]
            The retry policy
        streaming_retry_policy : Optional[RetryPolicy]
            The streaming retry policy
        """
        metadata = {"authorization": jwt_token} if jwt_token else None
        super().__init__(
            host=host,
            port=port,
            secure=secure,
            channel_options=channel_options,
            metadata=metadata,
            tracer=logger,
            retry_policy=retry_policy,
            streaming_retry_policy=streaming_retry_policy,
        )
        self._secure = secure
        self.cafile = Path(cafile) if cafile is not None else None
        self.certfile = Path(certfile) if certfile is not None else None
        self.keyfile = Path(keyfile) if keyfile is not None else None

    def _get_stub_class(self) -> Type[UserManagementStub]:
        """Get the stub class for the UserManagement service."""
        return UserManagementStub

    async def is_available(self) -> Response:
        """
        Check if the UserManagement service is available.

        Returns
        -------
        Response
            Service availability status
        """
        return await self.call_service_method(
            "is_available",
            Empty(),
        )

    async def register_user(self, username: str, password: str) -> RegisterUserResponse:
        """
        Register a new user account.

        Parameters
        ----------
        username : str
            Username for the new user
        password : str
            Password for the new user

        Returns
        -------
        RegisterUserResponse
            Registration response with user info and email status
        """
        return await self.call_service_method(
            "register_user",
            RegisterUserRequest(username=username, password=password),
        )

    async def validate_user(self, email_token: str) -> ValidateUserResponse:
        """
        Validate a user's email address with a token.

        Parameters
        ----------
        email_token : str
            Email validation token

        Returns
        -------
        ValidateUserResponse
            Validation response with success status and user ID
        """
        return await self.call_service_method(
            "validate_user",
            ValidateUserRequest(email_token=email_token),
        )

    async def sign_in(self, username: str, password: str) -> User:
        """
        Authenticate a user and receive JWT token.

        Parameters
        ----------
        username : str
            Username for authentication
        password : str
            Password for authentication

        Returns
        -------
        User
            User details with JWT token
        """
        return await self.call_service_method(
            "sign_in",
            SignInRequest(username=username, password=password),
        )

    async def logout(self) -> Response:
        """
        Logout the current user and invalidate the session.

        Returns
        -------
        Response
            Logout confirmation response
        """
        return await self.call_service_method(
            "logout",
            Empty(),
        )

    async def get_user(self, user_id: Optional[str] = None) -> User:
        """
        Get user details for the current user or a specific user.

        Parameters
        ----------
        user_id : Optional[str]
            User ID to retrieve. If not provided, returns current user.

        Returns
        -------
        User
            User details
        """
        request = GetUserRequest()
        if user_id:
            request.user_id = user_id
        return await self.call_service_method(
            "get_user",
            request,
        )

    async def list_user_ids(self) -> CollectionIds:
        """
        List all user IDs (admin only).

        Returns
        -------
        CollectionIds
            Collection of user IDs
        """
        return await self.call_service_method(
            "list_user_ids",
            Empty(),
        )

    async def stream_users(self) -> AsyncIterator[User]:
        """
        Stream all users (admin only).

        Yields
        ------
        User
            User details
        """
        async for user in self.stream_service_method(
            "stream_users",
            Empty(),
        ):
            yield user

    async def delete_user(self, user_id: str) -> Response:
        """
        Delete a user account (admin only).

        Parameters
        ----------
        user_id : str
            ID of the user to delete

        Returns
        -------
        Response
            Deletion confirmation response
        """
        return await self.call_service_method(
            "delete_user",
            DeleteUserRequest(user_id=user_id),
        )

    async def add_user(
        self,
        username: str,
        email: str,
        permissions: Optional[List[UserPermission]] = None,
        quotas: Optional[UserQuotas] = None,
    ) -> User:
        """
        Add a new user (admin only).

        Parameters
        ----------
        username : str
            Username for the new user
        email : str
            Email address for the new user
        permissions : Optional[List[UserPermission]]
            Specific permissions to grant
        quotas : Optional[UserQuotas]
            User quotas to set

        Returns
        -------
        User
            Created user details
        """
        request = AddUserRequest(username=username, email=email)
        if permissions:
            request.permissions.extend(permissions)
        if quotas:
            request.quotas = quotas
        return await self.call_service_method(
            "add_user",
            request,
        )

    async def update_user_authorization(
        self, authorization: UserAuthorization
    ) -> Response:
        """
        Update user authorization settings (admin only).

        Parameters
        ----------
        authorization : UserAuthorization
            Updated authorization settings

        Returns
        -------
        Response
            Update confirmation response
        """
        return await self.call_service_method(
            "update_user_authorization",
            authorization,
        )

    async def request_password_reset(self, email: str) -> RequestPasswordResetResponse:
        """
        Request a password reset for a user.

        Parameters
        ----------
        email : str
            Email address to send reset link to

        Returns
        -------
        RequestPasswordResetResponse
            Password reset request response
        """
        return await self.call_service_method(
            "request_password_reset",
            RequestPasswordResetRequest(email=email),
        )

    async def reset_password(
        self, reset_token: str, new_password: str
    ) -> ResetPasswordResponse:
        """
        Reset password using a reset token.

        Parameters
        ----------
        reset_token : str
            Token from the reset email
        new_password : str
            New password to set

        Returns
        -------
        ResetPasswordResponse
            Password reset response
        """
        return await self.call_service_method(
            "reset_password",
            ResetPasswordRequest(reset_token=reset_token, new_password=new_password),
        )

    async def resend_verification(self, email: str) -> ResendVerificationResponse:
        """
        Resend verification email to a user.

        Parameters
        ----------
        email : str
            Email to resend verification to

        Returns
        -------
        ResendVerificationResponse
            Resend verification response
        """
        return await self.call_service_method(
            "resend_verification",
            ResendVerificationRequest(email=email),
        )
