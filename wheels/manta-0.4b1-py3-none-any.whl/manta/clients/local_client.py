from __future__ import annotations

from logging import getLogger
from typing import AsyncIterator, Optional, Type, TypeVar

from ..common.base_client import GrpcClientBase
from ..common.build import (
    Binary,
    DataRequest,
    DirRequest,
    ExistsResponse,
    ListDirResponse,
    LocalStub,
    ReadText,
)
from ..common.retry import RetryPolicy, StreamingRetryPolicy

__all__ = ["LocalClient"]

T = TypeVar("T")


class LocalClient(GrpcClientBase):
    """
    Local client facilitates access to the local (Node) data with retry
    and connection management capabilities.
    """

    #: Default retry policy for regular methods
    DEFAULT_RETRY_POLICY = RetryPolicy(
        max_retries=3,
        initial_delay=0.2,
        max_delay=10.0,
        backoff_factor=2.0,
        jitter_factor=0.2,
    )

    #: Default retry policy for streaming methods
    DEFAULT_STREAMING_RETRY_POLICY = StreamingRetryPolicy(
        max_retries=3,
        initial_delay=0.2,
        max_delay=10.0,
        backoff_factor=2.0,
        jitter_factor=0.2,
        retry_if_no_items_processed=True,
    )

    def _get_stub_class(self) -> Type[LocalStub]:
        """
        Get the stub class for this client.
        """
        return LocalStub

    def __init__(
        self,
        host: str = "localhost",
        port: int = 50051,
        retry_policy: Optional[RetryPolicy] = None,
        streaming_retry_policy: Optional[StreamingRetryPolicy] = None,
    ) -> None:
        """
        Initialize Local client

        Parameters
        ----------
        host : str
            Node hostname
        port : int
            Node port
        retry_policy : Optional[RetryPolicy]
            Custom retry policy for operations
        streaming_retry_policy : Optional[StreamingRetryPolicy]
            Custom retry policy for streaming operations
        """
        super().__init__(
            host=host,
            port=port,
            retry_policy=retry_policy,
            streaming_retry_policy=streaming_retry_policy,
            tracer=getLogger(__name__),
        )

    async def get_binary_data(self, request: DataRequest) -> AsyncIterator[Binary]:
        """
        Get binary data from the node.

        Parameters
        ----------
        request : DataRequest
            Request containing task_id, swarm_id, and name

        Returns
        -------
        AsyncIterator[Binary]
            Stream of binary data chunks
        """
        async for chunk in self.stream_service_method("get_binary_data", request):
            yield chunk

    async def list_dir(self, request: DirRequest) -> ListDirResponse:
        """
        List directory contents on the node.

        Parameters
        ----------
        request : DirRequest
            Directory request containing data_request and path

        Returns
        -------
        ListDirResponse
            Response containing list of paths
        """
        return await self.call_service_method("list_dir", request)

    async def read_file_lines(self, request: ReadText) -> AsyncIterator[Binary]:
        """
        Read file lines from the node.

        Parameters
        ----------
        request : ReadText
            Request containing data_request, path, encoding, errors, and newline

        Returns
        -------
        AsyncIterator[Binary]
            Stream of file lines as binary chunks
        """
        async for chunk in self.stream_service_method("read_file_lines", request):
            yield chunk

    async def exists(self, request: DirRequest) -> ExistsResponse:
        """
        Check if a file or directory exists on the node.

        Parameters
        ----------
        request : DirRequest
            Directory request containing data_request and path

        Returns
        -------
        ExistsResponse
            Response indicating whether the path exists
        """
        return await self.call_service_method("exists", request)
