"""
Cluster Management Client implementation.

This module provides the ClusterManagementClient class for interacting with the ClusterManagement service.
"""

from __future__ import annotations

import ssl
from datetime import datetime
from functools import lru_cache
from logging import Logger
from pathlib import Path
from typing import Any, AsyncIterator, Dict, Optional, Type, TypeVar

from ..common.base_client import GrpcClientBase
from ..common.build import (
    Cluster,
    CollectionIds,
    Empty,  # Common types
    Error,
    MetricsSnapshot,
    Node,
    Response,
    StrId,
)
from ..common.build.core.user_services import (  # Request/Response messages; Service stub
    ClusterManagementStub,
    CreateClusterRequest,
    ErrorsRequest,
    NodeRequest,
    TaskResponse,
)
from ..common.retry import RetryPolicy

T = TypeVar("T")


class ClusterManagementClient(GrpcClientBase):
    """
    Client for interacting with the ClusterManagement Service.

    This client provides a high-level interface for making gRPC calls to the ClusterManagement service,
    handling cluster lifecycle and node management operations.
    """

    def __init__(
        self,
        host: str,
        port: int,
        jwt_token: str,
        secure: bool = False,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
        channel_options: Optional[Dict[str, Any]] = None,
        logger: Optional[Logger] = None,
        retry_policy: Optional[RetryPolicy] = None,
        streaming_retry_policy: Optional[RetryPolicy] = None,
    ):
        """
        Initialize the ClusterManagementClient.

        Parameters
        ----------
        host : str
            The host of the ClusterManagement service
        port : int
            The port of the ClusterManagement service
        jwt_token : str
            JWT token for authentication
        secure : bool
            Whether to use a secure connection
        cafile : Optional[str]
            Path to the CA certificate file for verifying the server
        certfile : Optional[str]
            Path to the client certificate file
        keyfile : Optional[str]
            Path to the client private key file
        channel_options : Optional[Dict[str, Any]]
            The channel options
        logger : Optional[Logger]
            The logger
        retry_policy : Optional[RetryPolicy]
            The retry policy
        streaming_retry_policy : Optional[RetryPolicy]
            The streaming retry policy
        """
        super().__init__(
            host=host,
            port=port,
            secure=secure,
            channel_options=channel_options,
            metadata={"authorization": jwt_token},
            tracer=logger,
            retry_policy=retry_policy,
            streaming_retry_policy=streaming_retry_policy,
        )
        self._secure = secure
        self.cafile = Path(cafile) if cafile is not None else None
        self.certfile = Path(certfile) if certfile is not None else None
        self.keyfile = Path(keyfile) if keyfile is not None else None

    # @property
    # @lru_cache(maxsize=1)
    # def ssl_context(self) -> Optional[ssl.SSLContext]:
    #     """
    #     Create a new SSL context with the given certificate authority
    #     and load the certificate and key from the given files.

    #     Returns
    #     -------
    #     Optional[ssl.SSLContext]
    #         Return an SSL context to be used for secure communication.
    #         If secure=True but no custom certificates are provided,
    #         uses system CA store for server verification.
    #     """
    #     # Only return None if explicitly in insecure mode
    #     if not self._secure:
    #         return None

    #     # Create SSL context for server authentication
    #     # If cafile is None, uses system's default CA bundle
    #     ssl_context = ssl.create_default_context(
    #         ssl.Purpose.SERVER_AUTH,
    #         cafile=str(self.cafile) if self.cafile else None,
    #     )

    #     # Load client certificate for mTLS if provided
    #     if self.certfile and self.keyfile:
    #         ssl_context.load_cert_chain(
    #             certfile=str(self.certfile),
    #             keyfile=str(self.keyfile),
    #         )
    #     return ssl_context

    def _get_stub_class(self) -> Type[ClusterManagementStub]:
        """Get the stub class for the ClusterManagement service."""
        return ClusterManagementStub

    async def is_available(self) -> Response:
        """
        Check if the ClusterManagement service is available.

        Returns
        -------
        Response
            Service availability status
        """
        return await self.call_service_method(
            "is_available",
            Empty(),
        )

    async def create_cluster(self, name: Optional[str] = None) -> StrId:
        """
        Create a new cluster.

        Parameters
        ----------
        name : Optional[str]
            Name for the cluster

        Returns
        -------
        StrId
            Cluster ID
        """
        request = CreateClusterRequest()
        if name:
            request.name = name
        return await self.call_service_method(
            "create_cluster",
            request,
        )

    async def start_cluster(self, cluster_id: str) -> Cluster:
        """
        Start cluster services.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster to start

        Returns
        -------
        Cluster
            Cluster details
        """
        return await self.call_service_method(
            "start_cluster",
            StrId(id=cluster_id),
        )

    async def stop_cluster(self, cluster_id: str) -> Response:
        """
        Stop cluster services.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster to stop

        Returns
        -------
        Response
            Stop operation response
        """
        return await self.call_service_method(
            "stop_cluster",
            StrId(id=cluster_id),
        )

    async def delete_cluster(self, cluster_id: str) -> Response:
        """
        Delete a cluster.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster to delete

        Returns
        -------
        Response
            Deletion confirmation response
        """
        return await self.call_service_method(
            "delete_cluster",
            StrId(id=cluster_id),
        )

    async def list_cluster_ids(self) -> CollectionIds:
        """
        List all cluster IDs for the authenticated user.

        Returns
        -------
        CollectionIds
            Collection of cluster IDs
        """
        return await self.call_service_method(
            "list_cluster_ids",
            Empty(),
        )

    async def stream_clusters(self) -> AsyncIterator[Cluster]:
        """
        Stream all clusters for the authenticated user.

        Yields
        ------
        Cluster
            Cluster details
        """
        async for cluster in self.stream_service_method(
            "stream_clusters",
            Empty(),
        ):
            yield cluster

    async def get_cluster(self, cluster_id: str) -> Cluster:
        """
        Get a cluster by its ID.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster

        Returns
        -------
        Cluster
            Cluster details
        """
        return await self.call_service_method(
            "get_cluster",
            StrId(id=cluster_id),
        )

    async def list_node_ids(self, cluster_id: str) -> CollectionIds:
        """
        List node IDs in a cluster.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster

        Returns
        -------
        CollectionIds
            Collection of node IDs
        """
        return await self.call_service_method(
            "list_node_ids",
            StrId(id=cluster_id),
        )

    async def stream_nodes(self, cluster_id: str) -> AsyncIterator[Node]:
        """
        Stream all nodes in a cluster.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster

        Yields
        ------
        Node
            Node information
        """
        async for node in self.stream_service_method(
            "stream_nodes",
            StrId(id=cluster_id),
        ):
            yield node

    async def stop_node(self, cluster_id: str, node_id: str) -> Response:
        """
        Stop a specific node.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster
        node_id : str
            ID of the node to stop

        Returns
        -------
        Response
            Stop operation response
        """
        return await self.call_service_method(
            "stop_node",
            NodeRequest(cluster_id=cluster_id, node_id=node_id),
        )

    async def remove_node(self, cluster_id: str, node_id: str) -> Response:
        """
        Remove a node from the cluster.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster
        node_id : str
            ID of the node to remove

        Returns
        -------
        Response
            Removal confirmation response
        """
        return await self.call_service_method(
            "remove_node",
            NodeRequest(cluster_id=cluster_id, node_id=node_id),
        )

    async def get_node(self, cluster_id: str, node_id: str) -> Node:
        """
        Get a node by its ID.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster
        node_id : str
            ID of the node

        Returns
        -------
        Node
            Node information
        """
        return await self.call_service_method(
            "get_node",
            NodeRequest(cluster_id=cluster_id, node_id=node_id),
        )

    async def get_node_resources(
        self, cluster_id: str, node_id: str
    ) -> MetricsSnapshot:
        """
        Get node resources for a specific node.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster
        node_id : str
            ID of the node

        Returns
        -------
        MetricsSnapshot
            Node resource metrics
        """
        return await self.call_service_method(
            "get_node_resources",
            NodeRequest(cluster_id=cluster_id, node_id=node_id),
        )

    async def stream_node_resources(
        self, cluster_id: str, node_id: str
    ) -> AsyncIterator[MetricsSnapshot]:
        """
        Stream node resources for a specific node.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster
        node_id : str
            ID of the node

        Yields
        ------
        MetricsSnapshot
            Stream of node resource metrics
        """
        async for resource in self.stream_service_method(
            "stream_node_resources",
            NodeRequest(cluster_id=cluster_id, node_id=node_id),
        ):
            yield resource

    async def list_available_node_ids(self, cluster_id: str) -> CollectionIds:
        """
        List available node IDs in a cluster.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster

        Returns
        -------
        CollectionIds
            Collection of available node IDs
        """
        return await self.call_service_method(
            "list_available_node_ids",
            StrId(id=cluster_id),
        )

    async def collect_errors(
        self,
        cluster_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: Optional[int] = None,
        sort_order: Optional[str] = None,
    ) -> AsyncIterator[Error]:
        """
        Collect errors from a cluster.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster
        start_time : Optional[datetime]
            Start time for filtering errors
        end_time : Optional[datetime]
            End time for filtering errors
        limit : Optional[int]
            Maximum number of errors to return
        sort_order : Optional[str]
            Sort order for results

        Yields
        ------
        Error
            Stream of errors
        """
        request = ErrorsRequest(cluster_id=cluster_id)
        if start_time:
            request.start_time = start_time
        if end_time:
            request.end_time = end_time
        if limit:
            request.limit = limit
        if sort_order:
            request.sort_order = sort_order
        async for error in self.stream_service_method(
            "collect_errors",
            request,
        ):
            yield error

    async def select_tasks(
        self, cluster_id: str, node_id: str
    ) -> AsyncIterator[TaskResponse]:
        """
        Select tasks for a specific node.

        Parameters
        ----------
        cluster_id : str
            ID of the cluster
        node_id : str
            ID of the node

        Yields
        ------
        TaskResponse
            Stream of task information
        """
        async for task in self.stream_service_method(
            "select_tasks",
            NodeRequest(cluster_id=cluster_id, node_id=node_id),
        ):
            yield task
