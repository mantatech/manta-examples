"""
Module Management Client implementation.

This module provides the ModuleManagementClient class for interacting with the ModuleManagement service.
"""

from __future__ import annotations

import ssl
from functools import lru_cache
from logging import Logger
from pathlib import Path
from typing import Any, AsyncIterator, Dict, Optional, Type, TypeVar

from ..common.base_client import GrpcClientBase
from ..common.build import CollectionIds, Empty, Module, Response, StrId  # Common types
from ..common.build.core.user_services import (  # Request/Response messages; Service stub
    ModuleManagementStub,
    ModuleRequest,
)
from ..common.retry import RetryPolicy

T = TypeVar("T")


class ModuleManagementClient(GrpcClientBase):
    """
    Client for interacting with the ModuleManagement Service.

    This client provides a high-level interface for making gRPC calls to the ModuleManagement service,
    handling module management and versioning operations.
    """

    def __init__(
        self,
        host: str,
        port: int,
        jwt_token: str,
        secure: bool = False,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
        channel_options: Optional[Dict[str, Any]] = None,
        logger: Optional[Logger] = None,
        retry_policy: Optional[RetryPolicy] = None,
        streaming_retry_policy: Optional[RetryPolicy] = None,
    ):
        """
        Initialize the ModuleManagementClient.

        Parameters
        ----------
        host : str
            The host of the ModuleManagement service
        port : int
            The port of the ModuleManagement service
        jwt_token : str
            JWT token for authentication
        secure : bool
            Whether to use a secure connection
        cafile : Optional[str]
            Path to the CA certificate file for verifying the server
        certfile : Optional[str]
            Path to the client certificate file
        keyfile : Optional[str]
            Path to the client private key file
        channel_options : Optional[Dict[str, Any]]
            The channel options
        logger : Optional[Logger]
            The logger
        retry_policy : Optional[RetryPolicy]
            The retry policy
        streaming_retry_policy : Optional[RetryPolicy]
            The streaming retry policy
        """
        super().__init__(
            host=host,
            port=port,
            secure=secure,
            channel_options=channel_options,
            metadata={"authorization": jwt_token},
            tracer=logger,
            retry_policy=retry_policy,
            streaming_retry_policy=streaming_retry_policy,
        )
        self._secure = secure
        self.cafile = Path(cafile) if cafile is not None else None
        self.certfile = Path(certfile) if certfile is not None else None
        self.keyfile = Path(keyfile) if keyfile is not None else None

    # @property
    # @lru_cache(maxsize=1)
    # def ssl_context(self) -> Optional[ssl.SSLContext]:
    #     """
    #     Create a new SSL context with the given certificate authority
    #     and load the certificate and key from the given files.

    #     Returns
    #     -------
    #     Optional[ssl.SSLContext]
    #         Return an SSL context to be used for secure communication.
    #         If secure=True but no custom certificates are provided,
    #         uses system CA store for server verification.
    #     """
    #     # Only return None if explicitly in insecure mode
    #     if not self._secure:
    #         return None

    #     # Create SSL context for server authentication
    #     # If cafile is None, uses system's default CA bundle
    #     ssl_context = ssl.create_default_context(
    #         ssl.Purpose.SERVER_AUTH,
    #         cafile=str(self.cafile) if self.cafile else None,
    #     )

    #     # Load client certificate for mTLS if provided
    #     if self.certfile and self.keyfile:
    #         ssl_context.load_cert_chain(
    #             certfile=str(self.certfile),
    #             keyfile=str(self.keyfile),
    #         )
    #     return ssl_context

    def _get_stub_class(self) -> Type[ModuleManagementStub]:
        """Get the stub class for the ModuleManagement service."""
        return ModuleManagementStub

    async def is_available(self) -> Response:
        """
        Check if the ModuleManagement service is available.

        Returns
        -------
        Response
            Service availability status
        """
        return await self.call_service_method(
            "is_available",
            Empty(),
        )

    async def send_module(self, module: Module) -> StrId:
        """
        Send/create a new module.

        Parameters
        ----------
        module : Module
            Module to create

        Returns
        -------
        StrId
            Module ID
        """
        return await self.call_service_method(
            "send_module",
            module,
        )

    async def list_module_ids(self) -> CollectionIds:
        """
        List all module IDs for the authenticated user.

        Returns
        -------
        CollectionIds
            Collection of module IDs
        """
        return await self.call_service_method(
            "list_module_ids",
            Empty(),
        )

    async def stream_modules(self) -> AsyncIterator[ModuleRequest]:
        """
        Stream all modules for the authenticated user.

        Yields
        ------
        ModuleRequest
            Module details wrapped in ModuleRequest
        """
        async for module_request in self.stream_service_method(
            "stream_modules",
            Empty(),
        ):
            yield module_request

    async def get_module(self, module_id: str) -> ModuleRequest:
        """
        Get a module by its ID.

        Parameters
        ----------
        module_id : str
            ID of the module

        Returns
        -------
        ModuleRequest
            Module details wrapped in ModuleRequest
        """
        return await self.call_service_method(
            "get_module",
            StrId(id=module_id),
        )

    async def update_module(self, module_request: ModuleRequest) -> StrId:
        """
        Update an existing module.

        Parameters
        ----------
        module_request : ModuleRequest
            Module request containing module data and module_id

        Returns
        -------
        StrId
            Module ID
        """
        return await self.call_service_method(
            "update_module",
            module_request,
        )

    async def remove_module(self, module_id: str) -> Response:
        """
        Remove a module from the system.

        Parameters
        ----------
        module_id : str
            ID of the module to remove

        Returns
        -------
        Response
            Removal confirmation response
        """
        return await self.call_service_method(
            "remove_module",
            StrId(id=module_id),
        )
