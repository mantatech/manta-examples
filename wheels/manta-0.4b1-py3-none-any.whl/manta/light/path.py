from __future__ import annotations

import io
from pathlib import Path
from typing import List, Optional, Union

from ..common.build import ProtoPath
from ..common.event_loop import EventLoopManager
from .local import Local

_shared_local = Local()  # shared Local instance between files


class MantaPath:
    def __init__(self, path: str, is_file: bool = True):
        self._is_file = is_file
        self._path = path
        self._local = _shared_local
        self.loop_manager = EventLoopManager.get_instance()

    def _to_proto(self):
        return ProtoPath(value=str(self._path), is_file=self._is_file)

    @property
    def name(self):
        return Path(self._path).name

    @property
    def stem(self):
        return Path(self._path).stem

    @property
    def suffix(self):
        return Path(self._path).suffix

    def __str__(self):
        return self._path

    def __truediv__(self, other: Union[str, MantaPath]) -> MantaPath:
        if isinstance(other, str):
            other_path = Path(other)
        elif isinstance(other, MantaPath):
            other_path = Path(other._path)
        else:
            raise TypeError(f"Unsupported type (found: {type(other)})")

        return MantaPath(str(Path(self._path) / other_path))

    async def async_exists(self) -> bool:
        response = await self._local.async_exists(self._to_proto())
        return response

    def exists(self) -> bool:
        return self._local.exists(self._to_proto())

    async def async_read_bytes(self) -> io.BytesIO:
        return await self._local.async_get_binary_data(self._to_proto())

    def read_bytes(self):
        return self._local.get_binary_data(self._to_proto())

    async def async_read_text(
        self,
        encoding: Optional[str] = None,
        errors: Optional[str] = None,
        newline: Optional[str] = None,
    ) -> io.StringIO:
        return await self._local.async_read_file_lines(
            self._to_proto(), encoding, errors, newline
        )

    def read_text(
        self,
        encoding: Optional[str] = None,
        errors: Optional[str] = None,
        newline: Optional[str] = None,
    ) -> io.StringIO:
        """
        Read Text

        Parameters
        ----------
        encoding : Optional[str], optional
            Specifies the encoding to use for decoding the file contents, by default None
        errors : Optional[str], optional
            Specifies how encoding/decoding errors should be handled, by default None
        newline : Optional[str], optional
            Specifies how newlines (`\n`, `\r\n`, `\r`) should be handled, by default None

        Returns
        -------
        io.StringIO
            _description_
        """
        return self._local.read_file_lines(self._to_proto(), encoding, errors, newline)

    async def async_iterdir(self) -> List[MantaPath]:
        response = await self._local.async_list_dir(self._to_proto())
        return [MantaPath(p.value, is_file=p.is_file) for p in response.paths]

    def iterdir(self) -> List[MantaPath]:
        return self.loop_manager.run_coroutine(self.async_iterdir())

    # async def async_glob(self, pattern, *, case_sensitive=None, recurse_symlinks=False):
    #     request = Glob(self._to_proto(), pattern, case_sensitive, recurse_symlinks)
    #     response = await self._local.glob(request)
    #     return [MantaPath(p.value, is_file=p.is_file) for p in response.paths]

    # def glob(self, pattern, *, case_sensitive=None, recurse_symlinks=False):
    #     return asyncio.run(
    #         self.async_glob(
    #             pattern,
    #             case_sensitive=case_sensitive,
    #             recurse_symlinks=recurse_symlinks,
    #         )
    #     )
