import logging
import os
from abc import ABC

from ..common.conversions import ID
from ..common.event_loop import EventLoopManager
from .local import Local
from .world import World

__all__ = ["Task"]


class Task(ABC):
    """
    Task abstract module.

    - Set the name of the task
    - Set the host and port for the RPC connection
    - Set the Task ID
    - Initialize the Local and World services
    - Initialize the logger

    Attributes
    ----------
    world: World
        For accessing and sending global data
    local: Local
        For accessing local data
    logger: logging.Logger
        Convenient logger which are collected and stored in Manager
    """

    __slots__ = [
        "name",
        "host",
        "port",
        "task_id",
        "swarm_id",
        "local",
        "world",
        "logger",
        "loop_manager",
    ]

    def __init__(self):
        """Initialize the task."""
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Initializing Task")

        self.name: str = str(__class__)

        self.host = os.getenv("RPC_HOST", "host.docker.internal")
        self.port = int(os.getenv("RPC_PORT", 50051))
        self.task_id = ID(os.getenv("TASK_ID"))
        self.swarm_id = ID(os.getenv("SWARM_ID"))

        self.local = Local(
            host=self.host, port=self.port, swarm_id=self.swarm_id, task_id=self.task_id
        )
        self.world = World(
            host=self.host, port=self.port, swarm_id=self.swarm_id, task_id=self.task_id
        )

        self.loop_manager = EventLoopManager.get_instance()

    def __str__(self):  # pragma: no cover
        return f"Task(name={self.name}, host={self.host}, port={self.port}, swarm_id={self.swarm_id}, task_id={self.task_id})"

    def __repr__(self):  # pragma: no cover
        return str(self)

    def cleanup(self) -> None:
        """Clean up any resources used by the task.

        This method should be called when the task is done to ensure all
        resources are properly released. It's especially important to
        close any open event loops to prevent resource leaks.
        """
        self.logger.info("Cleaning up task resources")
        try:
            self.loop_manager.run_coroutine(self.local.local_client.disconnect())
            self.loop_manager.run_coroutine(self.world.world_client.disconnect())
            self.loop_manager.close()
            self.logger.info("Event loop closed successfully")
        except Exception as e:
            self.logger.error(f"Error closing event loop: {e}")

    def __del__(self) -> None:
        """Destructor to ensure cleanup is called."""
        try:
            self.cleanup()
        except Exception as e:
            # Log the exception before suppressing to avoid silent failures
            try:
                self.logger.error(f"Error during task cleanup in destructor: {e}")
            except Exception:
                # If logging fails, at least print to stderr
                import sys

                print(f"Task cleanup error: {e}", file=sys.stderr)
