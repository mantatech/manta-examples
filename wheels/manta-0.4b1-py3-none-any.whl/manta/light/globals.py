import io
import logging
import os
from typing import AsyncIterable, Optional

import grpclib.exceptions

from ..clients.world_client import WorldClient
from ..common.build import GetGlobalRequest, SetGlobalRequest
from ..common.const import CHUNK_SIZE
from ..common.conversions import ID
from ..common.event_loop import EventLoopManager
from .utils import bytes_to_dict, dict_to_bytes

__all__ = ["Globals"]


class Globals:
    """
    Class which deals with global manipulation (getter and setter)

    Parameters
    ----------
    host : str
        Manager host
    port : int
        Manager port
    task_id : ID
        Task ID
    swarm_id : ID
        Swarm ID
    chunk_size : int
        Chunk size
    """

    __slots__ = [
        "world_client",
        "swarm_id",
        "task_id",
        "logger",
        "chunk_size",
        "_loop",
        "_loop_lock",
        "loop_manager",
    ]

    def __init__(
        self,
        world_client: Optional[WorldClient] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        swarm_id: Optional[ID] = None,
        task_id: Optional[ID] = None,
        chunk_size: int = CHUNK_SIZE,
    ):
        # Retrieve env variables for RPC host and port
        if world_client is None:
            self.world_client = WorldClient(
                host=host or os.getenv("RPC_HOST", "host.docker.internal"),
                port=int(port or os.getenv("RPC_PORT", 50051)),
            )
        else:
            self.world_client = world_client

        self.task_id: ID = task_id or ID(os.getenv("TASK_ID"))
        self.swarm_id: ID = swarm_id or ID(os.getenv("SWARM_ID"))

        self.chunk_size = chunk_size

        self.logger = logging.getLogger(__name__)

        self.loop_manager = EventLoopManager.get_instance()

    def __getitem__(self, tag: str):
        """
        Get the results of a Task

        Parameters
        ----------
        tag : str
            The tag of the result to get

        Returns
        -------
        dict
            The response from the world service

        Examples
        --------

        Inside a :class:`Task <manta_light.task.Task>` class, you can
        access globals defined by a :class:`Swarm <manta.swarm.Swarm>`
        by using the attribute :code:`self.world` automatically defined
        by :class:`Task <manta_light.task.Task>`:

        >>> weights = self.world.globals["global_model_params"]
        """
        return self.loop_manager.run_coroutine(self.async_get(tag))

    def __setitem__(self, tag: str, result: dict):
        """
        Set a result of a task

        Parameters
        ----------
        tag : str
            The tag of the result to set
        result : dict
            The result to set

        Examples
        --------

        Inside a :class:`Task <manta_light.task.Task>` class, you can
        change globals defined by a :class:`Swarm <manta.swarm.Swarm>`
        by using the attribute :code:`self.world` automatically defined
        by :class:`Task <manta_light.task.Task>`:

        >>> self.world.globals["global_model_params"] = new_weights
        """
        self.loop_manager.run_coroutine(self.async_set(tag, result))

    def __str__(self):  # pragma: no cover
        return f"Globals(host={self.world_client.host}, port={self.world_client.port}, swarm_id={self.swarm_id}, task_id={self.task_id})"

    def __repr__(self):  # pragma: no cover
        return str(self)

    # Asynchonous methods

    async def async_get(self, tag: str):
        """
        Get the results of tasks

        Parameters
        ----------
        tag : str
            The tag of the result to get

        Returns
        -------
        dict
            The response from the world service

        Examples
        --------

        Same as :meth:`__getitem__ <manta_light.globals.Globals.__getitem__>`
        but asynchronous.

        >>> weights = await self.world.globals.async_get(
        ...     "global_model_params"
        ... )
        """
        # Initialize a buffer to accumulate chunks
        buffer = io.BytesIO()

        self.logger.info(
            f"Getting global '{tag}' for task {self.task_id} and swarm {self.swarm_id}"
        )
        try:
            # Iterate over the chunks
            async for chunk in self.world_client.get_global(
                GetGlobalRequest(
                    task_id=self.task_id.oid, swarm_id=self.swarm_id.oid, tag=tag
                )
            ):
                self.logger.debug(
                    f"Received chunk for global '{tag}' of size {len(chunk.data)}"
                )
                # Append the chunk to the buffer
                buffer.write(chunk.data)

            self.logger.info(f"Successfully received all chunks for global '{tag}'")
            return bytes_to_dict(buffer.getvalue())
        except grpclib.exceptions.GRPCError as e:
            self.logger.error(
                f"GRPC error while getting global '{tag}': {e!r}", exc_info=True
            )
            raise  # Re-raise the original gRPC error
        except Exception as e:
            # This catches other potential errors, e.g., from bytes_to_dict if the stream was successful
            # but data was malformed, or other unexpected errors within this block.
            self.logger.error(
                f"Failed to process global '{tag}' after fetching: {e!r}", exc_info=True
            )
            raise

    async def chunked_global_update(
        self, request: SetGlobalRequest
    ) -> AsyncIterable[SetGlobalRequest]:
        """
        This function chunks the data into smaller pieces and yields GlobalUpdate messages.

        Parameters
        ----------
        request : SetGlobalRequest
            Set global request

        Returns
        -------
        AsyncIterable[SetGlobalRequest]
            Async iterable of SetGlobalRequest messages
        """
        data_stream = io.BytesIO(request.data)
        while chunk := data_stream.read(self.chunk_size):
            yield SetGlobalRequest(
                task_id=request.task_id,
                swarm_id=request.swarm_id,
                tag=request.tag,
                data=chunk,
            )

    async def async_set(self, tag: str, result: dict):
        """
        Set a result of a task

        Parameters
        ----------
        tag : str
            The tag of the result to set
        result : dict
            The result to set

        Examples
        --------

        Same as :meth:`__setitem__ <manta_light.globals.Globals.__setitem__>`
        but asynchronous.

        >>> await self.world.globals.async_set(
        ...     "global_model_params",
        ...     new_weights
        ... )
        """
        await self.world_client.set_global(
            self.chunked_global_update(
                SetGlobalRequest(
                    task_id=self.task_id.oid,
                    swarm_id=self.swarm_id.oid,
                    tag=tag,
                    data=dict_to_bytes(result),
                )
            )
        )
