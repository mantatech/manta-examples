"""
Unified Asynchronous User API implementation.

This module provides the unified AsyncUserAPI class that combines all functionality
from the previous user_api and cluster_api modules, using the new 4-client architecture.
"""

from collections import defaultdict
from dataclasses import asdict
from datetime import datetime
from typing import Any, AsyncIterator, Dict, List, Optional

from ..clients.cluster_management_client import ClusterManagementClient
from ..clients.module_management_client import ModuleManagementClient
from ..clients.swarm_management_client import SwarmManagementClient
from ..clients.user_management_client import UserManagementClient
from ..common.build import (
    Graph,
    LogQuery,
    ModuleRequest,
    ResultsResponse,
    SendSwarmRequest,
    Task,
)

# ClusterAPI has been removed in the refactoring
# from .cluster_api import AsyncClusterAPI, ClusterAPI
from .module import Module
from .results import Results
from .swarm import Swarm


class AsyncUserAPI:
    """
    Asynchronous User API

    Parameters
    ----------
    token : str
        The JWT token for the user
    host : str
        The host of the user servicer
    port : int
        The port of the user servicer
    cafile : Optional[str], optional
        Path to the CA certificate file for verifying the server, by default None
    certfile : Optional[str], optional
        Path to the client certificate file, by default None
    keyfile : Optional[str], optional
        Path to the client private key file, by default None

    See Also
    --------
    UserAPI : Synchronous User API
    UserServicerClient : User servicer client
    AsyncClusterAPI : Asynchronous Cluster API
    ClusterAPI : Synchronous Cluster API
    """

    __slots__ = [
        "_user_servicer_client",
        "_user_management_client",
        "_cluster_management_client",
        "_swarm_management_client",
        "_module_management_client",
    ]

    def __init__(
        self,
        token: str,
        host: str,
        port: int,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
    ):
        # Mandatory token validation
        if not token or token.strip() == "":
            raise ValueError(
                "Authentication token is required. "
                "Run 'manta sdk config init --interactive' to set up credentials."
            )

        if token.startswith("<") and token.endswith(">"):
            raise ValueError(
                "Please replace the placeholder token with your actual JWT token. "
                "Run 'manta sdk config set --token <your_jwt_token>' to update your configuration."
            )

        if len(token.strip()) < 10:
            raise ValueError(
                "Token appears to be too short for a valid JWT token. "
                "Please check your JWT token and update your configuration."
            )

        # Determine if we should use secure mode based on port (443 = HTTPS)
        # or explicit certificate configuration
        secure = port == 443 or any(
            [cafile is not None, certfile is not None, keyfile is not None]
        )

        # Initialize the different service clients for the new architecture
        self._user_management_client = UserManagementClient(
            host=host,
            port=port,
            jwt_token=token,
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )
        self._cluster_management_client = ClusterManagementClient(
            host=host,
            port=port,
            jwt_token=token,
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )
        self._swarm_management_client = SwarmManagementClient(
            host=host,
            port=port,
            jwt_token=token,
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )
        self._module_management_client = ModuleManagementClient(
            host=host,
            port=port,
            jwt_token=token,
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )
        # For backward compatibility, keep a reference to the main client
        self._user_servicer_client = self._user_management_client

    @classmethod
    async def sign_in(
        cls,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 50051,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
    ) -> "AsyncUserAPI":
        """
        Sign in and create an authenticated AsyncUserAPI instance.

        Parameters
        ----------
        username : str
            Username for authentication
        password : str
            Password for authentication
        host : str, optional
            The host of the user servicer, by default "localhost"
        port : int, optional
            The port of the user servicer, by default 50051
        cafile : Optional[str], optional
            Path to the CA certificate file for verifying the server, by default None
        certfile : Optional[str], optional
            Path to the client certificate file, by default None
        keyfile : Optional[str], optional
            Path to the client private key file, by default None

        Returns
        -------
        AsyncUserAPI
            An authenticated AsyncUserAPI instance with JWT token configured

        Raises
        ------
        Exception
            If authentication fails

        Examples
        --------
        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> user_info = await api.get_user()
        """
        # Determine if we should use secure mode based on port (443 = HTTPS)
        # or explicit certificate configuration
        secure = port == 443 or any(
            [cafile is not None, certfile is not None, keyfile is not None]
        )

        # Create a temporary client for authentication (no token required for sign_in)
        temp_client = UserManagementClient(
            host=host,
            port=port,
            jwt_token=None,  # No token needed for sign_in
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )

        # Authenticate and get the user with JWT token
        user_response = await temp_client.sign_in(username, password)

        # Extract the JWT token from the response
        jwt_token = user_response.token

        # Create and return a new AsyncUserAPI instance with the token
        return cls(
            token=jwt_token,
            host=host,
            port=port,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )

    async def is_available(self) -> bool:
        """
        Check if the User service is available.

        Returns
        -------
        bool
            Service availability status
        """
        try:
            await self._user_management_client.is_available()
            await self._cluster_management_client.is_available()
            await self._swarm_management_client.is_available()
            await self._module_management_client.is_available()
            return True
        except Exception:
            return False

    async def get_user(self) -> Dict[str, Any]:
        """
        Get the currently authenticated user's details.

        Returns
        -------
        Dict[str, Any]
            User details for the authenticated user.
        """
        response = await self._user_management_client.get_user()
        return asdict(response)

    async def list_cluster_ids(self) -> List[str]:
        """
        List all cluster IDs for the authenticated user.
        """
        response = await self._cluster_management_client.list_cluster_ids()
        return response.ids

    async def stream_clusters(self) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream all clusters for the authenticated user.
        """
        async for cluster in self._cluster_management_client.stream_clusters():
            yield asdict(cluster)

    async def stream_and_fetch_clusters(self) -> List[Dict[str, Any]]:
        """
        Stream all clusters for the authenticated user and fetch them.
        """
        clusters = []
        async for cluster in self._cluster_management_client.stream_clusters():
            clusters.append(asdict(cluster))
        return clusters

    async def get_cluster(self, cluster_id: str) -> dict:
        """
        Get cluster info

        Parameters
        ----------
        cluster_id : str
            ID of the cluster

        Returns
        -------
        dict
            Cluster Info
        """
        cluster = await self._cluster_management_client.get_cluster(cluster_id)
        return asdict(cluster)

    async def list_module_ids(self) -> List[str]:
        """
        List all module IDs for the authenticated user.

        Returns
        -------
        List[str]
            List of module IDs
        """
        response = await self._module_management_client.list_module_ids()
        return response.ids

    async def stream_modules(self) -> AsyncIterator[Module]:
        """
        Stream all modules for the authenticated user.

        Returns
        -------
        AsyncIterator[Module]
            Stream of Module objects
        """
        async for module_request in self._module_management_client.stream_modules():
            yield Module.from_proto(module_request.module)

    async def stream_and_fetch_modules(self) -> List[Module]:
        """
        Stream all modules for the authenticated user and fetch them.

        Returns
        -------
        List[Module]
            List of Module objects
        """
        modules = []
        async for module in self.stream_modules():
            modules.append(asdict(module))
        return modules

    async def get_module(self, module_id: str) -> Module:
        """
        Get a module by its ID.

        Parameters
        ----------
        module_id : str
            ID of the module

        Returns
        -------
        Module
            Module object
        """
        module_request = await self._module_management_client.get_module(module_id)
        return Module.from_proto(module_request.module)

    async def send_module(self, module: Module) -> str:
        """
        Send/create a new module.

        Parameters
        ----------
        module : Module
            Module object to create

        Returns
        -------
        str
            Module ID
        """
        # Convert Module to protobuf using its to_proto method
        module_proto = module.to_proto()

        response = await self._module_management_client.send_module(module_proto)
        return response.id

    async def update_module(self, module: Module, module_id: str) -> str:
        """
        Update an existing module.

        Parameters
        ----------
        module : Module
            Module object with updated data
        module_id : str
            ID of the module to update

        Returns
        -------
        str
            Module ID
        """
        # Convert Module to protobuf using its to_proto method
        module_proto = module.to_proto()

        # Create ModuleRequest
        module_request = ModuleRequest(module=module_proto, module_id=module_id)

        response = await self._module_management_client.update_module(module_request)
        return response.id

    async def remove_module(self, module_id: str) -> str:
        """
        Remove a module by its ID.

        Parameters
        ----------
        module_id : str
            ID of the module to remove

        Returns
        -------
        str
            Response message confirming removal
        """
        response = await self._module_management_client.remove_module(module_id)
        return response.message

    async def list_swarm_ids(self) -> List[str]:
        """
        List all swarm IDs for the authenticated user.

        Returns:
        -------
        List[str]:
            List of Swarm IDs
        """
        response = await self._swarm_management_client.list_swarm_ids()
        return response.ids

    async def stream_swarms(self) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream all swarms for the authenticated user.

        Returns:
        -------
        AsyncIterator[Dict[str, Any]]:
            Swarms info
        """
        async for swarm in self._swarm_management_client.stream_swarms():
            yield asdict(swarm)

    async def stream_and_fetch_swarms(self) -> List[Dict[str, Any]]:
        """
        Stream all swarms for the authenticated user and fetch them.

        Returns:
        -------
        List[Dict[str, Any]]:
            Swarms info
        """
        swarms = []
        async for swarm in self.stream_swarms():
            swarms.append(swarm)
        return swarms

    async def get_swarm(self, swarm_id: str) -> Dict[str, Any]:
        """
        Get a swarm by its ID.

        Parameters
        ----------
        swarm_id : str
            ID of the swarm

        Returns
        -------
        Dict[str, Any]
            Swarm details
        """
        response = await self._swarm_management_client.get_swarm(swarm_id)
        return asdict(response)

    async def stream_swarm_tasks(self, swarm_id: str) -> AsyncIterator[Dict[str, Any]]:
        """
        Get all tasks for a swarm by its ID.

        Parameters
        ----------
        swarm_id : str
            ID of the swarm

        Returns
        -------
        AsyncIterator[Dict[str, Any]]
            Stream of task details
        """
        async for task in self._swarm_management_client.stream_swarm_tasks(swarm_id):
            yield asdict(task)

    async def stream_and_fetch_tasks(self, swarm_id: str) -> List[Dict[str, Any]]:
        """
        Stream all tasks for a swarm by its ID and fetch them.

        Parameters
        ----------
        swarm_id : str
            ID of the swarm

        Returns
        -------
        List[Dict[str, Any]]
            List of task details
        """
        tasks = []
        async for task in self.stream_swarm_tasks(swarm_id):
            tasks.append(task)
        return tasks

    async def get_tasks(self, swarm_id: str) -> List[Dict[str, Any]]:
        """
        Get all tasks for a swarm by its ID.

        Parameters
        ----------
        swarm_id : str
            ID of the swarm

        Returns
        -------
        List[Dict[str, Any]]
            List of task details
        """
        return await self.stream_and_fetch_tasks(swarm_id)

    async def send_swarm(self, cluster_id: str, swarm: Swarm) -> Dict[str, Any]:
        """
        Send a Swarm to the server to be inserted into its database

        Parameters
        ----------
        swarm : Swarm
            Any class which inherit from the :code:`Swarm` class

        Returns
        -------
        Dict[str, Any]
            Swarm overview

        Examples
        --------

        >>> swarm = FLSwarm()
        >>> swarm_overview = await user_api.send_swarm(cluster_id, swarm)
        {'swarm_id': '9415dfd18edc45c9a6ffdf2055007bf9', 'status': 'ACTIVE', 'datetime': '2024-09-13 10:18:06'}

        Notes
        -----

        The argument :code:`service` is managed by a decorator under the hood.
        """
        # Get the graph with full Module objects
        graph_dicts = swarm.prepare_graph()

        # Extract unique modules and send them to get module_ids
        for task_dict in graph_dicts:
            module = task_dict.pop("module")
            # Convert to protobuf Module using the module's to_proto method
            module_proto = module.to_proto()
            # Send module and get its ID
            module_id_response = await self._module_management_client.send_module(
                module_proto
            )
            task_dict["module_id"] = module_id_response.id

        # Convert task dicts to Task protobuf objects
        tasks = []
        for task_dict in graph_dicts:
            task = Task(
                task_id=task_dict["task_id"],
                scheduling=task_dict[
                    "scheduling"
                ],  # Already converted by scheduling.to_proto()
                module_id=task_dict["module_id"],
                previous_tasks=task_dict["previous_tasks"],
                next_tasks=task_dict["next_tasks"],
                conditions=task_dict["conditions"],
                order=task_dict.get("order", 0),
                network=task_dict.get("network", ""),
                alias=task_dict["alias"],
            )
            tasks.append(task)

        graph = Graph(tasks=tasks)
        request = SendSwarmRequest(graph=graph, name=swarm.name, cluster_id=cluster_id)
        swarm_overview = await self._swarm_management_client.send_swarm(request)

        for global_chunks in swarm.prepare_globals(swarm_overview.swarm_id):

            async def async_generator():
                for global_chunk in global_chunks:
                    yield global_chunk

            await self._swarm_management_client.initialize_global(async_generator())

        networks = swarm.prepare_networks(swarm_overview.swarm_id)
        await self._swarm_management_client.initialize_networks(networks)

        return asdict(swarm_overview)

    async def start_swarm(self, swarm_id: str) -> str:
        """
        Start a Swarm given its ID if it is found in the database

        Parameters
        ----------
        swarm_id : str
            Swarm ID

        Returns
        -------
        str
            Response of the server

        Examples
        --------

        >>> swarm_id = '9415dfd18edc45c9a6ffdf2055007bf9'
        >>> await user_api.start_swarm(swarm_id)
        'Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has started.'

        Notes
        -----

        The argument :code:`service` is managed by a decorator under the hood.
        """
        response = await self._swarm_management_client.start_swarm(swarm_id)
        return response.message

    async def deploy_swarm(self, cluster_id: str, swarm: Swarm) -> Dict[str, Any]:
        """
        Deploy a Swarm

        Parameters
        ----------
        cluster_id : str
            Cluster ID
        swarm : Swarm
            Any class which inherit from the :code:`Swarm` class

        Returns
        -------
        Dict[str, Any]
            Swarm overview

        Examples
        --------

        >>> swarm = FLSwarm()
        >>> swarm_overview = await user_api.deploy_swarm(swarm)
        {'swarm_id': '9415dfd18edc45c9a6ffdf2055007bf9', 'status': 'ACTIVE', 'datetime': '2024-09-13 10:18:06'}

        Notes
        -----

        The argument :code:`service` is managed by a decorator under the hood.
        """
        swarm_dict = await self.send_swarm(cluster_id, swarm)
        await self.start_swarm(swarm_dict["swarm_id"])
        swarm_dict = await self.get_swarm(swarm_dict["swarm_id"])
        return swarm_dict

    async def stop_swarm(self, swarm_id: str, force: bool = False) -> str:
        """
        Stop a Swarm given its ID if it is found in the database

        Parameters
        ----------
        swarm_id : str
            Swarm ID
        force : bool
            Force the stop of all the running tasks

        Returns
        -------
        str
            Response of the server

        Examples
        --------

        >>> swarm_id = '9415dfd18edc45c9a6ffdf2055007bf9'
        >>> await user_api.stop_swarm(swarm_id)
        'Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has stopped.'

        Notes
        -----

        The argument :code:`service` is managed by a decorator under the hood.
        """
        response = await self._swarm_management_client.stop_swarm(
            swarm_id, force, False
        )
        return response.message

    async def remove_swarm(self, swarm_id: str) -> str:
        """
        Remove a swarm on the cluster

        Parameters
        ----------
        swarm_id : str
            Id of the swarm

        Returns
        -------
        str
            Response of the server

        Examples
        --------

        >>> swarm_id = '9415dfd18edc45c9a6ffdf2055007bf9'
        >>> await user_api.remove_swarm(swarm_id)
        '9415dfd18edc45c9a6ffdf2055007bf9 deleted.'

        Notes
        -----

        The argument :code:`service` is managed by a decorator under the hood.
        """
        response = await self._swarm_management_client.remove_swarm(swarm_id)
        return response.message

    async def select_tasks(self, cluster_id: str, node_id: str) -> List[Dict[str, Any]]:
        """
        Select tasks given node ID.
        Tasks are sorted by progression of the swarm from the end
        to the beginning.

        Parameters
        ----------
        service : UserStub
            Service to connect to the gRPC server (**not required**)
        node_id : str
            Node ID

        Returns
        -------
        List[Dict[str, Any]]
            List of several informations containing tasks

        Examples
        --------

        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> await user_api.select_tasks(cluster_id, node_id)
        [{'task_id': 'adcc83a14d8642bbb6413d196fb0b5b8', 'swarm_id': '435709c73c5344c5a3d5754c7eb2ab6d', 'status': ...}, ...]

        .. warning::

            The server is not returning the payloads in the response.
            Ask the Manta team to add this feature.
        """
        return [
            asdict(response)
            async for response in self._cluster_management_client.select_tasks(
                cluster_id, node_id
            )
        ]

    async def collect_errors(
        self,
        cluster_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: Optional[int] = None,
        sort_order: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Collect errors from a node

        Parameters
        ----------
        cluster_id: str
            Cluster ID
        start_time : Optional[datetime]
            Start time
        end_time : Optional[datetime]
            End time
        limit : Optional[int]
            Limit
        sort_order : Optional[str]
            Sort order

        Returns
        -------
        List[Dict[str, Any]]
            List of several informations containing errors

        Examples
        --------

        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> await user_api.collect_errors(cluster_id, node_id)
        [{'error_id': '1234567890', 'error_message': 'Error message', 'datetime': '2024-09-13 10:18:06'}, ...]
        """
        return [
            asdict(response)
            async for response in self._cluster_management_client.collect_errors(
                cluster_id,
                start_time,
                end_time,
                limit,
                sort_order,
            )
        ]

    async def stop_node(self, cluster_id: str, node_id: str) -> str:
        """
        Stop a node given its ID

        Parameters
        ----------
        cluster_id: str
            ID of the cluster
        node_id : str
            ID of the node to stop

        Returns
        -------
        str
            Response of the server

        Examples
        --------

        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> await user_api.stop_node(cluster_id, node_id)
        """
        response = await self._cluster_management_client.stop_node(cluster_id, node_id)
        return response.message

    async def remove_node(self, cluster_id: str, node_id: str) -> str:
        """
        Remove a node from the cluster

        Parameters
        ----------
        cluster_id: str
            ID of the cluster
        node_id : str
            ID of the node to remove

        Returns
        -------
        str
            Message of the server

        Examples
        --------

        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> await cluster.remove_node(cluster_id, node_id)
        'Node a2ff3abc76e045d7bb4a04a5ac416318 has been removed from the cluster.'
        """
        response = await self._cluster_management_client.remove_node(
            cluster_id, node_id
        )
        return response.message

    async def list_node_ids(
        self, cluster_id: str, available: bool = False
    ) -> List[str]:
        """
        Get node IDs

        Parameters
        ----------
        cluster_id: str
            ID of the cluster
        available : bool
            Get only available nodes

        Returns
        -------
        List[str]
            List of node IDs

        Examples
        --------

        >>> await cluster.get_node_ids(cluster_id, available=True)
        ['a2ff3abc76e045d7bb4a04a5ac416318', 'f8a7c1d7f9d44f6b9d0d3d5d9c7b3c9d']
        """
        if available:
            collection_ids = (
                await self._cluster_management_client.list_available_node_ids(
                    cluster_id
                )
            )
        else:
            collection_ids = await self._cluster_management_client.list_node_ids(
                cluster_id
            )
        return [node_id for node_id in collection_ids.ids]

    async def stream_nodes(self, cluster_id: str) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream all nodes in the cluster.

        Returns
        -------
        AsyncIterator[Dict[str, Any]]
            Stream of nodes

        Examples
        --------

        >>> async for node in user_api.stream_nodes(cluster_id):
        ...     print(node)
        {'node_id': 'a2ff3abc76e045d7bb4a04a5ac416318', 'resources': {'cpu': 1, 'memory': 1024, 'disk': 1024}, ...}, ...]
        """
        async for node in self._cluster_management_client.stream_nodes(cluster_id):
            yield asdict(node)

    async def stream_and_fetch_nodes(self, cluster_id: str) -> List[Dict[str, Any]]:
        """
        Stream all nodes in the cluster and fetch their resources.

        Returns
        -------
        List[Dict[str, Any]]
            List of nodes

        Examples
        --------

        >>> cluster = AsyncCluster(user_client, cluster_id)
        >>> cluster.stream_and_fetch_nodes()
        [{'node_id': 'a2ff3abc76e045d7bb4a04a5ac416318', 'resources': {'cpu': 1, 'memory': 1024, 'disk': 1024}, ...}, ...]
        """
        nodes = []
        async for node in self._cluster_management_client.stream_nodes(cluster_id):
            nodes.append(asdict(node))
        return nodes

    async def get_node(self, cluster_id: str, node_id: str) -> Dict[str, Any]:
        """
        Get a node by its ID.

        Parameters
        ----------
        node_id : str
            Node ID

        Returns
        -------
        Dict[str, Any]
            Node details

        Examples
        --------

        >>> cluster = AsyncCluster(user_client, cluster_id)
        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> cluster.get_node(node_id)
        {'node_id': 'a2ff3abc76e045d7bb4a04a5ac416318', 'resources': {'cpu': 1, 'memory': 1024, 'disk': 1024}, ...}
        """
        node = await self._cluster_management_client.get_node(cluster_id, node_id)
        return asdict(node)

    async def stream_node_resources(
        self, cluster_id: str, node_id: str
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream node resources for a specific node.

        Parameters
        ----------
        node_id : str
            Node ID

        Returns
        -------
        AsyncIterator[Dict[str, Any]]
            Stream of node resources

        Examples
        --------

        >>> cluster = AsyncCluster(user_client, cluster_id)
        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> async for resource in cluster.stream_node_resources(node_id):
        ...     print(resource)
        {'cpu': 1, 'memory': 1024, 'disk': 1024}, ...]
        """
        async for resource in self._cluster_management_client.stream_node_resources(
            cluster_id, node_id
        ):
            yield asdict(resource)

    async def get_node_resources(self, cluster_id: str, node_id: str) -> Dict[str, Any]:
        """
        Get node resources for a specific node.

        Parameters
        ----------
        cluster_id : str
            Cluster ID
        node_id : str
            Node ID

        Returns
        -------
        Dict[str, Any]
            Node resources

        Examples
        --------
        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> await user_api.get_node_resources(cluster_id, node_id)
        {'cpu': 1, 'memory': 1024, 'disk': 1024}
        """
        node_resources = await self._cluster_management_client.get_node_resources(
            cluster_id, node_id
        )
        return asdict(node_resources)

    async def stream_results(
        self, swarm_id: str, tag: str
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream results for a specific swarm.

        Parameters
        ----------
        swarm_id : str
            Swarm ID
        tag : str
            Tag

        Returns
        -------
        AsyncIterator[Dict[str, Any]]
            Stream of results
        """
        async for result in self._swarm_management_client.stream_results(swarm_id, tag):
            yield asdict(result)

    async def select_results(self, swarm_id: str, tag: str) -> Dict[str, Results]:
        """
        Select results from the database given the queries

        Parameters
        ----------
        swarm_id: str
            Swarm ID
        tag: str
            Tag

        Returns
        -------
        Dict[str, Results]
            Dictionary of :code:`(swarm_id, results)`

        Examples
        --------

        >>> cluster = AsyncCluster("localhost", 50051)
        >>> swarm_id = '9415dfd18edc45c9a6ffdf2055007bf9'
        >>> tags = ["accuracy", "loss"]
        >>> await cluster.select_results((swarm_id, tags))
        {'9415dfd18edc45c9a6ffdf2055007bf9': Results(len(iteration)=10, len(nodes)=8, len(tags)=2)}

        Notes
        -----

        The argument :code:`service` is managed by a decorator under the hood.
        """

        def sort_and_group(iterable) -> List[Dict[str, Dict[str, Any]]]:
            iter_dict = defaultdict(lambda: defaultdict(dict))
            for result in iterable:
                iter_dict[result.iteration][result.node_id][result.tag] = result.data
            return [iter_dict[i] for i in range(len(iter_dict))]

        results = []
        async for response in self._swarm_management_client.select_results(
            swarm_id, tag
        ):
            results.append(response)

        return {swarm_id: Results(sort_and_group(results))}

    async def delete_results(
        self,
        swarm_id: str,
        tag: str,
        node_id: Optional[str] = None,
        task_id: Optional[str] = None,
        iteration: Optional[int] = None,
    ) -> str:
        """
        Delete results for a specific swarm and tag.

        Parameters
        ----------
        swarm_id : str
            Swarm ID
        tag : str
            Tag of the results to delete
        node_id : str, optional
            Filter by node ID
        task_id : str, optional
            Filter by task ID
        iteration : int, optional
            Filter by iteration number

        Returns
        -------
        str
            Deletion confirmation message
        """
        response = await self._swarm_management_client.delete_results(
            swarm_id=swarm_id,
            tag=tag,
            node_id=node_id,
            task_id=task_id,
            iteration=iteration,
        )
        return response.message

    async def select_results_stream(
        self, swarm_id: str, tag: str
    ) -> AsyncIterator[ResultsResponse]:
        """
        Select results from the database given the queries

        Parameters
        ----------
        swarm_id: str
            Swarm ID
        tag: str
            Tag

        Returns
        -------
        AsyncIterator[ResultsResponse]
            Stream of results
        """
        async for response in self._swarm_management_client.select_results(
            swarm_id, tag
        ):
            yield response

    async def collect_logs(
        self,
        swarm_id: str,
        node_ids: Optional[List[str]] = None,
        task_ids: Optional[List[str]] = None,
        iteration: Optional[int] = None,
        circular: Optional[int] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        severity: Optional[List[str]] = None,
        limit: Optional[int] = None,
        sort_order: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Collect the logs stored in the :code:`Manager` database
        with optional filtering parameters

        Parameters
        ----------
        swarm_id : str
            Swarm ID
        node_ids : List[str]
            Node IDs
        task_ids : List[str]
            Task IDs
        iteration : int
            Iteration
        circular : int
            Circular
        start_time : int
            Start time
        end_time : int
            End time
        severity : List[str]
            Severity
        limit : int
            Limit
        sort_order : str
            Sort order ("asc" or "desc")

        Returns
        -------
        List[Dict[str, Any]]
            List of several informations containing logs

        Examples
        --------

        >>> cluster = AsyncCluster("localhost", 50051)
        >>> swarm_id = '9415dfd18edc45c9a6ffdf2055007bf9'
        >>> cluster.collect_logs(swarm_id)
        [{'swarm_id': '9415dfd18edc45c9a6ffdf2055007bf9', 'task_id': 'a2ff3abc76e045d7bb4a04a5ac416318', 'message': ..., 'datetime': '2024-09-13 10:18:06', 'iteration': '1'}, ...]

        Notes
        -----
        The argument :code:`service` is managed by a decorator under the hood.
        """
        # Create LogQuery object with the requested ID and other optional parameters
        query = LogQuery()
        if iteration:
            query.iteration = iteration
        if circular:
            query.circular = circular
        if start_time:
            query.start_time = start_time
        if end_time:
            query.end_time = end_time
        if severity:
            query.severity = severity
        if limit:
            query.limit = limit
        if sort_order:
            query.sort_order = sort_order

        # Start the streaming request
        stream = self._swarm_management_client.collect_logs(
            swarm_id=swarm_id,
            node_ids=node_ids,
            task_ids=task_ids,
            severity=severity,
            start_time=start_time,
            end_time=end_time,
            limit=limit,
            sort_order=sort_order,
            iteration=iteration,
            circular=circular,
        )

        # Process the stream of LogResponse objects
        log_entries = {}  # Dictionary to collect log parts by their unique ID

        async for response in stream:
            # Create a unique key for each log entry based on its metadata
            entry_key = (
                response.swarm_id if response.swarm_id else None,
                response.node_id if response.node_id else None,
                response.task_id if response.task_id else None,
                response.iteration,
                response.circular,
                response.timestamp,
            )

            # Initialize the log entry if it's the first chunk
            if entry_key not in log_entries:
                log_entries[entry_key] = {
                    "swarm_id": response.swarm_id if response.swarm_id else None,
                    "node_id": response.node_id if response.node_id else None,
                    "task_id": response.task_id if response.task_id else None,
                    "alias": response.alias,
                    "module_id": response.module_id,
                    "iteration": response.iteration,
                    "circular": response.circular,
                    "timestamp": response.timestamp,
                    "severity": response.severity,
                    "content": bytearray(),
                }

            # Append the content chunk to existing content
            log_entries[entry_key]["content"].extend(response.content)

        # Convert all content byte arrays to strings and prepare the final result
        result = []
        for entry in log_entries.values():
            # Convert binary content to string
            if entry["content"]:
                entry["message"] = entry["content"].decode("utf-8")
            else:
                entry["message"] = ""

            # Remove the binary content to avoid duplicating data
            del entry["content"]

            # Add to result list
            result.append(entry)

        return result

    async def stream_logs(self, swarm_id: str) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream logs for a specific swarm.

        Parameters
        ----------
        swarm_id : str
            Swarm ID

        Returns
        -------
        AsyncIterator[Dict[str, Any]]
            Stream of log entries
        """
        async for log in self._swarm_management_client.stream_logs(swarm_id):
            yield asdict(log)

    async def list_result_tags(self, swarm_id: str) -> Dict[str, Any]:
        """
        List result tags for a specific swarm.

        Parameters
        ----------
        swarm_id : str
            The swarm ID

        Returns
        -------
        Dict[str, Any]
            Tags with usage information
        """
        tags = await self._swarm_management_client.list_result_tags(swarm_id)
        return asdict(tags)

    async def list_global_tags(self, swarm_id: str) -> Dict[str, Any]:
        """
        List global tags for a specific swarm.

        Parameters
        ----------
        swarm_id : str
            The swarm ID

        Returns
        -------
        Dict[str, Any]
            Tags with usage information
        """
        tags = await self._swarm_management_client.list_global_tags(swarm_id)
        return asdict(tags)

    async def select_global(
        self, swarm_id: str, tag: str
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Select global data for a specific swarm and tag.

        Parameters
        ----------
        swarm_id : str
            The swarm ID
        tag : str
            The tag

        Returns
        -------
        AsyncIterator[Dict[str, Any]]
            Stream of global data
        """
        async for result in self._swarm_management_client.select_global(swarm_id, tag):
            yield asdict(result)
