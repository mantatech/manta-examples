"""
Unified Asynchronous User API implementation.

This module provides the unified AsyncUserAPI class that combines all functionality
from the previous user_api and cluster_api modules, using the new 4-client architecture.
"""

import asyncio
from collections import defaultdict
from dataclasses import asdict
from datetime import datetime
from logging import getLogger
from typing import Any, AsyncIterator, Dict, List, Optional

from ..clients.cluster_management_client import ClusterManagementClient
from ..clients.module_management_client import ModuleManagementClient
from ..clients.swarm_management_client import SwarmManagementClient
from ..clients.user_management_client import UserManagementClient
from ..common.build import (
    Cluster,
    Error,
    Graph,
    LogQuery,
    LogResponse,
    MetricsSnapshot,
    ModuleRequest,
    Node,
    ResultsResponse,
    SelectGlobalResponse,
    SendSwarmRequest,
)
from ..common.build import Swarm as SwarmProto
from ..common.build import Tags, Task, TaskResponse, User
from ..common.conversions import ID

# ClusterAPI has been removed in the refactoring
# from .cluster_api import AsyncClusterAPI, ClusterAPI
from .module import Module
from .results import Results
from .swarm import Swarm


class AsyncUserAPI:
    """
    Asynchronous User API

    Parameters
    ----------
    token : str
        The JWT token for the user
    host : str
        The host of the user servicer
    port : int
        The port of the user servicer
    cafile : Optional[str], optional
        Path to the CA certificate file for verifying the server, by default None
    certfile : Optional[str], optional
        Path to the client certificate file, by default None
    keyfile : Optional[str], optional
        Path to the client private key file, by default None

    See Also
    --------
    UserAPI : Synchronous User API
    UserServicerClient : User servicer client
    AsyncClusterAPI : Asynchronous Cluster API
    ClusterAPI : Synchronous Cluster API
    """

    __slots__ = [
        "_token",
        "_user_management_client",
        "_cluster_management_client",
        "_swarm_management_client",
        "_module_management_client",
        "logger",
    ]

    def __init__(
        self,
        token: str,
        host: str,
        port: int,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
    ):
        # Mandatory token validation
        if not token or token.strip() == "":
            raise ValueError(
                "Authentication token is required. "
                "Run 'manta sdk config init --interactive' to set up credentials."
            )

        if token.startswith("<") and token.endswith(">"):
            raise ValueError(
                "Please replace the placeholder token with your actual JWT token. "
                "Run 'manta sdk config set --token <your_jwt_token>' to update your configuration."
            )

        if len(token.strip()) < 10:
            raise ValueError(
                "Token appears to be too short for a valid JWT token. "
                "Please check your JWT token and update your configuration."
            )

        # Determine if we should use secure mode based on port (443 = HTTPS)
        # or explicit certificate configuration
        secure = port == 443 or any(
            [cafile is not None, certfile is not None, keyfile is not None]
        )

        # Store the JWT token for external access
        self._token = token

        # Initialize the different service clients for the new architecture
        self._user_management_client = UserManagementClient(
            host=host,
            port=port,
            jwt_token=token,
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )
        self._cluster_management_client = ClusterManagementClient(
            host=host,
            port=port,
            jwt_token=token,
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )
        self._swarm_management_client = SwarmManagementClient(
            host=host,
            port=port,
            jwt_token=token,
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )
        self._module_management_client = ModuleManagementClient(
            host=host,
            port=port,
            jwt_token=token,
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )

        # Initialize the tracer
        self.logger = getLogger()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - disconnect all clients."""
        await self.disconnect()

    async def disconnect(self):
        """
        Disconnect all gRPC clients to clean up resources.

        This method should be called when done using the AsyncUserAPI instance
        to properly close all gRPC connections and prevent resource leaks.

        Examples
        --------
        Manual disconnect:
        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> # ... use api ...
        >>> await api.disconnect()

        Or use as async context manager (recommended):
        >>> async with await AsyncUserAPI.sign_in("user@example.com", "password") as api:
        ...     # ... use api ...
        ...     pass  # automatic disconnect
        """
        # Disconnect all management clients with timeout protection
        clients = [
            self._user_management_client,
            self._cluster_management_client,
            self._swarm_management_client,
            self._module_management_client,
        ]

        # Set timeout for each client disconnect (1 second per client)
        disconnect_timeout = 1.0

        for client in clients:
            try:
                await asyncio.wait_for(client.disconnect(), timeout=disconnect_timeout)
            except asyncio.TimeoutError:
                self.logger.warning(
                    f"{client.__class__.__name__} disconnect timed out after {disconnect_timeout}s"
                )
            except Exception as e:
                # Silently ignore other disconnect errors
                self.logger.debug(
                    f"Error disconnecting {client.__class__.__name__}: {e}"
                )

    @property
    def token(self) -> str:
        """
        Get the JWT token used for authentication.

        Returns
        -------
        str
            The JWT authentication token
        """
        return self._token

    @classmethod
    async def register(
        cls,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 50051,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
    ) -> "AsyncUserAPI":
        """
        Register a new user and create an authenticated AsyncUserAPI instance.

        This method completes the registration for a pre-registered user by setting
        their password, then automatically signs them in and returns an authenticated
        API instance.

        Parameters
        ----------
        username : str
            Username for registration (must be pre-registered by admin)
        password : str
            Password to set for the user
        host : str, optional
            The host of the user servicer, by default "localhost"
        port : int, optional
            The port of the user servicer, by default 50051
        cafile : Optional[str], optional
            Path to the CA certificate file for verifying the server, by default None
        certfile : Optional[str], optional
            Path to the client certificate file, by default None
        keyfile : Optional[str], optional
            Path to the client private key file, by default None

        Returns
        -------
        AsyncUserAPI
            An authenticated AsyncUserAPI instance with JWT token configured

        Raises
        ------
        Exception
            If registration or authentication fails

        Examples
        --------
        >>> api = await AsyncUserAPI.register("user@example.com", "password")
        >>> user_info = await api.get_user()

        Notes
        -----
        The user must be pre-registered by an admin before calling this method.
        This method completes the registration by setting the password, then
        automatically signs in the user.
        """
        # Determine if we should use secure mode based on port (443 = HTTPS)
        # or explicit certificate configuration
        secure = port == 443 or any(
            [cafile is not None, certfile is not None, keyfile is not None]
        )

        # Create a temporary client for registration (no token required)
        temp_client = UserManagementClient(
            host=host,
            port=port,
            jwt_token=None,  # No token needed for register_user
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )

        # Complete registration by setting password
        await temp_client.register_user(username, password)

        # Now sign in to get JWT token
        user_response = await temp_client.sign_in(username, password)

        # Extract the JWT token from the response
        if user_response.token is None:
            raise ValueError("Token not returned by the Manager")

        # Create and return a new AsyncUserAPI instance with the token
        return cls(
            token=user_response.token,
            host=host,
            port=port,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )

    @classmethod
    async def sign_in(
        cls,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 50051,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
    ) -> "AsyncUserAPI":
        """
        Sign in and create an authenticated AsyncUserAPI instance.

        Parameters
        ----------
        username : str
            Username for authentication
        password : str
            Password for authentication
        host : str, optional
            The host of the user servicer, by default "localhost"
        port : int, optional
            The port of the user servicer, by default 50051
        cafile : Optional[str], optional
            Path to the CA certificate file for verifying the server, by default None
        certfile : Optional[str], optional
            Path to the client certificate file, by default None
        keyfile : Optional[str], optional
            Path to the client private key file, by default None

        Returns
        -------
        AsyncUserAPI
            An authenticated AsyncUserAPI instance with JWT token configured

        Raises
        ------
        Exception
            If authentication fails

        Examples
        --------
        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> user_info = await api.get_user()
        """
        # Determine if we should use secure mode based on port (443 = HTTPS)
        # or explicit certificate configuration
        secure = port == 443 or any(
            [cafile is not None, certfile is not None, keyfile is not None]
        )

        # Create a temporary client for authentication (no token required for sign_in)
        temp_client = UserManagementClient(
            host=host,
            port=port,
            jwt_token=None,  # No token needed for sign_in
            secure=secure,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )

        # Authenticate and get the user with JWT token
        user_response = await temp_client.sign_in(username, password)

        await temp_client.disconnect()

        # Extract the JWT token from the response
        if user_response.token is None:
            raise ValueError("Token not returned by the Manager")

        # Create and return a new AsyncUserAPI instance with the token
        return cls(
            token=user_response.token,
            host=host,
            port=port,
            cafile=cafile,
            certfile=certfile,
            keyfile=keyfile,
        )

    async def is_available(self) -> bool:
        """
        Check if all Manta platform services are available and responding.

        This method performs health checks on all four management services
        (User, Cluster, Swarm, Module) to verify the platform is operational.

        Returns
        -------
        bool
            True if all services are available, False otherwise

        Examples
        --------
        Check service availability before operations:
        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> if await api.is_available():
        ...     print("Platform is ready")
        ...     # Proceed with operations
        ... else:
        ...     print("Platform is unavailable")
        True

        Use for connection troubleshooting:
        >>> try:
        ...     available = await api.is_available()
        ...     if not available:
        ...         print("Services are down, check network/configuration")
        ... except Exception as e:
        ...     print(f"Connection error: {e}")

        Notes
        -----
        - This method does not raise exceptions, returns False on any error
        - Checks all four service endpoints: user, cluster, swarm, module management
        - Use this to validate configuration before deployment operations

        See Also
        --------
        disconnect : Close all service connections
        """
        try:
            await self._user_management_client.is_available()
            await self._cluster_management_client.is_available()
            await self._swarm_management_client.is_available()
            await self._module_management_client.is_available()
            return True
        except Exception:
            return False

    async def get_user(self) -> User:
        """
        Get the currently authenticated user's details and authorization.

        Retrieves complete user information including account details, permissions,
        and resource quotas for the authenticated user.

        Returns
        -------
        User
            User protobuf object containing:
            - user_id (str): Unique user identifier
            - username (str): Username/email
            - email (str): User email address
            - admin (bool): Admin status
            - status (str): Account status (ACTIVE/INACTIVE/SUSPENDED)
            - authorization (UserAuthorization): Permissions and quotas
              - permissions (List[Permission]): Resource-specific permissions
              - quotas (Quotas): Resource limits and current usage
            - created_at (datetime): Account creation timestamp
            - last_login (datetime): Last login timestamp

        Examples
        --------
        Get user details:
        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> user = await api.get_user()
        >>> print(f"User ID: {user.user_id}")
        >>> print(f"Username: {user.username}")
        >>> print(f"Admin: {user.admin}")
        User ID: a6afeb73446e409aafc8f8af10eadb0f
        Username: user@example.com
        Admin: False

        Check quota usage:
        >>> user = await api.get_user()
        >>> quotas = user.authorization.quotas
        >>> print(f"Clusters: {quotas.current_clusters}/{quotas.max_clusters}")
        >>> print(f"Storage: {quotas.current_storage_gb:.2f}/{quotas.max_storage_gb} GB")
        Clusters: 2/5
        Storage: 3.45/10.0 GB

        Check permissions:
        >>> user = await api.get_user()
        >>> for perm in user.authorization.permissions:
        ...     print(f"{perm.resource_type} {perm.resource_id}: {perm.actions}")
        cluster cluster123: ['read', 'write', 'execute']

        Notes
        -----
        - Requires valid JWT token (automatic with AsyncUserAPI.sign_in)
        - Returns current state; call again to refresh quota/permission info
        - Use to check quotas before creating new resources

        See Also
        --------
        sign_in : Authenticate and create API instance
        logout : Invalidate current session
        """
        return await self._user_management_client.get_user()

    async def logout(self) -> str:
        """
        Logout the currently authenticated user and invalidate the JWT token.

        This method invalidates the current JWT token on the server, preventing
        further authenticated requests with this token. After logout, create a
        new AsyncUserAPI instance to perform authenticated operations.

        Returns
        -------
        str
            Success message confirming logout

        Examples
        --------
        Basic logout:
        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> message = await api.logout()
        >>> print(message)
        User logged out successfully

        Logout with cleanup:
        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> try:
        ...     # Perform operations
        ...     clusters = await api.stream_and_fetch_clusters()
        ... finally:
        ...     await api.logout()
        ...     await api.disconnect()

        Using async context manager (automatic logout on exit):
        >>> async with await AsyncUserAPI.sign_in("user@example.com", "password") as api:
        ...     # Operations here
        ...     clusters = await api.stream_and_fetch_clusters()
        ...     # Automatic disconnect on exit (but manual logout needed if required)

        Notes
        -----
        - Token becomes invalid immediately after logout
        - Does not close network connections; call disconnect() separately
        - New operations require creating a new AsyncUserAPI instance via sign_in()
        - Recommended to call disconnect() after logout for complete cleanup

        See Also
        --------
        sign_in : Create new authenticated session
        disconnect : Close network connections
        """
        response = await self._user_management_client.logout()
        return response.message

    async def list_cluster_ids(self) -> List[str]:
        """
        List all cluster IDs owned by the authenticated user.

        This method retrieves only the cluster IDs without full cluster details.
        Use `stream_clusters()` or `get_cluster()` to retrieve complete cluster information.

        Returns
        -------
        List[str]
            List of cluster IDs owned by the authenticated user.
            Returns an empty list if the user has no clusters.

        Examples
        --------
        Basic usage - list all cluster IDs:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> cluster_ids = await api.list_cluster_ids()
        >>> print(f"Found {len(cluster_ids)} clusters")
        >>> for cluster_id in cluster_ids:
        ...     print(f"  - {cluster_id}")

        Check if user has any clusters:

        >>> cluster_ids = await api.list_cluster_ids()
        >>> if not cluster_ids:
        ...     print("No clusters found. Creating first cluster...")
        ...     new_cluster_id = await api.create_cluster("my-first-cluster")
        ... else:
        ...     print(f"Using existing cluster: {cluster_ids[0]}")

        Get details for all clusters:

        >>> cluster_ids = await api.list_cluster_ids()
        >>> clusters = []
        >>> for cluster_id in cluster_ids:
        ...     cluster = await api.get_cluster(cluster_id)
        ...     clusters.append(cluster)
        >>> print(f"Total clusters: {len(clusters)}")

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - Only returns clusters owned by the authenticated user
        - RBAC: Users can only list their own clusters (ownership check)
        - For complete cluster information, use `stream_clusters()` or `get_cluster()`
        - Cluster IDs are UUID strings generated during cluster creation

        See Also
        --------
        stream_clusters : Stream all clusters with full details
        get_cluster : Get complete information for a specific cluster
        create_cluster : Create a new cluster
        """
        response = await self._cluster_management_client.list_cluster_ids()
        return response.ids

    async def stream_clusters(self) -> AsyncIterator[Cluster]:
        """
        Stream all clusters owned by the authenticated user with real-time updates.

        This method provides an async iterator for efficient processing of clusters,
        especially useful when dealing with many clusters or when you need real-time
        updates from the backend.

        Returns
        -------
        AsyncIterator[Cluster]
            Async iterator yielding Cluster objects with the following structure:
            - cluster_id (str): Unique cluster identifier
            - owner_id (str): User ID of the cluster owner
            - name (str): Cluster name
            - status (int): Cluster status (0=CREATED, 1=RUNNING, 2=STOPPED)
            - node_host (str): Manager hostname for node connections (when running)
            - node_port (int): Manager port for node connections (when running)
            - jwt_token (str): Cluster JWT token for node authentication (when running)
            - creation_date (datetime): When the cluster was created
            - last_start (datetime): Last time cluster was started
            - last_stop (datetime): Last time cluster was stopped
            - swarm_count (int): Number of swarms in this cluster
            - node_count (int): Number of nodes connected to this cluster
            - active_node_count (int): Number of currently active nodes

        Examples
        --------
        Basic iteration over all clusters:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> async for cluster in api.stream_clusters():
        ...     print(f"Cluster: {cluster.name} ({cluster.cluster_id})")
        ...     print(f"  Status: {cluster.status}")
        ...     print(f"  Nodes: {cluster.active_node_count}/{cluster.node_count}")

        Find and use a running cluster:

        >>> async for cluster in api.stream_clusters():
        ...     if cluster.status == 1:  # RUNNING
        ...         print(f"Using running cluster: {cluster.name}")
        ...         # Deploy swarm to this cluster
        ...         swarm_id = await api.deploy_swarm(cluster.cluster_id, swarm)
        ...         break
        ... else:
        ...     print("No running clusters found")

        Collect running clusters for selection:

        >>> running_clusters = []
        >>> async for cluster in api.stream_clusters():
        ...     if cluster.status == 1:
        ...         running_clusters.append(cluster)
        >>>
        >>> if running_clusters:
        ...     selected = running_clusters[0]
        ...     print(f"Selected: {selected.name}")

        Monitor cluster status with live updates:

        >>> import asyncio
        >>> async for cluster in api.stream_clusters():
        ...     if cluster.cluster_id == target_cluster_id:
        ...         print(f"Cluster {cluster.name}: {cluster.active_node_count} active nodes")
        ...         await asyncio.sleep(1)  # Update every second

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - Only streams clusters owned by the authenticated user
        - RBAC: Users can only view their own clusters (ownership check)
        - For collecting all clusters at once, use `stream_and_fetch_clusters()`
        - For a single cluster, use `get_cluster(cluster_id)` which is more efficient
        - The stream provides real-time updates from the backend
        - Status values: 0 (CREATED), 1 (RUNNING), 2 (STOPPED)

        See Also
        --------
        stream_and_fetch_clusters : Collect all clusters into a list
        get_cluster : Get a specific cluster by ID
        list_cluster_ids : Get just the cluster IDs
        start_cluster : Start a stopped cluster
        """
        async for cluster in self._cluster_management_client.stream_clusters():
            yield cluster

    async def stream_and_fetch_clusters(self) -> List[Cluster]:
        """
        Fetch all clusters owned by the authenticated user as a complete list.

        This is a convenience method that streams all clusters and collects them
        into a list. Use this when you need to work with all clusters at once,
        rather than processing them one at a time.

        Returns
        -------
        List[Cluster]
            List of all Cluster objects owned by the user. Each Cluster contains:
            - cluster_id (str): Unique cluster identifier
            - owner_id (str): User ID of the cluster owner
            - name (str): Cluster name
            - status (int): Cluster status (0=CREATED, 1=RUNNING, 2=STOPPED)
            - node_host (str): Manager hostname (when running)
            - node_port (int): Manager port (when running)
            - jwt_token (str): Cluster JWT token (when running)
            - creation_date (datetime): Creation timestamp
            - last_start (datetime): Last start timestamp
            - last_stop (datetime): Last stop timestamp
            - swarm_count (int): Number of swarms
            - node_count (int): Total nodes
            - active_node_count (int): Currently active nodes

            Returns an empty list if the user has no clusters.

        Examples
        --------
        Get all clusters at once:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> clusters = await api.stream_and_fetch_clusters()
        >>> print(f"You have {len(clusters)} clusters")
        >>> for cluster in clusters:
        ...     print(f"  - {cluster.name}: {cluster.active_node_count} nodes")

        Filter running clusters:

        >>> all_clusters = await api.stream_and_fetch_clusters()
        >>> running = [c for c in all_clusters if c.status == 1]
        >>> stopped = [c for c in all_clusters if c.status == 2]
        >>> print(f"Running: {len(running)}, Stopped: {len(stopped)}")

        Sort clusters by creation date:

        >>> clusters = await api.stream_and_fetch_clusters()
        >>> sorted_clusters = sorted(clusters, key=lambda c: c.creation_date, reverse=True)
        >>> print("Most recent clusters:")
        >>> for cluster in sorted_clusters[:5]:
        ...     print(f"  {cluster.name} - {cluster.creation_date}")

        Find cluster by name:

        >>> clusters = await api.stream_and_fetch_clusters()
        >>> my_cluster = next((c for c in clusters if c.name == "production"), None)
        >>> if my_cluster:
        ...     print(f"Found: {my_cluster.cluster_id}")
        ... else:
        ...     print("Cluster 'production' not found")

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - Only returns clusters owned by the authenticated user
        - RBAC: Users can only view their own clusters (ownership check)
        - This method collects all results before returning (blocking operation)
        - For large numbers of clusters, consider using `stream_clusters()` for memory efficiency
        - For just cluster IDs, use `list_cluster_ids()` which is faster
        - Status values: 0 (CREATED), 1 (RUNNING), 2 (STOPPED)

        See Also
        --------
        stream_clusters : Stream clusters one at a time (more memory efficient)
        list_cluster_ids : Get just the cluster IDs (fastest option)
        get_cluster : Get a specific cluster by ID
        """
        clusters = []
        async for cluster in self._cluster_management_client.stream_clusters():
            clusters.append(cluster)
        return clusters

    async def get_cluster(self, cluster_id: str) -> Cluster:
        """
        Get detailed information for a specific cluster.

        This method retrieves complete cluster information including status,
        connection details, and resource counts. Use this when you need details
        for a specific cluster rather than iterating through all clusters.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster to retrieve.
            Must be a cluster owned by the authenticated user.

        Returns
        -------
        Cluster
            Complete Cluster object containing:
            - cluster_id (str): Unique cluster identifier
            - owner_id (str): User ID of the cluster owner
            - name (str): Cluster name
            - status (int): Current status (0=CREATED, 1=RUNNING, 2=STOPPED)
            - node_host (str): Manager hostname for node connections (when running)
            - node_port (int): Manager port for node connections (when running)
            - jwt_token (str): Cluster JWT token for node authentication (when running)
            - creation_date (datetime): When the cluster was created
            - last_start (datetime): Last time cluster was started
            - last_stop (datetime): Last time cluster was stopped
            - swarm_count (int): Total number of swarms in this cluster
            - active_swarm_count (int): Number of currently active swarms
            - node_count (int): Total number of nodes ever connected
            - node_limit (int): Maximum allowed nodes for this cluster
            - active_node_count (int): Number of currently connected nodes
            - task_count (int): Total tasks executed
            - active_task_count (int): Currently running tasks

        Raises
        ------
        grpc.RpcError
            If cluster_id is invalid or user doesn't have access to this cluster

        Examples
        --------
        Get cluster by ID:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> cluster = await api.get_cluster("cluster-123")
        >>> print(f"Cluster: {cluster.name}")
        >>> print(f"Status: {cluster.status}")
        >>> print(f"Active nodes: {cluster.active_node_count}/{cluster.node_count}")

        Check if cluster is running:

        >>> cluster = await api.get_cluster(cluster_id)
        >>> if cluster.status == 1:  # RUNNING
        ...     print(f"Cluster is running")
        ...     print(f"Connect nodes to: {cluster.node_host}:{cluster.node_port}")
        ... else:
        ...     print("Cluster is not running. Starting...")
        ...     await api.start_cluster(cluster_id)

        Monitor cluster resources:

        >>> cluster = await api.get_cluster(cluster_id)
        >>> print(f"Resource usage:")
        >>> print(f"  Nodes: {cluster.active_node_count}/{cluster.node_limit}")
        >>> print(f"  Swarms: {cluster.active_swarm_count}/{cluster.swarm_count}")
        >>> print(f"  Tasks: {cluster.active_task_count}/{cluster.task_count}")

        Get connection details for nodes:

        >>> cluster = await api.get_cluster(cluster_id)
        >>> if cluster.status == 1:
        ...     connection_info = {
        ...         "host": cluster.node_host,
        ...         "port": cluster.node_port,
        ...         "token": cluster.jwt_token
        ...     }
        ...     # Use this info to configure manta-node
        ...     print(f"Node connection: {connection_info}")

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - RBAC: Users can only get clusters they own (ownership check)
        - The cluster_id must be valid and belong to the authenticated user
        - Connection details (node_host, node_port, jwt_token) are only available when status=RUNNING
        - Status values: 0 (CREATED), 1 (RUNNING), 2 (STOPPED)
        - Use `start_cluster()` to start a stopped cluster before deploying swarms

        See Also
        --------
        stream_clusters : Get all clusters
        create_cluster : Create a new cluster
        start_cluster : Start a stopped cluster
        stop_cluster : Stop a running cluster
        """
        return await self._cluster_management_client.get_cluster(cluster_id)

    async def create_cluster(self, name: Optional[str] = None) -> str:
        """
        Create a new cluster for deploying swarms and managing distributed workloads.

        This method creates a cluster in CREATED status. You must call `start_cluster()`
        before deploying swarms or connecting nodes. The cluster will be owned by the
        authenticated user.

        Parameters
        ----------
        name : Optional[str], default=None
            Human-readable name for the cluster. If not provided, a default name
            will be auto-generated based on timestamp (e.g., "cluster-2024-01-15-123456").
            Names don't need to be unique.

        Returns
        -------
        str
            The unique cluster ID (UUID string) of the newly created cluster.
            Use this ID for all subsequent cluster operations (start, stop, deploy, etc.).

        Raises
        ------
        grpc.RpcError
            If quota limit exceeded (max_clusters_per_user) or creation fails

        Examples
        --------
        Create cluster with custom name:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> cluster_id = await api.create_cluster("my-ml-cluster")
        >>> print(f"Created cluster: {cluster_id}")
        >>> # Start the cluster before using it
        >>> cluster_info = await api.start_cluster(cluster_id)

        Create cluster with auto-generated name:

        >>> cluster_id = await api.create_cluster()
        >>> print(f"New cluster ID: {cluster_id}")
        >>> cluster = await api.get_cluster(cluster_id)
        >>> print(f"Auto-generated name: {cluster.name}")

        Create and immediately start a cluster:

        >>> cluster_id = await api.create_cluster("production")
        >>> cluster_info = await api.start_cluster(cluster_id)
        >>> print(f"Cluster running at {cluster_info.node_host}:{cluster_info.node_port}")

        Create cluster with error handling:

        >>> try:
        ...     cluster_id = await api.create_cluster("test-cluster")
        ...     print(f"Success: {cluster_id}")
        ... except grpc.RpcError as e:
        ...     if "quota exceeded" in str(e).lower():
        ...         print("Quota limit reached. Delete old clusters first.")
        ...     else:
        ...         print(f"Creation failed: {e}")

        Check quota before creating:

        >>> user = await api.get_user()
        >>> quotas = user.authorization.quotas
        >>> if quotas.current_clusters < quotas.max_clusters:
        ...     cluster_id = await api.create_cluster("new-cluster")
        ... else:
        ...     print(f"Quota full: {quotas.current_clusters}/{quotas.max_clusters}")

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - RBAC: Requires cluster creation permission (standard users have this by default)
        - Quota: Subject to max_clusters_per_user limit (default: 5 per user)
        - New clusters are created in CREATED (status=0) state
        - You must call `start_cluster()` before the cluster can be used
        - Cluster IDs are UUIDs and globally unique across all users
        - Cluster names are for human reference only and can be duplicated
        - Creating a cluster increments the user's cluster quota counter

        See Also
        --------
        start_cluster : Start the cluster to enable swarm deployment
        get_cluster : Get cluster details after creation
        delete_cluster : Delete a cluster to free quota
        get_user : Check current quota usage
        """
        response = await self._cluster_management_client.create_cluster(name)
        return response.id

    async def start_cluster(self, cluster_id: str) -> Cluster:
        """
        Start a cluster to enable swarm deployment and node connections.

        This method transitions a cluster from CREATED or STOPPED state to RUNNING state,
        provisioning the necessary backend services (watchdog, task scheduler, MQTT listener)
        and generating connection credentials for nodes. The cluster must be running before
        you can deploy swarms or connect compute nodes.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster to start.
            Must be a cluster owned by the authenticated user.

        Returns
        -------
        Cluster
            Complete cluster information including connection details:
            - cluster_id (str): Cluster identifier
            - name (str): Cluster name
            - status (int): Should be 1 (RUNNING) after successful start
            - node_host (str): Hostname for manta-node connections
            - node_port (int): Port for manta-node connections
            - jwt_token (str): Cluster JWT token for node authentication
            - creation_date (datetime): When cluster was created
            - last_start (datetime): Current timestamp
            - swarm_count, node_count, etc.: Resource counters

        Raises
        ------
        grpc.RpcError
            If cluster doesn't exist, user lacks permission, or start operation fails

        Examples
        --------
        Start a cluster and get connection info:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> cluster_info = await api.start_cluster(cluster_id)
        >>> print(f"Cluster '{cluster_info.name}' is now running")
        >>> print(f"Node connection: {cluster_info.node_host}:{cluster_info.node_port}")
        >>> print(f"Use JWT token: {cluster_info.jwt_token}")

        Configure manta-node with cluster connection:

        >>> cluster = await api.start_cluster(cluster_id)
        >>> node_config = {
        ...     "manager_host": cluster.node_host,
        ...     "manager_port": cluster.node_port,
        ...     "cluster_jwt": cluster.jwt_token
        ... }
        >>> # Save node_config to ~/.manta/nodes/my_node.toml
        >>> print("Configure your node with:", node_config)

        Start cluster and immediately deploy swarm:

        >>> cluster = await api.start_cluster(cluster_id)
        >>> if cluster.status == 1:  # Verify RUNNING
        ...     swarm_id = await api.deploy_swarm(cluster_id, swarm)
        ...     print(f"Swarm deployed: {swarm_id}")

        Handle already-running cluster:

        >>> try:
        ...     cluster = await api.start_cluster(cluster_id)
        ... except grpc.RpcError as e:
        ...     if "already running" in str(e).lower():
        ...         print("Cluster is already running")
        ...         cluster = await api.get_cluster(cluster_id)
        ...     else:
        ...         raise

        Wait for cluster to be fully started:

        >>> import asyncio
        >>> cluster = await api.start_cluster(cluster_id)
        >>> # Give backend services time to initialize
        >>> await asyncio.sleep(5)
        >>> # Now safe to deploy swarms
        >>> swarm_id = await api.deploy_swarm(cluster_id, swarm)

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - RBAC: Users can only start clusters they own (ownership check)
        - Backend provisioning: Creates Kubernetes namespace and deploys cluster services
          (watchdog, task scheduler, MQTT listener) in `cluster-{cluster_id}` namespace
        - Connection credentials (node_host, node_port, jwt_token) are generated on start
        - The cluster JWT token is different from user JWT and used by manta-nodes
        - Starting a cluster that's already running is idempotent (returns current state)
        - Allow 5-10 seconds after start before deploying swarms for backend initialization
        - Status transitions: CREATED (0) → RUNNING (1) or STOPPED (2) → RUNNING (1)

        See Also
        --------
        create_cluster : Create a new cluster first
        stop_cluster : Stop a running cluster
        get_cluster : Check cluster status
        deploy_swarm : Deploy swarms (requires running cluster)
        """
        return await self._cluster_management_client.start_cluster(cluster_id)

    async def stop_cluster(self, cluster_id: str) -> str:
        """
        Stop a running cluster and terminate all active swarms and tasks.

        This method transitions a cluster from RUNNING state to STOPPED state, shutting down
        backend services and terminating all running swarms and tasks. Stopped clusters
        can be restarted later with `start_cluster()`. Use this to save resources when
        the cluster is not actively needed.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster to stop.
            Must be a cluster owned by the authenticated user.

        Returns
        -------
        str
            Success message confirming cluster was stopped.

        Raises
        ------
        grpc.RpcError
            If cluster doesn't exist, user lacks permission, or stop operation fails

        Examples
        --------
        Stop a running cluster:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> message = await api.stop_cluster(cluster_id)
        >>> print(message)  # "Cluster stopped successfully"
        >>> # Verify cluster is stopped
        >>> cluster = await api.get_cluster(cluster_id)
        >>> assert cluster.status == 2  # STOPPED

        Stop cluster and wait for completion:

        >>> import asyncio
        >>> await api.stop_cluster(cluster_id)
        >>> await asyncio.sleep(10)  # Allow time for graceful shutdown
        >>> cluster = await api.get_cluster(cluster_id)
        >>> print(f"Status: {cluster.status}")  # Should be 2 (STOPPED)

        Stop all user's clusters:

        >>> clusters = await api.stream_and_fetch_clusters()
        >>> for cluster in clusters:
        ...     if cluster.status == 1:  # RUNNING
        ...         print(f"Stopping {cluster.name}...")
        ...         await api.stop_cluster(cluster.cluster_id)

        Handle already-stopped cluster:

        >>> try:
        ...     await api.stop_cluster(cluster_id)
        ... except grpc.RpcError as e:
        ...     if "not running" in str(e).lower():
        ...         print("Cluster is already stopped")
        ...     else:
        ...         raise

        Gracefully stop before deletion:

        >>> # Best practice: stop before delete
        >>> cluster = await api.get_cluster(cluster_id)
        >>> if cluster.status == 1:  # RUNNING
        ...     await api.stop_cluster(cluster_id)
        >>> await api.delete_cluster(cluster_id)

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - RBAC: Users can only stop clusters they own (ownership check)
        - Terminates all running swarms and tasks in the cluster
        - Disconnects all manta-nodes from the cluster
        - Removes Kubernetes namespace and cluster services (watchdog, scheduler, MQTT)
        - Connection credentials (node_host, node_port, jwt_token) become invalid
        - Cluster data (swarm definitions, results, logs) is preserved
        - Stopped clusters can be restarted with `start_cluster()`
        - Allow 10-15 seconds for graceful shutdown of swarms and tasks
        - Status transitions: RUNNING (1) → STOPPED (2)
        - Stopping an already-stopped cluster is idempotent

        See Also
        --------
        start_cluster : Restart a stopped cluster
        delete_cluster : Permanently delete a cluster
        get_cluster : Check cluster status
        """
        response = await self._cluster_management_client.stop_cluster(cluster_id)
        return response.message

    async def delete_cluster(self, cluster_id: str) -> str:
        """
        Permanently delete a cluster and all its associated data.

        This method removes the cluster and all associated data including swarm definitions,
        task results, logs, and execution history. This operation is irreversible. The cluster
        will be removed from the user's cluster list and the cluster quota will be decremented.

        **WARNING**: This permanently deletes all swarms, results, and logs in the cluster.
        Consider exporting important data before deletion.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster to delete.
            Must be a cluster owned by the authenticated user.

        Returns
        -------
        str
            Success message confirming cluster deletion.

        Raises
        ------
        grpc.RpcError
            If cluster doesn't exist, user lacks permission, or deletion fails

        Examples
        --------
        Delete a cluster:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> message = await api.delete_cluster(cluster_id)
        >>> print(message)  # "Cluster deleted successfully"
        >>> # Verify cluster is gone
        >>> cluster_ids = await api.list_cluster_ids()
        >>> assert cluster_id not in cluster_ids

        Safely delete cluster (stop first):

        >>> # Best practice: stop before delete
        >>> cluster = await api.get_cluster(cluster_id)
        >>> if cluster.status == 1:  # RUNNING
        ...     print("Stopping cluster first...")
        ...     await api.stop_cluster(cluster_id)
        ...     import asyncio
        ...     await asyncio.sleep(10)  # Wait for graceful shutdown
        >>>
        >>> print("Deleting cluster...")
        >>> await api.delete_cluster(cluster_id)

        Delete with confirmation:

        >>> cluster = await api.get_cluster(cluster_id)
        >>> print(f"About to delete cluster '{cluster.name}'")
        >>> print(f"  Swarms: {cluster.swarm_count}")
        >>> print(f"  Tasks: {cluster.task_count}")
        >>> confirm = input("Type cluster name to confirm deletion: ")
        >>> if confirm == cluster.name:
        ...     await api.delete_cluster(cluster_id)
        ...     print("Cluster deleted")
        ... else:
        ...     print("Deletion cancelled")

        Clean up old clusters to free quota:

        >>> clusters = await api.stream_and_fetch_clusters()
        >>> # Delete clusters older than 30 days with no swarms
        >>> import datetime
        >>> cutoff = datetime.datetime.now() - datetime.timedelta(days=30)
        >>> for cluster in clusters:
        ...     if cluster.creation_date < cutoff and cluster.swarm_count == 0:
        ...         print(f"Deleting old cluster: {cluster.name}")
        ...         await api.delete_cluster(cluster.cluster_id)

        Handle non-existent cluster:

        >>> try:
        ...     await api.delete_cluster(cluster_id)
        ... except grpc.RpcError as e:
        ...     if "not found" in str(e).lower():
        ...         print("Cluster already deleted")
        ...     else:
        ...         raise

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - RBAC: Users can only delete clusters they own (ownership check)
        - **PERMANENT DELETION**: All cluster data is irreversibly removed including:
          * All swarm definitions in the cluster
          * All task execution results
          * All task logs
          * All global parameters
          * All scheduling information
        - Best practice: Stop the cluster before deletion for graceful shutdown
        - Deletes Kubernetes namespace and all cluster resources
        - Decrements the user's cluster quota counter
        - Running clusters should be stopped first to avoid orphaned processes
        - Consider exporting important results/logs before deletion
        - Deletion is idempotent (deleting non-existent cluster returns success)

        See Also
        --------
        stop_cluster : Stop cluster before deletion
        create_cluster : Create a new cluster
        stream_results : Export results before deletion
        collect_logs : Export logs before deletion
        """
        response = await self._cluster_management_client.delete_cluster(cluster_id)
        return response.message

    async def list_module_ids(self) -> List[str]:
        """
        List all module IDs owned by the authenticated user.

        This method retrieves the unique identifiers of all algorithm modules that the
        authenticated user has created and stored in the platform. Modules are reusable
        components containing Python code and configuration that can be deployed across
        multiple swarms.

        This is useful for discovering available modules before swarm deployment, managing
        module inventory, or finding specific modules by their IDs.

        Returns
        -------
        List[str]
            List of module IDs (UUID format) owned by the user.
            Returns an empty list if the user has not created any modules.

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid or expired.

        Examples
        --------
        **List all user's modules:**

        >>> module_ids = await user_api.list_module_ids()
        >>> print(f"Total modules: {len(module_ids)}")
        Total modules: 5
        >>> print(module_ids)
        ['a1b2c3d4-...', 'e5f6g7h8-...', 'i9j0k1l2-...', ...]

        **Check if user has created any modules:**

        >>> module_ids = await user_api.list_module_ids()
        >>> if not module_ids:
        ...     print("No modules found. Create your first module!")
        ... else:
        ...     print(f"You have {len(module_ids)} modules")

        **Find a specific module by name (requires getting full details):**

        >>> module_ids = await user_api.list_module_ids()
        >>> for module_id in module_ids:
        ...     module = await user_api.get_module(module_id)
        ...     if module.name == "federated_aggregator":
        ...         print(f"Found module: {module_id}")
        ...         break

        **Count modules to check quota usage:**

        >>> module_ids = await user_api.list_module_ids()
        >>> max_allowed = 20  # From quota configuration
        >>> remaining = max_allowed - len(module_ids)
        >>> print(f"Using {len(module_ids)}/{max_allowed} modules")
        >>> print(f"Can create {remaining} more modules")
        Using 5/20 modules
        Can create 15 more modules

        **Get all modules efficiently (for further processing):**

        >>> # Use stream_and_fetch_modules() for full Module objects
        >>> modules = await user_api.stream_and_fetch_modules()
        >>> # Or just get IDs first, then fetch specific ones
        >>> module_ids = await user_api.list_module_ids()
        >>> selected_modules = []
        >>> for mid in module_ids[:3]:  # Get first 3 modules
        ...     selected_modules.append(await user_api.get_module(mid))

        Notes
        -----
        **RBAC and Permissions:**
        - Only modules owned by the authenticated user are returned.
        - No additional permissions required beyond valid authentication.
        - This method respects user isolation - users cannot see other users' modules.

        **Quotas:**
        - Platform enforces a maximum number of modules per user (typically 20).
        - Check current usage with `len(module_ids)` before creating new modules.
        - Quota limits prevent resource exhaustion and ensure fair platform usage.

        **Module Lifecycle:**
        - Modules persist until explicitly deleted with `remove_module()`.
        - Deleting a module does not affect swarms that have already been deployed
          (swarms store a snapshot of the module definition).
        - Consider cleaning up unused modules periodically to stay under quota limits.

        **Performance:**
        - This is a lightweight operation that returns only module IDs, not full
          module definitions or code.
        - For complete module details including code and configuration, use
          `stream_modules()` or `get_module()`.

        **Use Cases:**
        - **Pre-deployment checks**: Verify required modules exist before deploying swarms
        - **Quota management**: Monitor module count against user quota limits
        - **Module discovery**: List available modules for selection in deployment workflows
        - **Cleanup operations**: Identify old or unused modules for deletion

        See Also
        --------
        stream_modules : Stream full Module objects with code and configuration
        stream_and_fetch_modules : Fetch all modules as a list
        get_module : Get detailed information for a specific module
        send_module : Create a new module
        remove_module : Delete an existing module
        """
        response = await self._module_management_client.list_module_ids()
        return response.ids

    async def stream_modules(self) -> AsyncIterator[Module]:
        """
        Stream all modules owned by the authenticated user with full details.

        This method provides a streaming interface for retrieving all modules including
        their complete code, configuration, and metadata. Modules are yielded as they are
        retrieved from the backend, allowing for efficient processing of large module
        collections without loading everything into memory at once.

        Each Module object contains the Python code (as zipped files), Docker image
        specification, dataset requirements, and other configuration needed to deploy
        the algorithm in a swarm.

        Yields
        ------
        Module
            Module objects with the following structure:
            - module_id : str - Unique identifier for the module (UUID format)
            - name : str - Module name (derived from file/directory name)
            - python_program : Union[str, Path] - Path to the Python code
            - python_files : Dict[str, str] - Unzipped Python files {filename: content}
            - image : str - Docker image for task execution (e.g., 'ghcr.io/mantatech/manta_light_pytorch:latest')
            - datasets : Optional[List[str]] - Required dataset names (e.g., ['mnist', 'cifar10'])

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid or expired.

        Examples
        --------
        **Stream and process modules incrementally:**

        >>> async for module in user_api.stream_modules():
        ...     print(f"Module: {module.name}")
        ...     print(f"  ID: {module.module_id}")
        ...     print(f"  Image: {module.image}")
        ...     print(f"  Datasets: {module.datasets}")
        ...     print(f"  Files: {len(module.python_files)}")
        Module: federated_aggregator
          ID: a1b2c3d4-...
          Image: ghcr.io/mantatech/manta_light_pytorch:latest
          Datasets: []
          Files: 1
        Module: worker_trainer
          ID: e5f6g7h8-...
          Image: ghcr.io/mantatech/manta_light_pytorch:latest
          Datasets: ['mnist']
          Files: 3

        **Find modules using a specific Docker image:**

        >>> pytorch_modules = []
        >>> async for module in user_api.stream_modules():
        ...     if 'pytorch' in module.image.lower():
        ...         pytorch_modules.append(module.name)
        >>> print(f"PyTorch modules: {pytorch_modules}")
        PyTorch modules: ['federated_aggregator', 'worker_trainer', 'cnn_classifier']

        **Search for modules requiring specific datasets:**

        >>> mnist_modules = []
        >>> async for module in user_api.stream_modules():
        ...     if module.datasets and 'mnist' in module.datasets:
        ...         mnist_modules.append((module.module_id, module.name))
        >>> for mid, name in mnist_modules:
        ...     print(f"{name}: {mid}")

        **Count total lines of code across all modules:**

        >>> total_lines = 0
        >>> async for module in user_api.stream_modules():
        ...     for filename, content in module.python_files.items():
        ...         total_lines += len(content.splitlines())
        >>> print(f"Total lines of code: {total_lines}")

        **Export all module code to local filesystem:**

        >>> from pathlib import Path
        >>> export_dir = Path("exported_modules")
        >>> export_dir.mkdir(exist_ok=True)
        >>> async for module in user_api.stream_modules():
        ...     module_dir = export_dir / module.name
        ...     module_dir.mkdir(exist_ok=True)
        ...     for filename, content in module.python_files.items():
        ...         (module_dir / filename).write_text(content)
        ...     print(f"Exported: {module.name} ({len(module.python_files)} files)")

        Notes
        -----
        **RBAC and Permissions:**
        - Only modules owned by the authenticated user are returned.
        - No additional permissions required beyond valid authentication.
        - This method respects user isolation.

        **Memory Efficiency:**
        - Modules are yielded one at a time, making this suitable for users with many
          modules or large module code bases.
        - For small module collections, consider `stream_and_fetch_modules()` for
          simpler list-based processing.

        **Module Structure:**
        - **python_program**: Original path/content (may be a single .py file or directory)
        - **python_files**: Dictionary of all Python files after unzipping
        - **image**: Docker image that provides the execution environment
        - **datasets**: List of dataset names that must be available on nodes
        - **module_id**: Assigned automatically when the module is created

        **Code Access:**
        - Module code is automatically unzipped from the stored format into the
          `python_files` dictionary for easy inspection and modification.
        - Each entry in `python_files` maps a filename (relative path) to its content
          as a string.

        **Performance:**
        - Streaming is efficient for large collections but each module includes full
          code, so network transfer time scales with total code size.
        - Consider using `list_module_ids()` first if you only need to count modules
          or check for specific IDs.

        See Also
        --------
        stream_and_fetch_modules : Convenience method to collect all modules as a list
        list_module_ids : Get only module IDs (lightweight)
        get_module : Get a specific module by ID
        send_module : Create a new module
        update_module : Modify an existing module
        """
        async for module_request in self._module_management_client.stream_modules():
            yield Module.from_proto(module_request.module)

    async def stream_and_fetch_modules(self) -> List[Module]:
        """
        Fetch all modules owned by the authenticated user as a complete list.

        This method collects all modules from the streaming endpoint and returns them as
        a complete list. It's a convenience wrapper around `stream_modules()` for cases
        where you need to work with the full module collection at once rather than processing
        modules incrementally.

        Each Module object contains the complete Python code (as unzipped files), Docker
        image specification, dataset requirements, and configuration.

        Returns
        -------
        List[Module]
            List of Module objects with complete details. Each module contains:
            - module_id : str - Unique identifier (UUID format)
            - name : str - Module name
            - python_files : Dict[str, str] - Unzipped Python code files
            - image : str - Docker image specification
            - datasets : Optional[List[str]] - Required dataset names

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid or expired.

        Examples
        --------
        **Get all modules for analysis:**

        >>> modules = await user_api.stream_and_fetch_modules()

        Notes
        -----
        **Memory Considerations:**
        - This method loads all modules and their code into memory at once.
        - For users with many large modules, this can consume significant memory.
        - If memory usage is a concern, use `stream_modules()` instead to process
          modules incrementally.

        **RBAC and Permissions:**
        - Only modules owned by the authenticated user are returned.
        - No additional permissions required beyond valid authentication.

        **Performance:**
        - This method waits for all modules to be fetched before returning.
        - Total time scales with the number of modules and their combined code size.
        - For operations that can process modules incrementally, `stream_modules()`
          may provide better responsiveness.

        **Use Cases:**
        - **Batch analysis**: Analyze all modules together (e.g., find dependencies)
        - **Snapshot operations**: Get a consistent view of all modules at once
        - **Simple workflows**: When you need all modules and memory isn't a concern
        - **Export operations**: Backing up or exporting all module code

        **Consistency:**
        - The returned list represents a snapshot at the time of the query.
        - If modules are being added/removed concurrently by other processes, the
          list may not reflect the absolute latest state.

        See Also
        --------
        stream_modules : Stream modules incrementally (memory-efficient)
        list_module_ids : Get only module IDs (lightweight)
        get_module : Get a specific module by ID
        """
        modules = []
        async for module in self.stream_modules():
            modules.append(module)
        return modules

    async def get_module(self, module_id: str) -> Module:
        """
        Get complete details for a specific module by its ID.

        Retrieves the full module definition including Python code (unzipped), Docker
        image specification, dataset requirements, and metadata. This is useful when you
        need to inspect, modify, or redeploy a specific module.

        Parameters
        ----------
        module_id : str
            Unique identifier of the module to retrieve (UUID format).
            The authenticated user must own this module.

        Returns
        -------
        Module
            Module object with complete details:
            - module_id : str - Unique identifier (UUID format)
            - name : str - Module name (derived from file/directory name)
            - python_program : Union[str, Path] - Original path reference
            - python_files : Dict[str, str] - Unzipped Python files {filename: content}
            - image : str - Docker image for execution environment
            - datasets : Optional[List[str]] - Required dataset names

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified module.
        ValueError
            If module_id is not a valid UUID format.
        KeyError
            If the module does not exist.

        Examples
        --------
        **Get a module and inspect its code:**

        >>> module = await user_api.get_module(module_id)
        >>> print(f"Module: {module.name}")
        >>> print(f"Image: {module.image}")
        >>> print(f"Datasets: {module.datasets}")
        >>> print(f"Files: {list(module.python_files.keys())}")
        Module: federated_aggregator
        Image: ghcr.io/mantatech/manta_light_pytorch:latest
        Datasets: []
        Files: ['aggregator.py', 'utils.py']

        **View the main Python code:**

        >>> module = await user_api.get_module(module_id)
        >>> main_file = list(module.python_files.keys())[0]
        >>> print(f"--- {main_file} ---")
        >>> print(module.python_files[main_file])
        --- aggregator.py ---
        import torch
        from manta.light import World, Results
        ...

        **Check if module requires specific datasets:**

        >>> module = await user_api.get_module(module_id)
        >>> required_datasets = module.datasets or []
        >>> if 'mnist' in required_datasets:
        ...     print("This module requires MNIST dataset")
        ... else:
        ...     print("No MNIST dataset required")

        **Modify and update a module:**

        >>> # Get existing module
        >>> module = await user_api.get_module(module_id)
        >>> # Modify code
        >>> main_file = list(module.python_files.keys())[0]
        >>> modified_code = module.python_files[main_file].replace(
        ...     'learning_rate = 0.01',
        ...     'learning_rate = 0.001'
        ... )
        >>> module.python_files[main_file] = modified_code
        >>> # Update on platform
        >>> await user_api.update_module(module, module_id)
        >>> print("Module updated successfully")

        **Create a new module based on existing one:**

        >>> # Get template module
        >>> template = await user_api.get_module(template_module_id)
        >>> # Create new module with modified configuration
        >>> new_module = Module(
        ...     python_program=template.python_program,
        ...     image=template.image,
        ...     datasets=['cifar10']  # Different dataset
        ... )
        >>> # Send as new module
        >>> new_id = await user_api.send_module(new_module)
        >>> print(f"Created new module: {new_id}")

        Notes
        -----
        **RBAC and Permissions:**
        - Only the module owner can retrieve module details.
        - No sharing mechanism exists - modules are user-private resources.
        - Permission check enforced at the service boundary with 5-minute cache.

        **Code Unzipping:**
        - Module code is stored in compressed (zipped) format on the backend.
        - The `python_files` dictionary contains unzipped content for easy access.
        - Each file's content is decoded as UTF-8 text.

        **Module ID Format:**
        - module_id must be a valid UUID string format.
        - IDs are assigned automatically when modules are created via `send_module()`.
        - Use `list_module_ids()` or `stream_modules()` to discover available IDs.

        **Module Structure:**
        - **Single file modules**: python_files contains one entry
        - **Directory modules**: python_files contains multiple entries with relative paths
        - **Datasets**: List of dataset names (not paths) that must exist on nodes
        - **Image**: Full Docker image reference including registry and tag

        **Use Cases:**
        - **Code inspection**: Review algorithm implementation before deployment
        - **Module modification**: Update hyperparameters, fix bugs, add features
        - **Template creation**: Clone and customize existing modules
        - **Debugging**: Examine code when tasks fail during execution
        - **Documentation**: Generate documentation from module code

        See Also
        --------
        list_module_ids : Get all module IDs owned by user
        send_module : Create a new module
        update_module : Modify an existing module
        remove_module : Delete a module
        stream_modules : Stream all modules with full details
        """
        module_request = await self._module_management_client.get_module(module_id)
        return Module.from_proto(module_request.module)

    async def send_module(self, module: Module) -> str:
        """
        Upload a reusable algorithm module (Python code + Docker image).

        Parameters
        ----------
        module : Module
            Module with python_program (file/directory path), image, datasets

        Returns
        -------
        str
            Module ID (UUID) to reference in swarm deployments

        Examples
        --------
        >>> module = Module(
        ...     python_program="worker.py",
        ...     image="ghcr.io/mantatech/manta_light_pytorch:latest",
        ...     datasets=["mnist"]
        ... )
        >>> module_id = await user_api.send_module(module)

        Notes
        -----
        - Modules are user-private with quota limits (typically 20)
        - Code is auto-zipped and stored for reuse across swarms
        """
        # Convert Module to protobuf using its to_proto method
        module_proto = module.to_proto()

        response = await self._module_management_client.send_module(module_proto)
        return response.id

    async def update_module(self, module: Module, module_id: str) -> str:
        """
        Update an existing module's code or configuration.

        This method replaces the Python code, Docker image, dataset requirements, or other
        configuration of an existing module. The module ID remains the same, but the content
        is completely replaced with the new Module object provided.

        This is useful for versioning algorithms, fixing bugs in existing modules, or updating
        module configuration (Docker image, dataset requirements) without creating a new module.

        Important: Updating a module doesn't affect already-deployed swarms, as swarms store
        a snapshot of the module code at deployment time. Only new deployments will use the
        updated module version.

        Parameters
        ----------
        module : Module
            Module object with updated content, containing:

            - python_program : Union[str, Path] - Path to new Python file or directory
            - image : str - Updated Docker image (e.g., 'ghcr.io/mantatech/manta_light_pytorch:latest')
            - name : Optional[str] - Updated module name (defaults to file/directory name)
            - datasets : Optional[List[str]] - Updated dataset requirements
            - python_files : Dict[str, str] - Pre-loaded Python files (usually empty for updates)

            All fields replace the existing module content. To keep some fields unchanged,
            retrieve the current module with `get_module()`, modify specific fields, then
            call `update_module()`.

        module_id : str
            Unique identifier (UUID format) of the module to update.
            The authenticated user must own this module.

        Returns
        -------
        str
            The same module ID that was provided (module IDs don't change on update).
            This confirms the update was successful.

        Raises
        ------
        AuthenticationError
            If JWT token is invalid or expired.
        PermissionError
            If user doesn't own this module (modules cannot be updated by non-owners).
        ResourceNotFoundError
            If module_id doesn't exist or was deleted.
        ValidationError
            If updated module validation fails:
            - Invalid python_program path (file/directory doesn't exist)
            - Invalid image format
            - Invalid dataset names
            - Empty module (no Python files found)
        ConnectionError
            If connection to the manager service fails.

        Examples
        --------
        **Example 1: Update module code (fix bug or improve algorithm)**

        >>> # Get existing module
        >>> module = await api.get_module("3c7b2a89-1f45-4e3d-9b2c-8f4a3d2e1c5b")
        >>> print(f"Original code length: {len(module.python_files['my_algorithm.py'])} chars")
        Original code length: 450 chars
        >>>
        >>> # Create updated version with bug fix
        >>> updated_module = Module(
        ...     python_program="my_algorithm_v2.py",  # Fixed version
        ...     image=module.image,  # Keep same image
        ...     datasets=module.datasets  # Keep same dataset requirements
        ... )
        >>>
        >>> # Update the module
        >>> result_id = await api.update_module(
        ...     updated_module,
        ...     "3c7b2a89-1f45-4e3d-9b2c-8f4a3d2e1c5b"
        ... )
        >>> print(f"Module updated: {result_id}")
        Module updated: 3c7b2a89-1f45-4e3d-9b2c-8f4a3d2e1c5b

        **Example 2: Update Docker image only (upgrade to GPU version)**

        >>> # Get existing module
        >>> module = await api.get_module(module_id)
        >>>
        >>> # Create updated module with GPU image
        >>> updated_module = Module(
        ...     python_program=module.python_program,  # Keep same code
        ...     image="ghcr.io/mantatech/manta_light_pytorch:latest-gpu",  # GPU version
        ...     datasets=module.datasets
        ... )
        >>>
        >>> await api.update_module(updated_module, module_id)
        >>> print("Upgraded to GPU image")
        Upgraded to GPU image

        **Example 3: Add dataset requirements to existing module**

        >>> # Get module that currently has no dataset requirements
        >>> module = await api.get_module(module_id)
        >>> print(f"Current datasets: {module.datasets}")
        Current datasets: []
        >>>
        >>> # Create updated module with CIFAR-10 requirement
        >>> updated_module = Module(
        ...     python_program=module.python_program,
        ...     image=module.image,
        ...     datasets=["cifar10"]  # Add dataset requirement
        ... )
        >>>
        >>> await api.update_module(updated_module, module_id)
        >>>
        >>> # Verify update
        >>> module = await api.get_module(module_id)
        >>> print(f"Updated datasets: {module.datasets}")
        Updated datasets: ['cifar10']

        **Example 4: Update from single file to directory structure**

        >>> # Original: single file module
        >>> # Updated: multi-file package structure
        >>> # new_package/
        >>> #   __init__.py
        >>> #   model.py
        >>> #   trainer.py
        >>> #   utils.py
        >>>
        >>> updated_module = Module(
        ...     python_program="new_package",  # Directory instead of single file
        ...     image=module.image,
        ...     datasets=module.datasets
        ... )
        >>>
        >>> await api.update_module(updated_module, module_id)
        >>>
        >>> # Verify multi-file structure
        >>> module = await api.get_module(module_id)
        >>> print(f"Files: {list(module.python_files.keys())}")
        Files: ['new_package/__init__.py', 'new_package/model.py', 'new_package/trainer.py', 'new_package/utils.py']

        **Example 5: Incremental updates with version control pattern**

        >>> # Version control pattern: keep module name consistent, update code iteratively
        >>> module_id = "3c7b2a89-1f45-4e3d-9b2c-8f4a3d2e1c5b"
        >>>
        >>> # Version 1: Initial implementation
        >>> v1 = Module(python_program="algorithm_v1.py", image="...", name="my_algorithm")
        >>> await api.update_module(v1, module_id)
        >>>
        >>> # Version 2: Performance improvements
        >>> v2 = Module(python_program="algorithm_v2.py", image="...", name="my_algorithm")
        >>> await api.update_module(v2, module_id)
        >>>
        >>> # Version 3: Bug fixes
        >>> v3 = Module(python_program="algorithm_v3.py", image="...", name="my_algorithm")
        >>> await api.update_module(v3, module_id)
        >>>
        >>> # Retrieve latest version
        >>> latest = await api.get_module(module_id)
        >>> print(f"Latest version: {latest.name}")
        Latest version: my_algorithm

        Notes
        -----
        **RBAC and Ownership:**

        - Only module owners can update their modules
        - Module ownership cannot be transferred (updates must come from original owner)
        - Attempting to update another user's module results in PermissionError

        **Update Semantics:**

        - Updates completely replace module content (not incremental patches)
        - Module ID remains unchanged after update
        - Module name may change if derived from new file/directory name
        - Previous module version is not stored (no automatic version history)

        **Impact on Deployed Swarms:**

        - Running swarms are NOT affected by module updates (use snapshot)
        - Only NEW swarm deployments use the updated module version
        - To apply updates to running swarms, redeploy the swarm
        - Each swarm stores its own module snapshot at deployment time

        **Quota Considerations:**

        - Module updates don't consume additional quota (same module ID)
        - Module size limits still apply (typically 100MB compressed)
        - Failed updates don't create new modules or consume quota

        **Code Zipping:**

        - Python code is automatically re-zipped during update
        - Old zipped code is replaced with new version
        - `__pycache__` directories excluded automatically

        **Dataset Requirements:**

        - Updated dataset requirements affect node selection for future deployments
        - Adding datasets narrows node selection to those with the datasets
        - Removing datasets broadens node selection
        - Dataset names must match those configured on nodes (case-sensitive)

        **Docker Image Updates:**

        - Image must be accessible to cluster nodes
        - Changing image may affect task execution environment
        - Test updated images before production deployments
        - GPU/CPU image changes may require different node configurations

        **Version Control Best Practices:**

        - Keep external version control (Git) for module code
        - Use descriptive commit messages for tracking changes
        - Test updated modules in development before production
        - Document breaking changes in module code comments

        **Performance Considerations:**

        - Update time depends on new module size and network speed
        - Large modules (>10MB) may take several seconds to update
        - Consider partial updates (only changed files) by restructuring as packages
        - Updates are atomic (fully succeed or fully fail, no partial updates)

        **Use Cases:**

        - Fix bugs in deployed algorithms without changing module ID
        - Upgrade to GPU-optimized Docker images
        - Add or remove dataset requirements
        - Refactor code from single file to multi-file package
        - Iterate on algorithm implementations during development

        See Also
        --------
        send_module : Create a new module
        get_module : Retrieve current module content before updating
        remove_module : Delete module instead of updating
        list_module_ids : List all modules to find module_id
        """
        # Convert Module to protobuf using its to_proto method
        module_proto = module.to_proto()

        # Create ModuleRequest
        module_request = ModuleRequest(module=module_proto, module_id=module_id)

        response = await self._module_management_client.update_module(module_request)
        return response.id

    async def remove_module(self, module_id: str) -> str:
        """
        Delete a module and free quota space.

        This method permanently removes a module from the platform, deleting its Python code,
        configuration, and metadata. The module ID becomes invalid and cannot be reused.

        Deleting a module frees up quota space (typically 1 of 20 module slots) and storage,
        allowing you to create new modules. However, deletion doesn't affect already-deployed
        swarms, as each swarm stores a snapshot of module code at deployment time.

        This is useful for cleaning up unused or outdated modules, managing quota limits, or
        removing test/experimental code from the platform.

        Important: This operation is irreversible. Module code and configuration cannot be
        recovered after deletion. Consider exporting module code with `get_module()` before
        deletion if you might need it later.

        Parameters
        ----------
        module_id : str
            Unique identifier (UUID format) of the module to delete.
            The authenticated user must own this module.

        Returns
        -------
        str
            Confirmation message (typically "Module deleted successfully" or similar).
            The message confirms the module was permanently removed.

        Raises
        ------
        AuthenticationError
            If JWT token is invalid or expired.
        PermissionError
            If user doesn't own this module (modules can only be deleted by owners).
        ResourceNotFoundError
            If module_id doesn't exist or was already deleted.
        ConnectionError
            If connection to the manager service fails.

        Examples
        --------
        **Example 1: Delete unused module to free quota**

        >>> # Check current quota usage
        >>> module_ids = await api.list_module_ids()
        >>> print(f"Modules: {len(module_ids)}/20")
        Modules: 20/20
        >>>
        >>> # Delete oldest unused module
        >>> old_module_id = module_ids[0]
        >>> message = await api.remove_module(old_module_id)
        >>> print(message)
        Module deleted successfully
        >>>
        >>> # Verify quota freed
        >>> module_ids = await api.list_module_ids()
        >>> print(f"Modules after deletion: {len(module_ids)}/20")
        Modules after deletion: 19/20

        **Example 2: Export module code before deletion (backup)**

        >>> # Get module details before deletion
        >>> module = await api.get_module(module_id)
        >>>
        >>> # Export Python code to local filesystem
        >>> import os
        >>> backup_dir = f"backups/{module.name}"
        >>> os.makedirs(backup_dir, exist_ok=True)
        >>>
        >>> for filename, content in module.python_files.items():
        ...     filepath = os.path.join(backup_dir, filename)
        ...     os.makedirs(os.path.dirname(filepath), exist_ok=True)
        ...     with open(filepath, 'w') as f:
        ...         f.write(content)
        >>>
        >>> print(f"Module backed up to {backup_dir}")
        Module backed up to backups/my_algorithm
        >>>
        >>> # Now safe to delete
        >>> await api.remove_module(module_id)
        >>> print("Module deleted (backup preserved)")
        Module deleted (backup preserved)

        **Example 3: Batch delete test modules**

        >>> # Find all test modules
        >>> all_modules = await api.stream_and_fetch_modules()
        >>> test_modules = [m for m in all_modules if m.name.startswith("test_")]
        >>>
        >>> print(f"Found {len(test_modules)} test modules")
        Found 5 test modules
        >>>
        >>> # Delete all test modules
        >>> for module in test_modules:
        ...     message = await api.remove_module(module.module_id)
        ...     print(f"Deleted: {module.name} - {message}")
        Deleted: test_algorithm_1 - Module deleted successfully
        Deleted: test_algorithm_2 - Module deleted successfully
        Deleted: test_algorithm_3 - Module deleted successfully
        Deleted: test_algorithm_4 - Module deleted successfully
        Deleted: test_algorithm_5 - Module deleted successfully

        **Example 4: Delete module with verification**

        >>> # Verify module exists before deletion
        >>> try:
        ...     module = await api.get_module(module_id)
        ...     print(f"Deleting module: {module.name}")
        ...     message = await api.remove_module(module_id)
        ...     print(f"Success: {message}")
        ... except ResourceNotFoundError:
        ...     print("Module doesn't exist (already deleted?)")
        Deleting module: old_algorithm
        Success: Module deleted successfully
        >>>
        >>> # Verify deletion
        >>> try:
        ...     await api.get_module(module_id)
        ... except ResourceNotFoundError:
        ...     print("Confirmed: Module no longer exists")
        Confirmed: Module no longer exists

        **Example 5: Clean up modules by age pattern**

        >>> # List all modules with metadata
        >>> modules = await api.stream_and_fetch_modules()
        >>>
        >>> # Identify modules to delete (example: by naming convention)
        >>> # Real implementation might check creation date from database
        >>> old_modules = [
        ...     m for m in modules
        ...     if m.name.endswith("_old") or m.name.endswith("_deprecated")
        ... ]
        >>>
        >>> print(f"Cleaning up {len(old_modules)} old modules...")
        Cleaning up 3 old modules...
        >>>
        >>> for module in old_modules:
        ...     await api.remove_module(module.module_id)
        ...     print(f"Removed: {module.name}")
        Removed: algorithm_v1_old
        Removed: worker_deprecated
        Removed: aggregator_old

        Notes
        -----
        **RBAC and Ownership:**

        - Only module owners can delete their modules
        - Attempting to delete another user's module results in PermissionError
        - Module ownership cannot be transferred (permanent until deletion)

        **Deletion Permanence:**

        - Deletion is immediate and irreversible (no recovery mechanism)
        - Module code, configuration, and metadata are permanently removed
        - Module ID becomes invalid and cannot be reused or recreated
        - No "trash bin" or temporary deletion state

        **Impact on Deployed Swarms:**

        - Running swarms are NOT affected by module deletion (use snapshot)
        - Swarms store module code at deployment time (independent copy)
        - Deleted modules cannot be used in NEW swarm deployments
        - Existing swarms continue running with their module snapshot

        **Quota Management:**

        - Deletion immediately frees one module quota slot
        - New modules can be created immediately after deletion
        - Quota count decreases by 1 (e.g., 20/20 becomes 19/20)
        - Storage quota also freed based on module size

        **Best Practices Before Deletion:**

        - Export module code with `get_module()` for backup
        - Verify module is not referenced in planned deployments
        - Check module name/ID carefully before deletion
        - Consider updating instead of deleting if code needs changes

        **Common Deletion Scenarios:**

        - Free quota space when at maximum limit (20/20 modules)
        - Remove test/experimental modules after validation
        - Clean up old algorithm versions
        - Delete modules with bugs/security issues
        - Remove modules for deprecated datasets or images

        **Performance Considerations:**

        - Deletion is fast (typically <100ms)
        - Immediate availability of freed quota slot
        - No impact on platform performance
        - Batch deletions are safe (no rate limiting)

        **Error Handling:**

        - ResourceNotFoundError if module doesn't exist (safe to ignore if goal is deletion)
        - PermissionError if not module owner (check ownership first)
        - ConnectionError if network issues (retry with exponential backoff)

        **Use Cases:**

        - Quota management: Delete old modules to stay under limit
        - Cleanup: Remove test modules after experiments
        - Security: Delete modules with discovered vulnerabilities
        - Organization: Remove deprecated or superseded algorithms
        - Storage: Free disk space by removing large unused modules

        See Also
        --------
        get_module : Export module code before deletion (backup)
        list_module_ids : Check current quota usage before deletion
        update_module : Modify module instead of deleting and recreating
        send_module : Create new module after freeing quota with deletion
        """
        response = await self._module_management_client.remove_module(module_id)
        return response.message

    async def list_swarm_ids(self) -> List[str]:
        """
        List all swarm IDs owned by the authenticated user.

        This method retrieves the unique identifiers of all distributed algorithm swarms
        that the authenticated user has created. Swarms are computational workflows
        consisting of tasks deployed across clusters. Each swarm receives a unique UUID
        upon creation and persists until explicitly deleted.

        Unlike modules (which are reusable algorithm definitions), swarms represent
        specific deployments with execution state (iteration count, status, runtime data).

        Returns
        -------
        List[str]
            List of swarm IDs (UUID format) owned by the user.
            Returns an empty list if the user has not created any swarms.

            Each swarm ID is a 32-character hexadecimal string (UUID format without hyphens).

        Raises
        ------
        grpc.RpcError
            If the gRPC call fails due to network issues or authentication errors.

        Examples
        --------
        **List all swarms to check quota usage:**

        >>> swarm_ids = await api.list_swarm_ids()
        >>> print(f"You have {len(swarm_ids)} swarms")
        >>> print(f"Swarms: {swarm_ids}")
        You have 3 swarms
        Swarms: ['a41d4d1b01ff44f58ce8207d3c7273ca', '5f3a2c8e9b1d4e7f8c6a5b3d9e1f2a4c', ...]

        **Find specific swarm by filtering full details:**

        >>> swarm_ids = await api.list_swarm_ids()
        >>> # Get full details for swarms to find by name
        >>> async for swarm in api.stream_swarms():
        ...     if swarm.name == "FederatedMNIST":
        ...         target_swarm_id = swarm.swarm_id
        ...         break
        >>> print(f"Found swarm: {target_swarm_id}")

        **Check swarm quota before deployment:**

        >>> swarm_ids = await api.list_swarm_ids()
        >>> max_swarms = 10  # Platform quota
        >>> if len(swarm_ids) >= max_swarms:
        ...     print(f"Quota exceeded! Delete {len(swarm_ids) - max_swarms + 1} swarms")
        ...     # Delete oldest or inactive swarms
        ...     async for swarm in api.stream_swarms():
        ...         if swarm.status == "COMPLETED":
        ...             await api.remove_swarm(swarm.swarm_id)
        ...             break

        **Monitor swarm lifecycle (IDs persist even when stopped):**

        >>> initial_swarm_ids = await api.list_swarm_ids()
        >>> # Deploy new swarm
        >>> swarm_overview = await api.deploy_swarm(cluster_id, my_swarm)
        >>> new_swarm_ids = await api.list_swarm_ids()
        >>> added_swarm = set(new_swarm_ids) - set(initial_swarm_ids)
        >>> print(f"New swarm ID: {added_swarm.pop()}")
        >>> # Stop swarm (ID remains in list)
        >>> await api.stop_swarm(swarm_overview["swarm_id"])
        >>> stopped_swarm_ids = await api.list_swarm_ids()
        >>> assert swarm_overview["swarm_id"] in stopped_swarm_ids

        **Batch operations using IDs:**

        >>> swarm_ids = await api.list_swarm_ids()
        >>> # Stop all running swarms
        >>> for swarm_id in swarm_ids:
        ...     swarm = await api.get_swarm(swarm_id)
        ...     if swarm.status == "ACTIVE":
        ...         await api.stop_swarm(swarm_id)
        >>> # Delete all completed swarms
        >>> for swarm_id in swarm_ids:
        ...     swarm = await api.get_swarm(swarm_id)
        ...     if swarm.status == "COMPLETED":
        ...         await api.remove_swarm(swarm_id)

        Notes
        -----
        **RBAC and Ownership:**

        - Swarms are user-private resources; users can only list their own swarms.
        - Cluster admins can see all swarms in their clusters but are filtered by user_id.
        - Swarm IDs are returned in creation order (oldest first).

        **Swarm Quotas:**

        - Platform enforces maximum swarms per user (typically 10 swarms).
        - Each deployed swarm consumes one quota slot regardless of status (ACTIVE/STOPPED/COMPLETED).
        - Delete completed or inactive swarms to free quota space.
        - Quotas track total swarms, not just running swarms.

        **Swarm Lifecycle:**

        - Swarm IDs persist across start/stop cycles; stopping doesn't delete the swarm.
        - Swarm status values: "PENDING" (created), "ACTIVE" (running), "STOPPED" (paused), "COMPLETED" (finished).
        - Only `remove_swarm()` deletes the swarm and frees quota.
        - Deleted swarm IDs cannot be reused.

        **Performance:**

        - Very fast operation (typically <50ms) as it queries indexed database.
        - Suitable for frequent quota checks before deployments.
        - For full swarm details, use `stream_swarms()` instead of calling `get_swarm()` per ID.

        **Common Use Cases:**

        - Pre-deployment quota validation
        - Swarm inventory and cleanup
        - Batch operations on swarms
        - Identifying swarms for monitoring

        **Swarm vs Module Distinction:**

        - **Modules** are reusable algorithm definitions (code + config).
        - **Swarms** are specific deployments of algorithms with execution state.
        - One module can be used in multiple swarms.
        - Deleting a module doesn't affect deployed swarms (they snapshot module code).

        See Also
        --------
        stream_swarms : Get full swarm details for all swarms (more comprehensive)
        get_swarm : Get complete details for a specific swarm
        deploy_swarm : Create and start a new swarm
        remove_swarm : Delete a swarm and free quota
        """
        response = await self._swarm_management_client.list_swarm_ids()
        return response.ids

    async def stream_swarms(self) -> AsyncIterator[SwarmProto]:
        """
        Stream all swarms owned by the authenticated user with full details.

        This method provides a streaming interface for retrieving all swarms including
        their execution state, task graph, status, and metadata. Swarms are yielded as
        they are retrieved from the backend, allowing for efficient processing of large
        swarm collections without loading everything into memory at once.

        Each yielded SwarmProto object contains complete swarm information including
        deployment history, current execution state (iteration, status), task counts,
        and authorization details (quotas and permissions).

        Yields
        ------
        SwarmProto
            Swarm objects with the following structure:

            - swarm_id : str - Unique identifier (UUID format, 32-char hex)
            - cluster_id : str - Cluster where swarm is deployed
            - owner_id : str - User ID of the swarm creator
            - name : str - Swarm name (from Swarm class definition)
            - created_at : datetime - Swarm creation timestamp
            - last_start : datetime - Most recent start time (or epoch if never started)
            - last_stop : datetime - Most recent stop time (or epoch if never stopped)
            - status : str - Current status ("PENDING", "ACTIVE", "STOPPED", "COMPLETED")
            - iteration : int - Current execution iteration (starts at 0)
            - circular : int - Number of complete cycles through task graph
            - authorization : dict - Quotas and permissions for this swarm:
                - swarm_id : str - Swarm identifier
                - quotas : dict - Resource quotas:
                    - max_storage_gb : float - Maximum storage allowed
                    - current_storage_gb : float - Current storage usage
                    - max_concurrent_tasks : int - Maximum parallel tasks
                    - current_concurrent_tasks : int - Currently running tasks
                - permissions : list - Explicit permissions granted
                - permissions_updated_at : datetime - Last permission update

        Raises
        ------
        grpc.RpcError
            If the gRPC stream fails due to network issues or authentication errors.

        Examples
        --------
        **Incremental processing of swarms (memory efficient):**

        >>> async for swarm in api.stream_swarms():
        ...     print(f"Swarm: {swarm.name} ({swarm.swarm_id})")
        ...     print(f"  Status: {swarm.status}, Iteration: {swarm.iteration}")
        ...     print(f"  Storage: {swarm.authorization['quotas']['current_storage_gb']:.2f} GB")
        Swarm: FederatedMNIST (a41d4d1b01ff44f58ce8207d3c7273ca)
          Status: ACTIVE, Iteration: 15
          Storage: 0.25 GB
        Swarm: DistributedTraining (5f3a2c8e9b1d4e7f8c6a5b3d9e1f2a4c)
          Status: COMPLETED, Iteration: 100
          Storage: 1.50 GB

        **Filter swarms by status (find all active swarms):**

        >>> active_swarms = []
        >>> async for swarm in api.stream_swarms():
        ...     if swarm.status == "ACTIVE":
        ...         active_swarms.append(swarm)
        >>> print(f"Found {len(active_swarms)} active swarms")
        >>> for swarm in active_swarms:
        ...     print(f"  - {swarm.name}: {swarm.iteration} iterations")

        **Monitor resource usage across all swarms:**

        >>> total_storage = 0
        >>> total_tasks = 0
        >>> async for swarm in api.stream_swarms():
        ...     quotas = swarm.authorization['quotas']
        ...     total_storage += quotas['current_storage_gb']
        ...     total_tasks += quotas['current_concurrent_tasks']
        >>> print(f"Total storage: {total_storage:.2f} GB")
        >>> print(f"Total concurrent tasks: {total_tasks}")

        **Find swarms by name (search pattern):**

        >>> target_swarms = []
        >>> async for swarm in api.stream_swarms():
        ...     if "MNIST" in swarm.name or "federated" in swarm.name.lower():
        ...         target_swarms.append({
        ...             'swarm_id': swarm.swarm_id,
        ...             'name': swarm.name,
        ...             'status': swarm.status
        ...         })
        >>> print(f"Found {len(target_swarms)} matching swarms")

        **Cleanup completed swarms (free quota space):**

        >>> completed_count = 0
        >>> async for swarm in api.stream_swarms():
        ...     if swarm.status == "COMPLETED":
        ...         # Check if swarm hasn't been used recently
        ...         last_active = max(swarm.last_start, swarm.last_stop)
        ...         age_days = (datetime.now() - last_active).days
        ...         if age_days > 30:
        ...             await api.remove_swarm(swarm.swarm_id)
        ...             completed_count += 1
        >>> print(f"Deleted {completed_count} old completed swarms")

        Notes
        -----
        **RBAC and Ownership:**

        - Swarms are user-private resources; users can only stream their own swarms.
        - Cluster admins can filter by cluster_id to see swarms in specific clusters.
        - Swarms are ordered by creation time (oldest first).

        **Streaming Behavior:**

        - Swarms are yielded incrementally as they are retrieved from the database.
        - Memory-efficient for large swarm collections (processes one at a time).
        - Stream can be interrupted early using `break` without loading all swarms.
        - For collecting all swarms into a list, use `stream_and_fetch_swarms()` instead.

        **Swarm Status Values:**

        - **"PENDING"**: Created but not started yet.
        - **"ACTIVE"**: Currently executing tasks.
        - **"STOPPED"**: Paused execution (can be restarted).
        - **"COMPLETED"**: Finished execution (terminal state).

        **Iteration and Circular:**

        - **iteration**: Number of times task graph has been executed.
        - **circular**: Number of complete cycles for circular swarms.
        - Both start at 0 and increment during execution.

        **Authorization Structure:**

        - **quotas**: Resource limits and current usage for the swarm.
        - **permissions**: Explicit permissions granted to users (usually empty for owner).
        - **max_concurrent_tasks**: Platform limit on parallel task execution.
        - **max_storage_gb**: Storage limit for swarm results and logs.

        **Performance:**

        - Streaming is efficient; fetches swarms in batches from database.
        - Suitable for large swarm inventories (100+ swarms).
        - First swarm typically arrives within 100ms.
        - Processing time scales linearly with swarm count.

        **Common Use Cases:**

        - Swarm inventory and reporting
        - Resource usage monitoring
        - Automated cleanup of old/completed swarms
        - Finding swarms by name, status, or other criteria
        - Bulk status checks across all swarms

        **Swarm Lifecycle Timestamps:**

        - **created_at**: When swarm was first deployed (never changes).
        - **last_start**: Most recent start time (or Unix epoch if never started).
        - **last_stop**: Most recent stop time (or Unix epoch if never stopped).
        - Timestamps are timezone-aware (UTC).

        See Also
        --------
        stream_and_fetch_swarms : Collect all swarms into a list (simpler but less memory efficient)
        list_swarm_ids : Get just the swarm IDs (faster, no full details)
        get_swarm : Get complete details for a specific swarm
        deploy_swarm : Create and start a new swarm
        """
        async for swarm in self._swarm_management_client.stream_swarms():
            yield swarm

    async def stream_and_fetch_swarms(self) -> List[SwarmProto]:
        """
        Fetch all swarms owned by the authenticated user as a complete list.

        This method collects all swarms from the streaming endpoint and returns them as
        a complete list. It's a convenience wrapper around `stream_swarms()` for cases
        where you need to work with the full swarm collection at once, such as sorting,
        filtering with multiple conditions, or batch analysis.

        For large swarm inventories or memory-constrained environments, prefer the
        streaming version `stream_swarms()` which processes swarms incrementally.

        Returns
        -------
        List[SwarmProto]
            Complete list of all swarms owned by the user. Each SwarmProto contains:

            - swarm_id : str - Unique identifier (UUID format)
            - cluster_id : str - Cluster where swarm is deployed
            - owner_id : str - User ID of the swarm creator
            - name : str - Swarm name (from Swarm class definition)
            - created_at : datetime - Swarm creation timestamp
            - last_start : datetime - Most recent start time
            - last_stop : datetime - Most recent stop time
            - status : str - Current status ("PENDING", "ACTIVE", "STOPPED", "COMPLETED")
            - iteration : int - Current execution iteration (starts at 0)
            - circular : int - Number of complete cycles through task graph
            - authorization : dict - Quotas and permissions for this swarm

            Returns an empty list if the user has not created any swarms.

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks permission to list swarms (requires 'read' permission).

        Examples
        --------
        Get all swarms for comprehensive analysis:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> all_swarms = await api.stream_and_fetch_swarms()
        >>> print(f"Total swarms: {len(all_swarms)}")
        Total swarms: 7
        >>> for swarm in all_swarms:
        ...     print(f"{swarm.name}: {swarm.status}")
        FederatedMNIST: ACTIVE
        ImageClassifier: COMPLETED
        SentimentAnalysis: STOPPED

        Sort swarms by creation date to find newest/oldest:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> swarms = await api.stream_and_fetch_swarms()
        >>> # Sort by creation date (newest first)
        >>> sorted_swarms = sorted(swarms, key=lambda s: s.created_at, reverse=True)
        >>> print(f"Newest swarm: {sorted_swarms[0].name}")
        Newest swarm: TextGeneration
        >>> # Sort by last activity (oldest first)
        >>> by_activity = sorted(swarms, key=lambda s: s.last_start)
        >>> print(f"Least recently used: {by_activity[0].name}")
        Least recently used: OldExperiment

        Filter swarms with complex conditions (multiple criteria):

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> swarms = await api.stream_and_fetch_swarms()
        >>> # Find active swarms using >5GB storage
        >>> high_usage = [
        ...     s for s in swarms
        ...     if s.status == "ACTIVE" and
        ...        s.authorization["quotas"]["current_storage_gb"] > 5.0
        ... ]
        >>> print(f"High storage swarms: {len(high_usage)}")
        High storage swarms: 2

        Generate summary report across all swarms:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> swarms = await api.stream_and_fetch_swarms()
        >>> # Calculate aggregate statistics
        >>> total_storage = sum(
        ...     s.authorization["quotas"]["current_storage_gb"]
        ...     for s in swarms
        ... )
        >>> active_count = sum(1 for s in swarms if s.status == "ACTIVE")
        >>> print(f"Total storage: {total_storage:.2f} GB")
        >>> print(f"Active swarms: {active_count}/{len(swarms)}")
        Total storage: 12.45 GB
        Active swarms: 3/7

        Find oldest completed swarms for cleanup (quota management):

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> swarms = await api.stream_and_fetch_swarms()
        >>> # Find completed swarms, sorted by completion time
        >>> completed = [s for s in swarms if s.status == "COMPLETED"]
        >>> completed.sort(key=lambda s: s.last_stop)
        >>> # Delete oldest 3 to free up quota
        >>> for swarm in completed[:3]:
        ...     await api.remove_swarm(swarm.swarm_id)
        ...     print(f"Deleted old swarm: {swarm.name}")
        Deleted old swarm: OldExperiment1
        Deleted old swarm: TestSwarm2
        Deleted old swarm: DeprecatedModel

        Notes
        -----
        **Memory Considerations:**
        - All swarms are loaded into memory as a list. For users with many swarms
          (approaching the quota limit of ~10 swarms), this typically uses <10MB.
        - If you only need to process swarms one at a time, use `stream_swarms()`
          instead to minimize memory usage.
        - The entire list is materialized before the method returns, so there's a
          brief latency before you receive any results.

        **Performance Characteristics:**
        - Typical query time: 50-200ms for retrieving all swarms from the database
        - List materialization adds ~10-50ms depending on swarm count
        - Total time: usually <250ms for a user's full swarm inventory
        - Network latency may add 20-100ms depending on connection

        **RBAC & Authorization:**
        - Requires 'read' permission on swarm resources (automatically granted to owners)
        - Only returns swarms where the user is the owner (owner_id matches user_id)
        - Users cannot see swarms created by other users, even on shared clusters
        - Admins see only their own swarms unless they have explicit 'admin' permissions

        **Swarm Status Values:**
        - "PENDING": Swarm created but never started (initial state after deploy_swarm)
        - "ACTIVE": Swarm currently executing tasks across cluster nodes
        - "STOPPED": Swarm paused; can be restarted with start_swarm()
        - "COMPLETED": All tasks finished; swarm stopped automatically

        **Use Cases:**
        - Batch operations requiring sorting, filtering, or aggregation
        - Generating reports or dashboards with swarm statistics
        - Finding swarms based on multiple criteria (status + storage + date)
        - Quota management: identifying swarms to delete when approaching limit
        - Snapshot analysis: capturing swarm inventory at a specific point in time

        **When to Use stream_swarms() Instead:**
        - Processing each swarm independently without needing the full list
        - Working in memory-constrained environments
        - Implementing real-time monitoring or incremental processing
        - Need to start processing before all swarms are retrieved

        See Also
        --------
        stream_swarms : Stream swarms incrementally (more memory-efficient)
        list_swarm_ids : Get only swarm IDs without full details (faster)
        get_swarm : Get details for a specific swarm by ID
        list_cluster_ids : List clusters where swarms can be deployed
        remove_swarm : Delete swarm to free up quota space
        """
        swarms = []
        async for swarm in self.stream_swarms():
            swarms.append(swarm)
        return swarms

    async def get_swarm(self, swarm_id: str) -> SwarmProto:
        """
        Retrieve detailed information about a specific swarm by ID.

        This method fetches the complete swarm definition and current execution state
        for the specified swarm. Use this to inspect swarm configuration, monitor
        execution progress, check resource usage, or verify swarm state before
        performing operations like starting, stopping, or deletion.

        The swarm must be owned by the authenticated user or the user must have
        explicit 'read' permission for this swarm.

        Parameters
        ----------
        swarm_id : str
            Unique identifier of the swarm to retrieve (UUID format,
            32-character hexadecimal string without hyphens, e.g.,
            '9415dfd18edc45c9a6ffdf2055007bf9'). Obtain swarm IDs from
            `list_swarm_ids()`, `stream_swarms()`, or the return value
            of `deploy_swarm()`.

        Returns
        -------
        SwarmProto
            Complete swarm object containing definition and execution state:

            - swarm_id : str - Unique identifier (matches input parameter)
            - cluster_id : str - Cluster where swarm is deployed
            - owner_id : str - User ID of the swarm creator
            - name : str - Swarm name (from Swarm class definition, e.g., 'FederatedMNIST')
            - created_at : datetime - Timestamp when swarm was created
            - last_start : datetime - Most recent start time (epoch zero if never started)
            - last_stop : datetime - Most recent stop time (epoch zero if never stopped)
            - status : str - Current execution status:
              - "PENDING": Created but not yet started
              - "ACTIVE": Currently executing tasks
              - "STOPPED": Paused (can be resumed with start_swarm)
              - "COMPLETED": Finished all iterations
            - iteration : int - Current execution iteration (0-based, increments each
              time task graph completes)
            - circular : int - Number of complete cycles through the task graph (0-based)
            - authorization : dict - Resource quotas and permissions:
              - quotas.max_storage_gb : float - Maximum storage allowed
              - quotas.current_storage_gb : float - Current storage usage
              - quotas.max_concurrent_tasks : int - Maximum concurrent tasks
              - quotas.current_concurrent_tasks : int - Currently running tasks
              - permissions : list - Explicit permissions granted to other users

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks 'read' permission for this swarm. This occurs when:
            - The swarm is owned by another user AND
            - The user has not been granted explicit 'read' permission
        ResourceNotFoundError
            If the swarm_id does not exist in the database.
        ValidationError
            If swarm_id is not a valid UUID format.

        Examples
        --------
        Check swarm status after deployment:

        >>> # Deploy swarm and immediately check its state
        >>> swarm_overview = await api.deploy_swarm(cluster_id, my_swarm)
        >>> swarm = await api.get_swarm(swarm_overview['swarm_id'])
        >>> print(f"Swarm '{swarm.name}' status: {swarm.status}")
        >>> print(f"Created at: {swarm.created_at}")
        >>> if swarm.status == "ACTIVE":
        ...     print(f"Currently on iteration {swarm.iteration}")
        Swarm 'FederatedLearning' status: ACTIVE
        Created at: 2024-01-15 14:30:22
        Currently on iteration 0

        Monitor execution progress during long-running swarm:

        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"Progress: {swarm.iteration} iterations, {swarm.circular} cycles")
        >>> print(f"Status: {swarm.status}")
        >>> print(f"Running since: {swarm.last_start}")
        Progress: 15 iterations, 2 cycles
        Status: ACTIVE
        Running since: 2024-01-15 14:30:25

        Check resource usage before deploying additional tasks:

        >>> swarm = await api.get_swarm(swarm_id)
        >>> quotas = swarm.authorization['quotas']
        >>> storage_pct = (quotas['current_storage_gb'] / quotas['max_storage_gb']) * 100
        >>> tasks_pct = (quotas['current_concurrent_tasks'] / quotas['max_concurrent_tasks']) * 100
        >>> print(f"Storage usage: {storage_pct:.1f}%")
        >>> print(f"Task slots: {tasks_pct:.1f}%")
        >>> if storage_pct > 80:
        ...     print("Warning: Storage quota nearly exhausted")
        Storage usage: 45.2%
        Task slots: 20.0%

        Verify swarm state before performing operations:

        >>> # Check if swarm is running before attempting to stop it
        >>> swarm = await api.get_swarm(swarm_id)
        >>> if swarm.status == "ACTIVE":
        ...     await api.stop_swarm(swarm_id)
        ...     print("Swarm stopped successfully")
        >>> elif swarm.status == "STOPPED":
        ...     print("Swarm is already stopped")
        >>> elif swarm.status == "PENDING":
        ...     print("Swarm has not been started yet")
        Swarm stopped successfully

        Inspect swarm details before deletion:

        >>> # Verify swarm contents before permanent deletion
        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"About to delete swarm: {swarm.name}")
        >>> print(f"Status: {swarm.status}")
        >>> print(f"Storage used: {swarm.authorization['quotas']['current_storage_gb']:.2f} GB")
        >>> confirm = input("Confirm deletion (yes/no): ")
        >>> if confirm.lower() == "yes":
        ...     await api.remove_swarm(swarm_id)
        ...     print("Swarm deleted and quota freed")
        About to delete swarm: ExperimentalModel
        Status: COMPLETED
        Storage used: 1.25 GB
        Confirm deletion (yes/no): yes
        Swarm deleted and quota freed

        Notes
        -----
        **Performance:**
        - This is a direct database lookup by swarm_id (indexed field).
        - Typical response time: 10-30ms.
        - Does not retrieve result data or logs (use `stream_results` or `collect_logs`).
        - The authorization section includes current quota usage computed in real-time.

        **RBAC (Role-Based Access Control):**
        - Users can always access their own swarms.
        - For swarms owned by others, explicit 'read' permission is required.
        - Permissions are managed via `update_user_authorization()` (admin-only).
        - The returned authorization object shows quotas and permissions for this swarm.

        **Swarm Status Lifecycle:**
        - PENDING → ACTIVE (via start_swarm)
        - ACTIVE → STOPPED (via stop_swarm)
        - STOPPED → ACTIVE (via start_swarm - resumes)
        - ACTIVE/STOPPED/PENDING → deleted (via remove_swarm - permanent)
        - ACTIVE → COMPLETED (automatically when all iterations finish)

        **Iteration vs Circular Counters:**
        - iteration: Increments each time the task graph completes one full execution
        - circular: Tracks complete cycles through the entire swarm workflow
        - Both start at 0 when swarm is created
        - Useful for monitoring progress in iterative algorithms (e.g., federated learning rounds)

        **Use Cases:**
        - Monitoring swarm execution progress in dashboards or CLIs
        - Checking swarm state before operations (start, stop, delete)
        - Inspecting resource usage to avoid quota violations
        - Validating swarm configuration after deployment
        - Retrieving swarm metadata for logging or auditing

        **When NOT to Use:**
        - For listing all swarms → use `stream_swarms()` or `list_swarm_ids()`
        - For task-level details → use `stream_swarm_tasks()` after getting swarm
        - For result data → use `stream_results()` with the swarm_id
        - For execution logs → use `collect_logs()` with the swarm_id

        See Also
        --------
        deploy_swarm : Create and start a new swarm on a cluster
        start_swarm : Start or resume swarm execution
        stop_swarm : Pause swarm execution (preserves state)
        remove_swarm : Permanently delete swarm and free quota
        stream_swarms : List all swarms owned by user
        list_swarm_ids : Get swarm IDs without full details (faster)
        stream_swarm_tasks : Get task-level execution details
        stream_results : Retrieve result data produced by swarm
        collect_logs : Get execution logs for debugging
        """
        return await self._swarm_management_client.get_swarm(swarm_id)

    async def stream_swarm_tasks(self, swarm_id: str) -> AsyncIterator[TaskResponse]:
        """
        Stream real-time task status updates for all tasks in a swarm.

        This method returns an asynchronous iterator that yields task status updates as they
        become available from the platform. Each yielded TaskResponse contains the current
        execution state of a task including its status (PENDING, RUNNING, COMPLETED, FAILED),
        assigned node, iteration progress, and timing information. The stream continues until
        all tasks have been retrieved or the swarm completes execution.

        Use this method to monitor swarm execution in real-time, track task progress across
        iterations, identify failed tasks for debugging, or build live dashboards showing
        current task distribution across nodes. The streaming approach is memory-efficient
        for swarms with many tasks, as tasks are processed incrementally rather than loading
        all task data into memory at once.

        For non-streaming access that collects all tasks into a list, use
        `stream_and_fetch_tasks()` instead. For high-level swarm status without task details,
        use `get_swarm()`.

        Parameters
        ----------
        swarm_id : str
            Unique identifier of the swarm to monitor (UUID format, 32-character
            hexadecimal string without hyphens, e.g., '9415dfd18edc45c9a6ffdf2055007bf9').
            Obtain swarm IDs from `deploy_swarm()` return value, `list_swarm_ids()`,
            or `stream_swarms()`.

        Returns
        -------
        AsyncIterator[TaskResponse]
            Asynchronous iterator yielding TaskResponse objects with the following fields:

            - task_id : str
                Unique identifier for this task instance (UUID format)
            - task_name : str
                Human-readable task name from swarm graph definition
            - swarm_id : str
                Swarm this task belongs to
            - node_id : str
                Node currently executing this task (empty if not yet assigned)
            - status : str
                Current task execution status. Values:
                - "PENDING": Task created but not yet started
                - "RUNNING": Task currently executing on a node
                - "COMPLETED": Task finished successfully
                - "FAILED": Task encountered an error
                - "TERMINATED": Task was forcefully stopped
            - iteration : int
                Current swarm iteration this task is executing (0-indexed)
            - circular : int
                Circular counter for cyclic task graphs (0 if non-cyclic)
            - created_at : datetime
                Timestamp when task was created
            - started_at : datetime
                Timestamp when task execution began (null if not started)
            - completed_at : datetime
                Timestamp when task finished (null if not completed)
            - error_message : str
                Error details if status is "FAILED" (empty otherwise)

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks permission to view tasks for this swarm. This occurs when:
            - The swarm is owned by another user AND
            - The user has not been granted explicit 'read' permission
        ResourceNotFoundError
            If the swarm_id does not exist in the database.
        ValidationError
            If the swarm_id is not a valid UUID format.
        ConnectionError
            If the gRPC connection to the server is lost during streaming.

        Examples
        --------
        Monitor task execution progress in real-time:

        >>> # Start streaming task updates
        >>> print("Monitoring swarm execution...")
        >>> async for task in api.stream_swarm_tasks(swarm_id):
        ...     print(f"Task: {task.task_name}")
        ...     print(f"  Status: {task.status}")
        ...     print(f"  Node: {task.node_id[:8] if task.node_id else 'unassigned'}")
        ...     print(f"  Iteration: {task.iteration}")
        ...     print()
        Monitoring swarm execution...
        Task: worker-0
          Status: RUNNING
          Node: a2ff3abc
          Iteration: 5

        Task: worker-1
          Status: RUNNING
          Node: b3ee4bcd
          Iteration: 5

        Task: aggregator-0
          Status: COMPLETED
          Node: a2ff3abc
          Iteration: 5

        Filter tasks by status to identify failures:

        >>> # Find all failed tasks for debugging
        >>> failed_tasks = []
        >>> async for task in api.stream_swarm_tasks(swarm_id):
        ...     if task.status == "FAILED":
        ...         failed_tasks.append(task)
        ...         print(f"Failed: {task.task_name} on {task.node_id[:8]}")
        ...         print(f"  Error: {task.error_message}")
        Failed: worker-2 on c4ff5cde
          Error: CUDA out of memory
        >>>
        >>> print(f"Total failed tasks: {len(failed_tasks)}")
        Total failed tasks: 1

        Track task progress across iterations:

        >>> # Monitor training progress across federated learning rounds
        >>> import asyncio
        >>> from collections import defaultdict
        >>>
        >>> # Count tasks by status for each iteration
        >>> iteration_progress = defaultdict(lambda: defaultdict(int))
        >>>
        >>> async for task in api.stream_swarm_tasks(swarm_id):
        ...     iteration_progress[task.iteration][task.status] += 1
        >>>
        >>> # Display progress summary
        >>> for iteration in sorted(iteration_progress.keys()):
        ...     counts = iteration_progress[iteration]
        ...     print(f"Iteration {iteration}:")
        ...     print(f"  Completed: {counts['COMPLETED']}")
        ...     print(f"  Running: {counts['RUNNING']}")
        ...     print(f"  Pending: {counts['PENDING']}")
        Iteration 0:
          Completed: 5
          Running: 0
          Pending: 0
        Iteration 1:
          Completed: 3
          Running: 2
          Pending: 0

        Debug failed tasks with detailed timing:

        >>> # Analyze task execution times to identify slow or stuck tasks
        >>> async for task in api.stream_swarm_tasks(swarm_id):
        ...     if task.status == "FAILED":
        ...         if task.started_at and task.completed_at:
        ...             duration = (task.completed_at - task.started_at).total_seconds()
        ...             print(f"Task {task.task_name} failed after {duration:.1f}s")
        ...             print(f"  Error: {task.error_message}")
        ...         else:
        ...             print(f"Task {task.task_name} failed before starting")
        Task worker-1 failed after 45.3s
          Error: Connection timeout to aggregator
        Task worker-3 failed before starting
          Error: Node disconnected during task assignment

        Build live dashboard with task distribution:

        >>> # Display current task distribution across nodes
        >>> from collections import defaultdict
        >>>
        >>> node_tasks = defaultdict(list)
        >>> async for task in api.stream_swarm_tasks(swarm_id):
        ...     if task.status == "RUNNING":
        ...         node_tasks[task.node_id[:8]].append(task.task_name)
        >>>
        >>> # Print active tasks per node
        >>> for node_id, tasks in node_tasks.items():
        ...     print(f"Node {node_id}: {len(tasks)} tasks")
        ...     for task_name in tasks:
        ...         print(f"  - {task_name}")
        Node a2ff3abc: 2 tasks
          - worker-0
          - aggregator-0
        Node b3ee4bcd: 2 tasks
          - worker-1
          - worker-2
        Node c4ff5cde: 1 tasks
          - worker-3

        Notes
        -----
        **RBAC (Role-Based Access Control):**
        - Users can always view tasks for their own swarms.
        - For swarms owned by others, explicit 'read' permission is required.
        - Permissions are managed via `update_user_authorization()` (admin-only).
        - Task data includes node assignments, which may reveal cluster topology.

        **AsyncIterator Pattern:**
        - This method returns an async generator that yields tasks incrementally.
        - Use `async for` to iterate over task updates.
        - Tasks are yielded as they become available from the database.
        - The iterator completes when all tasks have been retrieved.
        - For non-streaming access, use `stream_and_fetch_tasks()` to get a list.

        **Task Status Values:**
        - "PENDING": Task created, waiting for node assignment and execution start
        - "RUNNING": Task actively executing on assigned node
        - "COMPLETED": Task finished successfully, results saved
        - "FAILED": Task encountered error during execution
        - "TERMINATED": Task forcefully stopped (via `stop_swarm()` or node failure)

        **Performance:**
        - Streaming is efficient for swarms with many tasks (100+ tasks).
        - Tasks are yielded incrementally, avoiding large memory allocation.
        - Typical latency: 10-50ms per task yielded.
        - Total stream time depends on task count and database query performance.
        - Use `stream_and_fetch_tasks()` if you need all tasks in memory for processing.

        **Real-Time Updates:**
        - This method retrieves task state from the database, not live from nodes.
        - Task status updates occur when nodes report progress via gRPC.
        - Typical update frequency: Every 1-5 seconds during active execution.
        - For immediate task state, nodes report to platform asynchronously.
        - Task status reflects last known state; nodes may have progressed further.

        **Task Lifecycle:**
        Task status transitions follow this flow:
        - PENDING → RUNNING (task starts executing on node)
        - RUNNING → COMPLETED (task finishes successfully)
        - RUNNING → FAILED (task encounters error)
        - RUNNING → TERMINATED (task stopped forcefully)
        - PENDING → TERMINATED (task cancelled before starting)

        **Filtering Strategies:**
        - Filter by status: `if task.status == "FAILED"` to find errors
        - Filter by iteration: `if task.iteration == 5` to track specific round
        - Filter by node: `if task.node_id == node_id` to see node workload
        - Filter by timing: `if task.completed_at` to find finished tasks
        - Combine filters: `if task.status == "RUNNING" and task.iteration > 3`

        **Error Recovery:**
        - If streaming fails mid-iteration (e.g., network error), call again to restart.
        - Tasks already yielded are not re-yielded (iterator position is not preserved).
        - Failed tasks remain in "FAILED" status until swarm is removed.
        - Use `stop_swarm()` to stop execution if many tasks are failing.
        - Check `task.error_message` for debugging information.

        **Use Cases:**
        - Monitor federated learning training progress across iterations
        - Identify and debug failed tasks in distributed simulations
        - Build real-time dashboards showing cluster task distribution
        - Track task execution times to optimize resource allocation
        - Verify all tasks completed before retrieving aggregated results

        **Memory Considerations:**
        - AsyncIterator approach uses minimal memory regardless of task count.
        - Each task is processed and can be discarded before next task is yielded.
        - For large swarms (1000+ tasks), streaming is significantly more efficient than list.
        - If you need to keep all tasks in memory, use `stream_and_fetch_tasks()`.

        **When to Use stream_swarm_tasks() vs stream_and_fetch_tasks():**
        - Use `stream_swarm_tasks()` for:
          - Real-time monitoring and progress tracking
          - Processing tasks incrementally (memory-efficient)
          - Finding specific tasks (can break early)
          - Building live dashboards with continuous updates
        - Use `stream_and_fetch_tasks()` for:
          - Need all tasks in a list for batch processing
          - Want to sort or filter tasks in memory
          - Simple data extraction without real-time requirements

        **Task Count Expectations:**
        - Small swarms: 5-20 tasks (single iteration)
        - Medium swarms: 50-200 tasks (federated learning with 10+ workers)
        - Large swarms: 500-5000 tasks (multi-iteration training over many rounds)
        - Very large swarms: 10,000+ tasks (long-running simulations)

        See Also
        --------
        stream_and_fetch_tasks : Collect all tasks into a list (non-streaming)
        get_swarm : Get high-level swarm status without task details
        deploy_swarm : Create and start a swarm
        stop_swarm : Stop swarm execution (terminates all tasks)
        stream_results : Monitor result generation alongside task execution
        collect_logs : Retrieve logs from failed tasks for debugging
        stream_swarms : Monitor multiple swarms across clusters
        list_swarm_ids : List all available swarms
        """
        async for task in self._swarm_management_client.stream_swarm_tasks(swarm_id):
            yield task

    async def stream_and_fetch_tasks(self, swarm_id: str) -> List[TaskResponse]:
        """
        Retrieve all tasks for a swarm and return them as a list.

        This convenience method streams all task status updates for a swarm using
        `stream_swarm_tasks()` and collects them into a list for easier batch processing,
        sorting, and filtering. Unlike the streaming approach, this method waits until all
        tasks have been retrieved before returning, making the entire task collection
        available in memory at once.

        Use this method when you need to perform batch operations on tasks (sorting,
        grouping, aggregation), want simpler code without async iteration, or need to
        access tasks multiple times. For memory-efficient incremental processing or
        real-time monitoring, use `stream_swarm_tasks()` directly.

        For high-level swarm status without detailed task information, use `get_swarm()`
        instead.

        Parameters
        ----------
        swarm_id : str
            Unique identifier of the swarm to query (UUID format, 32-character
            hexadecimal string without hyphens, e.g., '9415dfd18edc45c9a6ffdf2055007bf9').
            Obtain swarm IDs from `deploy_swarm()` return value, `list_swarm_ids()`,
            or `stream_swarms()`.

        Returns
        -------
        List[TaskResponse]
            List of all tasks in the swarm, where each TaskResponse contains:

            - task_id : str
                Unique identifier for this task instance (UUID format)
            - task_name : str
                Human-readable task name from swarm graph definition
            - swarm_id : str
                Swarm this task belongs to
            - node_id : str
                Node currently executing this task (empty if not yet assigned)
            - status : str
                Current task execution status ("PENDING", "RUNNING", "COMPLETED",
                "FAILED", "TERMINATED")
            - iteration : int
                Current swarm iteration this task is executing (0-indexed)
            - circular : int
                Circular counter for cyclic task graphs (0 if non-cyclic)
            - created_at : datetime
                Timestamp when task was created
            - started_at : datetime
                Timestamp when task execution began (null if not started)
            - completed_at : datetime
                Timestamp when task finished (null if not completed)
            - error_message : str
                Error details if status is "FAILED" (empty otherwise)

            Tasks are returned in the order yielded by the streaming API, which is
            typically sorted by task creation time. The list is empty if the swarm
            has no tasks.

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks permission to view tasks for this swarm. This occurs when:
            - The swarm is owned by another user AND
            - The user has not been granted explicit 'read' permission
        ResourceNotFoundError
            If the swarm_id does not exist in the database.
        ValidationError
            If the swarm_id is not a valid UUID format.
        ConnectionError
            If the gRPC connection to the server is lost during task retrieval.

        Examples
        --------
        Get all tasks and count by status:

        >>> # Fetch all tasks into a list
        >>> tasks = await api.stream_and_fetch_tasks(swarm_id)
        >>> print(f"Total tasks: {len(tasks)}")
        Total tasks: 25
        >>>
        >>> # Count tasks by status
        >>> from collections import Counter
        >>> status_counts = Counter(task.status for task in tasks)
        >>> for status, count in status_counts.items():
        ...     print(f"{status}: {count}")
        COMPLETED: 20
        RUNNING: 3
        FAILED: 2

        Sort tasks by execution time:

        >>> # Get all tasks and sort by duration
        >>> tasks = await api.stream_and_fetch_tasks(swarm_id)
        >>>
        >>> # Filter and sort completed tasks by execution time
        >>> completed = [t for t in tasks if t.status == "COMPLETED" and t.started_at]
        >>> completed_sorted = sorted(
        ...     completed,
        ...     key=lambda t: (t.completed_at - t.started_at).total_seconds(),
        ...     reverse=True
        ... )
        >>>
        >>> # Display slowest tasks
        >>> print("Slowest tasks:")
        >>> for task in completed_sorted[:5]:
        ...     duration = (task.completed_at - task.started_at).total_seconds()
        ...     print(f"{task.task_name}: {duration:.1f}s")
        Slowest tasks:
        worker-4: 125.3s
        worker-2: 118.7s
        aggregator-0: 95.2s
        worker-1: 87.6s
        worker-0: 82.4s

        Group tasks by node for load analysis:

        >>> # Analyze task distribution across nodes
        >>> tasks = await api.stream_and_fetch_tasks(swarm_id)
        >>> from collections import defaultdict
        >>>
        >>> # Group by node ID
        >>> tasks_by_node = defaultdict(list)
        >>> for task in tasks:
        ...     if task.node_id:  # Skip unassigned tasks
        ...         tasks_by_node[task.node_id[:8]].append(task)
        >>>
        >>> # Calculate node workloads
        >>> for node_id, node_tasks in tasks_by_node.items():
        ...     completed = sum(1 for t in node_tasks if t.status == "COMPLETED")
        ...     failed = sum(1 for t in node_tasks if t.status == "FAILED")
        ...     print(f"Node {node_id}: {completed} completed, {failed} failed")
        Node a2ff3abc: 8 completed, 0 failed
        Node b3ee4bcd: 7 completed, 1 failed
        Node c4ff5cde: 5 completed, 1 failed

        Filter and export failed tasks to JSON:

        >>> # Extract failed tasks for debugging
        >>> tasks = await api.stream_and_fetch_tasks(swarm_id)
        >>> failed_tasks = [
        ...     {
        ...         'task_name': t.task_name,
        ...         'node_id': t.node_id,
        ...         'iteration': t.iteration,
        ...         'error_message': t.error_message,
        ...         'started_at': t.started_at.isoformat() if t.started_at else None,
        ...         'failed_at': t.completed_at.isoformat() if t.completed_at else None
        ...     }
        ...     for t in tasks if t.status == "FAILED"
        ... ]
        >>>
        >>> # Save to file for analysis
        >>> import json
        >>> with open('failed_tasks.json', 'w') as f:
        ...     json.dump(failed_tasks, f, indent=2)
        >>> print(f"Saved {len(failed_tasks)} failed tasks to failed_tasks.json")
        Saved 2 failed tasks to failed_tasks.json

        Batch process tasks with multiple filters:

        >>> # Complex filtering and aggregation
        >>> tasks = await api.stream_and_fetch_tasks(swarm_id)
        >>>
        >>> # Find tasks from latest iteration that failed
        >>> max_iteration = max(t.iteration for t in tasks)
        >>> recent_failures = [
        ...     t for t in tasks
        ...     if t.iteration == max_iteration and t.status == "FAILED"
        ... ]
        >>>
        >>> # Calculate failure rate for latest iteration
        >>> latest_tasks = [t for t in tasks if t.iteration == max_iteration]
        >>> failure_rate = len(recent_failures) / len(latest_tasks) * 100
        >>> print(f"Iteration {max_iteration} failure rate: {failure_rate:.1f}%")
        >>> print(f"Failed tasks: {[t.task_name for t in recent_failures]}")
        Iteration 5 failure rate: 8.0%
        Failed tasks: ['worker-2']

        Notes
        -----
        **RBAC (Role-Based Access Control):**
        - Users can always view tasks for their own swarms.
        - For swarms owned by others, explicit 'read' permission is required.
        - Permissions are managed via `update_user_authorization()` (admin-only).
        - Task data includes node assignments and execution details.

        **Memory Usage:**
        - All tasks are loaded into memory at once.
        - For small swarms (< 100 tasks), memory impact is negligible.
        - For medium swarms (100-1000 tasks), expect ~1-5 MB memory usage.
        - For large swarms (1000-10,000 tasks), expect ~10-50 MB memory usage.
        - For very large swarms (> 10,000 tasks), consider using `stream_swarm_tasks()`
          with incremental processing to avoid excessive memory consumption.

        **Performance:**
        - Total retrieval time depends on task count and database performance.
        - Typical performance: 50-200ms for 100 tasks, 200-500ms for 1000 tasks.
        - Method waits for all tasks before returning (not incremental).
        - Subsequent operations on the returned list are in-memory (very fast).
        - Use `stream_swarm_tasks()` for real-time monitoring without waiting.

        **List Operations:**
        - Returned list can be sorted, filtered, and processed multiple times.
        - Use list comprehensions for filtering: `[t for t in tasks if t.status == "FAILED"]`
        - Use `sorted()` for sorting: `sorted(tasks, key=lambda t: t.iteration)`
        - Use `collections.Counter()` for counting: `Counter(t.status for t in tasks)`
        - Use `groupby()` for grouping: `groupby(tasks, key=lambda t: t.node_id)`

        **Task Status Values:**
        - "PENDING": Task created, waiting for execution
        - "RUNNING": Task actively executing on assigned node
        - "COMPLETED": Task finished successfully
        - "FAILED": Task encountered error
        - "TERMINATED": Task forcefully stopped

        **Ordering:**
        - Tasks are returned in database insertion order (typically by creation time).
        - To sort by iteration: `sorted(tasks, key=lambda t: t.iteration)`
        - To sort by status: `sorted(tasks, key=lambda t: t.status)`
        - To sort by node: `sorted(tasks, key=lambda t: t.node_id or '')`

        **Empty Results:**
        - Returns empty list if swarm has no tasks (newly created swarm).
        - Returns empty list if all tasks have been removed (unusual case).
        - Check `len(tasks) == 0` to detect empty results.

        **Error Recovery:**
        - If method fails (network error), entire operation must be retried.
        - Partial results are not returned on error.
        - Use `stream_swarm_tasks()` for more resilient incremental retrieval.

        **Use Cases:**
        - Batch analysis of task execution metrics
        - Generating reports with task statistics
        - Sorting and filtering tasks by multiple criteria
        - Exporting task data to JSON/CSV for external tools
        - Calculating aggregated metrics (failure rates, average duration)

        **When to Use stream_and_fetch_tasks() vs stream_swarm_tasks():**
        - Use `stream_and_fetch_tasks()` for:
          - Batch processing requiring all tasks in memory
          - Sorting or filtering tasks by multiple attributes
          - Multiple passes over task data
          - Simple code without async iteration complexity
          - Small to medium swarms (< 1000 tasks)

        - Use `stream_swarm_tasks()` for:
          - Real-time monitoring and progress tracking
          - Memory-efficient processing of large swarms (> 1000 tasks)
          - Early termination when finding specific tasks
          - Live dashboards with continuous updates
          - Processing tasks incrementally as they arrive

        **Batch Processing Patterns:**
        - Count by attribute: `Counter(t.status for t in tasks)`
        - Filter: `[t for t in tasks if t.status == "FAILED"]`
        - Sort: `sorted(tasks, key=lambda t: t.iteration)`
        - Group: `{k: list(v) for k, v in groupby(tasks, key=lambda t: t.node_id)}`
        - Aggregate: `sum(1 for t in tasks if t.status == "COMPLETED")`

        **Implementation Details:**
        - Internally calls `stream_swarm_tasks()` and collects results.
        - Waits for all tasks to be yielded before returning.
        - No additional network overhead compared to streaming approach.
        - Convenience wrapper for simpler code when list is needed.

        See Also
        --------
        stream_swarm_tasks : Stream tasks incrementally (memory-efficient)
        get_swarm : Get high-level swarm status without task details
        deploy_swarm : Create and start a swarm
        stop_swarm : Stop swarm execution (terminates all tasks)
        stream_results : Retrieve result data from completed tasks
        collect_logs : Get execution logs for debugging
        stream_swarms : Monitor multiple swarms
        """
        tasks = []
        async for task in self.stream_swarm_tasks(swarm_id):
            tasks.append(task)
        return tasks

    async def get_tasks(self, swarm_id: str) -> List[TaskResponse]:
        """
        Get all tasks for a swarm.

        Parameters
        ----------
        swarm_id : str
            Swarm ID

        Returns
        -------
        List[TaskResponse]
            List of tasks with status, node_id, iteration info

        Examples
        --------
        >>> tasks = await user_api.get_tasks(swarm_id)
        >>> for task in tasks:
        ...     print(f"{task.task_id}: {task.status}")
        """
        return await self.stream_and_fetch_tasks(swarm_id)

    async def send_swarm(self, cluster_id: str, swarm: Swarm) -> SwarmProto:
        """
        Create a swarm in the database and prepare it for execution on a cluster.

        This method uploads the swarm definition (task graph, modules, global parameters,
        and networks) to the platform without starting execution. The swarm is created
        with status "PENDING" and must be explicitly started using `start_swarm()`.
        Use this method when you need to create a swarm but delay execution, or when
        you want to separate swarm creation from execution control.

        For most use cases, prefer `deploy_swarm()` which combines `send_swarm()` and
        `start_swarm()` into a single operation.

        The method performs several operations atomically:
        1. Uploads all modules referenced in the task graph (if not already uploaded)
        2. Creates the task graph structure with task dependencies
        3. Uploads global parameters defined in the swarm
        4. Configures custom networks for inter-task communication
        5. Returns swarm overview with newly assigned swarm_id

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster where the swarm will be deployed (UUID format,
            32-character hexadecimal string without hyphens, e.g.,
            '90700570a2ce4b1891b32341a192fc1a'). The cluster must be in "RUNNING" status
            and owned by the authenticated user. Obtain cluster IDs from `list_cluster_ids()`
            or `stream_clusters()`.
        swarm : Swarm
            Swarm instance defining the computational workflow. Must be a subclass of the
            `Swarm` base class with an implemented `execute()` method that returns the task
            graph. Common examples: FLSwarm (federated learning), SimpleSwarm (basic tasks),
            or custom Swarm subclasses.

            The swarm object contains:
            - Task graph: Defined by the `execute()` method
            - Global parameters: Set via `set_global(tag, value)`
            - Custom networks: Added via `add_network(name, driver)`
            - Swarm name: Class attribute `name` (default: "Swarm")

        Returns
        -------
        Dict[str, Any]
            Swarm overview dictionary with the following keys:

            - swarm_id : str - Newly assigned unique identifier (UUID format)
            - cluster_id : str - Cluster where swarm is deployed (matches input)
            - owner_id : str - User ID of the swarm creator (from JWT token)
            - name : str - Swarm name (from swarm.name class attribute)
            - created_at : datetime - Timestamp when swarm was created
            - last_start : datetime - Start time (epoch zero since not started yet)
            - last_stop : datetime - Stop time (epoch zero)
            - status : str - Always "PENDING" (swarm created but not started)
            - iteration : int - Current iteration (always 0 for new swarms)
            - circular : int - Cycle count (always 0 for new swarms)
            - authorization : dict - Resource quotas and permissions:
              - quotas.max_storage_gb : float - Maximum storage allowed
              - quotas.current_storage_gb : float - Storage used by swarm data
              - quotas.max_concurrent_tasks : int - Maximum concurrent tasks
              - quotas.current_concurrent_tasks : int - Currently running tasks (0 initially)
              - permissions : list - Explicit permissions granted to other users (empty initially)

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks permission to create swarms or access the specified cluster.
            This occurs when:
            - User does not own the cluster AND has no 'execute' permission
            - User's swarm quota is exhausted (max_swarms reached)
        ResourceNotFoundError
            If the cluster_id does not exist or is not in "RUNNING" status.
        ValidationError
            If the swarm definition is invalid:
            - execute() method not implemented or returns invalid task graph
            - Task dependencies form a cycle (circular dependencies not allowed in non-circular graphs)
            - Module definitions are invalid (missing required fields)
            - Global parameters exceed size limits
        QuotaExceededError
            If creating the swarm would exceed user quotas:
            - Maximum number of swarms per user (typically 10)
            - Maximum storage per user (after accounting for global parameters)

        Examples
        --------
        Create a federated learning swarm for manual start control:

        >>> from manta.apis.swarm import Swarm
        >>> from manta.apis.graph import Task
        >>> from manta.apis.module import Module
        >>>
        >>> # Define custom swarm
        >>> class MyFLSwarm(Swarm):
        ...     name = "FederatedMNIST"
        ...
        ...     def __init__(self):
        ...         super().__init__()
        ...         self.set_global("hyperparameters", {
        ...             "epochs": 5,
        ...             "batch_size": 32,
        ...             "learning_rate": 0.001
        ...         })
        ...
        ...     def execute(self):
        ...         worker = Task(Module("worker.py", "pytorch_image"), replicas=5)
        ...         aggregator = Task(Module("aggregator.py", "pytorch_image"), replicas=1)
        ...         return aggregator(worker())  # Task dependency
        >>>
        >>> # Create swarm (but don't start yet)
        >>> swarm = MyFLSwarm()
        >>> overview = await api.send_swarm(cluster_id, swarm)
        >>> print(f"Created swarm {overview['swarm_id']}")
        >>> print(f"Status: {overview['status']}")  # Will be "PENDING"
        >>> print(f"Name: {overview['name']}")
        Created swarm 9415dfd18edc45c9a6ffdf2055007bf9
        Status: PENDING
        Name: FederatedMNIST
        >>>
        >>> # Start execution later
        >>> await api.start_swarm(overview['swarm_id'])

        Create swarm with validation before starting:

        >>> # Create swarm
        >>> swarm = MySwarm()
        >>> overview = await api.send_swarm(cluster_id, swarm)
        >>>
        >>> # Validate swarm was created correctly
        >>> swarm_details = await api.get_swarm(overview['swarm_id'])
        >>> print(f"Task count: {len(swarm_details.graph.tasks)}")
        >>> print(f"Storage used: {swarm_details.authorization['quotas']['current_storage_gb']:.2f} GB")
        Task count: 6
        Storage used: 0.15 GB
        >>>
        >>> # If validation passes, start execution
        >>> if len(swarm_details.graph.tasks) > 0:
        ...     await api.start_swarm(overview['swarm_id'])

        Batch create multiple swarms for scheduled execution:

        >>> # Prepare multiple experiment variations
        >>> swarms_to_create = []
        >>> for lr in [0.001, 0.01, 0.1]:
        ...     swarm = MyFLSwarm(learning_rate=lr)
        ...     swarm.name = f"Experiment_LR_{lr}"
        ...     swarms_to_create.append(swarm)
        >>>
        >>> # Create all swarms (but don't start yet)
        >>> swarm_ids = []
        >>> for swarm in swarms_to_create:
        ...     overview = await api.send_swarm(cluster_id, swarm)
        ...     swarm_ids.append(overview['swarm_id'])
        ...     print(f"Created {overview['name']}: {overview['swarm_id']}")
        Created Experiment_LR_0.001: abc123...
        Created Experiment_LR_0.01: def456...
        Created Experiment_LR_0.1: ghi789...
        >>>
        >>> # Start swarms sequentially or in parallel later
        >>> for swarm_id in swarm_ids:
        ...     await api.start_swarm(swarm_id)

        Handle quota limits gracefully:

        >>> try:
        ...     overview = await api.send_swarm(cluster_id, swarm)
        ...     print(f"Swarm created: {overview['swarm_id']}")
        ... except QuotaExceededError as e:
        ...     print(f"Quota exceeded: {e}")
        ...     # List existing swarms to identify candidates for deletion
        ...     swarms = await api.stream_and_fetch_swarms()
        ...     completed_swarms = [s for s in swarms if s.status == "COMPLETED"]
        ...     print(f"Found {len(completed_swarms)} completed swarms to clean up")
        ...     for s in completed_swarms:
        ...         await api.remove_swarm(s.swarm_id)
        ...         print(f"Removed {s.name}")
        ...     # Retry swarm creation
        ...     overview = await api.send_swarm(cluster_id, swarm)
        ...     print(f"Swarm created after cleanup: {overview['swarm_id']}")

        Create swarm with custom networks for inter-task communication:

        >>> class NetworkedSwarm(Swarm):
        ...     name = "DistributedTraining"
        ...
        ...     def __init__(self):
        ...         super().__init__()
        ...         # Add custom Docker network for direct task communication
        ...         self.add_network("training_network", Driver.BRIDGE)
        ...         self.set_global("master_address", "10.0.1.1:5555")
        ...
        ...     def execute(self):
        ...         # Tasks will share the custom network
        ...         worker1 = Task(Module("worker.py", "pytorch"), network="training_network")
        ...         worker2 = Task(Module("worker.py", "pytorch"), network="training_network")
        ...         return worker2(worker1())
        >>>
        >>> swarm = NetworkedSwarm()
        >>> overview = await api.send_swarm(cluster_id, swarm)
        >>> print(f"Swarm with custom network: {overview['swarm_id']}")

        Notes
        -----
        **Module Upload Behavior:**
        - Modules are automatically uploaded if not already in the system.
        - Module deduplication: Identical modules (same checksum) are reused.
        - If a module with the same checksum exists, its existing module_id is used.
        - Module upload happens before swarm creation, ensuring all dependencies are resolved.

        **Global Parameters:**
        - Global parameters (set via `set_global()`) are uploaded after swarm creation.
        - Parameters are chunked if they exceed the gRPC message size limit (4MB).
        - Common use cases: hyperparameters, initial model weights, configuration.
        - Global parameters are accessible to all tasks via the `manta.light.world` interface.

        **Custom Networks:**
        - Custom Docker networks enable direct inter-task communication.
        - Useful for distributed training frameworks (PyTorch DDP, Horovod, etc.).
        - Network driver options: BRIDGE (single-host), OVERLAY (multi-host).
        - Networks are created automatically when the swarm starts.

        **RBAC (Role-Based Access Control):**
        - Users must own the cluster OR have 'execute' permission on it.
        - Swarm creation counts against the user's swarm quota (typically 10 swarms max).
        - The created swarm is owned by the authenticated user.
        - Initial permissions list is empty; grant access via `update_user_authorization()`.

        **Swarm Status:**
        - Swarms created via `send_swarm()` have status "PENDING".
        - Status remains "PENDING" until `start_swarm()` is called.
        - To create and start in one operation, use `deploy_swarm()` instead.

        **Task Graph Validation:**
        - The task graph is validated before swarm creation.
        - Validation checks:
          - All tasks have valid module references
          - No circular dependencies (unless swarm is configured as circular)
          - Task IDs are unique within the swarm
          - Scheduling constraints are valid (CPU, GPU, dataset requirements)
        - Invalid graphs raise ValidationError with detailed error messages.

        **Quota Management:**
        - Creating a swarm increments the user's swarm count.
        - Global parameters and swarm metadata count toward storage quota.
        - If quota is exceeded, remove old swarms with `remove_swarm()` to free space.
        - Quota usage is shown in the returned authorization.quotas object.

        **Performance:**
        - Swarm creation typically takes 200-500ms depending on:
          - Number of modules to upload (first-time vs cached)
          - Size of global parameters (larger parameters take longer)
          - Number of custom networks to configure
        - Module uploads are parallelized for better performance.
        - Use `deploy_swarm()` for single-operation create+start (slightly faster).

        **Error Recovery:**
        - If swarm creation fails partway through (e.g., after modules uploaded but before
          swarm created), modules remain in the system and can be reused in subsequent attempts.
        - Partially created swarms are automatically cleaned up on failure.
        - Global parameters and networks are NOT created if swarm creation fails.

        **Use Cases:**
        - Staged deployment: Create swarm now, start execution later
        - Batch swarm creation for scheduled execution
        - Swarm validation before starting execution
        - Swarm template preparation for repeated use
        - Integration with external scheduling systems

        **When to Use send_swarm() vs deploy_swarm():**
        - Use `send_swarm()` when you need manual control over start timing
        - Use `send_swarm()` for batch swarm creation
        - Use `deploy_swarm()` for immediate execution (create + start in one call)
        - Use `deploy_swarm()` for simpler workflows where delayed start is not needed

        See Also
        --------
        deploy_swarm : Create and immediately start a swarm (combines send_swarm + start_swarm)
        start_swarm : Start execution of a swarm in "PENDING" status
        stop_swarm : Pause execution of an active swarm
        remove_swarm : Permanently delete a swarm and free quota
        get_swarm : Retrieve swarm details after creation
        stream_swarms : List all swarms owned by user
        list_cluster_ids : Get available clusters for swarm deployment
        send_module : Upload individual modules (called automatically by send_swarm)
        """
        # Get the graph with full Module objects
        graph_dicts = swarm.prepare_graph()

        # Extract unique modules and send them to get module_ids
        for task_dict in graph_dicts:
            module = task_dict.pop("module")
            # Convert to protobuf Module using the module's to_proto method
            module_proto = module.to_proto()
            # Send module and get its ID
            module_id_response = await self._module_management_client.send_module(
                module_proto
            )
            task_dict["module_id"] = ID(module_id_response.id).oid

        # Convert task dicts to Task protobuf objects
        tasks = []
        for task_dict in graph_dicts:
            task = Task(
                task_id=task_dict["task_id"],
                scheduling=task_dict[
                    "scheduling"
                ],  # Already converted by scheduling.to_proto()
                module_id=task_dict["module_id"],
                previous_tasks=task_dict["previous_tasks"],
                next_tasks=task_dict["next_tasks"],
                conditions=task_dict["conditions"],
                order=task_dict.get("order", 0),
                network=task_dict.get("network", ""),
                alias=task_dict["alias"],
            )
            tasks.append(task)

        graph = Graph(tasks=tasks)
        request = SendSwarmRequest(graph=graph, name=swarm.name, cluster_id=cluster_id)
        swarm_overview = await self._swarm_management_client.send_swarm(request)

        for global_chunks in swarm.prepare_globals(swarm_overview.swarm_id):

            async def async_generator():
                for global_chunk in global_chunks:
                    yield global_chunk

            await self._swarm_management_client.initialize_global(async_generator())

        networks = swarm.prepare_networks(swarm_overview.swarm_id)
        await self._swarm_management_client.initialize_networks(networks)

        return swarm_overview

    async def start_swarm(self, swarm_id: str) -> str:
        """
        Start or resume execution of a swarm on the cluster.

        This method initiates task execution for swarms in "PENDING" status (created via
        `send_swarm()` but not yet started) or resumes execution for swarms in "STOPPED"
        status (paused via `stop_swarm()`). The swarm status transitions to "ACTIVE" and
        tasks begin executing on available cluster nodes according to their scheduling
        constraints.

        For swarms already in "ACTIVE" status, this operation is idempotent (safe to call
        multiple times with no side effects). Use this method when you need explicit control
        over when swarm execution begins, or when resuming execution after a temporary pause.

        For most use cases where immediate execution is desired, prefer `deploy_swarm()`
        which combines swarm creation and starting into a single operation.

        Parameters
        ----------
        swarm_id : str
            Unique identifier of the swarm to start (UUID format, 32-character
            hexadecimal string without hyphens, e.g., '9415dfd18edc45c9a6ffdf2055007bf9').
            The swarm must be in "PENDING" or "STOPPED" status. Obtain swarm IDs from
            `send_swarm()` return value, `list_swarm_ids()`, or `stream_swarms()`.

        Returns
        -------
        str
            Success message confirming swarm has started. Format:
            "Swarm <swarm_id> has started."

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks permission to start this swarm. This occurs when:
            - The swarm is owned by another user AND
            - The user has not been granted explicit 'execute' permission
        ResourceNotFoundError
            If the swarm_id does not exist in the database.
        ValidationError
            If the swarm_id is not a valid UUID format.
        StateError
            If the cluster associated with the swarm is not in "RUNNING" status.
            The cluster must be started before swarm execution can begin.

        Examples
        --------
        Start a swarm after creating it with send_swarm:

        >>> # Create swarm without starting (status: PENDING)
        >>> swarm = MySwarm()
        >>> overview = await api.send_swarm(cluster_id, swarm)
        >>> print(f"Swarm created with status: {overview['status']}")
        Swarm created with status: PENDING
        >>>
        >>> # Validate or prepare before starting
        >>> swarm_details = await api.get_swarm(overview['swarm_id'])
        >>> print(f"Task count: {len(swarm_details.graph.tasks)}")
        Task count: 6
        >>>
        >>> # Start execution when ready
        >>> message = await api.start_swarm(overview['swarm_id'])
        >>> print(message)
        Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has started.
        >>>
        >>> # Verify status changed to ACTIVE
        >>> swarm_after_start = await api.get_swarm(overview['swarm_id'])
        >>> print(f"Status: {swarm_after_start.status}")
        Status: ACTIVE

        Resume a stopped swarm:

        >>> # Stop a running swarm
        >>> await api.stop_swarm(swarm_id)
        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"Status after stop: {swarm.status}")
        Status after stop: STOPPED
        >>>
        >>> # Resume execution from where it left off
        >>> message = await api.start_swarm(swarm_id)
        >>> print(message)
        Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has started.
        >>>
        >>> # Check that execution resumed (iteration preserved)
        >>> swarm_resumed = await api.get_swarm(swarm_id)
        >>> print(f"Status: {swarm_resumed.status}")
        >>> print(f"Iteration: {swarm_resumed.iteration}")  # Continues from where it stopped
        Status: ACTIVE
        Iteration: 5

        Conditional start based on swarm status:

        >>> # Check status before attempting to start
        >>> swarm = await api.get_swarm(swarm_id)
        >>> if swarm.status == "PENDING":
        ...     message = await api.start_swarm(swarm_id)
        ...     print(f"Started swarm: {message}")
        >>> elif swarm.status == "STOPPED":
        ...     message = await api.start_swarm(swarm_id)
        ...     print(f"Resumed swarm: {message}")
        >>> elif swarm.status == "ACTIVE":
        ...     print("Swarm is already running")
        >>> elif swarm.status == "COMPLETED":
        ...     print("Swarm has completed all iterations")
        Started swarm: Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has started.

        Handle swarm already running (idempotent):

        >>> # Safe to call start_swarm multiple times
        >>> message = await api.start_swarm(swarm_id)
        >>> print(message)
        Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has started.
        >>>
        >>> # Calling again on already-running swarm is safe
        >>> message = await api.start_swarm(swarm_id)
        >>> print(message)
        Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has started.
        >>>
        >>> # Status remains ACTIVE, no side effects
        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"Status: {swarm.status}")
        Status: ACTIVE

        Batch start multiple swarms sequentially:

        >>> # Create multiple swarms for different experiments
        >>> swarm_ids = []
        >>> for config in experiment_configs:
        ...     swarm = MyExperimentSwarm(config)
        ...     overview = await api.send_swarm(cluster_id, swarm)
        ...     swarm_ids.append(overview['swarm_id'])
        >>>
        >>> # Start all swarms sequentially
        >>> for swarm_id in swarm_ids:
        ...     message = await api.start_swarm(swarm_id)
        ...     print(f"Started: {swarm_id}")
        Started: 9415dfd18edc45c9a6ffdf2055007bf9
        Started: a41d4d1b01ff44f58ce8207d3c7273ca
        Started: b52e5e2c12ee55d69d00ee3166118c0d
        >>>
        >>> # Monitor all swarms
        >>> async for swarm in api.stream_swarms():
        ...     print(f"{swarm.name}: {swarm.status}, iteration {swarm.iteration}")
        Experiment_A: ACTIVE, iteration 0
        Experiment_B: ACTIVE, iteration 0
        Experiment_C: ACTIVE, iteration 0

        Notes
        -----
        **RBAC (Role-Based Access Control):**
        - Users can always start their own swarms.
        - For swarms owned by others, explicit 'execute' permission is required.
        - Permissions are managed via `update_user_authorization()` (admin-only).
        - Starting a swarm does not count toward quota (quota is consumed at creation).

        **Status Transitions:**
        - PENDING → ACTIVE: First-time start after `send_swarm()`
        - STOPPED → ACTIVE: Resume after `stop_swarm()`
        - ACTIVE → ACTIVE: Idempotent (no change, safe to call)
        - COMPLETED → Error: Cannot restart completed swarms (must create new swarm)

        **Start vs Resume Behavior:**
        - Starting PENDING swarms: Begins execution from iteration 0
        - Resuming STOPPED swarms: Continues from last iteration/circular counter
        - Task state is preserved when stopped (not reset)
        - Global parameters and results are retained across stop/start cycles

        **Cluster Requirements:**
        - The cluster associated with the swarm must be in "RUNNING" status.
        - If cluster is "STOPPED", start it first with `start_cluster()`.
        - Cluster must have sufficient resources (CPU, memory, GPU) for swarm tasks.
        - At least one node must be available and connected to the cluster.

        **Performance:**
        - Swarm start typically takes 100-200ms for command dispatch.
        - Task execution begins asynchronously after start command is received.
        - Actual task startup time depends on:
          - Docker image pull time (if not cached on nodes)
          - Node availability and resource allocation
          - Dataset loading time for data-dependent tasks
        - Monitor task status with `stream_swarm_tasks()` to track execution progress.

        **Idempotency:**
        - Safe to call `start_swarm()` multiple times on the same swarm.
        - If swarm is already "ACTIVE", the operation succeeds with no side effects.
        - Useful for retry logic or when uncertain about current swarm state.
        - No performance penalty for redundant start calls (fast no-op).

        **Task Execution:**
        - Tasks are scheduled to nodes according to scheduling constraints (CPU, GPU, datasets).
        - Task execution is asynchronous; tasks may start at different times.
        - Task dependencies are respected (child tasks wait for parent completion).
        - Use `stream_swarm_tasks()` to monitor individual task progress.

        **Error Recovery:**
        - If task execution fails, the swarm continues running other tasks.
        - Failed tasks can be retried by stopping and restarting the swarm.
        - Use `collect_errors()` to diagnose task failures.
        - Use `stream_logs()` to view detailed execution logs for debugging.

        **Use Cases:**
        - Staged deployment: Create swarm now, start execution later
        - Manual approval workflows: Validate swarm before starting
        - Scheduled execution: Start swarms at specific times
        - Resume interrupted workflows: Restart after cluster maintenance
        - Batch swarm orchestration: Control execution order of multiple swarms

        **When to Use start_swarm() vs deploy_swarm():**
        - Use `start_swarm()` when you need explicit control over start timing
        - Use `start_swarm()` to resume stopped swarms
        - Use `start_swarm()` in multi-step workflows (create, validate, start)
        - Use `deploy_swarm()` for immediate execution (simpler, faster)
        - Use `deploy_swarm()` when you don't need to inspect swarm before starting

        See Also
        --------
        send_swarm : Create swarm without starting (status: PENDING)
        deploy_swarm : Create and immediately start a swarm (combines send_swarm + start_swarm)
        stop_swarm : Pause swarm execution (can be resumed with start_swarm)
        remove_swarm : Permanently delete a swarm
        get_swarm : Retrieve swarm status and details
        stream_swarm_tasks : Monitor individual task execution
        start_cluster : Start cluster if needed before starting swarm
        stream_results : Retrieve results produced by running swarm
        collect_logs : Get execution logs for debugging
        """
        response = await self._swarm_management_client.start_swarm(swarm_id)
        return response.message

    async def deploy_swarm(self, cluster_id: str, swarm: Swarm) -> SwarmProto:
        """
        Create and immediately start a swarm on a cluster in a single operation.

        This is a convenience method that combines three operations into one:
        1. `send_swarm()` - Creates the swarm with status "PENDING"
        2. `start_swarm()` - Initiates execution, status becomes "ACTIVE"
        3. `get_swarm()` - Retrieves the final swarm state

        Use this method for the common case where you want immediate swarm execution.
        The swarm is created, started, and returned with status "ACTIVE" and tasks
        already executing on cluster nodes. This is the recommended approach for most
        federated learning and distributed computing workflows.

        For workflows requiring explicit control over start timing (e.g., staged deployment,
        validation before execution, or scheduled execution), use `send_swarm()` followed
        by `start_swarm()` separately.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster where the swarm will be deployed (UUID format,
            32-character hexadecimal string without hyphens, e.g.,
            '90700570a2ce4b1891b32341a192fc1a'). The cluster must be in "RUNNING" status
            and owned by the authenticated user. Obtain cluster IDs from `list_cluster_ids()`
            or `stream_clusters()`.
        swarm : Swarm
            Swarm instance defining the computational workflow. Must be a subclass of the
            `Swarm` base class with an implemented `execute()` method that returns the task
            graph. Common examples: FLSwarm (federated learning), SimpleSwarm (basic tasks),
            or custom Swarm subclasses.

            The swarm object contains:
            - Task graph: Defined by the `execute()` method
            - Global parameters: Set via `set_global(tag, value)`
            - Custom networks: Added via `add_network(name, driver)`
            - Swarm name: Class attribute `name` (default: "Swarm")

        Returns
        -------
        SwarmProto
            Complete swarm object with status "ACTIVE" and execution in progress:

            - swarm_id : str - Newly assigned unique identifier (UUID format)
            - cluster_id : str - Cluster where swarm is deployed (matches input)
            - owner_id : str - User ID of the swarm creator (from JWT token)
            - name : str - Swarm name (from swarm.name class attribute)
            - created_at : datetime - Timestamp when swarm was created
            - last_start : datetime - Start time (set to current time)
            - last_stop : datetime - Stop time (epoch zero since never stopped)
            - status : str - Always "ACTIVE" (swarm is running)
            - iteration : int - Current iteration (0 for newly started swarm)
            - circular : int - Cycle count (0 for newly started swarm)
            - authorization : dict - Resource quotas and permissions:
              - quotas.max_storage_gb : float - Maximum storage allowed
              - quotas.current_storage_gb : float - Storage used by swarm data
              - quotas.max_concurrent_tasks : int - Maximum concurrent tasks
              - quotas.current_concurrent_tasks : int - Tasks currently running
              - permissions : list - Explicit permissions granted to other users

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks permission to create swarms or access the specified cluster.
            This occurs when:
            - User does not own the cluster AND has no 'execute' permission
            - User's swarm quota is exhausted (max_swarms reached)
        ResourceNotFoundError
            If the cluster_id does not exist or is not in "RUNNING" status.
        ValidationError
            If the swarm definition is invalid:
            - execute() method not implemented or returns invalid task graph
            - Task dependencies form a cycle (unless swarm configured as circular)
            - Module definitions are invalid
            - Global parameters exceed size limits
        QuotaExceededError
            If creating the swarm would exceed user quotas:
            - Maximum number of swarms per user (typically 10)
            - Maximum storage per user
        StateError
            If the cluster is not in "RUNNING" status when attempting to start the swarm.

        Examples
        --------
        Deploy a federated learning swarm for immediate execution:

        >>> from manta.apis.swarm import Swarm
        >>> from manta.apis.graph import Task
        >>> from manta.apis.module import Module
        >>>
        >>> # Define custom federated learning swarm
        >>> class FederatedMNISTSwarm(Swarm):
        ...     name = "FederatedMNIST_Experiment"
        ...
        ...     def __init__(self):
        ...         super().__init__()
        ...         # Set hyperparameters as global parameters
        ...         self.set_global("hyperparameters", {
        ...             "epochs": 5,
        ...             "batch_size": 32,
        ...             "learning_rate": 0.001,
        ...             "optimizer": "SGD"
        ...         })
        ...
        ...     def execute(self):
        ...         # Define task graph
        ...         worker = Task(Module("worker.py", "pytorch_image"), replicas=5)
        ...         aggregator = Task(Module("aggregator.py", "pytorch_image"), replicas=1)
        ...         return aggregator(worker())  # Aggregator depends on workers
        >>>
        >>> # Deploy and immediately start execution
        >>> swarm = FederatedMNISTSwarm()
        >>> swarm_proto = await api.deploy_swarm(cluster_id, swarm)
        >>> print(f"Swarm ID: {swarm_proto.swarm_id}")
        >>> print(f"Status: {swarm_proto.status}")  # Will be "ACTIVE"
        >>> print(f"Started at: {swarm_proto.last_start}")
        >>> print(f"Running tasks: {swarm_proto.authorization['quotas']['current_concurrent_tasks']}")
        Swarm ID: 9415dfd18edc45c9a6ffdf2055007bf9
        Status: ACTIVE
        Started at: 2024-01-15 14:30:25
        Running tasks: 6

        Monitor swarm immediately after deployment:

        >>> # Deploy swarm
        >>> swarm_proto = await api.deploy_swarm(cluster_id, my_swarm)
        >>>
        >>> # Start monitoring task execution right away
        >>> async for task in api.stream_swarm_tasks(swarm_proto.swarm_id):
        ...     print(f"Task {task.task_id}: {task.status}")
        Task worker-0: RUNNING
        Task worker-1: RUNNING
        Task worker-2: PENDING
        Task aggregator-0: PENDING

        Deploy with error handling and quota check:

        >>> try:
        ...     swarm = MySwarm()
        ...     swarm_proto = await api.deploy_swarm(cluster_id, swarm)
        ...     print(f"Deployed: {swarm_proto.name}")
        ...     print(f"Status: {swarm_proto.status}")
        ... except QuotaExceededError as e:
        ...     print(f"Quota exceeded: {e}")
        ...     # Clean up old swarms to free quota
        ...     swarms = await api.stream_and_fetch_swarms()
        ...     for s in swarms:
        ...         if s.status == "COMPLETED":
        ...             await api.remove_swarm(s.swarm_id)
        ...     # Retry deployment
        ...     swarm_proto = await api.deploy_swarm(cluster_id, swarm)
        ... except StateError as e:
        ...     print(f"Cluster not running: {e}")
        ...     # Start cluster first
        ...     await api.start_cluster(cluster_id)
        ...     # Retry deployment
        ...     swarm_proto = await api.deploy_swarm(cluster_id, swarm)
        Deployed: ExperimentalModel
        Status: ACTIVE

        Deploy and immediately stream results:

        >>> # Deploy swarm
        >>> swarm_proto = await api.deploy_swarm(cluster_id, my_swarm)
        >>> print(f"Swarm {swarm_proto.name} started at {swarm_proto.last_start}")
        >>>
        >>> # Start collecting results immediately
        >>> async for result in api.stream_results(swarm_proto.swarm_id, tag="metrics"):
        ...     metrics = bytes_to_dict(result.data)
        ...     print(f"Iteration {result.iteration}: accuracy={metrics['accuracy']:.3f}")
        Swarm TrainingExperiment started at 2024-01-15 14:30:25
        Iteration 0: accuracy=0.654
        Iteration 1: accuracy=0.712
        Iteration 2: accuracy=0.768

        Deploy multiple swarms with different configurations:

        >>> # Hyperparameter sweep: deploy swarms with different learning rates
        >>> learning_rates = [0.001, 0.01, 0.1]
        >>> deployed_swarms = []
        >>>
        >>> for lr in learning_rates:
        ...     swarm = MyFLSwarm(learning_rate=lr)
        ...     swarm.name = f"Experiment_LR_{lr}"
        ...     swarm_proto = await api.deploy_swarm(cluster_id, swarm)
        ...     deployed_swarms.append(swarm_proto)
        ...     print(f"Deployed {swarm_proto.name}: {swarm_proto.swarm_id}")
        Deployed Experiment_LR_0.001: 9415dfd18edc45c9a6ffdf2055007bf9
        Deployed Experiment_LR_0.01: a41d4d1b01ff44f58ce8207d3c7273ca
        Deployed Experiment_LR_0.1: b52e5e2c12ee55d69d00ee3166118c0d
        >>>
        >>> # All swarms are now running in parallel
        >>> for swarm_proto in deployed_swarms:
        ...     print(f"{swarm_proto.name}: {swarm_proto.status}")
        Experiment_LR_0.001: ACTIVE
        Experiment_LR_0.01: ACTIVE
        Experiment_LR_0.1: ACTIVE

        Notes
        -----
        **Convenience Method:**
        - `deploy_swarm()` combines `send_swarm()` + `start_swarm()` + `get_swarm()`.
        - Equivalent to:
          ```python
          overview = await api.send_swarm(cluster_id, swarm)
          await api.start_swarm(overview['swarm_id'])
          swarm_proto = await api.get_swarm(overview['swarm_id'])
          ```
        - Saves two method calls and simplifies code for common case.
        - Returns SwarmProto (not dict like send_swarm()).

        **Module Upload Behavior:**
        - Modules are automatically uploaded during the send_swarm phase.
        - Module deduplication: Identical modules (same checksum) are reused.
        - If a module with the same checksum exists, its module_id is reused.
        - Module upload happens before swarm creation, ensuring all dependencies are resolved.

        **Global Parameters:**
        - Global parameters (set via `set_global()`) are uploaded after swarm creation.
        - Parameters are chunked if they exceed the gRPC message size limit (4MB).
        - Common use cases: hyperparameters, initial model weights, configuration.
        - Global parameters are accessible to all tasks via the `manta.light.world` interface.

        **Custom Networks:**
        - Custom Docker networks enable direct inter-task communication.
        - Useful for distributed training frameworks (PyTorch DDP, Horovod, etc.).
        - Network driver options: BRIDGE (single-host), OVERLAY (multi-host).
        - Networks are created automatically when the swarm starts.

        **RBAC (Role-Based Access Control):**
        - Users must own the cluster OR have 'execute' permission on it.
        - Swarm creation counts against the user's swarm quota (typically 10 swarms max).
        - The created swarm is owned by the authenticated user.
        - Initial permissions list is empty; grant access via `update_user_authorization()`.

        **Swarm Status:**
        - Swarms deployed via `deploy_swarm()` have status "ACTIVE".
        - Tasks begin executing immediately after deployment.
        - Use `stream_swarm_tasks()` to monitor task-level progress.
        - Use `stream_results()` to collect results as they're produced.

        **Task Graph Validation:**
        - The task graph is validated before swarm creation.
        - Validation checks:
          - All tasks have valid module references
          - No circular dependencies (unless swarm is configured as circular)
          - Task IDs are unique within the swarm
          - Scheduling constraints are valid (CPU, GPU, dataset requirements)
        - Invalid graphs raise ValidationError with detailed error messages.

        **Quota Management:**
        - Creating a swarm increments the user's swarm count.
        - Global parameters and swarm metadata count toward storage quota.
        - If quota is exceeded, remove old swarms with `remove_swarm()` to free space.
        - Quota usage is shown in the returned authorization.quotas object.

        **Performance:**
        - Total deployment time: 300-700ms typically (sum of send + start + get).
        - Breakdown:
          - send_swarm: 200-500ms (module upload, swarm creation, globals)
          - start_swarm: 100-200ms (task dispatch)
          - get_swarm: 10-30ms (state retrieval)
        - Slightly slower than separate calls due to sequential execution.
        - For batch deployments, consider using `send_swarm()` + batch `start_swarm()`.

        **Task Execution:**
        - Tasks are scheduled to nodes according to scheduling constraints.
        - Task execution is asynchronous; tasks may start at different times.
        - Task dependencies are respected (child tasks wait for parent completion).
        - Use `stream_swarm_tasks()` to monitor individual task progress.

        **Error Recovery:**
        - If deployment fails during swarm creation, no swarm is created (atomic).
        - If deployment fails during start, swarm exists with status "PENDING":
          - Use `start_swarm(swarm_id)` to retry starting
          - Or use `remove_swarm(swarm_id)` to clean up
        - Partially uploaded modules remain in the system and can be reused.

        **Use Cases:**
        - Federated learning experiments with immediate execution
        - Distributed training jobs that should start right away
        - Data processing pipelines with no manual approval needed
        - Hyperparameter sweeps running multiple experiments in parallel
        - Production workloads with continuous execution

        **When to Use deploy_swarm() vs send_swarm() + start_swarm():**
        - Use `deploy_swarm()` for immediate execution (most common case)
        - Use `deploy_swarm()` when you don't need to inspect swarm before starting
        - Use `send_swarm()` + `start_swarm()` for staged deployment
        - Use `send_swarm()` + `start_swarm()` for validation workflows
        - Use `send_swarm()` + `start_swarm()` for scheduled execution
        - Use `send_swarm()` + `start_swarm()` for batch swarm creation

        See Also
        --------
        send_swarm : Create swarm without starting (status: PENDING)
        start_swarm : Start or resume swarm execution
        stop_swarm : Pause swarm execution (preserves state)
        remove_swarm : Permanently delete a swarm and free quota
        get_swarm : Retrieve swarm details and status
        stream_swarm_tasks : Monitor individual task execution
        stream_results : Retrieve results produced by swarm
        collect_logs : Get execution logs for debugging
        start_cluster : Start cluster if needed before deploying swarm
        """
        swarm_dict = await self.send_swarm(cluster_id, swarm)
        await self.start_swarm(swarm_dict.swarm_id)
        swarm_response = await self.get_swarm(swarm_dict.swarm_id)
        return swarm_response

    async def stop_swarm(self, swarm_id: str, force: bool = False) -> str:
        """
        Pause execution of a running swarm and terminate all its tasks.

        This method gracefully stops swarm execution by terminating all running and pending
        tasks on cluster nodes. The swarm status transitions from "ACTIVE" to "STOPPED",
        and all task state, global parameters, and results are preserved. Stopped swarms
        can be resumed later with `start_swarm()`, which will continue execution from the
        last completed iteration with all state intact.

        Use graceful stop (force=False, default) to allow tasks to complete their current
        work and save intermediate results before terminating. Use forced stop (force=True)
        to immediately terminate all tasks, which may result in incomplete work or data loss
        but is useful for recovering from stuck or runaway tasks.

        For permanent swarm deletion that frees quota and removes all data, use
        `remove_swarm()` instead. Stopped swarms continue to count toward your swarm quota
        until explicitly deleted.

        Parameters
        ----------
        swarm_id : str
            Unique identifier of the swarm to stop (UUID format, 32-character
            hexadecimal string without hyphens, e.g., '9415dfd18edc45c9a6ffdf2055007bf9').
            The swarm must be in "ACTIVE" status to be stopped. Obtain swarm IDs from
            `deploy_swarm()` return value, `list_swarm_ids()`, or `stream_swarms()`.
        force : bool, default=False
            Force immediate termination of all tasks without graceful shutdown.

            - force=False (default): Graceful stop. Tasks are sent a termination signal
              and given time to save intermediate results, close file handles, and clean
              up resources before being forcefully terminated. Recommended for most cases.

            - force=True: Immediate termination. Tasks are killed immediately without
              cleanup opportunity. Use when tasks are stuck, unresponsive, or consuming
              excessive resources. May result in incomplete work or partial data corruption.

        Returns
        -------
        str
            Success message confirming swarm has stopped. Format:
            "Swarm <swarm_id> has stopped."

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks permission to stop this swarm. This occurs when:
            - The swarm is owned by another user AND
            - The user has not been granted explicit 'write' or 'delete' permission
        ResourceNotFoundError
            If the swarm_id does not exist in the database.
        ValidationError
            If the swarm_id is not a valid UUID format.
        StateError
            If the swarm is not in "ACTIVE" status. Swarms already "STOPPED" or
            "COMPLETED" cannot be stopped (operation is a no-op).

        Examples
        --------
        Gracefully stop a running swarm:

        >>> # Check swarm is running
        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"Status before stop: {swarm.status}")
        Status before stop: ACTIVE
        >>>
        >>> # Stop swarm gracefully (default behavior)
        >>> message = await api.stop_swarm(swarm_id)
        >>> print(message)
        Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has stopped.
        >>>
        >>> # Verify status changed to STOPPED
        >>> swarm_after_stop = await api.get_swarm(swarm_id)
        >>> print(f"Status after stop: {swarm_after_stop.status}")
        >>> print(f"Iteration preserved: {swarm_after_stop.iteration}")
        Status after stop: STOPPED
        Iteration preserved: 5

        Force stop to terminate stuck tasks:

        >>> # Swarm has tasks stuck in infinite loop or deadlock
        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"Running for: {datetime.now() - swarm.last_start}")
        Running for: 2 days, 5:30:00
        >>>
        >>> # Force immediate termination
        >>> message = await api.stop_swarm(swarm_id, force=True)
        >>> print(message)
        Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has stopped.
        >>>
        >>> # Tasks terminated immediately without cleanup
        >>> async for task in api.stream_swarm_tasks(swarm_id):
        ...     print(f"Task {task.task_id}: {task.status}")
        Task worker-0: TERMINATED
        Task worker-1: TERMINATED
        Task aggregator-0: TERMINATED

        Conditional stop based on swarm status:

        >>> # Only stop if swarm is actually running
        >>> swarm = await api.get_swarm(swarm_id)
        >>> if swarm.status == "ACTIVE":
        ...     message = await api.stop_swarm(swarm_id)
        ...     print(f"Stopped: {message}")
        >>> elif swarm.status == "STOPPED":
        ...     print("Swarm is already stopped")
        >>> elif swarm.status == "COMPLETED":
        ...     print("Swarm has completed all iterations")
        Stopped: Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has stopped.

        Stop and resume workflow for cluster maintenance:

        >>> # Stop swarm before cluster maintenance
        >>> print("Stopping swarm for cluster maintenance...")
        >>> await api.stop_swarm(swarm_id)
        >>>
        >>> # Perform cluster maintenance
        >>> await api.stop_cluster(cluster_id)
        >>> # ... perform maintenance operations ...
        >>> await api.start_cluster(cluster_id)
        >>>
        >>> # Resume swarm execution
        >>> print("Resuming swarm after maintenance...")
        >>> await api.start_swarm(swarm_id)
        >>>
        >>> # Verify execution resumed from same iteration
        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"Status: {swarm.status}, Iteration: {swarm.iteration}")
        Stopping swarm for cluster maintenance...
        Resuming swarm after maintenance...
        Status: ACTIVE, Iteration: 5

        Batch stop multiple swarms:

        >>> # Stop all running swarms in a cluster
        >>> swarms = await api.stream_and_fetch_swarms()
        >>> active_swarms = [s for s in swarms if s.status == "ACTIVE"]
        >>> print(f"Stopping {len(active_swarms)} active swarms...")
        Stopping 3 active swarms...
        >>>
        >>> for swarm in active_swarms:
        ...     message = await api.stop_swarm(swarm.swarm_id)
        ...     print(f"Stopped {swarm.name}: {message}")
        Stopped Experiment_A: Swarm 9415dfd18edc45c9a6ffdf2055007bf9 has stopped.
        Stopped Experiment_B: Swarm a41d4d1b01ff44f58ce8207d3c7273ca has stopped.
        Stopped Experiment_C: Swarm b52e5e2c12ee55d69d00ee3166118c0d has stopped.
        >>>
        >>> # Verify all stopped
        >>> swarms_after = await api.stream_and_fetch_swarms()
        >>> for swarm in swarms_after:
        ...     print(f"{swarm.name}: {swarm.status}")
        Experiment_A: STOPPED
        Experiment_B: STOPPED
        Experiment_C: STOPPED

        Notes
        -----
        **RBAC (Role-Based Access Control):**
        - Users can always stop their own swarms.
        - For swarms owned by others, explicit 'write' or 'delete' permission is required.
        - Permissions are managed via `update_user_authorization()` (admin-only).
        - Stopping a swarm does not free quota (use `remove_swarm()` to free quota).

        **Status Transitions:**
        - ACTIVE → STOPPED: Normal stop (swarm was running)
        - STOPPED → STOPPED: Idempotent (no change if already stopped)
        - PENDING → Error: Cannot stop swarms that were never started
        - COMPLETED → Error: Cannot stop swarms that finished all iterations

        **Graceful vs Force Stop:**
        - Graceful (force=False): Tasks receive SIGTERM signal, have 30 seconds to clean up
          - Tasks can save intermediate results to results collection
          - Tasks can update global parameters via world interface
          - Tasks can flush logs and close file handles
          - After 30 seconds, tasks are forcefully terminated with SIGKILL

        - Force (force=True): Tasks immediately receive SIGKILL signal
          - No cleanup opportunity, immediate termination
          - May result in incomplete writes, data corruption, or resource leaks
          - Use only for stuck tasks that don't respond to graceful termination
          - Useful for tasks with infinite loops, deadlocks, or resource exhaustion

        **State Preservation:**
        - All global parameters are preserved when swarm is stopped
        - Task execution state (iteration, circular counters) is preserved
        - All previously saved results remain accessible
        - Swarm can be resumed with `start_swarm()` to continue from last iteration
        - Network resources (custom Docker networks) are cleaned up on stop

        **Cluster Impact:**
        - Stopping a swarm frees cluster resources (CPU, memory, GPU) for other swarms
        - Node Docker containers are removed, freeing disk space
        - Cluster can be stopped after all swarms are stopped
        - Other swarms on the same cluster continue running unaffected

        **Performance:**
        - Graceful stop typically takes 100-500ms (depends on task cleanup time)
        - Force stop typically takes 50-100ms (immediate termination)
        - Large swarms with many tasks may take longer to stop all tasks
        - Monitor with `stream_swarm_tasks()` to verify all tasks terminated

        **Task Termination:**
        - All running tasks are terminated (gracefully or forcefully)
        - Pending tasks (not yet started) are cancelled
        - Completed tasks remain in completed state
        - Failed tasks remain in failed state
        - Use `stream_swarm_tasks()` to see final task statuses

        **Resume Behavior:**
        - Stopped swarms can be resumed with `start_swarm(swarm_id)`
        - Execution continues from last completed iteration
        - Global parameters and results are available to resumed tasks
        - Same task graph and scheduling constraints apply
        - Useful for temporary pauses, cluster maintenance, or debugging

        **Error Recovery:**
        - If stop fails (e.g., network error), swarm may remain in "ACTIVE" status
        - Retry stop operation; it is safe to call multiple times
        - If some tasks fail to terminate, use force=True to kill stuck tasks
        - Check task statuses with `stream_swarm_tasks()` after stop

        **Use Cases:**
        - Pause long-running experiments for cluster maintenance
        - Temporarily stop swarms to free resources for higher-priority work
        - Stop swarms with stuck or runaway tasks (use force=True)
        - Emergency stop before cluster shutdown or restart
        - Debugging: stop swarm, examine logs/results, optionally resume

        **Quota Impact:**
        - Stopped swarms continue to count toward max_swarms quota
        - Stopped swarms continue to consume storage quota (results, globals)
        - To free quota, use `remove_swarm()` to permanently delete swarm
        - Check quota usage: `swarm.authorization['quotas']`

        **When to Use stop_swarm() vs remove_swarm():**
        - Use `stop_swarm()` for temporary pause (can resume later)
        - Use `stop_swarm()` when you want to preserve results and state
        - Use `remove_swarm()` for permanent deletion (frees quota)
        - Use `remove_swarm()` when swarm is no longer needed
        - Use `remove_swarm()` to clean up completed or failed swarms

        See Also
        --------
        start_swarm : Resume stopped swarm execution
        remove_swarm : Permanently delete swarm and free quota
        deploy_swarm : Create and immediately start a swarm
        get_swarm : Check swarm status before stopping
        stream_swarm_tasks : Monitor task termination after stop
        stop_cluster : Stop entire cluster after stopping all swarms
        stream_results : Retrieve results before stopping
        collect_logs : Get execution logs before stopping
        """
        response = await self._swarm_management_client.stop_swarm(
            swarm_id, force, False
        )
        return response.message

    async def remove_swarm(self, swarm_id: str) -> str:
        """
        Permanently delete a swarm and all associated data from the platform.

        This method irreversibly deletes a swarm and all its associated resources including:
        task execution results, log entries, global parameters, task definitions, and execution
        state. The swarm ID is freed and the swarm count decrements from your quota, making
        room for new swarms. This operation cannot be undone.

        The swarm must be in "STOPPED", "PENDING", or "COMPLETED" status before deletion.
        Running swarms ("ACTIVE" status) must be stopped first with `stop_swarm()`. Use this
        method to clean up completed experiments, free quota space, or remove swarms that are
        no longer needed.

        For temporary pauses where you want to preserve all data and resume later, use
        `stop_swarm()` instead. Stopped swarms can be resumed with `start_swarm()`, whereas
        removed swarms are permanently gone.

        Parameters
        ----------
        swarm_id : str
            Unique identifier of the swarm to delete (UUID format, 32-character
            hexadecimal string without hyphens, e.g., '9415dfd18edc45c9a6ffdf2055007bf9').
            The swarm must be in "STOPPED", "PENDING", or "COMPLETED" status. Obtain
            swarm IDs from `list_swarm_ids()`, `stream_swarms()`, or `deploy_swarm()`
            return value.

        Returns
        -------
        str
            Success message confirming deletion. Format:
            "<swarm_id> deleted."

        Raises
        ------
        AuthenticationError
            If the JWT token is invalid, expired, or missing.
        PermissionError
            If the user lacks permission to delete this swarm. This occurs when:
            - The swarm is owned by another user AND
            - The user has not been granted explicit 'delete' permission
        ResourceNotFoundError
            If the swarm_id does not exist in the database.
        ValidationError
            If the swarm_id is not a valid UUID format.
        StateError
            If the swarm is in "ACTIVE" status. Running swarms must be stopped
            before deletion. Use `stop_swarm()` first, then `remove_swarm()`.

        Examples
        --------
        Remove a stopped swarm to free quota:

        >>> # Check swarm status
        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"Status: {swarm.status}")
        >>> print(f"Quota before: {swarm.authorization['quotas']['current_swarms']}")
        Status: STOPPED
        Quota before: 8
        >>>
        >>> # Remove swarm permanently
        >>> message = await api.remove_swarm(swarm_id)
        >>> print(message)
        9415dfd18edc45c9a6ffdf2055007bf9 deleted.
        >>>
        >>> # Verify quota freed
        >>> swarms = await api.stream_and_fetch_swarms()
        >>> print(f"Quota after: {len(swarms)}")
        Quota after: 7

        Stop and remove a running swarm:

        >>> # Must stop before removing
        >>> swarm = await api.get_swarm(swarm_id)
        >>> if swarm.status == "ACTIVE":
        ...     print("Stopping swarm first...")
        ...     await api.stop_swarm(swarm_id)
        Stopping swarm first...
        >>>
        >>> # Now safe to remove
        >>> message = await api.remove_swarm(swarm_id)
        >>> print(message)
        9415dfd18edc45c9a6ffdf2055007bf9 deleted.

        Clean up completed swarms to free quota:

        >>> # Find all completed swarms
        >>> swarms = await api.stream_and_fetch_swarms()
        >>> completed_swarms = [s for s in swarms if s.status == "COMPLETED"]
        >>> print(f"Found {len(completed_swarms)} completed swarms to clean up")
        Found 5 completed swarms to clean up
        >>>
        >>> # Remove each completed swarm
        >>> for swarm in completed_swarms:
        ...     message = await api.remove_swarm(swarm.swarm_id)
        ...     print(f"Removed {swarm.name}: {message}")
        Removed Experiment_A: 9415dfd18edc45c9a6ffdf2055007bf9 deleted.
        Removed Experiment_B: a41d4d1b01ff44f58ce8207d3c7273ca deleted.
        Removed Experiment_C: b52e5e2c12ee55d69d00ee3166118c0d deleted.
        >>>
        >>> # Verify quota freed
        >>> swarms_after = await api.stream_and_fetch_swarms()
        >>> print(f"Remaining swarms: {len(swarms_after)}")
        Remaining swarms: 3

        Conditional removal based on status:

        >>> # Only remove if not running
        >>> swarm = await api.get_swarm(swarm_id)
        >>> if swarm.status == "ACTIVE":
        ...     print("Cannot remove running swarm. Stop it first.")
        ...     await api.stop_swarm(swarm_id)
        >>> elif swarm.status in ["STOPPED", "PENDING", "COMPLETED"]:
        ...     message = await api.remove_swarm(swarm_id)
        ...     print(f"Removed: {message}")
        Removed: 9415dfd18edc45c9a6ffdf2055007bf9 deleted.

        Save results before removing swarm:

        >>> # Export results before deletion
        >>> swarm = await api.get_swarm(swarm_id)
        >>> print(f"Saving results from {swarm.name}...")
        Saving results from TrainingExperiment...
        >>>
        >>> # Collect all results
        >>> all_results = []
        >>> async for result in api.stream_results(swarm_id):
        ...     result_data = bytes_to_dict(result.data)
        ...     all_results.append({
        ...         'iteration': result.iteration,
        ...         'tag': result.tag,
        ...         'data': result_data
        ...     })
        >>> print(f"Saved {len(all_results)} results")
        Saved 150 results
        >>>
        >>> # Save to file
        >>> import json
        >>> with open(f'{swarm.name}_results.json', 'w') as f:
        ...     json.dump(all_results, f)
        >>>
        >>> # Now safe to remove swarm
        >>> message = await api.remove_swarm(swarm_id)
        >>> print(f"Swarm removed: {message}")
        Swarm removed: 9415dfd18edc45c9a6ffdf2055007bf9 deleted.

        Notes
        -----
        **Irreversible Operation:**
        - Deletion is permanent and cannot be undone.
        - All swarm data is deleted from the platform databases.
        - The swarm_id becomes invalid after deletion.
        - There is no "recycle bin" or recovery mechanism.
        - Double-check swarm_id before calling this method.

        **Data Deleted:**
        The following data is permanently removed when a swarm is deleted:
        - Task execution results (all iterations, all tags)
        - Log entries from all tasks
        - Global parameters and state
        - Task execution history and status
        - Swarm metadata (name, creation date, etc.)
        - Network configurations
        - Error records associated with the swarm

        **Quota Impact:**
        - Swarm count decrements: `current_swarms` decreases by 1
        - Storage quota freed: `current_storage_gb` decreases by swarm data size
        - Makes room for new swarms if at max_swarms limit
        - Check quota before/after: `swarm.authorization['quotas']`

        **RBAC (Role-Based Access Control):**
        - Users can always delete their own swarms.
        - For swarms owned by others, explicit 'delete' permission is required.
        - Permissions are managed via `update_user_authorization()` (admin-only).
        - Deletion removes all permissions granted to other users on this swarm.

        **Status Requirements:**
        - STOPPED: Can be removed immediately
        - PENDING: Can be removed immediately (swarm never started)
        - COMPLETED: Can be removed immediately (finished all iterations)
        - ACTIVE: Must stop first with `stop_swarm()`, then remove

        **Cluster Impact:**
        - Swarm deletion does not affect the cluster.
        - Other swarms on the same cluster continue running unaffected.
        - Cluster can be deleted only after all swarms are removed.
        - Use `list_cluster_ids()` to check cluster's swarms before cluster deletion.

        **Performance:**
        - Deletion typically takes 50-200ms for small swarms.
        - Large swarms with many results may take 500-1000ms.
        - Deletion is synchronous; method waits for completion.
        - Database cleanup happens in background after method returns.

        **Data Retention:**
        - Platform may retain swarm metadata for audit purposes (admin-only access).
        - Results and logs are immediately inaccessible to users after deletion.
        - Backup/archive mechanisms (if any) are platform-specific.
        - Contact platform administrators for data recovery requests (rare cases).

        **Best Practices:**
        - Export important results before deletion (use `stream_results()`)
        - Save logs for debugging before deletion (use `collect_logs()`)
        - Verify swarm_id before calling (use `get_swarm()` to confirm)
        - Use batch deletion for multiple swarms (loop with error handling)
        - Check quota after deletion to verify space freed

        **Error Recovery:**
        - If deletion fails (e.g., network error), swarm remains in database
        - Retry deletion; it is safe to call multiple times
        - If swarm is partially deleted, contact platform administrators
        - Use `get_swarm()` to verify swarm still exists after failed deletion

        **Use Cases:**
        - Clean up completed experiments to free quota
        - Remove failed swarms that cannot be recovered
        - Delete test swarms after development/debugging
        - Free storage space when approaching quota limits
        - Remove swarms before deleting a cluster

        **Quota Management:**
        - Monitor quota usage: `swarm.authorization['quotas']`
        - Remove old swarms when approaching max_swarms limit
        - Typical max_swarms: 10 swarms per user
        - Typical max_storage_gb: 10 GB per user
        - Admins can adjust quotas via `update_user_authorization()`

        **When to Use remove_swarm() vs stop_swarm():**
        - Use `remove_swarm()` for permanent deletion (frees quota)
        - Use `remove_swarm()` when swarm is no longer needed
        - Use `remove_swarm()` to clean up completed or failed swarms
        - Use `stop_swarm()` for temporary pause (preserves data)
        - Use `stop_swarm()` when you might resume execution later
        - Use `stop_swarm()` when you want to keep results and logs

        See Also
        --------
        stop_swarm : Temporarily pause swarm execution (preserves data)
        get_swarm : Check swarm status before deletion
        stream_results : Save results before deletion
        collect_logs : Save logs before deletion
        list_swarm_ids : List all swarms to identify candidates for deletion
        stream_swarms : Find completed/stopped swarms for cleanup
        deploy_swarm : Create new swarm after freeing quota
        """
        response = await self._swarm_management_client.remove_swarm(swarm_id)
        return response.message

    async def select_tasks(self, cluster_id: str, node_id: str) -> List[TaskResponse]:
        """
        Select tasks given node ID.
        Tasks are sorted by progression of the swarm from the end
        to the beginning.

        Parameters
        ----------
        service : UserStub
            Service to connect to the gRPC server (**not required**)
        node_id : str
            Node ID

        Returns
        -------
        List[TaskResponse]
            List of several informations containing tasks

        Examples
        --------

        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> await user_api.select_tasks(cluster_id, node_id)
        [{'task_id': 'adcc83a14d8642bbb6413d196fb0b5b8', 'swarm_id': '435709c73c5344c5a3d5754c7eb2ab6d', 'status': ...}, ...]

        .. warning::

            The server is not returning the payloads in the response.
            Ask the Manta team to add this feature.
        """
        return [
            response
            async for response in self._cluster_management_client.select_tasks(
                cluster_id, node_id
            )
        ]

    async def collect_errors(
        self,
        cluster_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: Optional[int] = None,
        sort_order: Optional[str] = None,
    ) -> List[Error]:
        """
        Collect errors from a node

        Parameters
        ----------
        cluster_id: str
            Cluster ID
        start_time : Optional[datetime]
            Start time
        end_time : Optional[datetime]
            End time
        limit : Optional[int]
            Limit
        sort_order : Optional[str]
            Sort order

        Returns
        -------
        List[Error]
            List of several informations containing errors

        Examples
        --------

        >>> node_id = 'a2ff3abc76e045d7bb4a04a5ac416318'
        >>> await user_api.collect_errors(cluster_id, node_id)
        [{'error_id': '1234567890', 'error_message': 'Error message', 'datetime': '2024-09-13 10:18:06'}, ...]
        """
        return [
            response
            async for response in self._cluster_management_client.collect_errors(
                cluster_id,
                start_time,
                end_time,
                limit,
                sort_order,
            )
        ]

    async def stop_node(self, cluster_id: str, node_id: str) -> str:
        """
        Stop a running node and terminate all its active tasks.

        Gracefully stops the specified node, terminating any tasks currently executing on it.
        The node will transition to a DISCONNECTED state but remains registered with the cluster
        and can be restarted later. This is useful for maintenance, resource reallocation, or
        troubleshooting problematic nodes.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster containing the node (UUID format).
            The authenticated user must own this cluster.
        node_id : str
            Unique identifier of the node to stop (UUID format).

        Returns
        -------
        str
            Success message confirming the node stop operation, typically:
            "Node {node_id} has been stopped successfully."

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified cluster.
        ValueError
            If cluster_id or node_id is not a valid UUID format.
        KeyError
            If the node_id does not exist in the cluster.
        RuntimeError
            If the node is already stopped or cannot be stopped.
        ConnectionError
            If the gRPC connection to the backend fails.

        Examples
        --------
        **Stop a problematic node:**

        >>> message = await user_api.stop_node(cluster_id, node_id)
        >>> print(message)
        Node abc123def456 has been stopped successfully.

        **Stop node before maintenance:**

        >>> # Get node details first
        >>> node = await user_api.get_node(cluster_id, node_id)
        >>> print(f"Stopping node {node.node_id} for maintenance...")
        >>> message = await user_api.stop_node(cluster_id, node_id)
        >>> print(message)
        Stopping node abc123def456 for maintenance...
        Node abc123def456 has been stopped successfully.

        **Stop multiple nodes:**

        >>> node_ids_to_stop = ["node1", "node2", "node3"]
        >>> for node_id in node_ids_to_stop:
        ...     try:
        ...         message = await user_api.stop_node(cluster_id, node_id)
        ...         print(f"✓ {message}")
        ...     except Exception as e:
        ...         print(f"✗ Failed to stop {node_id}: {e}")
        ✓ Node node1 has been stopped successfully.
        ✓ Node node2 has been stopped successfully.
        ✗ Failed to stop node3: Node is already stopped

        **Stop nodes exceeding resource threshold:**

        >>> async for node in user_api.stream_nodes(cluster_id):
        ...     if node.status == "CONNECTED":
        ...         metrics = await user_api.get_node_resources(cluster_id, node.node_id)
        ...         if metrics.cpu_percent > 95:
        ...             print(f"Node {node.node_id} overloaded, stopping...")
        ...             await user_api.stop_node(cluster_id, node.node_id)
        Node abc123 overloaded, stopping...

        **Stop node and verify status:**

        >>> await user_api.stop_node(cluster_id, node_id)
        >>> # Wait a moment for state to propagate
        >>> import asyncio
        >>> await asyncio.sleep(2)
        >>> node = await user_api.get_node(cluster_id, node_id)
        >>> print(f"Node status: {node.status}")
        Node status: DISCONNECTED

        Notes
        -----
        - **Task Termination**: All tasks currently running on the node will be forcefully
          terminated. Results may be incomplete and unsaved. Consider waiting for tasks to
          complete naturally before stopping nodes.

        - **RBAC Enforcement**: The authenticated user must own the cluster containing the node.
          Users cannot stop nodes from clusters they don't own.

        - **State Persistence**: The node remains registered with the cluster after stopping.
          It retains its node_id, configuration, and dataset references. Use `remove_node()`
          to completely deregister the node.

        - **Restart Capability**: A stopped node can be restarted by relaunching the manta-node
          process with the same configuration. It will reconnect using its existing node_id.

        - **Swarm Impact**: If the stopped node was participating in an active swarm, the
          swarm may fail or stall if the node was critical to task execution. The task
          scheduler may attempt to reschedule tasks to other available nodes.

        - **Graceful Shutdown**: The stop operation sends a shutdown signal to the node agent,
          which attempts to clean up resources before disconnecting. This may take a few seconds.

        See Also
        --------
        remove_node : Permanently remove a node from the cluster
        get_node : Get current node status
        list_node_ids : List all registered nodes
        """
        response = await self._cluster_management_client.stop_node(cluster_id, node_id)
        return response.message

    async def remove_node(self, cluster_id: str, node_id: str) -> str:
        """
        Permanently remove a node from the cluster and delete its registration.

        Completely deregisters the node from the cluster, removing all associated metadata,
        configuration, and references. The node_id will no longer be valid and the node
        cannot reconnect without re-registering with a new ID. This operation is irreversible.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster containing the node (UUID format).
            The authenticated user must own this cluster.
        node_id : str
            Unique identifier of the node to remove (UUID format).

        Returns
        -------
        str
            Success message confirming the node removal, typically:
            "Node {node_id} has been removed from the cluster."

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified cluster.
        ValueError
            If cluster_id or node_id is not a valid UUID format.
        KeyError
            If the node_id does not exist in the cluster.
        RuntimeError
            If the node has active tasks that must be stopped first.
        ConnectionError
            If the gRPC connection to the backend fails.

        Examples
        --------
        **Remove a decommissioned node:**

        >>> message = await user_api.remove_node(cluster_id, node_id)
        >>> print(message)
        Node abc123def456 has been removed from the cluster.

        **Stop and remove a node:**

        >>> # First stop the node to terminate any running tasks
        >>> await user_api.stop_node(cluster_id, node_id)
        >>> # Then remove it from the cluster
        >>> message = await user_api.remove_node(cluster_id, node_id)
        >>> print(message)
        Node abc123def456 has been removed from the cluster.

        **Remove multiple disconnected nodes:**

        >>> # Get all disconnected nodes
        >>> nodes = await user_api.stream_and_fetch_nodes(cluster_id)
        >>> disconnected = [n for n in nodes if n.status == "DISCONNECTED"]
        >>> print(f"Removing {len(disconnected)} disconnected nodes...")
        >>> for node in disconnected:
        ...     try:
        ...         message = await user_api.remove_node(cluster_id, node.node_id)
        ...         print(f"✓ Removed {node.node_id[:8]}")
        ...     except Exception as e:
        ...         print(f"✗ Failed to remove {node.node_id[:8]}: {e}")
        Removing 3 disconnected nodes...
        ✓ Removed abc12345
        ✓ Removed def67890
        ✓ Removed ghi01234

        **Verify node removal:**

        >>> await user_api.remove_node(cluster_id, node_id)
        >>> # Try to get the node (should raise KeyError)
        >>> try:
        ...     node = await user_api.get_node(cluster_id, node_id)
        ... except KeyError:
        ...     print("Node successfully removed (no longer exists)")
        Node successfully removed (no longer exists)

        **Clean up old nodes:**

        >>> from datetime import datetime, timedelta
        >>> cutoff = datetime.now() - timedelta(days=30)
        >>> nodes = await user_api.stream_and_fetch_nodes(cluster_id)
        >>> for node in nodes:
        ...     if node.status == "DISCONNECTED" and node.last_update < cutoff:
        ...         print(f"Removing inactive node {node.node_id[:8]}...")
        ...         await user_api.remove_node(cluster_id, node.node_id)
        Removing inactive node abc12345...
        Removing inactive node def67890...

        Notes
        -----
        - **Irreversible Operation**: Once removed, the node cannot reconnect without
          re-registering, which will assign a new node_id. All references to the old
          node_id will be invalid.

        - **RBAC Enforcement**: The authenticated user must own the cluster containing
          the node. Users cannot remove nodes from clusters they don't own.

        - **Active Tasks**: If the node has active tasks, the removal may fail. Always
          stop the node first with `stop_node()` to ensure clean termination of tasks.

        - **Historical Data**: Removal deletes the node's registration metadata but does
          not delete historical task results, logs, or execution records associated with
          the node_id. These remain in the database for audit purposes.

        - **Cluster Capacity**: Removing nodes reduces the cluster's total capacity.
          Ensure you maintain sufficient nodes for your workload requirements.

        - **Node Re-registration**: If you need to reconnect a node after removal, you
          must re-register it as a new node. It will receive a new node_id and must
          reconfigure any dataset paths and settings.

        - **vs stop_node**: Use `stop_node()` for temporary disconnections (maintenance,
          troubleshooting). Use `remove_node()` for permanent decommissioning of hardware.

        See Also
        --------
        stop_node : Temporarily stop a node without removing it
        get_node : Get current node status
        list_node_ids : List all registered nodes
        """
        response = await self._cluster_management_client.remove_node(
            cluster_id, node_id
        )
        return response.message

    async def list_node_ids(
        self, cluster_id: str, available: bool = False
    ) -> List[str]:
        """
        List node IDs for a cluster, optionally filtering for available nodes only.

        This method retrieves node IDs without full node details. Use `stream_nodes()`
        or `get_node()` to retrieve complete node information including resources,
        datasets, and system metrics.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster.
            Must be a cluster owned by the authenticated user.
        available : bool, default=False
            If True, return only nodes that are currently connected and ready to execute tasks.
            If False, return all nodes that have ever connected to this cluster.

        Returns
        -------
        List[str]
            List of node IDs (UUID strings). Returns empty list if no nodes found.
            - When available=False: All nodes ever registered (includes disconnected nodes)
            - When available=True: Only currently connected and ready nodes

        Raises
        ------
        grpc.RpcError
            If cluster doesn't exist or user lacks permission

        Examples
        --------
        List all nodes in a cluster:

        >>> api = await AsyncUserAPI.sign_in("user@example.com", "password")
        >>> all_nodes = await api.list_node_ids(cluster_id)
        >>> print(f"Total nodes registered: {len(all_nodes)}")
        >>> for node_id in all_nodes:
        ...     print(f"  - {node_id}")

        List only available (connected) nodes:

        >>> available_nodes = await api.list_node_ids(cluster_id, available=True)
        >>> print(f"Available nodes: {len(available_nodes)}")
        >>> if len(available_nodes) > 0:
        ...     print("Ready to deploy swarms")
        ... else:
        ...     print("No nodes connected. Start manta-node instances first.")

        Check node availability before deployment:

        >>> available = await api.list_node_ids(cluster_id, available=True)
        >>> if len(available) >= 3:
        ...     print(f"Sufficient nodes ({len(available)}), deploying swarm...")
        ...     swarm_id = await api.deploy_swarm(cluster_id, swarm)
        ... else:
        ...     print(f"Need at least 3 nodes, only {len(available)} available")

        Compare total vs available nodes:

        >>> total = await api.list_node_ids(cluster_id, available=False)
        >>> available = await api.list_node_ids(cluster_id, available=True)
        >>> disconnected = len(total) - len(available)
        >>> print(f"Nodes - Total: {len(total)}, Available: {len(available)}, Disconnected: {disconnected}")

        Get details for all available nodes:

        >>> node_ids = await api.list_node_ids(cluster_id, available=True)
        >>> nodes = []
        >>> for node_id in node_ids:
        ...     node = await api.get_node(cluster_id, node_id)
        ...     nodes.append(node)
        >>> print(f"Retrieved {len(nodes)} node details")

        Notes
        -----
        - Requires valid JWT token (automatically included from `AsyncUserAPI.sign_in()`)
        - RBAC: Users can only list nodes in clusters they own (ownership check)
        - Cluster must be in RUNNING state (status=1) to have available nodes
        - Node IDs are UUIDs generated when manta-node registers with the cluster
        - Available nodes are those with recent heartbeat (last 30 seconds)
        - Disconnected nodes remain in the total list but not in available list
        - For complete node information, use `stream_nodes()` or `get_node()`

        See Also
        --------
        stream_nodes : Stream all nodes with complete details
        get_node : Get complete information for a specific node
        list_available_node_ids : Convenience method (same as available=True)
        get_node_resources : Get resource metrics for a node
        """
        if available:
            collection_ids = (
                await self._cluster_management_client.list_available_node_ids(
                    cluster_id
                )
            )
        else:
            collection_ids = await self._cluster_management_client.list_node_ids(
                cluster_id
            )
        return [node_id for node_id in collection_ids.ids]

    async def stream_nodes(self, cluster_id: str) -> AsyncIterator[Node]:
        """
        Stream all nodes registered to a cluster with real-time updates.

        This method provides a streaming interface for retrieving all nodes that have ever
        connected to the specified cluster. Nodes are yielded as they are retrieved from
        the backend, allowing for efficient processing of large node lists without loading
        everything into memory.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster (UUID format).
            The authenticated user must own this cluster.

        Yields
        ------
        Node
            Node objects with the following structure:
            - node_id : str
                Unique identifier for the node (UUID format)
            - cluster_id : str
                The cluster this node belongs to
            - status : str
                Current node status ('CONNECTED', 'DISCONNECTED', 'UNKNOWN')
            - last_update : datetime
                Timestamp of last heartbeat or status update
            - datetime : datetime
                Initial registration timestamp
            - resources : dict
                Node hardware resources:
                - cpu_count : int - Number of CPU cores
                - memory_gb : float - Total system memory in GB
                - disk_gb : float - Available disk space in GB
                - gpu_count : int - Number of GPUs (0 if none)
            - dataset_overviews : List[dict]
                Available datasets on this node:
                - name : str - Dataset identifier
                - path : str - Local filesystem path
                - size_bytes : int - Dataset size
                - file_count : int - Number of files
            - platform_info : dict
                System information:
                - os : str - Operating system
                - architecture : str - CPU architecture
                - python_version : str - Python runtime version
            - metrics_snapshot : dict (optional)
                Latest resource utilization metrics:
                - cpu_percent : float - CPU usage percentage
                - memory_percent : float - Memory usage percentage
                - disk_percent : float - Disk usage percentage
                - network_sent_gb : float - Network data sent in GB
                - network_recv_gb : float - Network data received in GB

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified cluster.
        ValueError
            If cluster_id is not a valid UUID format.
        ConnectionError
            If the gRPC connection to the backend fails.

        Examples
        --------
        **Stream and process nodes incrementally:**

        >>> async for node in user_api.stream_nodes(cluster_id):
        ...     print(f"Node {node.node_id}: {node.status}")
        ...     print(f"  Resources: {node.resources.cpu_count} CPUs, "
        ...           f"{node.resources.memory_gb}GB RAM")
        ...     if node.dataset_overviews:
        ...         print(f"  Datasets: {[d.name for d in node.dataset_overviews]}")
        Node abc123: CONNECTED
          Resources: 8 CPUs, 32.0GB RAM
          Datasets: ['mnist', 'cifar10']
        Node def456: DISCONNECTED
          Resources: 4 CPUs, 16.0GB RAM
          Datasets: ['mnist']

        **Filter nodes by status:**

        >>> connected_nodes = []
        >>> async for node in user_api.stream_nodes(cluster_id):
        ...     if node.status == "CONNECTED":
        ...         connected_nodes.append(node.node_id)
        >>> print(f"Connected nodes: {connected_nodes}")
        Connected nodes: ['abc123', 'xyz789']

        **Check resource availability before deployment:**

        >>> min_cpus = 4
        >>> min_memory_gb = 8.0
        >>> suitable_nodes = []
        >>> async for node in user_api.stream_nodes(cluster_id):
        ...     if (node.status == "CONNECTED" and
        ...         node.resources.cpu_count >= min_cpus and
        ...         node.resources.memory_gb >= min_memory_gb):
        ...         suitable_nodes.append(node.node_id)
        >>> print(f"Suitable nodes for deployment: {len(suitable_nodes)}")
        Suitable nodes for deployment: 3

        **Monitor node metrics:**

        >>> async for node in user_api.stream_nodes(cluster_id):
        ...     if node.metrics_snapshot:
        ...         print(f"Node {node.node_id[:8]}:")
        ...         print(f"  CPU: {node.metrics_snapshot.cpu_percent:.1f}%")
        ...         print(f"  Memory: {node.metrics_snapshot.memory_percent:.1f}%")
        Node abc12345:
          CPU: 45.2%
          Memory: 62.8%

        **Find nodes with specific datasets:**

        >>> dataset_name = "mnist"
        >>> async for node in user_api.stream_nodes(cluster_id):
        ...     has_dataset = any(d.name == dataset_name for d in node.dataset_overviews)
        ...     if has_dataset:
        ...         print(f"Node {node.node_id[:8]} has {dataset_name}")
        Node abc12345 has mnist
        Node def67890 has mnist

        Notes
        -----
        - **RBAC Enforcement**: The authenticated user must own the cluster. Users cannot
          access nodes from clusters they don't own.

        - **Node Status**: Nodes are marked as 'CONNECTED' if they have sent a heartbeat
          within the last 30 seconds, 'DISCONNECTED' if registered but not recently active,
          or 'UNKNOWN' if status cannot be determined.

        - **Historical vs Current**: This method returns all nodes that have ever registered
          to the cluster, including currently disconnected nodes. Use `list_node_ids(available=True)`
          to get only currently connected nodes.

        - **Streaming Efficiency**: For large clusters with many nodes, streaming is more
          memory-efficient than collecting all nodes into a list. Process nodes incrementally
          whenever possible.

        - **Resource Metrics**: The metrics_snapshot field contains the latest reported
          resource utilization. This may be None or outdated for disconnected nodes.

        - **Dataset Discovery**: Nodes report their available datasets during registration.
          Use this information to schedule tasks on nodes with required data.

        See Also
        --------
        list_node_ids : Get node IDs without full node details
        stream_and_fetch_nodes : Collect all nodes into a list
        get_node : Get detailed information for a specific node
        list_available_node_ids : Get only currently connected nodes
        """
        async for node in self._cluster_management_client.stream_nodes(cluster_id):
            yield node

    async def stream_and_fetch_nodes(self, cluster_id: str) -> List[Node]:
        """
        Fetch all nodes registered to a cluster as a complete list.

        This method collects all nodes from the streaming endpoint and returns them as
        a complete list. It's a convenience wrapper around `stream_nodes()` for cases
        where you need to work with the full node list at once rather than processing
        nodes incrementally.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster (UUID format).
            The authenticated user must own this cluster.

        Returns
        -------
        List[Node]
            Complete list of all nodes registered to the cluster. Each Node object contains:
            - node_id : str - Node identifier
            - cluster_id : str - Parent cluster ID
            - status : str - Current status ('CONNECTED', 'DISCONNECTED', 'UNKNOWN')
            - last_update : datetime - Last heartbeat timestamp
            - datetime : datetime - Registration timestamp
            - resources : dict - Hardware resources (cpu_count, memory_gb, disk_gb, gpu_count)
            - dataset_overviews : List[dict] - Available datasets
            - platform_info : dict - System information
            - metrics_snapshot : dict (optional) - Latest resource metrics

            Returns an empty list if the cluster has no registered nodes.

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified cluster.
        ValueError
            If cluster_id is not a valid UUID format.
        ConnectionError
            If the gRPC connection to the backend fails.

        Examples
        --------
        **Get all nodes for analysis:**

        >>> nodes = await user_api.stream_and_fetch_nodes(cluster_id)
        >>> print(f"Cluster has {len(nodes)} registered nodes")
        >>> for node in nodes:
        ...     print(f"  {node.node_id}: {node.status}")
        Cluster has 5 registered nodes
          abc123: CONNECTED
          def456: CONNECTED
          ghi789: DISCONNECTED
          jkl012: CONNECTED
          mno345: CONNECTED

        **Calculate total cluster resources:**

        >>> nodes = await user_api.stream_and_fetch_nodes(cluster_id)
        >>> total_cpus = sum(n.resources.cpu_count for n in nodes if n.status == "CONNECTED")
        >>> total_memory = sum(n.resources.memory_gb for n in nodes if n.status == "CONNECTED")
        >>> print(f"Cluster resources: {total_cpus} CPUs, {total_memory}GB RAM")
        Cluster resources: 32 CPUs, 128.0GB RAM

        **Filter and count by criteria:**

        >>> nodes = await user_api.stream_and_fetch_nodes(cluster_id)
        >>> gpu_nodes = [n for n in nodes if n.resources.gpu_count > 0]
        >>> high_mem_nodes = [n for n in nodes if n.resources.memory_gb >= 32.0]
        >>> print(f"GPU nodes: {len(gpu_nodes)}, High-memory nodes: {len(high_mem_nodes)}")
        GPU nodes: 2, High-memory nodes: 3

        **Group nodes by operating system:**

        >>> nodes = await user_api.stream_and_fetch_nodes(cluster_id)
        >>> from collections import Counter
        >>> os_distribution = Counter(n.platform_info.os for n in nodes)
        >>> print(dict(os_distribution))
        {'Linux': 8, 'Darwin': 2, 'Windows': 1}

        **Find nodes with specific dataset:**

        >>> nodes = await user_api.stream_and_fetch_nodes(cluster_id)
        >>> dataset = "cifar10"
        >>> nodes_with_data = [
        ...     n for n in nodes
        ...     if any(d.name == dataset for d in n.dataset_overviews)
        ... ]
        >>> print(f"Nodes with {dataset}: {len(nodes_with_data)}")
        Nodes with cifar10: 6

        Notes
        -----
        - **Memory Usage**: This method loads all nodes into memory at once. For clusters
          with hundreds of nodes, consider using `stream_nodes()` to process nodes
          incrementally and reduce memory footprint.

        - **RBAC Enforcement**: The authenticated user must own the cluster to access
          node information.

        - **Node Status**: Includes all nodes that have ever registered, not just currently
          connected ones. Filter by `status == "CONNECTED"` for active nodes only.

        - **Performance**: For large clusters, this method may take several seconds to
          collect all node data. Use `list_node_ids()` if you only need node identifiers.

        - **Snapshot Consistency**: The returned list represents a snapshot at the time
          of the call. Node statuses may change after the method returns.

        See Also
        --------
        stream_nodes : Stream nodes incrementally for better memory efficiency
        list_node_ids : Get node IDs without full details
        get_node : Get detailed information for a specific node
        """
        nodes = []
        async for node in self._cluster_management_client.stream_nodes(cluster_id):
            nodes.append(node)
        return nodes

    async def get_node(self, cluster_id: str, node_id: str) -> Node:
        """
        Get detailed information for a specific node in a cluster.

        Retrieves complete information about a single node, including its current status,
        hardware resources, available datasets, system information, and latest resource
        utilization metrics.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster containing the node (UUID format).
            The authenticated user must own this cluster.
        node_id : str
            Unique identifier of the node to retrieve (UUID format).

        Returns
        -------
        Node
            Complete node information with the following structure:
            - node_id : str
                Unique identifier for the node (UUID format)
            - cluster_id : str
                The cluster this node belongs to
            - status : str
                Current node status: 'CONNECTED', 'DISCONNECTED', or 'UNKNOWN'
            - last_update : datetime
                Timestamp of the most recent heartbeat or status update
            - datetime : datetime
                Initial registration timestamp
            - resources : dict
                Node hardware resources:
                - cpu_count : int - Number of CPU cores available
                - memory_gb : float - Total system memory in gigabytes
                - disk_gb : float - Available disk space in gigabytes
                - gpu_count : int - Number of GPUs (0 if none)
            - dataset_overviews : List[dict]
                Datasets available on this node:
                - name : str - Dataset identifier used in task definitions
                - path : str - Local filesystem path to the dataset
                - size_bytes : int - Total size of the dataset in bytes
                - file_count : int - Number of files in the dataset
            - platform_info : dict
                System information about the node:
                - os : str - Operating system (e.g., 'Linux', 'Darwin', 'Windows')
                - architecture : str - CPU architecture (e.g., 'x86_64', 'arm64')
                - python_version : str - Python runtime version (e.g., '3.10.12')
            - metrics_snapshot : dict (optional)
                Latest resource utilization metrics (may be None for disconnected nodes):
                - cpu_percent : float - CPU usage percentage (0-100)
                - memory_percent : float - Memory usage percentage (0-100)
                - disk_percent : float - Disk usage percentage (0-100)
                - network_sent_gb : float - Total network data sent in GB
                - network_recv_gb : float - Total network data received in GB

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified cluster.
        ValueError
            If cluster_id or node_id is not a valid UUID format.
        KeyError
            If the node_id does not exist in the cluster.
        ConnectionError
            If the gRPC connection to the backend fails.

        Examples
        --------
        **Get node details:**

        >>> node = await user_api.get_node(cluster_id, node_id)
        >>> print(f"Node: {node.node_id}")
        >>> print(f"Status: {node.status}")
        >>> print(f"Resources: {node.resources.cpu_count} CPUs, {node.resources.memory_gb}GB RAM")
        Node: abc123def456
        Status: CONNECTED
        Resources: 8 CPUs, 32.0GB RAM

        **Check node status before deployment:**

        >>> node = await user_api.get_node(cluster_id, node_id)
        >>> if node.status != "CONNECTED":
        ...     print(f"Warning: Node is {node.status}, cannot deploy tasks")
        ... else:
        ...     print("Node is ready for task deployment")
        Node is ready for task deployment

        **Verify node has required dataset:**

        >>> node = await user_api.get_node(cluster_id, node_id)
        >>> required_dataset = "cifar10"
        >>> has_dataset = any(d.name == required_dataset for d in node.dataset_overviews)
        >>> if has_dataset:
        ...     print(f"Node has {required_dataset} dataset")
        ... else:
        ...     print(f"Node is missing {required_dataset} dataset")
        Node has cifar10 dataset

        **Monitor node resource utilization:**

        >>> node = await user_api.get_node(cluster_id, node_id)
        >>> if node.metrics_snapshot:
        ...     print(f"CPU: {node.metrics_snapshot.cpu_percent:.1f}%")
        ...     print(f"Memory: {node.metrics_snapshot.memory_percent:.1f}%")
        ...     print(f"Disk: {node.metrics_snapshot.disk_percent:.1f}%")
        ... else:
        ...     print("No metrics available (node may be disconnected)")
        CPU: 45.2%
        Memory: 62.8%
        Disk: 35.6%

        **Check node platform compatibility:**

        >>> node = await user_api.get_node(cluster_id, node_id)
        >>> print(f"Platform: {node.platform_info.os} ({node.platform_info.architecture})")
        >>> print(f"Python: {node.platform_info.python_version}")
        >>> if node.platform_info.os == "Linux" and node.resources.gpu_count > 0:
        ...     print("GPU-enabled Linux node - suitable for deep learning")
        Platform: Linux (x86_64)
        Python: 3.10.12
        GPU-enabled Linux node - suitable for deep learning

        Notes
        -----
        - **RBAC Enforcement**: The authenticated user must own the cluster containing
          the node. Users cannot access nodes from clusters they don't own.

        - **Node Status**: Nodes are marked 'CONNECTED' if they have sent a heartbeat
          within the last 30 seconds, 'DISCONNECTED' if registered but not recently active,
          or 'UNKNOWN' if status cannot be determined.

        - **Metrics Freshness**: The metrics_snapshot field contains the most recently
          reported resource utilization. For disconnected nodes, this may be outdated or
          None. Always check the last_update timestamp for metric freshness.

        - **Dataset Paths**: The dataset_overviews contain the local filesystem paths
          as configured on each node. These paths are not accessible remotely.

        - **UUID Format**: Both cluster_id and node_id must be valid UUID strings.
          Invalid formats will raise ValueError before making the backend request.

        See Also
        --------
        list_node_ids : Get list of all node IDs in a cluster
        stream_nodes : Stream all nodes with real-time updates
        get_node_resources : Get detailed resource metrics for a node
        stop_node : Stop a running node
        remove_node : Remove a node from the cluster
        """
        node = await self._cluster_management_client.get_node(cluster_id, node_id)
        return node

    async def stream_node_resources(
        self, cluster_id: str, node_id: str
    ) -> AsyncIterator[MetricsSnapshot]:
        """
        Stream real-time resource utilization updates for a specific node.

        Continuously receives updated resource metrics from the node as they are reported,
        allowing for live monitoring of CPU, memory, disk, and network usage. This is useful
        for tracking resource consumption during task execution or identifying capacity issues.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster containing the node (UUID format).
            The authenticated user must own this cluster.
        node_id : str
            Unique identifier of the node to monitor (UUID format).

        Yields
        ------
        MetricsSnapshot
            Real-time resource metrics with the following structure:
            - timestamp : datetime - When metrics were collected
            - cpu_percent : float - CPU utilization (0-100)
            - cpu_count : int - Total CPU cores
            - memory_used_gb : float - Used memory in GB
            - memory_total_gb : float - Total memory in GB
            - memory_percent : float - Memory utilization (0-100)
            - disk_used_gb : float - Used disk space in GB
            - disk_total_gb : float - Total disk space in GB
            - disk_percent : float - Disk utilization (0-100)
            - network_sent_gb : float - Total data sent in GB
            - network_recv_gb : float - Total data received in GB
            - gpu_metrics : List[dict] (optional) - GPU metrics if available

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified cluster.
        ValueError
            If cluster_id or node_id is not a valid UUID format.
        KeyError
            If the node_id does not exist in the cluster.
        ConnectionError
            If the gRPC connection fails or node becomes unreachable.

        Examples
        --------
        **Monitor node during task execution:**

        >>> async for metrics in user_api.stream_node_resources(cluster_id, node_id):
        ...     print(f"[{metrics.timestamp}] CPU: {metrics.cpu_percent:.1f}%, "
        ...           f"Memory: {metrics.memory_percent:.1f}%")
        ...     if metrics.cpu_percent > 90:
        ...         print("WARNING: High CPU usage!")
        [2024-01-15 10:30:15] CPU: 45.2%, Memory: 62.8%
        [2024-01-15 10:30:45] CPU: 78.3%, Memory: 71.5%
        [2024-01-15 10:31:15] CPU: 92.1%, Memory: 85.3%
        WARNING: High CPU usage!

        **Track memory usage trend:**

        >>> memory_samples = []
        >>> async for metrics in user_api.stream_node_resources(cluster_id, node_id):
        ...     memory_samples.append(metrics.memory_percent)
        ...     if len(memory_samples) >= 10:
        ...         avg_memory = sum(memory_samples) / len(memory_samples)
        ...         print(f"Average memory usage: {avg_memory:.1f}%")
        ...         break
        Average memory usage: 68.4%

        **Monitor GPU utilization:**

        >>> async for metrics in user_api.stream_node_resources(cluster_id, node_id):
        ...     if metrics.gpu_metrics:
        ...         for gpu in metrics.gpu_metrics:
        ...             print(f"GPU {gpu.index}: {gpu.utilization_percent:.1f}% compute, "
        ...                   f"{gpu.memory_percent:.1f}% memory")
        GPU 0: 85.2% compute, 92.3% memory
        GPU 1: 45.7% compute, 67.1% memory

        Notes
        -----
        - **Update Frequency**: Metrics are streamed whenever the node reports updated
          resource usage, typically every 30 seconds with heartbeats.

        - **RBAC Enforcement**: The authenticated user must own the cluster containing
          the node.

        - **Network Considerations**: This creates a long-lived gRPC stream. Ensure proper
          cleanup by using async context managers or try/finally blocks.

        - **Disconnection Handling**: The stream will end if the node disconnects. Implement
          reconnection logic if continuous monitoring is needed.

        See Also
        --------
        get_node_resources : Get a single snapshot of node resources
        get_node : Get complete node information
        """
        async for resource in self._cluster_management_client.stream_node_resources(
            cluster_id, node_id
        ):
            yield resource

    async def get_node_resources(
        self, cluster_id: str, node_id: str
    ) -> MetricsSnapshot:
        """
        Get current resource utilization metrics for a specific node.

        Retrieves a snapshot of the node's current resource usage, including CPU, memory,
        disk, and network utilization. This provides real-time insight into the node's
        capacity and load for making deployment decisions.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster containing the node (UUID format).
            The authenticated user must own this cluster.
        node_id : str
            Unique identifier of the node (UUID format).

        Returns
        -------
        MetricsSnapshot
            Current resource utilization metrics with the following structure:
            - timestamp : datetime
                When these metrics were collected
            - cpu_percent : float
                Current CPU utilization percentage (0-100)
            - cpu_count : int
                Total number of CPU cores available
            - memory_used_gb : float
                Currently used memory in gigabytes
            - memory_total_gb : float
                Total system memory in gigabytes
            - memory_percent : float
                Memory utilization percentage (0-100)
            - disk_used_gb : float
                Currently used disk space in gigabytes
            - disk_total_gb : float
                Total disk space in gigabytes
            - disk_percent : float
                Disk utilization percentage (0-100)
            - network_sent_gb : float
                Total network data sent since node startup (in GB)
            - network_recv_gb : float
                Total network data received since node startup (in GB)
            - gpu_metrics : List[dict] (optional)
                GPU utilization if GPUs are present:
                - index : int - GPU device index
                - name : str - GPU model name
                - memory_used_gb : float - GPU memory used
                - memory_total_gb : float - Total GPU memory
                - memory_percent : float - GPU memory utilization (0-100)
                - utilization_percent : float - GPU compute utilization (0-100)

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified cluster.
        ValueError
            If cluster_id or node_id is not a valid UUID format.
        KeyError
            If the node_id does not exist in the cluster.
        ConnectionError
            If the gRPC connection to the backend fails or node is unreachable.

        Examples
        --------
        **Check current resource usage:**

        >>> metrics = await user_api.get_node_resources(cluster_id, node_id)
        >>> print(f"CPU: {metrics.cpu_percent:.1f}%")
        >>> print(f"Memory: {metrics.memory_used_gb:.1f}GB / {metrics.memory_total_gb:.1f}GB "
        ...       f"({metrics.memory_percent:.1f}%)")
        >>> print(f"Disk: {metrics.disk_percent:.1f}%")
        CPU: 45.2%
        Memory: 12.5GB / 32.0GB (39.1%)
        Disk: 62.3%

        **Verify node has capacity before deployment:**

        >>> metrics = await user_api.get_node_resources(cluster_id, node_id)
        >>> if metrics.cpu_percent < 80 and metrics.memory_percent < 80:
        ...     print("Node has capacity for new tasks")
        ... else:
        ...     print("Node is near capacity, consider another node")
        Node has capacity for new tasks

        **Monitor GPU availability:**

        >>> metrics = await user_api.get_node_resources(cluster_id, node_id)
        >>> if metrics.gpu_metrics:
        ...     for gpu in metrics.gpu_metrics:
        ...         print(f"GPU {gpu.index} ({gpu.name}): "
        ...               f"{gpu.utilization_percent:.1f}% compute, "
        ...               f"{gpu.memory_percent:.1f}% memory")
        ... else:
        ...     print("No GPUs available on this node")
        GPU 0 (NVIDIA Tesla V100): 35.2% compute, 45.8% memory
        GPU 1 (NVIDIA Tesla V100): 12.5% compute, 23.1% memory

        **Calculate available resources:**

        >>> metrics = await user_api.get_node_resources(cluster_id, node_id)
        >>> available_memory = metrics.memory_total_gb - metrics.memory_used_gb
        >>> available_disk = metrics.disk_total_gb - metrics.disk_used_gb
        >>> print(f"Available: {available_memory:.1f}GB memory, {available_disk:.1f}GB disk")
        Available: 19.5GB memory, 230.4GB disk

        **Track network usage:**

        >>> metrics = await user_api.get_node_resources(cluster_id, node_id)
        >>> total_traffic = metrics.network_sent_gb + metrics.network_recv_gb
        >>> print(f"Network usage: {metrics.network_sent_gb:.2f}GB sent, "
        ...       f"{metrics.network_recv_gb:.2f}GB received")
        >>> print(f"Total: {total_traffic:.2f}GB")
        Network usage: 12.45GB sent, 8.32GB received
        Total: 20.77GB

        Notes
        -----
        - **RBAC Enforcement**: The authenticated user must own the cluster containing
          the node. Users cannot access resource metrics from clusters they don't own.

        - **Metrics Freshness**: Metrics are collected every time a node sends a heartbeat
          (typically every 30 seconds). For disconnected nodes, this method may fail or
          return stale data. Check the timestamp field to verify metric freshness.

        - **Resource Percentages**: Percentage values are calculated as:
          (used / total) * 100. Values above 90% indicate the node is near capacity.

        - **Network Counters**: Network metrics are cumulative since node startup and
          reset when the node restarts. Use these for total bandwidth tracking, not
          instantaneous rates.

        - **GPU Metrics**: Only available if the node has NVIDIA GPUs with nvidia-smi
          and pynvml installed. The gpu_metrics list will be empty otherwise.

        - **Deployment Planning**: Use these metrics to:
          - Select nodes with sufficient capacity
          - Balance load across the cluster
          - Identify overloaded nodes
          - Monitor resource trends over time

        See Also
        --------
        get_node : Get complete node information including static resources
        stream_node_resources : Stream real-time resource updates
        list_node_ids : Get all nodes in a cluster
        """
        node_resources = await self._cluster_management_client.get_node_resources(
            cluster_id, node_id
        )
        return node_resources

    async def list_available_node_ids(self, cluster_id: str) -> List[str]:
        """
        List all currently available (connected and ready) node IDs for a cluster.

        This method returns only the IDs of nodes that are currently connected and ready
        to accept tasks. Unlike `list_node_ids()`, which can return all registered nodes
        (including historical/disconnected ones), this method filters to only nodes with
        recent heartbeats (within the last 30 seconds) and 'CONNECTED' status.

        This is useful for quick availability checks before task deployment, capacity
        planning, or monitoring the real-time health of the cluster's compute resources.

        Parameters
        ----------
        cluster_id : str
            Unique identifier of the cluster (UUID format).
            The authenticated user must own this cluster.

        Returns
        -------
        List[str]
            List of node IDs (UUID format) for all currently available nodes.
            Returns an empty list if no nodes are currently connected.

        Raises
        ------
        PermissionError
            If the authenticated user does not own the specified cluster.
        ValueError
            If cluster_id is not a valid UUID format.
        KeyError
            If the cluster does not exist.

        Examples
        --------
        **List currently available nodes:**

        >>> available = await user_api.list_available_node_ids(cluster_id)
        >>> print(f"Ready nodes: {len(available)}")
        Ready nodes: 3
        >>> print(available)
        ['a1b2c3d4-...', 'e5f6g7h8-...', 'i9j0k1l2-...']

        **Compare available nodes with total registered nodes:**

        >>> # Get all registered nodes (historical + current)
        >>> all_nodes = await user_api.list_node_ids(cluster_id)
        >>> # Get only currently available nodes
        >>> available_nodes = await user_api.list_available_node_ids(cluster_id)
        >>> disconnected_count = len(all_nodes) - len(available_nodes)
        >>> print(f"Total: {len(all_nodes)}, Available: {len(available_nodes)}, "
        ...       f"Disconnected: {disconnected_count}")
        Total: 5, Available: 3, Disconnected: 2

        **Check availability before deploying a swarm:**

        >>> # Verify minimum node count before deployment
        >>> min_required = 3
        >>> available = await user_api.list_available_node_ids(cluster_id)
        >>> if len(available) < min_required:
        ...     raise RuntimeError(
        ...         f"Insufficient nodes: need {min_required}, have {len(available)}"
        ...     )
        >>> # Safe to deploy swarm
        >>> swarm_overview = await user_api.deploy_swarm(cluster_id, swarm)

        **Monitor node availability changes over time:**

        >>> import asyncio
        >>> previous_available = set()
        >>> while True:
        ...     current_available = set(
        ...         await user_api.list_available_node_ids(cluster_id)
        ...     )
        ...     # Detect new nodes that became available
        ...     newly_available = current_available - previous_available
        ...     if newly_available:
        ...         print(f"Nodes came online: {newly_available}")
        ...     # Detect nodes that became unavailable
        ...     newly_unavailable = previous_available - current_available
        ...     if newly_unavailable:
        ...         print(f"Nodes went offline: {newly_unavailable}")
        ...     previous_available = current_available
        ...     await asyncio.sleep(30)  # Check every 30 seconds

        **Get available nodes for specific resource requirements:**

        >>> # Get all available nodes
        >>> available_ids = await user_api.list_available_node_ids(cluster_id)
        >>> # Filter by resource requirements
        >>> gpu_nodes = []
        >>> for node_id in available_ids:
        ...     node = await user_api.get_node(cluster_id, node_id)
        ...     if node.resources.get('gpu_count', 0) > 0:
        ...         gpu_nodes.append(node_id)
        >>> print(f"Available GPU nodes: {len(gpu_nodes)}/{len(available_ids)}")

        Notes
        -----
        **Availability Criteria:**
        - A node is considered "available" if it has sent a heartbeat within the last
          30 seconds and has status 'CONNECTED'.
        - Nodes that are registered but haven't sent recent heartbeats (status
          'DISCONNECTED' or 'UNKNOWN') are excluded from this list.
        - The availability status is evaluated in real-time at the time of the request.

        **RBAC and Permissions:**
        - Requires ownership of the cluster or explicit read permission.
        - Permission check enforced at the service boundary with 5-minute cache.

        **Performance:**
        - This is a lightweight operation that queries only node status metadata,
          not full node details or metrics.
        - For frequent polling, consider caching the result for a few seconds to
          reduce API load.

        **Difference from list_node_ids():**
        - `list_node_ids()` returns all registered nodes (historical + current).
        - `list_node_ids(available=True)` is functionally equivalent to this method.
        - `list_available_node_ids()` is a convenience method with clearer semantics
          specifically for real-time availability checks.

        **Deployment Planning:**
        - Use this method to verify sufficient compute capacity before deploying
          swarms or tasks.
        - For resource-specific checks (GPU, memory, datasets), combine with
          `get_node()` or `get_node_resources()` to inspect available nodes in detail.

        See Also
        --------
        list_node_ids : Get all registered node IDs (historical + current)
        stream_nodes : Stream full node details for all registered nodes
        get_node : Get detailed information for a specific node
        get_node_resources : Get current resource metrics for a node
        """
        response = await self._cluster_management_client.list_available_node_ids(
            cluster_id
        )
        return response.ids

    async def stream_results(
        self, swarm_id: str, tag: str
    ) -> AsyncIterator[ResultsResponse]:
        """
        Stream results in real-time as they are produced.

        Parameters
        ----------
        swarm_id : str
            Swarm ID
        tag : str
            Result tag (e.g., 'metrics', 'weights')

        Returns
        -------
        AsyncIterator[ResultsResponse]
            Stream of results with data, node_id, iteration

        Examples
        --------
        >>> async for result in user_api.stream_results(swarm_id, 'metrics'):
        ...     print(f"Iteration {result.iteration}: {result.data}")
        """
        async for result in self._swarm_management_client.stream_results(swarm_id, tag):
            yield result

    async def select_results(self, swarm_id: str, tag: str) -> Dict[str, Results]:
        """
        Collect all results for a specific tag from swarm execution.

        Parameters
        ----------
        swarm_id : str
            Swarm ID
        tag : str
            Result tag (e.g., 'metrics', 'weights')

        Returns
        -------
        Dict[str, Results]
            Results grouped by iteration and node: {swarm_id: Results}

        Examples
        --------
        >>> results = await user_api.select_results(swarm_id, 'metrics')
        >>> print(results[swarm_id])
        Results(len(iteration)=10, len(nodes)=8, len(tags)=1)
        """

        def sort_and_group(iterable) -> List[Dict[str, Dict[str, Any]]]:
            iter_dict = defaultdict(lambda: defaultdict(dict))
            for result in iterable:
                iter_dict[result.iteration][result.node_id][result.tag] = result.data
            return [iter_dict[i] for i in range(len(iter_dict))]

        results = []
        async for response in self._swarm_management_client.select_results(
            swarm_id, tag
        ):
            results.append(response)

        return {swarm_id: Results(sort_and_group(results))}

    async def delete_results(
        self,
        swarm_id: str,
        tag: str,
        node_id: Optional[str] = None,
        task_id: Optional[str] = None,
        iteration: Optional[int] = None,
    ) -> str:
        """
        Delete results for a specific tag with optional filtering.

        Parameters
        ----------
        swarm_id : str
            Swarm ID
        tag : str
            Result tag to delete (e.g., 'metrics', 'weights')
        node_id : str, optional
            Delete only results from specific node
        task_id : str, optional
            Delete only results from specific task
        iteration : int, optional
            Delete only results from specific iteration

        Returns
        -------
        str
            Deletion confirmation message

        Examples
        --------
        >>> await user_api.delete_results(swarm_id, 'metrics')
        'Results deleted successfully'
        """
        response = await self._swarm_management_client.delete_results(
            swarm_id=swarm_id,
            tag=tag,
            node_id=node_id,
            task_id=task_id,
            iteration=iteration,
        )
        return response.message

    async def select_results_stream(
        self, swarm_id: str, tag: str
    ) -> AsyncIterator[ResultsResponse]:
        """
        Select results from the database given the queries

        Parameters
        ----------
        swarm_id: str
            Swarm ID
        tag: str
            Tag

        Returns
        -------
        AsyncIterator[ResultsResponse]
            Stream of results
        """
        async for response in self._swarm_management_client.select_results(
            swarm_id, tag
        ):
            yield response

    async def collect_logs(
        self,
        swarm_id: str,
        node_ids: Optional[List[str]] = None,
        task_ids: Optional[List[str]] = None,
        iteration: Optional[int] = None,
        circular: Optional[int] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        severity: Optional[List[str]] = None,
        limit: Optional[int] = None,
        sort_order: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Retrieve logs from swarm execution with filtering options.

        Parameters
        ----------
        swarm_id : str
            Swarm ID
        node_ids : List[str], optional
            Filter by specific nodes
        task_ids : List[str], optional
            Filter by specific tasks
        iteration : int, optional
            Filter by iteration number
        severity : List[str], optional
            Filter by severity levels (e.g., ['ERROR', 'WARNING'])
        limit : int, optional
            Maximum number of logs to return
        sort_order : str, optional
            Sort order: 'asc' or 'desc' (default: 'desc')

        Returns
        -------
        List[Dict[str, Any]]
            Log entries with message, severity, timestamp, task_id

        Examples
        --------
        >>> logs = await user_api.collect_logs(swarm_id, limit=100, severity=['ERROR'])
        >>> for log in logs:
        ...     print(f"{log['severity']}: {log['message']}")
        """
        # Create LogQuery object with the requested ID and other optional parameters
        query = LogQuery()
        if iteration:
            query.iteration = iteration
        if circular:
            query.circular = circular
        if start_time:
            query.start_time = start_time
        if end_time:
            query.end_time = end_time
        if severity:
            query.severity = severity
        if limit:
            query.limit = limit
        if sort_order:
            query.sort_order = sort_order

        # Start the streaming request
        stream = self._swarm_management_client.collect_logs(
            swarm_id=swarm_id,
            node_ids=node_ids,
            task_ids=task_ids,
            severity=severity,
            start_time=start_time,
            end_time=end_time,
            limit=limit,
            sort_order=sort_order,
            iteration=iteration,
            circular=circular,
        )

        # Process the stream of LogResponse objects
        log_entries = {}  # Dictionary to collect log parts by their unique ID

        async for response in stream:
            # Create a unique key for each log entry based on its metadata
            entry_key = (
                response.swarm_id if response.swarm_id else None,
                response.node_id if response.node_id else None,
                response.task_id if response.task_id else None,
                response.iteration,
                response.circular,
                response.timestamp,
            )

            # Initialize the log entry if it's the first chunk
            if entry_key not in log_entries:
                log_entries[entry_key] = {
                    "swarm_id": response.swarm_id if response.swarm_id else None,
                    "node_id": response.node_id if response.node_id else None,
                    "task_id": response.task_id if response.task_id else None,
                    "alias": response.alias,
                    "module_id": response.module_id,
                    "iteration": response.iteration,
                    "circular": response.circular,
                    "timestamp": response.timestamp,
                    "severity": response.severity,
                    "content": bytearray(),
                }

            # Append the content chunk to existing content
            log_entries[entry_key]["content"].extend(response.content)

        # Convert all content byte arrays to strings and prepare the final result
        result = []
        for entry in log_entries.values():
            # Convert binary content to string
            if entry["content"]:
                entry["message"] = entry["content"].decode("utf-8")
            else:
                entry["message"] = ""

            # Remove the binary content to avoid duplicating data
            del entry["content"]

            # Add to result list
            result.append(entry)

        return result

    async def stream_logs(self, swarm_id: str) -> AsyncIterator[LogResponse]:
        """
        Stream real-time logs from swarm execution.

        Parameters
        ----------
        swarm_id : str
            Swarm ID

        Returns
        -------
        AsyncIterator[LogResponse]
            Stream of log entries with severity, message, timestamp

        Examples
        --------
        >>> async for log in user_api.stream_logs(swarm_id):
        ...     print(f"{log.severity}: {log.message}")
        """
        async for log in self._swarm_management_client.stream_logs(swarm_id):
            yield log

    async def list_result_tags(self, swarm_id: str) -> Tags:
        """
        List result tags for a specific swarm.

        Parameters
        ----------
        swarm_id : str
            The swarm ID

        Returns
        -------
        Tags
            Tags with usage information
        """
        tags = await self._swarm_management_client.list_result_tags(swarm_id)
        return tags

    async def list_global_tags(self, swarm_id: str) -> Tags:
        """
        List global tags for a specific swarm.

        Parameters
        ----------
        swarm_id : str
            The swarm ID

        Returns
        -------
        Tags
            Tags with usage information
        """
        tags = await self._swarm_management_client.list_global_tags(swarm_id)
        return tags

    async def select_global(
        self, swarm_id: str, tag: str
    ) -> AsyncIterator[SelectGlobalResponse]:
        """
        Select global data for a specific swarm and tag.

        Parameters
        ----------
        swarm_id : str
            The swarm ID
        tag : str
            The tag

        Returns
        -------
        AsyncIterator[SelectGlobalResponse]
            Stream of global data
        """
        async for result in self._swarm_management_client.select_global(swarm_id, tag):
            yield result
