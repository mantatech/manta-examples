# domain/task_lifecycle.py
"""Pure business logic for task lifecycle management."""

# Import domain entities (no infrastructure!)
from ..common.build import TaskStatus


class TaskTransitionRule:
    """Business rules for task state transitions."""

    ALLOWED_TRANSITIONS = {
        TaskStatus.PENDING: [TaskStatus.RUNNING, TaskStatus.FAILED],
        TaskStatus.RUNNING: [
            TaskStatus.COMPLETED,
            TaskStatus.FAILED,
            TaskStatus.STOPPED,
        ],
        TaskStatus.COMPLETED: [],  # Terminal state
        TaskStatus.FAILED: [],  # Terminal state
        TaskStatus.STOPPED: [],  # Terminal state
    }

    @staticmethod
    def can_transition(from_status: TaskStatus, to_status: TaskStatus) -> bool:
        """Check if a state transition is valid."""
        return to_status in TaskTransitionRule.ALLOWED_TRANSITIONS.get(from_status, [])

    @staticmethod
    def is_terminal(status: TaskStatus) -> bool:
        """
        Check if a status is a terminal state.

        Note: STOPPED is terminal for transitions but NOT for is_finished_task logic.
        The original logic only considered COMPLETED and FAILED as "finished".
        """
        return status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.STOPPED]

    @staticmethod
    def is_finished(status: TaskStatus) -> bool:
        """
        Check if a task is finished (ready to be marked as STOPPED).
        This matches the original is_finished_task() logic.
        """
        return status in [TaskStatus.COMPLETED, TaskStatus.FAILED]


class TaskLifecycleService:
    """Domain service for task lifecycle decisions (no infrastructure)."""

    @staticmethod
    def calculate_status_from_container(container_status: str) -> TaskStatus:
        """
        Business logic: Map container status to task status.
        No Docker dependency - just string input.
        """
        status_map = {
            "created": TaskStatus.PENDING,
            "running": TaskStatus.RUNNING,
            "exited": TaskStatus.COMPLETED,
            "dead": TaskStatus.FAILED,
            "paused": TaskStatus.FAILED,
            "restarting": TaskStatus.FAILED,
        }
        return status_map.get(container_status, TaskStatus.FAILED)

    @staticmethod
    def should_restart_task(
        current_iteration: int,
        new_iteration: int,
        current_circular: int,
        new_circular: int,
    ) -> bool:
        """
        Business rule: Should we restart a task based on iteration numbers?
        """
        return (new_iteration != current_iteration) or (
            new_circular != current_circular
        )

    @staticmethod
    def is_active(status: TaskStatus) -> bool:
        """Business rule: Is this an active (non-terminal) task?"""
        return not TaskTransitionRule.is_terminal(status)
