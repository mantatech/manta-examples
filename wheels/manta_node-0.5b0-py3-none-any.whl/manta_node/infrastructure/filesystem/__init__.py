"""Filesystem infrastructure - Dataset and file management."""

from .dataset_manager import DatasetManager

__all__ = [
    "DatasetManager",
]
