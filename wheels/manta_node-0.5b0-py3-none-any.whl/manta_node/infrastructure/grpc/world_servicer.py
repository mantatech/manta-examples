from logging import getLogger
from typing import AsyncIterator

from ...common.build import (
    ChunkResultValues,
    EnvId,
    GetGlobalRequest,
    GlobalTag,
    GlobalUpdate,
    GlobalValue,
    LightResult,
    LightResultQuery,
    Ok,
    Result,
    ResultQuery,
    SetGlobalRequest,
    TaskScheduling,
    TaskUpdate,
    WorldBase,
)
from ...common.conversions import ID
from ...common.decorators import catch_batch_errors, catch_streaming_errors
from ...common.traces import Tracer
from ..grpc.client import NodeClient
from ...tasks import TaskProgressions

__all__ = ["WorldServicer"]


class WorldServicer(WorldBase):
    """
    World Servicer allows containers to access data stored in the Manager

    Parameters
    ----------
    node_id : ID
        Node ID
    node_client : NodeClient
        Node client
    tasks : TaskProgressions
        Task Progressions from Task Manager
    """

    __slots__ = ["tracer", "node_client", "tasks"]

    def __init__(self, node_id: ID, node_client: NodeClient, tasks: TaskProgressions):
        self.tracer = Tracer(getLogger(__name__), node_id.oid)
        self.node_client = node_client
        self.tasks = tasks
        super().__init__()

    def task_update(self, swarm_id: ID, task_id: ID) -> TaskUpdate:
        """
        Convenient method to access task update from tasks
        given a task ID

        Parameters
        ----------
        swarm_id : PairId
            Swarm ID
        task_id : PairId
            Task ID

        Returns
        -------
        TaskUpdate
            Task Update
        """
        return self.tasks[(swarm_id.tid, task_id.tid)].task_update

    @catch_streaming_errors
    async def get_task_result(
        self, light_request: LightResultQuery
    ) -> AsyncIterator[ChunkResultValues]:
        """
        Get the swarm results

        Parameters
        ----------
        request : LightResultQuery
            Result query from the container

        Returns
        -------
        AsyncIterator[ChunkResultValues]
            Result values
        """
        task_id = ID(light_request.task_id)
        swarm_id = ID(light_request.swarm_id)
        task_update = self.task_update(swarm_id, task_id)
        iteration = task_update.iteration
        circular = task_update.circular
        self.tracer.set_metadata(
            task_id=task_id,
            swarm_id=swarm_id,
            iteration=iteration,
            circular=circular,
        )

        async for chunk in self.node_client.get_task_result(
            ResultQuery(
                swarm_id=swarm_id.oid,
                task_id=task_id.oid,
                node_id=self.tracer.metadata.node_id,
                iteration=iteration,
                tag=light_request.tag,
                size=light_request.size,
                method=light_request.method,
            )
        ):
            self.tracer.set_metadata(
                task_id=task_id,
                swarm_id=swarm_id,
                iteration=iteration,
                circular=circular,
            )
            yield chunk

    @catch_batch_errors
    async def add_task_result(self, stream: AsyncIterator[LightResult]) -> Ok:
        """
        Set a swarm result

        Parameters
        ----------
        request : LightResult
            Result from the container

        Returns
        -------
        Ok
            Response
        """

        async def stream_generator(
            stream: AsyncIterator[LightResult],
        ) -> AsyncIterator[Result]:
            async for light_request in stream:
                task_id = ID(light_request.task_id)
                swarm_id = ID(light_request.swarm_id)
                task_update = self.task_update(swarm_id, task_id)
                self.tracer.set_metadata(
                    task_id=task_id,
                    swarm_id=swarm_id,
                    iteration=task_update.iteration,
                    circular=task_update.circular,
                )

                yield Result(
                    swarm_id=swarm_id.oid,
                    task_id=task_id.oid,
                    node_id=self.tracer.metadata.node_id,
                    iteration=task_update.iteration,
                    tag=light_request.tag,
                    data=light_request.data,
                )

        return await self.node_client.add_task_result(stream_generator(stream))

    @catch_streaming_errors
    async def get_global(self, request: GetGlobalRequest) -> AsyncIterator[GlobalValue]:
        """
        Set a swarm global value

        Parameters
        ----------
        request : GlobalTag
            Task ID and global tag

        Returns
        -------
        GlobalValue
            Global value
        """
        task_id = ID(request.task_id)
        swarm_id = ID(request.swarm_id)
        task_update = self.task_update(swarm_id, task_id)
        circular = task_update.circular
        iteration = task_update.iteration

        async for chunk in self.node_client.get_global(
            GlobalTag(swarm_id=swarm_id.oid, tag=request.tag)
        ):
            self.tracer.set_metadata(
                task_id=task_id,
                swarm_id=swarm_id,
                iteration=iteration,
                circular=circular,
            )
            self.tracer.info(f"Received chunk for global of size {len(chunk.data)}")
            yield chunk

    @catch_batch_errors
    async def set_global(self, stream: AsyncIterator[SetGlobalRequest]) -> Ok:
        """
        Set a swarm result

        Parameters
        ----------
        request : SetGlobalRequest
            Task ID, global tag and value

        Returns
        -------
        Ok
            Response
        """

        async def stream_generator(
            stream: AsyncIterator[SetGlobalRequest],
        ) -> AsyncIterator[GlobalUpdate]:
            async for request in stream:
                swarm_id = ID(request.swarm_id)
                task_id = ID(request.task_id)
                task_update = self.task_update(swarm_id, task_id)
                self.tracer.set_metadata(
                    task_id=task_id,
                    swarm_id=swarm_id,
                    iteration=task_update.iteration,
                    circular=task_update.circular,
                )

                yield GlobalUpdate(
                    swarm_id=swarm_id.oid,
                    tag=request.tag,
                    data=request.data,
                )

        return await self.node_client.set_global(stream_generator(stream))

    @catch_batch_errors
    async def stop_swarm(self, request: EnvId) -> Ok:
        """
        Stop the swarm

        Parameters
        ----------
        request : EnvId
            Task ID

        Returns
        -------
        Ok
            Response
        """
        swarm_id = ID(request.swarm_id)
        task_id = ID(request.task_id)
        task_update = self.task_update(swarm_id, task_id)
        self.tracer.set_metadata(
            task_id=task_id,
            swarm_id=swarm_id,
            iteration=task_update.iteration,
            circular=task_update.circular,
        )
        return await self.node_client.stop_swarm(task_update)

    @catch_batch_errors
    async def schedule_task(self, light_request: TaskScheduling) -> Ok:
        """
        Schedule a task

        Parameters
        ----------
        request : TaskScheduling
            Task Scheduling from container

        Returns
        -------
        Ok
            Response
        """
        swarm_id = ID(light_request.swarm_id)
        task_id = ID(light_request.task_id)
        task_update = self.task_update(swarm_id, task_id)
        self.tracer.set_metadata(
            task_id=task_id,
            swarm_id=swarm_id,
            iteration=task_update.iteration,
            circular=task_update.circular,
        )
        return await self.node_client.schedule_task(light_request)
