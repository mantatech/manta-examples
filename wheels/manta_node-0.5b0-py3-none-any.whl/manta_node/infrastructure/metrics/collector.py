from ...common.errors import MantaError, MantaGRPCError, MantaMQTTError, MantaNodeError
from ...common.build import (
    DatasetOverviews,
    NodeStatus,
    NodeStatusEnum,
    SetSystemSummaryRequest,
)
from ...common.traces import Tracer
from ..filesystem.dataset_manager import DatasetManager
from ..metrics.metrics_collector import MetricsCollectorBase
from ..grpc.client import NodeClient


class Collector:
    """
    Collector class to collect information from the node

    Parameters
    ----------
    tracer : Tracer
        Tracer for the collector
    """

    tracer: Tracer
    node_client: NodeClient
    metrics_collector: MetricsCollectorBase
    dataset_manager: DatasetManager

    async def collect_information(self, payload: bytes):
        """
        Send the node information to the Manager

        Parameters
        ----------
        payload : bytes
            Payload

        Raises
        ------
        TaskManagerException
            Exception when the method requested is not allowed
        """
        try:
            method = payload.decode("utf-8")
            if method == "set_node_status":
                await self.set_node_status()
            elif method == "set_system_summary":
                await self.set_system_summary()
            elif method == "set_overviews":
                await self.set_overviews()
            else:
                raise MantaMQTTError(
                    f"Not allowed method: {method}", metadata=self.tracer.metadata
                )
        except MantaGRPCError as e:
            self.tracer.exception(f"Error when collecting information: {e}")
        except MantaError as manta_error:
            self.tracer.exception(repr(manta_error))
            await self.node_client.send_error(manta_error)
        except Exception as exc:
            message = f"Error for collecting information: {repr(exc)}"
            self.tracer.exception(message)
            await self.node_client.send_error(
                MantaNodeError(message, metadata=self.tracer.metadata)
            )

    async def set_node_status(self):  # DEAD CODE
        """
        Send the node information to the Manager
        """
        self.tracer.info("Sending NodeInfo to the Manager")
        await self.node_client.set_node_status(
            NodeStatus(
                node_id=self.tracer.metadata.node_id, status=NodeStatusEnum.CONNECTED
            )
        )

    async def set_system_summary(self):
        """
        Send the system information to the Manager
        """
        self.tracer.info("Sending SystemInfo to the Manager")
        metrics = await self.metrics_collector.collect_all_metrics()
        await self.node_client.set_system_summary(
            SetSystemSummaryRequest(
                node_id=self.tracer.metadata.node_id,
                metrics_snapshot=metrics,
            )
        )

    async def set_overviews(self):
        """
        Send the data information to the Manager
        """
        self.tracer.info("Sending DataInfo to the Manager")

        # Refresh the dataset metadata before sending
        self.dataset_manager.refresh()

        # Use the dataset_manager to get the overview information
        await self.node_client.set_overviews(
            DatasetOverviews(
                node_id=self.tracer.metadata.node_id,
                content=self.dataset_manager.to_proto(),
            )
        )
