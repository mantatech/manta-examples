"""Node configuration management command implementation."""

import argparse
import os
import subprocess
import sys
from pathlib import Path
from typing import List

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from ...infrastructure.config import IdentityConfig, NodeConfigManager, NodeConfiguration

console = Console()


def print_error(message: str):
    """Print error message in red."""
    console.print(f"[red]Error: {message}[/red]")


def print_success(message: str):
    """Print success message in green."""
    console.print(f"[green]{message}[/green]")


def print_warning(message: str):
    """Print warning message in yellow."""
    console.print(f"[yellow]{message}[/yellow]")


def init_config_from_file(config_file_path: str) -> int:
    """Create configuration from a YAML or TOML file.
    
    Args:
        config_file_path: Path to the configuration file (YAML or TOML)
        
    Returns:
        Exit code (0 for success, non-zero for error)
    """
    import yaml
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib
    
    console.print(
        Panel(
            "[bold cyan]Node Configuration Setup[/bold cyan]\n\n"
            "Loading configuration from file...\n"
            "Configuration will be saved in ~/.manta/nodes/",
            title="manta_node Configuration",
        )
    )

    try:
        # Validate input file exists
        source_path = Path(config_file_path).expanduser().absolute()
        if not source_path.exists():
            print_error(f"Configuration file not found: {source_path}")
            return 1
        
        # Extract config name from filename (without extension)
        config_name = source_path.stem
        
        # Determine file format from extension
        file_ext = source_path.suffix.lower()
        if file_ext not in ['.yaml', '.yml', '.toml']:
            print_error(f"Unsupported file format: {file_ext}")
            console.print("Supported formats: .yaml, .yml, .toml")
            return 1
        
        console.print(f"Loading configuration from: [cyan]{source_path}[/cyan]")
        console.print(f"Configuration name: [cyan]{config_name}[/cyan]")
        
        # Load configuration data based on file format
        try:
            with open(source_path, 'rb') as f:
                if file_ext in ['.yaml', '.yml']:
                    config_data = yaml.safe_load(f)
                else:  # .toml
                    config_data = tomllib.load(f)
        except yaml.YAMLError as e:
            print_error(f"Invalid YAML format: {e}")
            return 1
        except Exception as e:
            print_error(f"Failed to parse configuration file: {e}")
            return 1
        
        if not isinstance(config_data, dict):
            print_error("Configuration file must contain a dictionary/object at the root level")
            return 1
        
        # Create the target directory if it doesn't exist
        nodes_dir = Path.home() / ".manta" / "nodes"
        nodes_dir.mkdir(parents=True, exist_ok=True)
        console.print(f"[green]✓[/green] Configuration directory ready: {nodes_dir}")
        
        # Check if configuration already exists
        target_path = nodes_dir / f"{config_name}.toml"
        if target_path.exists():
            print_warning(f"Configuration '{config_name}' already exists at: {target_path}")
            overwrite = Confirm.ask(
                "Overwrite existing configuration?",
                default=False,
            )
            if not overwrite:
                console.print("[yellow]Configuration creation cancelled[/yellow]")
                return 1
        
        # Create NodeConfiguration from the loaded data
        try:
            config = NodeConfiguration.from_dict(config_data)
        except Exception as e:
            print_error(f"Invalid configuration structure: {e}")
            console.print("\n[dim]Please ensure your configuration file contains all required fields.[/dim]")
            console.print("[dim]Required: identity.secured_token[/dim]")
            return 1
        
        # Update metadata with the config name if not already set
        if not config.metadata.name or config.metadata.name == "default":
            config.metadata.name = config_name
        
        # Update logging filename based on config name
        if config.identity.alias:
            node_name = config.identity.alias
        elif config.metadata.name and config.metadata.name != "default":
            node_name = config.metadata.name
        else:
            node_name = "node"
        
        # Clean the name to be filesystem-safe
        safe_name = "".join(
            c if c.isalnum() or c in "-_" else "_" for c in node_name
        )
        # Set to centralized logs directory with nodes subfolder
        config.logging.filename = str(
            Path.home() / ".manta" / "logs" / "nodes" / f"{safe_name}.log"
        )
        
        # Save configuration as TOML
        config_manager = NodeConfigManager(target_path)
        config_manager._config = config
        config_manager.save()
        
        console.print(
            f"\n[green]✓[/green] Configuration '{config_name}' created successfully!"
        )
        console.print(f"[dim]Saved to: {target_path}[/dim]")
        
        # Validate configuration
        issues = config_manager.validate()
        if issues:
            print_warning("Configuration has validation issues:")
            for issue in issues:
                console.print(f"  - {issue}")
        else:
            console.print("[green]✓[/green] Configuration is valid")
        
        console.print("\nYou can now start a node with:")
        console.print(f"  [cyan]manta_node start {config_name}[/cyan]")
        
        return 0
    
    except KeyboardInterrupt:
        console.print("\n[yellow]Configuration creation cancelled[/yellow]")
        return 1
    except Exception as e:
        print_error(f"Failed to create configuration: {e}")
        import traceback
        console.print(f"[dim]{traceback.format_exc()}[/dim]")
        return 1


def list_configs() -> int:
    """List all available configurations."""
    config_manager = NodeConfigManager()
    configs = config_manager.list_available_configs()

    if not configs:
        console.print("No configurations found.")
        console.print("")
        console.print("Create a configuration with:")
        console.print("  manta_node config init <path/to/config.yaml>")
        return 0

    table = Table(title="Available Node Configurations")
    table.add_column("Name", style="cyan")
    table.add_column("Path", style="dim")
    table.add_column("Status", style="magenta")

    for config_name in configs:
        config_path = Path.home() / ".manta" / "nodes" / f"{config_name}.toml"

        # Try to load and validate config
        try:
            temp_manager = NodeConfigManager(config_path)
            issues = temp_manager.validate()
            status = (
                "[green]Valid[/green]"
                if not issues
                else f"[yellow]{len(issues)} issues[/yellow]"
            )
        except Exception:
            status = "[red]Invalid[/red]"

        table.add_row(config_name, str(config_path), status)

    console.print(table)
    return 0


def show_config(config_name: str) -> int:
    """Show details of a specific configuration."""
    config_path = Path.home() / ".manta" / "nodes" / f"{config_name}.toml"

    if not config_path.exists():
        print_error(f"Configuration '{config_name}' not found")
        console.print("Available configurations:")
        config_manager = NodeConfigManager()
        for cfg in config_manager.list_available_configs():
            console.print(f"  - {cfg}")
        return 1

    try:
        config_manager = NodeConfigManager(config_path)
        config = config_manager.config

        console.print(f"\n[bold]Configuration: {config_name}[/bold]")
        console.print(f"Path: [dim]{config_path}[/dim]")

        # Show identity
        console.print("\n[bold cyan]Identity:[/bold cyan]")
        console.print(f"  Alias: {config.identity.alias or 'Auto-generated'}")
        console.print(f"  Random ID: {config.identity.random_id}")
        console.print(
            f"  Secured Token: {'Set' if config.identity.secured_token else 'Not set'}"
        )

        # Show network
        console.print("\n[bold cyan]Network:[/bold cyan]")
        console.print(
            f"  Manager: {config.network.manager_host}:{config.network.manager_port}"
        )
        # Don't show light service configuration by default (simplify for users)

        # Show datasets if configured
        if config.datasets.mappings:
            console.print("\n[bold cyan]Datasets:[/bold cyan]")
            for name, path in config.datasets.mappings.items():
                console.print(f"  {name}: {path}")

        # Show metadata
        console.print("\n[bold cyan]Metadata:[/bold cyan]")
        console.print(f"  Name: {config.metadata.name}")
        console.print(f"  Description: {config.metadata.description}")
        console.print(f"  Created: {config.metadata.created_at}")
        console.print(f"  Version: {config.metadata.version}")

        # Validate and show issues
        issues = config_manager.validate()
        if issues:
            console.print("\n[bold red]Validation Issues:[/bold red]")
            for issue in issues:
                console.print(f"  - {issue}")
        else:
            console.print("\n[green]✓ Configuration is valid[/green]")

        return 0

    except Exception as e:
        print_error(f"Failed to load configuration: {e}")
        return 1


def validate_config(config_name: str) -> int:
    """Validate a configuration."""
    config_path = Path.home() / ".manta" / "nodes" / f"{config_name}.toml"

    if not config_path.exists():
        print_error(f"Configuration '{config_name}' not found")
        return 1

    try:
        config_manager = NodeConfigManager(config_path)
        issues = config_manager.validate()

        if not issues:
            print_success(f"Configuration '{config_name}' is valid")
            return 0
        else:
            print_error(
                f"Configuration '{config_name}' has {len(issues)} validation issue(s):"
            )
            for issue in issues:
                console.print(f"  - {issue}")
            return 1

    except Exception as e:
        print_error(f"Failed to validate configuration: {e}")
        return 1


def delete_config(config_name: str) -> int:
    """Delete a configuration file."""
    config_path = Path.home() / ".manta" / "nodes" / f"{config_name}.toml"

    if not config_path.exists():
        print_error(f"Configuration '{config_name}' not found")
        console.print("Available configurations:")
        config_manager = NodeConfigManager()
        for cfg in config_manager.list_available_configs():
            console.print(f"  - {cfg}")
        return 1

    # Confirm deletion
    console.print(f"Configuration to delete: [cyan]{config_name}[/cyan]")
    console.print(f"File: [dim]{config_path}[/dim]")

    if not Confirm.ask(
        f"Are you sure you want to delete configuration '{config_name}'?", default=False
    ):
        console.print("[yellow]Deletion cancelled[/yellow]")
        return 0

    try:
        config_path.unlink()
        print_success(f"Configuration '{config_name}' deleted successfully")
        return 0

    except Exception as e:
        print_error(f"Failed to delete configuration: {e}")
        return 1


def edit_config(config_name: str) -> int:
    """Edit a configuration file in the default text editor."""
    try:
        # Build configuration path
        config_path = Path.home() / ".manta" / "nodes" / f"{config_name}.toml"

        if not config_path.exists():
            print_error(f"Configuration '{config_name}' not found")
            console.print("Available configurations:")
            config_manager = NodeConfigManager()
            for cfg in config_manager.list_available_configs():
                console.print(f"  - {cfg}")
            return 1

        # Determine which editor to use
        editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")

        if not editor:
            # Try common editors
            for cmd in ["nano", "vim", "vi", "emacs", "code", "notepad"]:
                try:
                    subprocess.run(["which", cmd], capture_output=True, check=True)
                    editor = cmd
                    break
                except (subprocess.CalledProcessError, FileNotFoundError):
                    continue

        if not editor:
            print_error(
                "No text editor found. Please set the EDITOR environment variable."
            )
            console.print(f"Configuration file location: {config_path}")
            return 1

        # Open the file in the editor
        console.print(f"Opening {config_path} in {editor}...")

        try:
            result = subprocess.run([editor, str(config_path)])
            if result.returncode == 0:
                print_success(f"Configuration '{config_name}' edited successfully")

                # Validate the configuration after editing
                config_manager = NodeConfigManager(config_path)
                issues = config_manager.validate()
                if issues:
                    print_warning("Configuration has validation issues:")
                    for issue in issues:
                        console.print(f"  - {issue}")

                return 0
            else:
                print_error(f"Editor exited with error code {result.returncode}")
                return 1

        except Exception as e:
            print_error(f"Failed to open editor: {e}")
            console.print(f"Configuration file location: {config_path}")
            return 1

    except Exception as e:
        print_error(f"Failed to edit configuration: {e}")
        return 1


def config_command(args: List[str]) -> int:
    """Handle node config command.

    Args:
        args: Command line arguments

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    parser = argparse.ArgumentParser(
        prog="manta_node config", description="Manage node configurations"
    )
    subparsers = parser.add_subparsers(dest="action", help="Configuration actions")

    # Init subcommand
    init_parser = subparsers.add_parser(
        "init", 
        help="Create a new configuration from a YAML or TOML file"
    )
    init_parser.add_argument(
        "config_file",
        help="Path to configuration file (.yaml, .yml, or .toml)"
    )

    # List subcommand
    subparsers.add_parser("list", help="List all configurations")

    # Show subcommand
    show_parser = subparsers.add_parser("show", help="Show configuration details")
    show_parser.add_argument("config", help="Configuration name to show")

    # Validate subcommand
    validate_parser = subparsers.add_parser("validate", help="Validate a configuration")
    validate_parser.add_argument("config", help="Configuration name to validate")

    # Delete subcommand
    delete_parser = subparsers.add_parser("delete", help="Delete a configuration")
    delete_parser.add_argument("config", help="Configuration name to delete")

    # Edit subcommand
    edit_parser = subparsers.add_parser(
        "edit", help="Edit configuration file in text editor"
    )
    edit_parser.add_argument(
        "config",
        nargs="?",
        default="default",
        help="Configuration name to edit (default: default)",
    )

    try:
        parsed_args = parser.parse_args(args)
    except SystemExit:
        return 1

    if not parsed_args.action:
        parser.print_help()
        return 1

    if parsed_args.action == "init":
        return init_config_from_file(parsed_args.config_file)
    elif parsed_args.action == "list":
        return list_configs()
    elif parsed_args.action == "show":
        return show_config(parsed_args.config)
    elif parsed_args.action == "validate":
        return validate_config(parsed_args.config)
    elif parsed_args.action == "delete":
        return delete_config(parsed_args.config)
    elif parsed_args.action == "edit":
        return edit_config(parsed_args.config)
    else:
        print_error(f"Unknown action: {parsed_args.action}")
        return 1


if __name__ == "__main__":
    import sys

    sys.exit(config_command(sys.argv[1:]))
