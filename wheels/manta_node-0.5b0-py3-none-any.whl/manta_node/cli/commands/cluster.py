"""Node cluster management command implementation."""

import argparse
import subprocess
import sys
import time
from pathlib import Path
from typing import List

from rich.console import Console
from rich.prompt import Confirm, Prompt

from ...infrastructure.config import NodeConfigManager
from .stop import find_running_instances, stop_instance_by_pid

console = Console()

# Configuration constants
NODE_START_DELAY_SECONDS = 1  # Delay between node starts to prevent resource conflicts


def print_error(message: str):
    """Print error message in red."""
    console.print(f"[red]Error: {message}[/red]")


def print_success(message: str):
    """Print success message in green."""
    console.print(f"[green]{message}[/green]")


def print_warning(message: str):
    """Print warning message in yellow."""
    console.print(f"[yellow]{message}[/yellow]")


def start_cluster_multi_config(count: int) -> int:
    """Start a cluster with different configurations for each node."""
    console.print(f"[bold]Starting cluster with {count} nodes[/bold]")
    console.print("You will be prompted to select a configuration for each node.\n")

    config_manager = NodeConfigManager()
    available_configs = config_manager.list_available_configs()

    if not available_configs:
        print_error("No configurations found. Please create configurations first.")
        console.print("Run: manta_node config init <path/to/config.yaml>")
        return 1

    # Show available configurations
    console.print("[cyan]Available configurations:[/cyan]")
    for i, cfg in enumerate(available_configs, 1):
        console.print(f"  {i}. {cfg}")
    console.print("")

    # Collect configuration for each node
    node_configs = []
    for i in range(count):
        console.print(f"[bold]Node {i+1}/{count}:[/bold]")

        # Allow user to select configuration
        while True:
            config_choice = Prompt.ask(
                f"Select configuration for node {i+1}",
                choices=available_configs,
                default=available_configs[0] if available_configs else None,
            )

            # Config name should be valid since we're using choices constraint
            if config_choice in available_configs:
                config_name = config_choice
                break
            else:
                print_error(f"Invalid choice: {config_choice}")

        # Get alias for this node - try to get from config file first
        config_manager = NodeConfigManager()
        node_config = config_manager.get_node_config(config_name)

        # Use config's alias if available, otherwise use config name
        if node_config and node_config.identity.alias:
            default_alias = node_config.identity.alias
        else:
            default_alias = config_name

        alias = Prompt.ask(f"Alias for node {i+1}", default=default_alias)

        node_configs.append({"config": config_name, "alias": alias})
        console.print("")

    # Confirm before starting
    console.print("[bold]Cluster configuration summary:[/bold]")
    for i, node in enumerate(node_configs, 1):
        console.print(f"  Node {i}: config='{node['config']}', alias='{node['alias']}'")
    console.print("")

    if not Confirm.ask("Start cluster with this configuration?", default=True):
        console.print("Operation cancelled.")
        return 0

    # Start nodes
    console.print("\n[bold]Starting nodes...[/bold]")
    started_nodes = []
    failed_nodes = []

    for i, node in enumerate(node_configs):
        console.print(f"Starting node {i+1}/{count}: {node['alias']}")

        try:
            # Use subprocess to start each node in background
            cmd = [
                sys.executable,
                "-m",
                "manta_node",
                "start",
                node["config"],
                "--alias",
                node["alias"],
                "--background",
            ]

            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                started_nodes.append(node["alias"])
                console.print(f"  ✓ Started {node['alias']}")
            else:
                failed_nodes.append(node["alias"])
                console.print(
                    f"  ✗ Failed to start {node['alias']}: {result.stderr.strip()}"
                )

        except (subprocess.SubprocessError, OSError, FileNotFoundError) as e:
            failed_nodes.append(node["alias"])
            console.print(f"  ✗ Failed to start {node['alias']}: {e}")

        # Small delay between starts to prevent resource conflicts
        if i < count - 1:
            time.sleep(NODE_START_DELAY_SECONDS)

    # Summary
    console.print("")
    if started_nodes:
        print_success(f"Successfully started {len(started_nodes)} nodes:")
        for node in started_nodes:
            console.print(f"  - {node}")

    if failed_nodes:
        print_error(f"Failed to start {len(failed_nodes)} nodes:")
        for node in failed_nodes:
            console.print(f"  - {node}")
        return 1

    console.print("")
    console.print("Cluster commands:")
    console.print("  View all nodes: manta_node status")
    console.print("  Stop cluster: manta_node cluster stop")
    console.print("  View logs: manta_node logs <node-name>")

    return 0


def start_cluster_simple(count: int, config_name: str) -> int:
    """Start a simple cluster with N nodes using the same configuration."""
    console.print(
        f"Starting cluster with {count} nodes using config '{config_name}'..."
    )

    # Check if config exists
    config_path = Path.home() / ".manta" / "nodes" / f"{config_name}.toml"
    if not config_path.exists():
        print_error(f"Configuration '{config_name}' not found")
        console.print("Available configurations:")

        config_manager = NodeConfigManager()
        for cfg in config_manager.list_available_configs():
            console.print(f"  - {cfg}")
        return 1

    started_nodes = []
    failed_nodes = []

    console.print(f"Starting {count} nodes...")

    for i in range(count):
        node_alias = f"{config_name}-cluster-{i+1}"
        console.print(f"Starting node {i+1}/{count}: {node_alias}")

        try:
            # Use subprocess to start each node in background
            cmd = [
                sys.executable,
                "-m",
                "manta_node",
                "start",
                config_name,
                "--alias",
                node_alias,
                "--background",
            ]

            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                started_nodes.append(node_alias)
                console.print(f"  ✓ Started {node_alias}")
            else:
                failed_nodes.append(node_alias)
                console.print(
                    f"  ✗ Failed to start {node_alias}: {result.stderr.strip()}"
                )

        except (subprocess.SubprocessError, OSError, FileNotFoundError) as e:
            failed_nodes.append(node_alias)
            console.print(f"  ✗ Failed to start {node_alias}: {e}")

        # Small delay between starts to prevent resource conflicts
        if i < count - 1:
            time.sleep(NODE_START_DELAY_SECONDS)

    # Summary
    console.print("")
    if started_nodes:
        print_success(f"Successfully started {len(started_nodes)} nodes:")
        for node in started_nodes:
            console.print(f"  - {node}")

    if failed_nodes:
        print_error(f"Failed to start {len(failed_nodes)} nodes:")
        for node in failed_nodes:
            console.print(f"  - {node}")
        return 1

    console.print("")
    console.print("Cluster commands:")
    console.print("  View all nodes: manta_node status")
    console.print("  Stop cluster: manta_node cluster stop")
    console.print("  View logs: manta_node logs <node-name>")

    return 0


def stop_cluster() -> int:
    """Stop all cluster nodes (nodes with '-cluster-' in their name)."""
    # Find all running instances

    instances = find_running_instances()

    # Filter cluster instances (check both instance_id and alias)
    cluster_instances = [
        inst
        for inst in instances
        if "-cluster-" in inst.get("instance_id", "")
        or "-cluster-" in inst.get("alias", "")
    ]

    if not cluster_instances:
        console.print("No cluster nodes found.")
        return 0

    console.print(f"Found {len(cluster_instances)} cluster nodes:")
    for instance in cluster_instances:
        console.print(f"  - {instance['instance_id']} (PID: {instance['pid']})")

    if not Confirm.ask("Stop all cluster nodes?", default=False):
        console.print("Operation cancelled.")
        return 0

    console.print("")
    console.print("Stopping cluster nodes...")

    stopped_count = 0
    for instance in cluster_instances:
        try:

            if stop_instance_by_pid(instance):
                stopped_count += 1
                console.print(f"  ✓ Stopped {instance['instance_id']}")
            else:
                console.print(f"  ✗ Failed to stop {instance['instance_id']}")
        except Exception as e:
            console.print(f"  ✗ Failed to stop {instance['instance_id']}: {e}")

    console.print("")
    if stopped_count == len(cluster_instances):
        print_success(f"All {stopped_count} cluster nodes stopped successfully")
        return 0
    else:
        print_warning(f"Stopped {stopped_count}/{len(cluster_instances)} cluster nodes")
        return 1


def cluster_command(args: List[str]) -> int:
    """Handle node cluster command.

    Args:
        args: Command line arguments

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    # Special handling for direct count argument (e.g., "manta_node cluster 2")
    if args and args[0].isdigit():
        count = int(args[0])
        # Call multi-config function to prompt for each node's configuration
        return start_cluster_multi_config(count)

    parser = argparse.ArgumentParser(
        prog="manta_node cluster", description="Manage node clusters"
    )
    subparsers = parser.add_subparsers(dest="action", help="Cluster actions")

    # Start subcommand - make both count and config flexible
    start_parser = subparsers.add_parser("start", help="Start a cluster of nodes")
    start_parser.add_argument(
        "positional_count", type=int, nargs="?", help="Number of nodes to start"
    )
    start_parser.add_argument(
        "--config",
        "-c",
        default=None,  # Changed from "default" to None to detect when not specified
        help="Base configuration to use (if not specified, prompts for each node)",
    )
    start_parser.add_argument(
        "--count",
        "-n",
        type=int,
        dest="flag_count",
        help="Number of nodes to start (alternative to positional argument)",
    )

    # Stop subcommand
    subparsers.add_parser("stop", help="Stop all cluster nodes")

    try:
        parsed_args = parser.parse_args(args)
    except SystemExit:
        return 1

    if not parsed_args.action:
        console.print("[bold]manta_node Cluster Management[/bold]")
        console.print("")
        console.print("Available commands:")
        console.print("  [cyan]start[/cyan]   Start a cluster of nodes")
        console.print("  [cyan]stop[/cyan]    Stop all cluster nodes")
        console.print("")
        console.print("Examples:")
        console.print(
            "  manta_node cluster 2                     # Quick start: prompts for each node's config"
        )
        console.print(
            "  manta_node cluster start 3               # Prompts for config for each node"
        )
        console.print(
            "  manta_node cluster start 3 --config dev  # Uses same config for all nodes"
        )
        console.print(
            "  manta_node cluster stop                  # Stop all cluster nodes"
        )
        console.print("")
        console.print("To view status of all nodes (including cluster nodes):")
        console.print("  manta_node status")
        return 0

    if parsed_args.action == "start":
        # Get count from either positional argument or --count flag
        # Priority: --count flag > positional argument
        count = None

        # Check --count flag first (higher priority)
        if hasattr(parsed_args, "flag_count") and parsed_args.flag_count is not None:
            count = parsed_args.flag_count
        # Fall back to positional argument
        elif (
            hasattr(parsed_args, "positional_count")
            and parsed_args.positional_count is not None
        ):
            count = parsed_args.positional_count

        if count is None:
            print_error("Node count is required")
            console.print("Examples:")
            console.print("  manta_node cluster 2  # Prompts for config for each node")
            console.print(
                "  manta_node cluster start 3  # Prompts for config for each node"
            )
            console.print(
                "  manta_node cluster start 3 --config dev_0  # Uses same config for all"
            )
            return 1

        if count <= 0:
            print_error("Node count must be greater than 0")
            return 1
        if count > 10:
            print_warning(
                "Starting more than 10 nodes may consume significant resources"
            )
            if not Confirm.ask("Continue?", default=False):
                return 0

        # If config is specified, use simple cluster start (same config for all nodes)
        if parsed_args.config is not None:
            return start_cluster_simple(count, parsed_args.config)
        else:
            # If no config specified, prompt for each node's configuration
            return start_cluster_multi_config(count)

    elif parsed_args.action == "stop":
        return stop_cluster()

    else:
        print_error(f"Unknown action: {parsed_args.action}")
        return 1


if __name__ == "__main__":
    import sys

    sys.exit(cluster_command(sys.argv[1:]))
