"""Node start command implementation."""

import argparse
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import List

from rich.console import Console

from ...common.logging_config import configure_logging

from ...node_orchestrator import Node

from ...infrastructure.config import NodeConfigManager

console = Console()


def print_error(message: str):
    """Print error message in red."""
    console.print(f"[red]Error: {message}[/red]")


def print_success(message: str):
    """Print success message in green."""
    console.print(f"[green]{message}[/green]")


def print_warning(message: str):
    """Print warning message in yellow."""
    console.print(f"[yellow]{message}[/yellow]")


def start_node_foreground(
    config_manager: NodeConfigManager,
    instance_id: str,
    instance_alias: str,
    skip_instance_file: bool = False,
) -> int:
    """Start a node in foreground mode."""
    console.print(f"[cyan]Starting node '{instance_alias}' in foreground...[/cyan]")
    console.print("[dim]Press Ctrl+C to stop[/dim]")

    # Create instance file to track running node (unless we're a subprocess of background mode)
    instance_file = None
    if not skip_instance_file:
        instance_dir = Path.home() / ".manta" / "nodes" / "instances"
        instance_dir.mkdir(parents=True, exist_ok=True)
        instance_file = instance_dir / f"{instance_id}.json"

        console.print(f"Instance ID: {instance_id}")
        console.print(f"Log file: {config_manager.config.logging.filename}")

        instance_data = {
            "instance_id": instance_id,
            "alias": instance_alias,
            "config_name": config_manager.config.metadata.name,
            "pid": os.getpid(),
            "start_time": datetime.now().isoformat(),
            "status": "running",
            "manager_host": config_manager.config.network.manager_host,
            "manager_port": config_manager.config.network.manager_port,
            "log_file": config_manager.config.logging.filename,
        }

        with open(instance_file, "w") as f:
            json.dump(instance_data, f, indent=2)

    loop = None  # Initialize loop variable for cleanup
    node = None  # Initialize node variable for cleanup
    shutdown_requested = False  # Track if shutdown was requested

    def signal_handler(signum, frame):
        """Handle termination signals (SIGTERM, SIGINT)."""
        nonlocal shutdown_requested
        if not shutdown_requested:
            shutdown_requested = True
            sig_name = signal.Signals(signum).name
            console.print(f"\n[yellow]Received {sig_name}, stopping node...[/yellow]")
            # Raise KeyboardInterrupt to trigger the cleanup in the except block
            raise KeyboardInterrupt()

    # Set up signal handlers for graceful shutdown
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    try:
        # Configure logging based on node configuration
        log_config = config_manager.config.logging

        # Ensure log directory exists
        log_path = Path(log_config.filename)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        # Create config dictionary based on MANTA_LOGGING_CONFIG template
        config_dict = {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "standard": {
                    "format": "%(asctime)s - %(levelname)s - %(name)s - %(message)s"
                }
            },
            "filters": {
                "manta_filter": {
                    "()": "manta_node.common.logging_config.filter_manta",
                    "level": "INFO",
                },
                "warnings_and_below": {
                    "()": "manta_node.common.logging_config.filter_maker",
                    "level": "WARNING",
                },
            },
            "handlers": {
                "file": {
                    "class": "logging.FileHandler",
                    "formatter": "standard",
                    "filename": log_config.filename,
                    "filters": ["manta_filter"],
                    "mode": "w",
                },
                "rich": {
                    "class": "rich.logging.RichHandler",
                    "formatter": "standard",
                    "markup": True,
                    "filters": ["manta_filter"],
                    "console": Console(
                        _environ={"COLUMNS": "284"},
                    ),
                },
            },
            "root": {"level": log_config.level, "handlers": []},
        }

        # Set up handlers based on configuration
        if log_config.log_to_file:
            config_dict["root"]["handlers"].append("file")
        if log_config.log_to_console:
            config_dict["root"]["handlers"].append("rich")

        # Call configure_logging with the config dictionary
        configure_logging(config=config_dict, debug=log_config.debug_mode)

        # Display connection information before starting
        security_mode = "TLS" if (
            config_manager.config.security.use_tls or
            config_manager.config.network.manager_port == 443
        ) else "insecure"
        endpoint = (
            f"{security_mode}://"
            f"{config_manager.config.network.manager_host}:"
            f"{config_manager.config.network.manager_port}"
        )

        console.print(f"[cyan]Manager endpoint:[/cyan] {endpoint}")

        # Show JWT token status (without exposing the token)
        token = config_manager.config.identity.secured_token
        if token:
            token_parts = token.count('.') + 1
            token_status = "valid format" if token_parts == 3 else f"invalid format ({token_parts} parts, expected 3)"
            console.print(f"[cyan]JWT token:[/cyan] present ({len(token)} chars, {token_status})")
        else:
            console.print("[red]JWT token:[/red] missing")

        console.print("")  # Empty line for readability

        # Create Node instance with configuration manager
        node = Node(config_manager)

        # Start node in current thread (blocking)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(node.start())

        print_success("Node stopped successfully")
        return 0

    except KeyboardInterrupt:
        # This handles both CTRL-C and SIGTERM via signal_handler
        try:
            if loop and node:
                # Ensure cleanup is called when stopping the node
                loop.run_until_complete(node.stop())
        except Exception as e:
            console.print(f"[red]Error during node cleanup: {e}[/red]")

        # Clean up instance file
        if instance_file and instance_file.exists():
            instance_file.unlink()

        console.print("[green]Node stopped gracefully[/green]")
        return 0

    except Exception as e:
        print_error(f"Node failed with error: {e}")
        # Clean up instance file on error
        if instance_file and instance_file.exists():
            instance_file.unlink()
        return 1


def start_node_background(
    config_manager: NodeConfigManager,
    instance_id: str,
    instance_alias: str,
    log_file: Path,
) -> int:
    """Start a node in background mode."""
    console.print(f"[cyan]Starting node '{instance_alias}' in background...[/cyan]")

    try:
        # Prepare command to run node in background
        # We call the CLI with the start command in foreground mode
        cmd = [
            sys.executable,
            "-m",
            "manta_node",
            "start",
            str(config_manager.config_path.stem),  # Use config name without extension
            "--foreground",  # This will run in foreground for the subprocess
            "--subprocess",  # Tell the subprocess not to create instance file
        ]

        # If alias was overridden, add it to the command
        if instance_alias != config_manager.config.identity.alias:
            cmd.extend(["--alias", instance_alias])

        # Ensure log directory exists
        log_file.parent.mkdir(parents=True, exist_ok=True)

        # Start subprocess
        with open(log_file, "w") as log:
            proc = subprocess.Popen(
                cmd,
                stdout=log,
                stderr=log,
                start_new_session=True,  # Detach from parent
            )

        # Wait a moment and check if process is running
        time.sleep(2)

        if proc.poll() is None:  # Process is still running
            print_success(f"Node '{instance_alias}' started successfully")
            console.print(f"Instance ID: {instance_id}")
            console.print(f"Process ID: {proc.pid}")
            console.print(f"Log file: {log_file}")

            # Create instance file for tracking (same format as foreground)
            instance_dir = Path.home() / ".manta" / "nodes" / "instances"
            instance_dir.mkdir(parents=True, exist_ok=True)
            instance_file = instance_dir / f"{instance_id}.json"

            instance_data = {
                "instance_id": instance_id,
                "alias": instance_alias,
                "config_name": config_manager.config.metadata.name,
                "pid": proc.pid,
                "start_time": datetime.now().isoformat(),
                "status": "running",
                "manager_host": config_manager.config.network.manager_host,
                "manager_port": config_manager.config.network.manager_port,
                "log_file": str(log_file),
            }

            with open(instance_file, "w") as f:
                json.dump(instance_data, f, indent=2)

            return 0
        else:
            print_error("Node failed to start. Check logs for details.")
            if log_file.exists():
                console.print(f"Log file: {log_file}")
            return 1

    except Exception as e:
        print_error(f"Failed to start background node: {e}")
        return 1


def start_command(args: List[str]) -> int:
    """Handle node start command.

    Args:
        args: Command line arguments

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    parser = argparse.ArgumentParser(
        prog="manta_node start", description="Start a node instance"
    )
    parser.add_argument(
        "config",
        nargs="?",
        default="default",
        help="Configuration name to use (default: default)",
    )
    parser.add_argument("--alias", help="Override node alias")
    parser.add_argument(
        "--background", "-d", action="store_true", help="Run node in background"
    )
    parser.add_argument(
        "--foreground", action="store_true", help="Run node in foreground (default)"
    )
    parser.add_argument(
        "--subprocess",
        action="store_true",
        help=argparse.SUPPRESS,  # Hidden flag for internal use
    )

    try:
        parsed_args = parser.parse_args(args)
    except SystemExit:
        return 1

    config_name = parsed_args.config
    alias = parsed_args.alias
    background = parsed_args.background and not parsed_args.foreground

    # Build configuration path
    config_path = Path.home() / ".manta" / "nodes" / f"{config_name}.toml"

    if not config_path.exists():
        print_error(f"Configuration '{config_name}' not found at {config_path}")
        console.print("Available configurations:")
        config_mgr = NodeConfigManager()
        for cfg in config_mgr.list_available_configs():
            console.print(f"  - {cfg}")
        console.print("")
        console.print("Create a new configuration with:")
        console.print("  manta_node config init <path/to/config.yaml>")
        return 1

    try:
        # Create NodeConfigManager with the config path
        config_manager = NodeConfigManager(config_path)

        # Override alias if provided
        if alias:
            config_manager.config.identity.alias = alias
            config_manager.save()
        elif (
            config_manager.config.identity.alias is None
            and config_manager.config.metadata.name is not None
        ):
            config_manager.config.identity.alias = config_manager.config.metadata.name
            config_manager.save()
        elif (
            config_manager.config.identity.alias is None
            and config_manager.config.identity.alias is None
        ):
            config_manager.config.identity.alias = config_name
            config_manager.save()

        # Validate configuration
        issues = config_manager.validate()
        if issues:
            print_error("Configuration validation failed:")
            for issue in issues:
                console.print(f"  - {issue}")
            return 1

        # Generate instance ID
        instance_id = f"{config_name}-{uuid.uuid4().hex[:8]}"
        instance_alias = alias or config_manager.config.identity.alias or config_name

        # Check for token in configuration
        if (
            not config_manager.config.identity.secured_token
            or config_manager.config.identity.secured_token.startswith("<")
        ):
            print_error("No valid secured token found in configuration")
            console.print("A secured token (JWT) is required for node authentication.")
            console.print("")
            console.print("Solutions:")
            console.print(
                "  • Set environment variable: export MANTA_NODE_TOKEN=your_jwt_token"
            )
            console.print(f"  • Edit config file: {config_path}")
            console.print('  • Update: secured_token = "your_jwt_token_here"')
            console.print("  • Or recreate config: manta_node config init <path/to/config.yaml>")
            return 1

        # Prepare log file - use configured filename
        # Defensively handle tilde expansion
        log_filename = config_manager.config.logging.filename

        # Expand tilde if present at the start of the path
        if log_filename.startswith("~"):
            log_path = Path(log_filename).expanduser()
        else:
            log_path = Path(log_filename)

        # Check if path is now absolute or still relative
        if log_path.is_absolute():
            log_file = log_path
        else:
            # If relative path, place it in the standard log directory
            log_dir = Path.home() / ".manta" / "logs" / "nodes"
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / log_path

        if background:
            return start_node_background(
                config_manager, instance_id, instance_alias, log_file
            )
        else:
            # Check if we're being called as a subprocess from background mode
            skip_instance_file = getattr(parsed_args, "subprocess", False)
            return start_node_foreground(
                config_manager, instance_id, instance_alias, skip_instance_file
            )

    except Exception as e:
        print_error(f"Failed to start node: {e}")
        console.print("")
        console.print("Troubleshooting steps:")
        console.print(
            "  1. Check if configuration is valid: manta_node config validate"
        )
        console.print(
            "  2. Verify manager is running: docker ps (look for manta services)"
        )
        console.print("  3. Check if port is available: netstat -ln | grep :50051")
        console.print("  4. Validate secured_token is set in config file")
        return 1


if __name__ == "__main__":
    import sys

    sys.exit(start_command(sys.argv[1:]))
