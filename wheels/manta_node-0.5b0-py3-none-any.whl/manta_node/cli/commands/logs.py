"""Node logs command implementation."""

import argparse
import time
from pathlib import Path
from typing import List

from rich.console import Console

console = Console()


def print_error(message: str):
    """Print error message in red."""
    console.print(f"[red]Error: {message}[/red]")


def find_log_files():
    """Find available log files."""
    logs_dir = Path.home() / ".manta" / "logs" / "nodes"
    log_files = {}

    if not logs_dir.exists():
        return log_files

    for log_file in logs_dir.glob("*.log"):
        instance_id = log_file.stem
        log_files[instance_id] = log_file

    return log_files


def tail_log_file(log_file: Path, lines: int = 50, follow: bool = False) -> None:
    """Tail a log file, similar to 'tail -f'."""
    try:
        if not log_file.exists():
            print_error(f"Log file not found: {log_file}")
            return

        # Read last N lines if not following
        if not follow:
            with open(log_file, "r") as f:
                # Read all lines and take the last N
                all_lines = f.readlines()
                last_lines = all_lines[-lines:] if len(all_lines) > lines else all_lines
                for line in last_lines:
                    console.print(line.rstrip())
            return

        # Follow mode - continuously read new lines
        console.print(f"Following log file: {log_file}")
        console.print("Press Ctrl+C to stop")
        console.print("-" * 60)

        with open(log_file, "r") as f:
            # First, show last N lines
            all_lines = f.readlines()
            last_lines = all_lines[-lines:] if len(all_lines) > lines else all_lines
            for line in last_lines:
                console.print(line.rstrip())

            # Then follow new lines
            while True:
                line = f.readline()
                if line:
                    console.print(line.rstrip())
                else:
                    time.sleep(0.1)

    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped following log file[/yellow]")
    except Exception as e:
        print_error(f"Error reading log file: {e}")


def logs_command(args: List[str]) -> int:
    """Handle node logs command.

    Args:
        args: Command line arguments

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    parser = argparse.ArgumentParser(
        prog="manta_node logs", description="View node logs"
    )
    parser.add_argument(
        "instance", nargs="?", help="Instance ID or name to show logs for"
    )
    parser.add_argument(
        "--follow", "-f", action="store_true", help="Follow log output (like tail -f)"
    )
    parser.add_argument(
        "--lines",
        "-n",
        type=int,
        default=50,
        help="Number of lines to show (default: 50)",
    )
    parser.add_argument("--list", action="store_true", help="List available log files")

    try:
        parsed_args = parser.parse_args(args)
    except SystemExit:
        return 1

    log_files = find_log_files()

    if parsed_args.list:
        if not log_files:
            console.print("No log files found.")
            console.print("")
            console.print("Log files are created when nodes are started.")
            console.print("Start a node with: manta_node start")
        else:
            console.print("Available log files:")
            for instance_id, log_file in log_files.items():
                size_mb = log_file.stat().st_size / (1024 * 1024)
                console.print(f"  - {instance_id} ({size_mb:.1f} MB) - {log_file}")
        return 0

    if not parsed_args.instance:
        if not log_files:
            print_error("No log files found and no instance specified")
            console.print("")
            console.print("Available options:")
            console.print("  - Start a node: manta_node start")
            console.print("  - List log files: manta_node logs --list")
            return 1

        if len(log_files) == 1:
            # Only one log file, use it
            instance_id, log_file = next(iter(log_files.items()))
            console.print(f"Using log file for instance: {instance_id}")
        else:
            # Multiple log files, ask user to specify
            print_error("Multiple log files found. Please specify an instance:")
            for instance_id in log_files.keys():
                console.print(f"  - {instance_id}")
            return 1
    else:
        instance_name = parsed_args.instance

        # Find matching log file
        log_file = None
        for instance_id, file_path in log_files.items():
            if instance_id == instance_name or instance_id.startswith(instance_name):
                log_file = file_path
                break

        if not log_file:
            print_error(f"No log file found for instance '{instance_name}'")
            if log_files:
                console.print("Available log files:")
                for instance_id in log_files.keys():
                    console.print(f"  - {instance_id}")
            return 1

    # Show logs
    tail_log_file(log_file, parsed_args.lines, parsed_args.follow)
    return 0


if __name__ == "__main__":
    import sys

    sys.exit(logs_command(sys.argv[1:]))
