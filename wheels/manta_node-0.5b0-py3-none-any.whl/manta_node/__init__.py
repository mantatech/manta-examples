import importlib.metadata

__version__ = importlib.metadata.version(str(__package__))

from .node_orchestrator import Node as Node  # Explicit re-export
