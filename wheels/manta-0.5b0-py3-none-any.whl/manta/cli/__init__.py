"""CLI functionality for manta-sdk."""
