"""Simplified component detection for Manta CLI.

This module provides simple detection for external Manta components
that are not part of manta-sdk itself.
"""

import importlib
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ComponentInfo:
    """Information about a detected external Manta component."""

    name: str
    version: str
    installed: bool
    capabilities: List[str] = None

    def __post_init__(self):
        # Initialize capabilities if not provided
        if self.capabilities is None:
            self.capabilities = []


class ComponentDetector:
    """Detects external Manta components (node, admin)."""

    def __init__(self):
        self._components: Dict[str, ComponentInfo] = {}
        self._refresh_detection()

    def _refresh_detection(self) -> None:
        """Refresh component detection cache."""
        self._components.clear()

        # Only detect external components
        self._detect_node()

    def _detect_node(self) -> None:
        """Detect manta-node component."""
        try:
            manta_node = importlib.import_module("manta_node")
            version = getattr(manta_node, "__version__", "unknown")

            self._components["node"] = ComponentInfo(
                name="manta-node",
                version=version,
                installed=True,
                capabilities=["start", "stop", "status", "config", "logs", "cluster"],
            )

            logger.debug(f"Detected manta-node v{version}")

        except (ImportError, AttributeError) as e:
            self._components["node"] = ComponentInfo(
                name="manta-node", version="not-installed", installed=False
            )
            logger.debug(f"manta-node not detected: {e}")

    def is_installed(self, component: str) -> bool:
        """Check if a component is installed."""
        return self._components.get(component, ComponentInfo("", "", False)).installed

    def get_component_info(self, component: str) -> Optional[ComponentInfo]:
        """Get information about a component."""
        return self._components.get(component)

    def get_installed_components(self) -> List[ComponentInfo]:
        """Get list of all installed components."""
        return [comp for comp in self._components.values() if comp.installed]

    def get_missing_components(self) -> List[ComponentInfo]:
        """Get list of missing components."""
        return [comp for comp in self._components.values() if not comp.installed]

    def get_installation_command(self, component: str) -> str:
        """Get pip installation command for a component."""
        component_names = {"node": "manta-node"}

        package_name = component_names.get(component, component)
        return f"pip install {package_name}"

    def refresh(self) -> None:
        """Refresh component detection."""
        self._refresh_detection()

    def list_components(self) -> List[str]:
        """Get list of all component names."""
        return list(self._components.keys())

    def list_installed_components(self) -> List[str]:
        """Get list of installed component names."""
        return [name for name, comp in self._components.items() if comp.installed]

    def get_status_summary(self) -> Dict[str, Any]:
        """Get a summary of component detection status."""
        installed_count = len(self.get_installed_components())
        total_count = len(self._components)

        return {
            "installed": [comp.name for comp in self.get_installed_components()],
            "missing": [comp.name for comp in self.get_missing_components()],
            "total_components": total_count,
            "installation_coverage": (
                installed_count / total_count if total_count > 0 else 0.0
            ),
        }
