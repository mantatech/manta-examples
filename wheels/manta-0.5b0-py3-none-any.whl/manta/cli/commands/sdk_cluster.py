"""SDK cluster information and management commands."""

from rich.panel import Panel
from rich.table import Table

from .base_handler import BaseSDKHandler
from ..utils import (
    enum_to_string,
    timestamp_to_string,
    extract_platform_type,
    NODE_STATUS_MAP,
    CLUSTER_STATUS_MAP,
)


class SDKClusterHandler(BaseSDKHandler):
    """Handle cluster-related SDK commands."""

    def add_subparsers(self, parent_parser):
        """Add cluster command subparsers."""
        self.parser = parent_parser  # Store parser reference
        subparsers = parent_parser.add_subparsers(
            dest="cluster_command", help="Cluster commands"
        )

        # List clusters command
        list_parser = subparsers.add_parser("list", help="List available clusters")

        # Show cluster command
        show_parser = subparsers.add_parser(
            "show", help="Show detailed cluster information"
        )
        show_parser.add_argument("cluster_id", help="Cluster ID to show")

        # Get cluster nodes command
        nodes_parser = subparsers.add_parser("nodes", help="List nodes in cluster")
        nodes_parser.add_argument("cluster_id", help="Cluster ID to show nodes for")

        # Add common arguments to all subcommands
        for parser in [list_parser, show_parser, nodes_parser]:
            parser.add_argument("--profile", help="Use specific profile")
            parser.add_argument(
                "--debug", action="store_true", help="Enable debug output"
            )

    def handle(self, args) -> int:
        """Handle cluster commands."""
        # Enable debug if requested
        if getattr(args, "debug", False):
            self.enable_debug(True)

        if not args.cluster_command:
            if hasattr(self, "parser"):
                self.parser.print_help()
            return 0  # Return 0 for help display

        if args.cluster_command == "list":
            return self.list_clusters()
        elif args.cluster_command == "show":
            return self.show_cluster(args.cluster_id)
        elif args.cluster_command == "nodes":
            return self.show_cluster_nodes(args.cluster_id)
        else:
            self.print_error(f"Unknown cluster command: {args.cluster_command}")
            return 1

    def list_clusters(self) -> int:
        """List available clusters."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                clusters = await api.stream_and_fetch_clusters()
                return clusters

            clusters = self._run_with_progress(run, "Fetching clusters...")

            # Check if the operation failed
            if clusters is None:
                return 1

            # Display clusters
            if not clusters:
                self.print("No clusters found.")
                return 0

            # Always use console (it's always available in SDK context)
            table = Table(title="Available Clusters")
            table.add_column("Cluster ID", style="cyan")
            table.add_column("Name", style="blue")
            table.add_column("Status", style="green")
            table.add_column("Nodes", style="magenta")

            for cluster in clusters:
                status = enum_to_string(cluster.get("status", 0), CLUSTER_STATUS_MAP)

                table.add_row(
                    cluster.get("cluster_id", "Unknown"),
                    cluster.get("name", "Unknown"),
                    status,
                    str(cluster.get("node_count", 0)),
                )

            self.console.print(table)

            return 0

        except KeyboardInterrupt:
            return 130  # Standard exit code for SIGINT
        except Exception:
            # Error already printed by base handler
            return 1

    def show_cluster(self, cluster_id: str) -> int:
        """Show detailed cluster information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.get_cluster(cluster_id)

            cluster = self._run_with_progress(run, f"Fetching cluster {cluster_id}...")

            # Check if the operation failed
            if cluster is None:
                return 1

            # Extract and format fields
            status = enum_to_string(cluster.get("status", 0), CLUSTER_STATUS_MAP)
            created = timestamp_to_string(
                cluster.get("created_at") or cluster.get("creation_date")
            )

            # Display cluster details
            panel = Panel.fit(
                f"[cyan]Cluster ID:[/cyan] {cluster.get('cluster_id', 'Unknown')}\n"
                f"[cyan]Name:[/cyan] {cluster.get('name', 'Unknown')}\n"
                f"[cyan]Status:[/cyan] {status}\n"
                f"[cyan]Node Count:[/cyan] {cluster.get('node_count', 0)}\n"
                f"[cyan]Created:[/cyan] {created}",
                title=f"Cluster: {cluster_id}",
            )
            self.console.print(panel)

            return 0

        except KeyboardInterrupt:
            return 130
        except Exception:
            # Error already printed by base handler
            return 1

    def show_cluster_nodes(self, cluster_id: str) -> int:
        """Show nodes in a cluster."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                return await api.stream_and_fetch_nodes(cluster_id)

            nodes = self._run_with_progress(
                run, f"Fetching nodes for cluster {cluster_id}..."
            )

            # Check if the operation failed
            if nodes is None:
                return 1

            if not nodes:
                self.print("No nodes found in this cluster.")
                return 0

            # Create and display nodes table
            table = Table(title=f"Nodes in Cluster: {cluster_id}")
            table.add_column("Node ID", style="cyan")
            table.add_column("Status", style="green")
            table.add_column("Type", style="blue")
            table.add_column("Last Seen", style="yellow")

            for node in nodes:
                # Use converter functions for consistent parsing
                status = enum_to_string(node.get("node_status", 0), NODE_STATUS_MAP)

                node_type = extract_platform_type(node.get("platform_info"))

                last_seen = timestamp_to_string(
                    node.get("updated_at") or node.get("created_at")
                )

                table.add_row(
                    node.get("node_id", "Unknown"), status, node_type, last_seen
                )

            self.console.print(table)

            return 0

        except KeyboardInterrupt:
            return 130
        except Exception:
            # Error already printed by base handler
            return 1
