"""SDK user and authentication commands."""

import asyncio

from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from .base_handler import BaseSDKHandler


class SDKUserHandler(BaseSDKHandler):
    """Handle user-related SDK commands."""

    def add_subparsers(self, parent_parser):
        """Add user command subparsers."""
        subparsers = parent_parser.add_subparsers(
            dest="user_command", help="User commands"
        )

        # User status command
        status_parser = subparsers.add_parser(
            "status", help="Check user service status"
        )

        # Get user info command
        get_parser = subparsers.add_parser(
            "get-user", help="Get current user information"
        )

        # List clusters command
        list_clusters_parser = subparsers.add_parser(
            "list-clusters", help="List available clusters"
        )

        # List swarms command
        list_swarms_parser = subparsers.add_parser(
            "list-swarms", help="List user swarms"
        )
        list_swarms_parser.add_argument("--cluster-id", help="Filter by cluster ID")

        # Add profile override to all subcommands
        for parser in [
            status_parser,
            get_parser,
            list_clusters_parser,
            list_swarms_parser,
        ]:
            parser.add_argument("--profile", help="Use specific profile")

    def handle(self, args) -> int:
        """Handle user commands."""
        if not args.user_command:
            self.print_error("User command required")
            return 1

        if args.user_command == "status":
            return self.check_user_service_status()
        elif args.user_command == "get-user":
            return self.get_user_info()
        elif args.user_command == "list-clusters":
            return self.list_clusters()
        elif args.user_command == "list-swarms":
            return self.list_swarms(getattr(args, "cluster_id", None))
        else:
            self.print_error(f"Unknown user command: {args.user_command}")
            return 1

    def check_user_service_status(self) -> int:
        """Check user service status."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                # Try to get user info to test connection
                user_info = await api.get_user()
                return user_info is not None

            status = self._run_with_progress(run, "Checking user service status...")

            if status:
                self.print_success("User service is accessible")
                return 0
            else:
                self.print_error("User service is not accessible")
                return 1

        except Exception as e:
            self.print_error(f"User service check failed: {e}")
            return 1

    def get_user_info(self) -> int:
        """Get current user information."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                user_info = await api.get_user()
                return user_info

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            ) as progress:
                task = progress.add_task("Getting user information...", total=None)
                user_info = asyncio.run(run())
                progress.update(task, completed=True)

            # Display user info
            panel = Panel.fit(
                f"[cyan]User ID:[/cyan] {user_info.get('user_id', 'Unknown')}\n"
                f"[cyan]Username:[/cyan] {user_info.get('username', 'Unknown')}\n"
                f"[cyan]Email:[/cyan] {user_info.get('email', 'Unknown')}\n"
                f"[cyan]Roles:[/cyan] {', '.join(user_info.get('roles', []))}",
                title="User Information",
            )
            self.console.print(panel)
            return 0

        except Exception as e:
            self.print_error(f"Failed to get user information: {e}")
            return 1

    def list_clusters(self) -> int:
        """List available clusters."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                clusters = await api.stream_and_fetch_clusters()
                return clusters

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            ) as progress:
                task = progress.add_task("Fetching clusters...", total=None)
                clusters = asyncio.run(run())
                progress.update(task, completed=True)

            # Display clusters
            if not clusters:
                self.print("No clusters found.")
                return 0

            table = Table(title="Available Clusters")
            table.add_column("Cluster ID", style="cyan")
            table.add_column("Name", style="blue")
            table.add_column("Status", style="green")
            table.add_column("Nodes", style="magenta")

            for cluster in clusters:
                # UserAPI always returns dictionaries
                cluster_id = cluster.get("cluster_id", "Unknown")
                name = cluster.get("name", "Unknown")
                status = cluster.get("status", "Unknown")
                node_count = str(cluster.get("node_count", 0))

                table.add_row(cluster_id, name, status, node_count)

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to list clusters: {e}")
            return 1

    def list_swarms(self, cluster_id: str = None) -> int:
        """List user swarms, optionally filtered by cluster."""
        api = self._get_user_api()
        if not api:
            return 1

        try:

            async def run():
                # stream_and_fetch_swarms doesn't take cluster_id parameter
                swarms = await api.stream_and_fetch_swarms()
                # Filter by cluster_id if provided (swarms are dicts)
                if cluster_id:
                    swarms = [s for s in swarms if s.get("cluster_id") == cluster_id]
                return swarms

            message = f"Fetching swarms{f' for cluster {cluster_id}' if cluster_id else ''}..."
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            ) as progress:
                task = progress.add_task(message, total=None)
                swarms = asyncio.run(run())
                progress.update(task, completed=True)

            # Display swarms
            if not swarms:
                self.print("No swarms found.")
                return 0

            table = Table(
                title=f"User Swarms{f' (Cluster: {cluster_id})' if cluster_id else ''}"
            )
            table.add_column("Swarm ID", style="cyan")
            table.add_column("Name", style="blue")
            table.add_column("Status", style="green")
            table.add_column("Cluster", style="magenta")
            table.add_column("Created", style="yellow")

            for swarm in swarms:
                table.add_row(
                    swarm.get("swarm_id", "Unknown"),
                    swarm.get("name", "Unknown"),
                    swarm.get("status", "Unknown"),
                    swarm.get("cluster_id", "Unknown"),
                    swarm.get("created_at", "Unknown"),
                )

            self.console.print(table)
            return 0

        except Exception as e:
            self.print_error(f"Failed to list swarms: {e}")
            return 1
