"""SDK configuration management commands matching node config pattern."""

import os
import subprocess

from rich.panel import Panel
from rich.prompt import Confirm, Prompt, IntPrompt
from rich.table import Table

from .base_handler import BaseSDKHandler


class SDKConfigHandler(BaseSDKHandler):
    """Handle configuration-related SDK commands."""

    def add_subparsers(self, parent_parser):
        """Add config command subparsers."""
        self.parser = parent_parser  # Store parser reference
        subparsers = parent_parser.add_subparsers(
            dest="config_command", help="Config commands"
        )

        # Init config command
        init_parser = subparsers.add_parser("init", help="Initialize configuration")
        init_parser.add_argument(
            "--interactive", action="store_true", help="Run interactive setup"
        )
        init_parser.add_argument("--name", help="Configuration name", default="default")
        init_parser.add_argument("--token", help="JWT authentication token")
        init_parser.add_argument("--host", default="localhost", help="Server host")
        init_parser.add_argument("--port", type=int, default=50052, help="Server port")

        # List configs command
        subparsers.add_parser("list", help="List all configurations")

        # Show config command
        show_parser = subparsers.add_parser("show", help="Show configuration")
        show_parser.add_argument(
            "name", nargs="?", help="Configuration name (uses active if not specified)"
        )

        # Use config command (set active)
        use_parser = subparsers.add_parser("use", help="Set active configuration")
        use_parser.add_argument("name", help="Configuration name")

        # Delete config command
        delete_parser = subparsers.add_parser("delete", help="Delete configuration")
        delete_parser.add_argument("name", help="Configuration name")

        # Edit config command
        edit_parser = subparsers.add_parser(
            "edit", help="Edit configuration file in text editor"
        )
        edit_parser.add_argument(
            "name", nargs="?", help="Configuration name (uses active if not specified)"
        )

    def handle(self, args) -> int:
        """Handle config commands."""
        if not args.config_command:
            if hasattr(self, "parser"):
                self.parser.print_help()
            return 0  # Return 0 for help display

        if args.config_command == "init":
            return self.init_config(args)
        elif args.config_command == "list":
            return self.list_configs()
        elif args.config_command == "show":
            return self.show_config(getattr(args, "name", None))
        elif args.config_command == "use":
            return self.use_config(args.name)
        elif args.config_command == "delete":
            return self.delete_config(args.name)
        elif args.config_command == "edit":
            return self.edit_config(getattr(args, "name", None))
        else:
            self.print_error(f"Unknown config command: {args.config_command}")
            return 1

    # Profile methods removed - using simple config approach

    def init_config(self, args) -> int:
        """Initialize configuration system."""
        try:
            config_name = getattr(args, "name", "default")

            # Check if configuration already exists
            config_path = self.config_manager.config_dir / f"{config_name}.toml"
            if config_path.exists():
                overwrite = Confirm.ask(
                    f"Configuration '{config_name}' already exists. Overwrite?",
                    console=self.console,
                    default=False,
                )
                if not overwrite:
                    self.print("[yellow]Configuration creation cancelled[/yellow]")
                    return 1

            # Default to interactive mode if no token provided
            token = getattr(args, "token", None)
            interactive = getattr(args, "interactive", False) or token is None

            if interactive:
                self.console.print(
                    Panel(
                        "[bold cyan]SDK Configuration Setup[/bold cyan]\n\n"
                        "This wizard will help you create a new SDK configuration.\n"
                        "Configuration will be saved in ~/.manta/sdk/",
                        title="manta sdk Configuration",
                        border_style="blue",
                    )
                )

                # Get configuration details
                host = Prompt.ask(
                    "[cyan]Manager host[/cyan]",
                    console=self.console,
                    default="localhost",
                )

                port = IntPrompt.ask(
                    "[cyan]Manager port[/cyan]", console=self.console, default=50052
                )

                token = Prompt.ask(
                    "[cyan]JWT authentication token[/cyan]",
                    password=True,
                    console=self.console,
                )

                if not token:
                    self.print_error("JWT token is required for SDK authentication")
                    return 1

                # Optional: TLS configuration
                use_tls = Confirm.ask(
                    "[cyan]Use TLS connection?[/cyan]",
                    console=self.console,
                    default=False,
                )

                cert_folder = None
                if use_tls:
                    cert_folder = Prompt.ask(
                        "[cyan]Certificate folder path[/cyan]",
                        console=self.console,
                        default="~/.manta/certs",
                    )
            else:
                # Non-interactive mode - use command line arguments
                token = getattr(args, "token", None)
                host = getattr(args, "host", "localhost")
                port = getattr(args, "port", 50052)
                cert_folder = None

            # Create or update configuration
            if config_path.exists():
                # If we got here, user agreed to overwrite
                success = self.config_manager.update_config(
                    name=config_name,
                    token=token,
                    host=host,
                    port=port,
                    cert_folder=cert_folder,
                    description=f"SDK configuration '{config_name}'",
                )
            else:
                success = self.config_manager.create_config(
                    name=config_name,
                    token=token,
                    host=host,
                    port=port,
                    cert_folder=cert_folder,
                    description=f"SDK configuration '{config_name}'",
                )

            if success:
                self.config_manager.set_active_config(config_name)
                self.print_success(
                    f"Configuration '{config_name}' created and activated successfully"
                )
                if not token:
                    self.print("Run 'manta sdk config edit' to add your JWT token")
            else:
                self.print_error("Failed to create configuration")
                return 1

            return 0

        except Exception as e:
            self.print_error(f"Failed to initialize configuration: {e}")
            return 1

    def show_config(self, config_name: str = None) -> int:
        """Show current configuration."""
        try:
            if config_name:
                config = self.config_manager.load_config(config_name)
                if not config:
                    self.print_error(f"Configuration '{config_name}' not found")
                    return 1
                title = f"Configuration: {config_name}"
            else:
                config = self.config_manager.get_active_config()
                active_name = self.config_manager.get_active_config_name()
                if config:
                    title = f"Active Configuration: {active_name}"
                else:
                    self.print_error("No active configuration found")
                    return 1

            config_text = ""
            for key, value in config.__dict__.items():
                if key == "token" and value:
                    # Mask token for security
                    masked_token = value[:8] + "..." if len(value) > 8 else "***"
                    config_text += f"[cyan]{key}:[/cyan] {masked_token}\n"
                else:
                    config_text += f"[cyan]{key}:[/cyan] {value}\n"

            panel = Panel.fit(config_text.strip(), title=title)
            self.console.print(panel)

            return 0

        except Exception as e:
            self.print_error(f"Failed to show configuration: {e}")
            return 1

    def edit_config(self, config_name: str = None) -> int:
        """Edit configuration file in default editor."""
        try:
            if config_name is None:
                config_name = self.config_manager.get_active_config_name()

            config_path = self.config_manager.config_dir / f"{config_name}.toml"
            if not config_path.exists():
                self.print_error(f"Configuration '{config_name}' not found")
                return 1

            # Get default editor
            editor = os.environ.get("EDITOR", "nano")

            # Launch editor
            try:
                subprocess.run([editor, str(config_path)], check=True)
                self.print_success(f"Configuration '{config_name}' edited successfully")
                return 0
            except subprocess.CalledProcessError:
                self.print_error(f"Failed to launch editor: {editor}")
                return 1
            except FileNotFoundError:
                self.print_error(f"Editor not found: {editor}")
                self.print(
                    "Set the EDITOR environment variable to your preferred editor"
                )
                return 1

        except Exception as e:
            self.print_error(f"Failed to edit configuration: {e}")
            return 1

    def list_configs(self) -> int:
        """List all configurations."""
        try:
            configs = self.config_manager.list_configs()
            active_config_name = self.config_manager.get_active_config_name()

            if not configs:
                self.print("No configurations found.")
                self.print("Run 'manta sdk config init --interactive' to create one.")
                return 0

            table = Table(title="SDK Configurations")
            table.add_column("Configuration Name", style="cyan")
            table.add_column("Status", style="green")
            table.add_column("Host", style="blue")
            table.add_column("Port", style="magenta")
            table.add_column("Description", style="white")

            for config_name in configs:
                config = self.config_manager.load_config(config_name)
                status = "Active" if config_name == active_config_name else ""

                if config:
                    table.add_row(
                        config_name,
                        status,
                        config.host,
                        str(config.port),
                        config.description or "",
                    )
                else:
                    table.add_row(
                        config_name, status, "Error", "Error", "Failed to load"
                    )

            self.console.print(table)

            return 0

        except Exception as e:
            self.print_error(f"Failed to list configurations: {e}")
            return 1

    def use_config(self, config_name: str) -> int:
        """Set the active configuration."""
        try:
            success = self.config_manager.set_active_config(config_name)
            if success:
                self.print_success(f"Active configuration set to '{config_name}'")
                return 0
            else:
                return 1

        except Exception as e:
            self.print_error(f"Failed to set active configuration: {e}")
            return 1

    def delete_config(self, config_name: str) -> int:
        """Delete a configuration."""
        try:
            if config_name == "default":
                self.print_error("Cannot delete default configuration")
                return 1

            confirm = Confirm.ask(
                f"Are you sure you want to delete configuration '{config_name}'?",
                console=self.console,
            )
            if not confirm:
                self.print("Operation cancelled.")
                return 0

            success = self.config_manager.delete_config(config_name)
            if success:
                self.print_success(
                    f"Configuration '{config_name}' deleted successfully"
                )
                return 0
            else:
                return 1

        except Exception as e:
            self.print_error(f"Failed to delete configuration: {e}")
            return 1
