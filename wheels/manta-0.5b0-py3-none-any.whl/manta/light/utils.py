import io
from typing import Union

import numpy as np

from ..common.conversions import bytes_to_dict, dict_to_bytes

__all__ = [
    "dict_to_bytes",
    "bytes_to_dict",
    "numpy_to_bytes",
    "bytes_to_numpy",
    "torchmodel_to_bytes",
    "bytes_to_torchmodel",
]


def numpy_to_bytes(data: Union[np.ndarray, list, dict]) -> Union[bytes, dict]:
    """
    Recursive function which converts a numpy array or iterator with numpy arrays to bytes

    Parameters
    ----------
    data : np.array
        The numpy array to convert

    Returns
    -------
    bytes
        The bytes representation of the numpy array

    Examples
    --------

    * From :code:`np.array`

    >>> import numpy as np
    >>> from manta_light.utils import bytes_to_numpy, numpy_to_bytes
    >>> np_array = np.array([1, 2, 3])
    >>> numpy_to_bytes(np_array)

    * From :code:`Dict[str, np.array]`

    >>> import numpy as np
    >>> from manta_light.utils import bytes_to_numpy, numpy_to_bytes
    >>> dict_np_array = {"key1": np.array([1, 2, 3]), "key2": np.array([4, 5, 6])}
    >>> numpy_to_bytes(dict_np_array)

    * From :code:`Dict[str, list]`

    >>> import numpy as np
    >>> from manta_light.utils import bytes_to_numpy, numpy_to_bytes
    >>> dict_list = {"key1": [1, 2, 3], "key2": [4, 5, 6]}
    >>> numpy_to_bytes(dict_list)

    * From :code:`List[np.array]`

    >>> import numpy as np
    >>> from manta_light.utils import bytes_to_numpy, numpy_to_bytes
    >>> list_np_array = [np.array([1, 2, 3]), np.array([4, 5, 6])]
    >>> numpy_to_bytes(list_np_array)
    """
    import numpy as np

    if isinstance(data, np.ndarray) or isinstance(data, list):
        buffer = io.BytesIO()
        np.save(buffer, data)
        return buffer.getvalue()
    elif isinstance(data, dict):
        return {key: numpy_to_bytes(value) for key, value in data.items()}
    else:
        raise ValueError(f"Unsupported type: {type(data)}")


def bytes_to_numpy(b: Union[bytes, dict]) -> Union[np.ndarray, dict]:
    """
    Convert bytes to a numpy array

    Parameters
    ----------
    b : bytes
        The bytes to convert

    Returns
    -------
    np.array
        The numpy array representation of the bytes

    Examples
    --------

    * From :code:`np.array`

    >>> import numpy as np
    >>> from manta_light.utils import bytes_to_numpy, numpy_to_bytes
    >>> np_array = np.array([1, 2, 3])
    >>> np_bytes = numpy_to_bytes(np_array)
    >>> bytes_to_numpy(np_bytes)

    * From :code:`Dict[str, np.array]`

    >>> import numpy as np
    >>> from manta_light.utils import bytes_to_numpy, numpy_to_bytes
    >>> dict_np_array = {"key1": np.array([1, 2, 3]), "key2": np.array([4, 5, 6])}
    >>> np_bytes = numpy_to_bytes(dict_np_array)
    >>> bytes_to_numpy(np_bytes)

    * From :code:`Dict[str, list]`

    >>> import numpy as np
    >>> from manta_light.utils import bytes_to_numpy, numpy_to_bytes
    >>> dict_list = {"key1": [1, 2, 3], "key2": [4, 5, 6]}
    >>> np_bytes = numpy_to_bytes(dict_list)
    >>> bytes_to_numpy(np_bytes)

    * From :code:`List[np.array]`

    >>> import numpy as np
    >>> from manta_light.utils import bytes_to_numpy, numpy_to_bytes
    >>> list_np_array = [np.array([1, 2, 3]), np.array([4, 5, 6])]
    >>> np_bytes = numpy_to_bytes(list_np_array)
    >>> bytes_to_numpy(np_bytes)
    """
    import numpy as np

    if isinstance(b, bytes):
        buffer = io.BytesIO(b)
        return np.load(buffer)
    elif isinstance(b, dict):
        return {key: bytes_to_numpy(value) for key, value in b.items()}
    else:
        raise ValueError(f"Unsupported type: {type(b)}")


def torchmodel_to_bytes(model: "torch.nn.Module") -> bytes:  # type: ignore # noqa: F821
    """
    Transform a torch model into bytes

    Parameters
    ----------
    model : "torch.nn.Module"
        Torch model

    Returns
    -------
    bytes
        Bytes from the torch model

    Examples
    --------

    >>> from torch.nn import Linear, ReLU, Sequential
    >>> from manta_light.utils import bytes_to_torchmodel, torchmodel_to_bytes
    >>> torch_model = Sequential(
    ...     Linear(3, 2), ReLU(), Linear(2, 1), ReLU(), Linear(1, 1), ReLU()
    ... )
    >>> torchmodel_to_bytes(torch_model)
    """
    import torch

    buffer = io.BytesIO()
    torch.save(model, buffer)
    return buffer.getvalue()


def bytes_to_torchmodel(b: bytes) -> "torch.nn.Module":  # type: ignore # noqa: F821
    """
    Transform bytes to torch model

    Parameters
    ----------
    b : bytes
        Bytes from a torch model

    Returns
    -------
    "torch.nn.Module"
        Torch model

    Examples
    --------

    >>> from torch.nn import Linear, ReLU, Sequential
    >>> from manta_light.utils import bytes_to_torchmodel, torchmodel_to_bytes
    >>> torch_model = Sequential(
    ...     Linear(3, 2), ReLU(), Linear(2, 1), ReLU(), Linear(1, 1), ReLU()
    ... )
    >>> model_bytes = torchmodel_to_bytes(torch_model)
    >>> bytes_to_torchmodel(model_bytes)

    Security Note
    -------------
    This function uses torch.load with weights_only=False which can execute
    arbitrary code. Only use with trusted model sources. In the Manta platform,
    models should only come from authenticated users and trusted containers.
    """
    import pickle
    import warnings

    import torch

    buffer = io.BytesIO(b)

    # Try to load with weights_only=True first (safer)
    try:
        return torch.load(buffer, weights_only=True)
    except (RuntimeError, TypeError, pickle.UnpicklingError):
        # If that fails, fallback to full model loading with a warning
        # This is necessary for complex models with custom layers
        buffer.seek(0)  # Reset buffer position
        warnings.warn(
            "Loading PyTorch model with weights_only=False. "
            "This can execute arbitrary code. Ensure the model source is trusted.",
            UserWarning,
            stacklevel=2,
        )
        return torch.load(buffer, weights_only=False)
