import io
import logging
import os
from typing import AsyncIterable, Dict, Optional

from ..clients.world_client import WorldClient
from ..common.build import LightResult, LightResultQuery, ResultMethod
from ..common.const import CHUNK_SIZE
from ..common.conversions import ID
from ..common.event_loop import EventLoopManager
from .utils import bytes_to_dict, dict_to_bytes

__all__ = ["Results"]


class Results:
    """
    Class for accessing results from the shared database or
    adding results into the shared database

    Parameters
    ----------
    host : str
        Manager host
    port : int
        Manager port
    swarm_id : ID
        Swarm ID
    task_id : ID
        Task ID
    chunk_size : int
        Chunk size
    """

    __slots__ = [
        "world_client",
        "swarm_id",
        "task_id",
        "logger",
        "chunk_size",
        "loop_manager",
    ]

    def __init__(
        self,
        world_client: Optional[WorldClient] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        swarm_id: Optional[ID] = None,
        task_id: Optional[ID] = None,
        chunk_size: int = CHUNK_SIZE,
    ):
        # Retrieve env variables for RPC host and port
        if world_client is None:
            self.world_client = WorldClient(
                host=host or os.getenv("RPC_HOST", "host.docker.internal"),
                port=int(port or os.getenv("RPC_PORT", 50051)),
            )
        else:
            self.world_client = world_client

        self.task_id: ID = task_id or ID(os.getenv("TASK_ID"))
        self.swarm_id: ID = swarm_id or ID(os.getenv("SWARM_ID"))

        self.chunk_size = chunk_size
        self.logger = logging.getLogger(__name__)
        self.loop_manager = EventLoopManager.get_instance()

    def select(self, tag: str, size: int = -1, method: ResultMethod = ResultMethod.ALL):
        """
        Get the results of a Task

        Parameters
        ----------
        tag : str
            The tag of the result to get
        size : int, optional
            The number of results to get
        method : ResultMethod, optional
            Method to use to select the results

        Returns
        -------
        dict
            The response from the world service

        Examples
        --------

        Inside a :class:`Task <manta_light.task.Task>` class, you can
        select results stored in the Manager database from the attribute
        :code:`self.world` automatically created by
        :class:`Task <manta_light.task.Task>`:

        >>> params = self.world.results.select("model_params")
        """
        return self.loop_manager.run_coroutine(self.async_select(tag, size, method))

    def add(self, tag: str, result: dict):
        """
        Set a result of a task

        Parameters
        ----------
        tag : str
            The tag of the result to set
        result : dict
            The result to set

        Examples
        --------

        Inside a :class:`Task <manta_light.task.Task>` class, you can
        add results to be stored in the Manager database from the
        attribute :code:`self.world` automatically created by
        :class:`Task <manta_light.task.Task>`:

        >>> self.world.results.add("metrics", metrics)
        """
        self.loop_manager.run_coroutine(self.async_add(tag, result))

    def __str__(self):  # pragma: no cover
        return f"Results(host={self.world_client.host}, port={self.world_client.port}, swarm_id={self.swarm_id}, task_id={self.task_id})"

    def __repr__(self):  # pragma: no cover
        return str(self)

    # Asynchronous methods

    async def async_select(self, tag: str, size: int, method: ResultMethod) -> dict:
        """
        Get the results of tasks

        Parameters
        ----------
        tag : str
            Tag of the result to get
        size : int
            Number of results to get
        method : str
            The method to use to select the results

        Returns
        -------
        dict
            Response from the world service

        Examples
        --------

        Same as :meth:`select <manta_light.results.Results.select>`
        but asynchronous:

        >>> params = await self.world.results.async_select("model_params")
        """
        # Initialize a buffer to accumulate chunks
        buffer_dict: Dict[str, io.BytesIO] = {}

        # Iterate over the chunks
        async for chunk in self.world_client.get_task_result(
            LightResultQuery(
                task_id=self.task_id.oid,
                swarm_id=self.swarm_id.oid,
                tag=tag,
                size=size,
                method=method,
            )
        ):
            node_id = ID(chunk.node_id).xid
            if node_id not in buffer_dict:
                buffer_dict[node_id] = io.BytesIO()
            buffer_dict[node_id].write(chunk.data)

        self.logger.info("Results received")
        return {
            node_id: bytes_to_dict(buffer.getvalue())
            for node_id, buffer in buffer_dict.items()
        }

    async def chunked_light_result(
        self, request: LightResult
    ) -> AsyncIterable[LightResult]:
        """
        This function chunks the data into smaller pieces and yields LightResult messages.

        Parameters
        ----------
        request : LightResult
            Request

        Returns
        -------
        AsyncIterable[LightResult]
            AsyncIterable of LightResult messages
        """
        data_stream = io.BytesIO(request.data)
        while chunk := data_stream.read(self.chunk_size):
            yield LightResult(
                task_id=request.task_id,
                swarm_id=request.swarm_id,
                tag=request.tag,
                data=chunk,
            )

    async def async_add(self, tag: str, result: dict):
        """
        Set a result of a task

        Parameters
        ----------
        tag : str
            Tag of the result to set
        result : dict
            Result to add

        Examples
        --------

        Same as :meth:`select <manta_light.results.Results.add>`
        but asynchronous:

        >>> await self.world.results.async_add("metrics", metrics)
        """
        self.logger.info(f"Setting result for tag: {tag}")
        await self.world_client.add_task_result(
            self.chunked_light_result(
                LightResult(
                    task_id=self.task_id.oid,
                    swarm_id=self.swarm_id.oid,
                    tag=tag,
                    data=dict_to_bytes(result),
                )
            )
        )
        self.logger.info("Set result response")
