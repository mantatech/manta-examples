import logging
import logging.config

FORMAT = (
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)"
)

MANTA_LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {"format": FORMAT},
    },
    "filters": {
        "warnings_and_below": {
            "()": "manta.common.logging_config.filter_maker",
            "level": "WARNING",
        },
        "manta_filter": {
            "()": "manta.common.logging_config.filter_manta",
            "level": "INFO",
        },
    },
    "handlers": {
        "default": {
            "class": "logging.StreamHandler",
            "level": "INFO",
            "formatter": "standard",
        },
    },
    "root": {
        "level": "DEBUG",
        "handlers": ["default"],
    },
}


def configure_logging():
    logging.config.dictConfig(MANTA_LOGGING_CONFIG)
