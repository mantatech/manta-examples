from functools import reduce
from operator import ior, itemgetter
from typing import Any, Dict, List, Tuple, Union

__all__ = ["Results"]


def is_int(obj: Any) -> bool:
    """
    Check if the :code:`obj` is an integer

    Parameters
    ----------
    obj : Any
        Object input

    Returns
    -------
    bool
        Is an integer
    """
    return isinstance(obj, int)


class Schema:
    """
    This class represents the rows and columns of values from
    results.

    Parameters
    ----------
    values : List[Dict[str, Dict[str, Any]]]
        List of values from results

    Attributes
    ----------
    unordered_rows : Set[str]
        Node IDs
    unordered_columns : Set[str]
        Tags
    """

    __slots__ = ["unordered_rows", "unordered_columns"]

    def __init__(self, values: List[Dict[str, Dict[str, Any]]]):
        def ior_dict(dictn, next_item):
            return ior(dictn, next_item.keys())

        def reduce_ior_dict(dictn, next_item):
            return reduce(ior_dict, next_item.values(), dictn)

        self.unordered_rows = reduce(ior_dict, values, set())
        self.unordered_columns = reduce(reduce_ior_dict, values, set())

    def parse(self, values: Dict[str, Dict[str, Any]]) -> List[List[Any]]:
        """
        Order results based on the schema values

        Parameters
        ----------
        values : Dict[str, Dict[str, Any]]
            Input values for one iteration

        Returns
        -------
        List[List[Any]]
            Ordered values
        """
        return [
            [values.get(row, {}).get(column, None) for column in self.columns]
            for row in self.rows
        ]

    @property
    def rows(self) -> List[str]:
        """
        Convenient to have sorted rows

        Returns
        -------
        List[str]
            Sorted rows
        """
        return sorted(self.unordered_rows)

    @property
    def columns(self) -> List[str]:
        """
        Convenient to have sorted columns

        Returns
        -------
        List[str]
            Sorted columns
        """
        return sorted(self.unordered_columns)

    def __str__(self):  # pragma: no cover
        return f"Schema(rows={self.rows}, columns={self.columns})"

    def __repr__(self):  # pragma: no cover
        return str(self)


class Results:
    """
    This class organizes the results gotten from the database
    for ergonomic manipulations

    Parameters
    ----------
    values : List[Dict[str, Dict[str, Any]]]
        Values organized by the class

    Examples
    --------

    >>> values = [
    ...     {
    ...         "node_c": {"accuracy": 0.8, "params": [0.80, 0.84]},
    ...         "node_a": {"accuracy": 0.7, "params": [0.61, 0.72]},
    ...         "node_b": {"accuracy": 0.1, "params": [0.23, 0.37]},
    ...     },
    ...     {
    ...         "node_c": {"accuracy": 0.1, "params": [0.53, 0.68]},
    ...         "node_a": {"accuracy": 0.4, "params": [0.12, 0.90]},
    ...         "node_b": {"accuracy": 0.9, "params": [0.11, 0.79]},
    ...     },
    ... ]
    >>> results = Results(values)
    >>> results.schema.rows
    ["node_a", "node_b", "node_c"]
    >>> results.schema.columns
    ["accuracy", "params"]
    >>> results.iterations
    [0, 1]
    >>> results(0)
    [[0.7, [0.61, 0.72]], [0.1, [0.23, 0.37]], [0.8, [0.8, 0.84]]]
    >>> results("node_a")
    [[0.7, [0.61, 0.72]], [0.4, [0.12, 0.9]]]
    >>> results("accuracy")
    [[0.7, 0.1, 0.8], [0.4, 0.9, 0.1]]
    >>> results([0], "accuracy")
    [[0.7, 0.1, 0.8]]
    """

    __slots__ = ["schema", "values"]

    def __init__(self, values: List[Dict[str, Dict[str, Any]]]):
        self.schema = Schema(values)
        self.values = list(map(self.schema.parse, values))

    @property
    def iterations(self) -> List[int]:
        """
        Return list of iterations

        Returns
        -------
        List[int]
            Iterations
        """
        return list(range(len(self.values)))

    def sort_queries(
        self,
        indices: Tuple[List[int], List[int], List[int]],
        query: Union[int, List[int], str],
    ) -> Tuple[List[int], List[int], List[int]]:
        """
        Convert the query into index and add it to its corresponding
        list of indices

        Parameters
        ----------
        indices : Tuple[List[int], List[int], List[int]],
            Iteration indices, row indices, column indices
        query : Union[int, List[int], str]
            Query

        Returns
        -------
        Tuple[List[int], List[int], List[int]]
            Updated iteration indices, row indices, column indices

        Raises
        ------
        TypeError
            When query input is a list which not contains only integers
        KeyError
            When query can not be found in keys defined by :code:`self.values`
        """
        it_indices, row_indices, column_indices = indices
        if isinstance(query, int):
            it_indices.append(query)
        elif isinstance(query, list):
            if not all(map(is_int, query)):
                args = ", ".join(map(repr, query))
                raise TypeError(
                    "Only integers in list queries are supported. "
                    f"Maybe try `results(..., {args})`."
                )
            it_indices.extend(query)
        elif isinstance(query, str):
            if query in self.schema.unordered_rows:
                row_indices.append(self.schema.rows.index(query))
            elif query in self.schema.unordered_columns:
                column_indices.append(self.schema.columns.index(query))
            else:
                raise KeyError(f"Item {query!r} not found in schema.")
        return (it_indices, row_indices, column_indices)

    def __call__(self, *query: Union[str, int, List[int]]) -> list:
        """
        Return a list filtered by queries and ordered by :code:`self.schema`

        Parameters
        ----------
        *query : Union[str, int, List[int]]
            It can be an iteration, a list of iterations, a tag or a node ID

        Returns
        -------
        list
            Filtered list of results
        """
        if not query:
            return self.values
        it_indices, row_indices, column_indices = reduce(
            self.sort_queries, query, ([], [], [])
        )
        values = itemgetter(*it_indices)(self.values) if it_indices else self.values
        values = [values] if it_indices and (row_indices or column_indices) else values
        values = map(itemgetter(*row_indices), values) if row_indices else values
        values = [values] if row_indices and column_indices else values
        values = (
            (list(map(itemgetter(*column_indices), matrix)) for matrix in values)
            if column_indices
            else values
        )
        return list(values)

    def __str__(self):  # pragma: no cover
        return (
            f"Results(len(iterations)={len(self.iterations)},"
            f" len(nodes)={len(self.schema.unordered_rows)}, "
            f"len(tags)={len(self.schema.unordered_columns)})"
        )

    def __repr__(self):  # pragma: no cover
        return str(self)
