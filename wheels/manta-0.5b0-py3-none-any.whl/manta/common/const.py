from datetime import timedelta

# Maximum chunk size : see https://protobuf.dev/programming-guides/proto3
# bytes may contain any arbitrary sequence of bytes no longer than 2^32
CHUNK_SIZE = 2**32

ERROR_LOGS_KWS = [
    "ERROR",
    "Error",
    "Traceback",
    "Exception",
    "Failed",
    "FAIL",
]

MAX_TIMEDELTA = timedelta(seconds=30)

# Maximum of BSON document : 16 MB
# Source : https://www.mongodb.com/docs/v6.2/reference/limits/
# We add a coefficient of security : 0.9
MAX_CHUNK_SIZE = int((2**24) * 0.9)
